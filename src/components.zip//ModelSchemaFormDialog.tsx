import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Alert, AlertDescription } from './ui/alert';
import { AlertCircle, FileJson, Plus, Save } from 'lucide-react';
import { ModelSchema, createModelSchema, updateModelSchema } from '../lib/api';
import { toast } from 'sonner@2.0.3';

interface ModelSchemaFormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
  schema?: ModelSchema; // If provided, we're editing
}

export function ModelSchemaFormDialog({ 
  open, 
  onOpenChange, 
  onSuccess,
  schema 
}: ModelSchemaFormDialogProps) {
  const isEdit = !!schema;
  
  // Form state
  const [model, setModel] = useState('');
  const [version, setVersion] = useState(1);
  const [state, setState] = useState<'active' | 'deprecated' | 'draft'>('active');
  const [semver, setSemver] = useState('1.0.0');
  const [jsonSchemaText, setJsonSchemaText] = useState('');
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Initialize form with schema data if editing
  useEffect(() => {
    if (schema) {
      setModel(schema.model);
      setVersion(schema.version);
      setState(schema.state as 'active' | 'deprecated' | 'draft');
      setSemver(schema.semver);
      setJsonSchemaText(JSON.stringify(schema.jsonSchema, null, 2));
      setNotes('');
    } else {
      // Default JSON Schema template
      const defaultSchema = {
        "$id": "https://yourco/schemas/YourModel/1",
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "title": "YourModel",
        "type": "object",
        "required": ["id", "name"],
        "properties": {
          "id": { "type": "string" },
          "name": { "type": "string" }
        },
        "unevaluatedProperties": true
      };
      setJsonSchemaText(JSON.stringify(defaultSchema, null, 2));
    }
  }, [schema]);

  const handleSubmit = async () => {
    setError(null);

    // Validate inputs
    if (!model.trim()) {
      setError('Model name is required');
      return;
    }
    if (version < 1) {
      setError('Version must be at least 1');
      return;
    }
    if (!semver.trim()) {
      setError('Semantic version is required');
      return;
    }

    // Validate and parse JSON Schema
    let jsonSchema;
    try {
      jsonSchema = JSON.parse(jsonSchemaText);
    } catch (err) {
      setError('Invalid JSON Schema syntax');
      return;
    }

    setIsSubmitting(true);

    try {
      if (isEdit) {
        // Update existing schema
        await updateModelSchema(
          model,
          version,
          {
            state,
            semver,
            jsonSchema,
            notes: notes || undefined
          },
          schema._etag
        );
        toast.success(`Schema "${model}" v${version} updated successfully`);
      } else {
        // Create new schema
        await createModelSchema({
          model: model.trim(),
          version,
          state,
          semver: semver.trim(),
          jsonSchema,
          notes: notes.trim() || undefined
        });
        toast.success(`Schema "${model}" v${version} created successfully`);
      }

      onSuccess();
      onOpenChange(false);
      resetForm();
    } catch (err: any) {
      console.error('Error saving ModelSchema:', err);
      setError(err.message || 'Failed to save schema');
      toast.error(err.message || 'Failed to save schema');
    } finally {
      setIsSubmitting(false);
    }
  };

  const resetForm = () => {
    setModel('');
    setVersion(1);
    setState('active');
    setSemver('1.0.0');
    setJsonSchemaText('');
    setNotes('');
    setError(null);
  };

  const handleCancel = () => {
    resetForm();
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[900px] max-h-[90vh]">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle className="flex items-center gap-2">
            {isEdit ? <Save className="h-5 w-5" /> : <Plus className="h-5 w-5" />}
            {isEdit ? `Edit ${schema.model} v${schema.version}` : 'Create New Model Schema'}
          </DialogTitle>
          <DialogDescription>
            {isEdit 
              ? 'Update the schema properties. The model name and version cannot be changed.'
              : 'Define a new JSON Schema for transaction validation and documentation.'
            }
          </DialogDescription>
        </DialogHeader>

        <div className="overflow-y-auto max-h-[calc(90vh-180px)] space-y-4">
          {/* Error Alert */}
          {error && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {/* Basic Information */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="model">Model Name *</Label>
              <Input
                id="model"
                value={model}
                onChange={(e) => setModel(e.target.value)}
                placeholder="e.g., Customer, Invoice, Location"
                disabled={isEdit} // Cannot change model name when editing
              />
              <p className="text-xs text-muted-foreground">
                {isEdit ? 'Model name cannot be changed' : 'The name of the transaction model'}
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="version">Version *</Label>
              <Input
                id="version"
                type="number"
                min="1"
                value={version}
                onChange={(e) => setVersion(parseInt(e.target.value) || 1)}
                disabled={isEdit} // Cannot change version when editing
              />
              <p className="text-xs text-muted-foreground">
                {isEdit ? 'Version number cannot be changed' : 'Integer version number (1, 2, 3, ...)'}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="semver">Semantic Version *</Label>
              <Input
                id="semver"
                value={semver}
                onChange={(e) => setSemver(e.target.value)}
                placeholder="1.0.0"
              />
              <p className="text-xs text-muted-foreground">
                Semantic version (e.g., 1.0.0, 2.1.3)
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="state">State *</Label>
              <Select value={state} onValueChange={(value: any) => setState(value)}>
                <SelectTrigger id="state">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="draft">Draft</SelectItem>
                  <SelectItem value="deprecated">Deprecated</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                Schema lifecycle state
              </p>
            </div>
          </div>

          {/* JSON Schema Editor */}
          <div className="space-y-2">
            <Label htmlFor="jsonSchema" className="flex items-center gap-2">
              <FileJson className="h-4 w-4" />
              JSON Schema (Draft 2020-12) *
            </Label>
            <Textarea
              id="jsonSchema"
              value={jsonSchemaText}
              onChange={(e) => setJsonSchemaText(e.target.value)}
              placeholder="Enter JSON Schema definition..."
              className="font-mono text-xs min-h-[300px] resize-none"
            />
            <p className="text-xs text-muted-foreground">
              Must be valid JSON conforming to JSON Schema Draft 2020-12 specification
            </p>
          </div>

          {/* Notes */}
          <div className="space-y-2">
            <Label htmlFor="notes">Notes (Optional)</Label>
            <Textarea
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Additional notes about this schema or changes..."
              className="min-h-[80px] resize-none"
            />
          </div>
        </div>

        <DialogFooter className="border-t pt-4 px-6">
          <Button
            variant="outline"
            onClick={handleCancel}
            disabled={isSubmitting}
          >
            Cancel
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={isSubmitting}
            className="bg-[#1D6BCD] hover:bg-[#1557A8]"
          >
            {isSubmitting ? (
              <>
                <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                Saving...
              </>
            ) : (
              <>
                {isEdit ? <Save className="h-4 w-4 mr-2" /> : <Plus className="h-4 w-4 mr-2" />}
                {isEdit ? 'Update Schema' : 'Create Schema'}
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}