# Data Capture Spec API Format Fix

## Проблема
При создании Data Capture Specifications через `/datacapturespecs` endpoint получали ошибку **400 "Missing tenantId"**.

## Причина
Функции `createDataCaptureSpec` и `updateDataCaptureSpec` в `/lib/api.ts` преобразовывали payload из camelCase в PascalCase:
```javascript
// ❌ НЕПРАВИЛЬНО - отправляли PascalCase
{
  "DataCaptureSpecName": "Quote",
  "TenantId": "BFS",
  "DataSourceId": "bidtools",
  // ...
}
```

Но BFS API `/1.0/data-capture-specs` endpoint ожидает **camelCase** формат, как показано в рабочем curl запросе:
```javascript
// ✅ ПРАВИЛЬНО - API ожидает camelCase
{
  "dataCaptureSpecName": "Quote",
  "tenantId": "BFS",
  "dataSourceId": "bidtools",
  "isActive": true,
  "version": 1,
  "profile": "data-capture",
  "sourcePrimaryKeyField": "quoteId",
  "partitionKeyField": "partitionKey",
  "partitionKeyValue": "BFS-bidtools",
  "allowedFilters": [...],
  "requiredFields": [...],
  "containerSchema": {...}
}
```

## Решение
Обновлены функции в `/lib/api.ts`:

### 1. `createDataCaptureSpec` (строка ~1556)
- ❌ Убрали преобразование в PascalCase
- ✅ Отправляем payload в camelCase формате

### 2. `updateDataCaptureSpec` (строка ~1612)
- ❌ Убрали преобразование в PascalCase
- ✅ Отправляем payload в camelCase формате

## Результат
Теперь создание Data Capture Specifications работает корректно:

```javascript
const apiPayload = {
  dataCaptureSpecName: spec.dataCaptureSpecName,
  containerName: spec.containerName,
  tenantId: spec.tenantId,           // ✅ camelCase вместо TenantId
  dataSourceId: spec.dataSourceId,   // ✅ camelCase вместо DataSourceId
  isActive: spec.isActive,
  version: spec.version,
  profile: spec.profile,
  sourcePrimaryKeyField: spec.sourcePrimaryKeyField,
  partitionKeyField: spec.partitionKeyField,
  partitionKeyValue: spec.partitionKeyValue,
  allowedFilters: spec.allowedFilters,
  requiredFields: spec.requiredFields,
  containerSchema: spec.containerSchema
};
```

## Тестирование
1. Открыть Data Source Onboarding вкладку
2. Выбрать Data Source (например, Bidtools)
3. Нажать "Create Data Capture Specification"
4. Заполнить форму и создать спецификацию
5. ✅ Успешное создание без ошибок "Missing tenantId"

## Файлы изменены
- `/lib/api.ts` - функции `createDataCaptureSpec` и `updateDataCaptureSpec`
