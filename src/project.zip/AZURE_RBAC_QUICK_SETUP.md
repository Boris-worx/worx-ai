# Azure AD RBAC - Quick Setup Guide

## ✅ What Changed?

The application now uses **Microsoft Entra ID (Azure AD) roles** instead of custom claims for section access control. This is the **standard Microsoft approach** and fully supported by Azure AD.

## 🎯 Problem Solved

**Before:** Application tried to use custom claim `access` (not supported by Azure AD schema)  
**After:** Application uses built-in `roles` claim (fully supported by Azure AD)

## 📋 Quick Setup Steps

### Step 1: Define App Roles in Azure Portal

1. Go to **Azure Portal** → **App registrations**
2. Select your application
3. Navigate to **App roles** → **Create app role**

Create these roles:

#### Permission Roles (for CRUD control):
- `Portal.Admin` - Full access (Create, Read, Update, Delete)
- `Portal.Editor` - Edit access (Read, Update, Delete - no Create)
- `Portal.Reader` - Read-only access

#### Section Access Roles (for UI visibility):
- `Portal.Tenants` - Access to Tenants section
- `Portal.Transactions` - Access to Transactions section  
- `Portal.DataPlane` - Access to Data Plane section

### Step 2: Configure Token to Include Roles

1. Go to **App registrations** → Your app → **Token configuration**
2. Click **Add optional claim**
3. Select **ID** token type
4. Add **roles** claim
5. Check "Turn on the Microsoft Graph profile permission"
6. Save changes

### Step 3: Assign Roles to Users

1. Go to **Enterprise applications** → Your app
2. Navigate to **Users and groups**
3. Click **Add user/group**
4. Select user and assign one or more roles

### Step 4: Deploy Application

No code changes needed! The application automatically:
- Reads all assigned roles from Azure AD
- Determines permission level (admin/edit/view)
- Determines section access (which tabs to show)

## 🎨 Role Combinations Examples

### Example 1: Full System Admin
```
Assigned Roles: ["Portal.Admin"]
Result:
✅ Can: Create, Edit, Delete all resources
✅ Access: All sections (Tenants, Transactions, Data Plane)
```

### Example 2: Finance Viewer
```
Assigned Roles: ["Portal.Reader", "Portal.Transactions"]
Result:
✅ Can: View only (read-only)
✅ Access: Transactions section only
```

### Example 3: Tenant Manager
```
Assigned Roles: ["Portal.Editor", "Portal.Tenants"]
Result:
✅ Can: Edit and Delete (no Create)
✅ Access: Tenants section only
```

### Example 4: Multi-Section Editor
```
Assigned Roles: ["Portal.Editor", "Portal.Tenants", "Portal.Transactions"]
Result:
✅ Can: Edit and Delete (no Create)
✅ Access: Tenants and Transactions (no Data Plane)
```

## 🔍 How It Works

### Role Parsing Logic

```typescript
// 1. Extract all roles from Azure AD token
const roles = ["Portal.Admin", "Portal.Tenants"];

// 2. Determine permission level
if (roles.includes('Portal.Admin')) → admin permissions
else if (roles.includes('Portal.Editor')) → edit permissions
else → view permissions

// 3. Determine section access
if (roles.includes('Portal.Admin|Editor|Reader')) → All sections
else:
  - Portal.Tenants → Show Tenants tab
  - Portal.Transactions → Show Transactions tab
  - Portal.DataPlane → Show Data Plane tab
```

### Token Example

```json
{
  "user_claims": [
    {
      "typ": "roles",
      "val": "Portal.Admin"
    },
    {
      "typ": "roles", 
      "val": "Portal.Tenants"
    }
  ]
}
```

## ✅ Testing

### Development Mode
Use the built-in **Role Test Dialog**:
1. Click your avatar → "Change Role & Access"
2. Select role and section access
3. Click "Apply Changes"
4. UI updates instantly (no page reload)

### Production Mode
Roles come from Azure AD automatically!

## 📚 Documentation

- **Full Guide**: [AZURE_RBAC_GUIDE.md](./AZURE_RBAC_GUIDE.md)
- **Integration Details**: [AZURE_AD_INTEGRATION.md](./AZURE_AD_INTEGRATION.md)
- **Quick Reference**: [AZURE_AD_QUICK_REFERENCE.md](./AZURE_AD_QUICK_REFERENCE.md)

## 🚀 Benefits

✅ **Microsoft Standard** - Uses official Azure AD schema  
✅ **No Custom Claims** - No special backend configuration needed  
✅ **Multiple Roles** - Assign multiple roles to one user  
✅ **Granular Control** - Separate permission and section access  
✅ **Easy Management** - All in Azure Portal  
✅ **Production Ready** - Follows Microsoft best practices  

## 🔧 Code Changes

**Updated Files:**
- `/lib/azure-auth.ts` - Role parsing logic
- `/components/AuthContext.tsx` - State management
- `/AZURE_AD_INTEGRATION.md` - Documentation
- `/AZURE_RBAC_GUIDE.md` - Detailed guide

**What Changed:**
- ❌ Removed: Custom `access` claim (not supported)
- ✅ Added: Multi-role support via `roles` claim
- ✅ Added: Section access based on roles
- ✅ Added: Proper role combination logic

## ❓ FAQ

**Q: Can one user have multiple roles?**  
A: Yes! Assign multiple roles to combine permissions and access.

**Q: What if I only assign Portal.Tenants role?**  
A: User will have view-only access to Tenants section only.

**Q: Do I need to modify the backend?**  
A: No! Just configure roles in Azure Portal and assign them to users.

**Q: How do I test different roles locally?**  
A: Use the "Change Role & Access" dialog in the user menu.

**Q: What's the minimum role needed?**  
A: Portal.Reader gives view-only access to all sections.

## 🎯 Summary

The application now correctly uses **Azure AD roles** (not custom claims) for authorization. This is:
- ✅ Fully supported by Microsoft Entra ID
- ✅ Easy to configure in Azure Portal
- ✅ Production-ready and secure
- ✅ Compatible with standard RBAC patterns

No breaking changes for users - everything works automatically! 🚀
