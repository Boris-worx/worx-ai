# 🚀 Удаление Data Sources - Quick Start

## ✅ Статус: Готово к использованию

Функциональность удаления Data Sources **уже полностью реализована** в вашем приложении!

## 🎯 Как удалить Data Source

### 1️⃣ Откройте Data Source Onboarding
```
BFS Portal → Data Source Onboarding (вкладка)
```

### 2️⃣ Найдите Data Source
- Используйте поиск для быстрого поиска
- Или прокрутите таблицу

### 3️⃣ Нажмите кнопку Delete
```
🗑️ Кнопка в столбце "Action"
Цвет: серый → красный (hover)
```

### 4️⃣ Подтвердите удаление
```
AlertDialog:
  "Delete Data Source"
  "Are you sure you want to delete "{name}"?"
  "This action cannot be undone."
  
Кнопки: [Cancel] [Delete]
```

### 5️⃣ Готово!
```
✅ Toast: "Data source "{name}" deleted successfully!"
✅ Data Source исчез из таблицы
✅ Автообновление через 1 секунду
```

## 🔐 Права доступа

### ✅ Могут удалять:
- **Portal.SuperUser** - все data sources всех тенантов
- **Admin** - data sources своего тенанта
- **Developer** - data sources своего тенанта

### ❌ НЕ могут удалять:
- **ViewOnlySuperUser** - только просмотр
- **Viewer** - только просмотр

## 🌐 Tenant Isolation

### Обычный тенант (BFS, Meritage, и т.д.)
```
✅ Видит: Только свои Data Sources
✅ Удаляет: Только свои Data Sources
❌ Не видит: Data Sources других тенантов
```

### GLOBAL TENANT
```
✅ Видит: ВСЕ Data Sources всех тенантов
✅ Удаляет: Любой Data Source любого тенанта
🔍 Отображает: TenantId в таблице для идентификации
```

## 🔧 API Endpoint

```bash
DELETE /1.0/datasources/{id}
Headers:
  X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
  If-Match: {etag}
```

**Пример:**
```bash
curl -X DELETE \
  'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/datasources/datasource_2f32c5e5-c817-4575-989a-81a470b3c7fe' \
  -H 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
  -H 'If-Match: "abc123etag"'
```

## ⚠️ Важно!

### Действие необратимо
- ❌ Нет функции "восстановить"
- ❌ Удаление физическое, не soft delete
- ⚠️ Могут удаляться связанные данные (Data Capture Specs, и т.д.)

### ETag обязателен
- API использует ETag для предотвращения конфликтов
- Если Data Source был изменен - получите 412 error
- Решение: обновите страницу и попробуйте снова

### Tenant Isolation строгий
- Нельзя удалить Data Source другого тенанта
- API проверяет TenantId на сервере
- Попытка обойти → 403 Forbidden

## 🧪 Быстрый тест

### Тест 1: Базовый (1 минута)
1. Login как **Admin** или **SuperUser**
2. Перейти в **Data Source Onboarding**
3. Создать test data source
4. Нажать 🗑️ **Delete**
5. Подтвердить удаление
6. Проверить: ✅ success toast, ✅ исчез из таблицы

### Тест 2: Права доступа (30 секунд)
1. Login как **Viewer**
2. Перейти в **Data Source Onboarding**
3. Проверить: ❌ кнопка Delete не отображается

### Тест 3: Tenant Isolation (1 минута)
1. Login как **Admin** тенанта "BFS"
2. Создать data source в "BFS"
3. Переключиться на тенант "Meritage"
4. Проверить: ❌ data source от "BFS" не виден

## 💡 Советы

### Проверка перед удалением
```typescript
// Откройте Data Source Detail для просмотра:
- Какие Data Capture Specs связаны
- Используется ли в активных транзакциях
- Metadata и другие зависимости
```

### Если кнопка Delete не видна
```
Причина: Недостаточно прав
Решение: Войдите как SuperUser/Admin/Developer
```

### Если удаление не работает
```
1. Откройте Browser Console (F12)
2. Посмотрите Network tab
3. Проверьте error в Console
4. Посмотрите логи: "🗑️ DELETE Data Source Request"
```

### Массовое удаление
```
❌ Пока нет batch delete endpoint
✅ Удаляйте по одному Data Source
⏳ Batch API - в разработке
```

## 📊 Console Logs

Откройте Browser Console (F12) для просмотра логов:

```javascript
// Успешное удаление
🗑️ DELETE Data Source Request:
  DataSourceId: datasource_xxx
  TenantId: BFS
  URL: https://...
  ETag: "abc123"

📥 DELETE Response:
  Status: 204 No Content
  OK: true

✅ Data source deleted successfully
```

## 🔍 Troubleshooting

### Проблема: After delete, Data Source appears again
```
Причина: Устаревшая версия кода (до 13.11.2025)
Решение: Обновите код - добавлена задержка 1 сек перед refresh
```

### Проблема: 412 Precondition Failed
```
Причина: ETag не совпадает (data source был изменен)
Решение: 
  1. Обновите страницу (F5)
  2. Попробуйте удалить снова
```

### Проблема: 403 Forbidden
```
Причина: Недостаточно прав или другой тенант
Решение:
  1. Проверьте свою роль (должна быть SuperUser/Admin/Developer)
  2. Проверьте TenantId (нельзя удалять чужие data sources)
```

### Проблема: 404 Not Found
```
Причина: Data Source уже удален
Результат: Приложение обрабатывает как успех (не показывает ошибку)
```

## 📚 Дополнительная документация

### Полное руководство
📖 [DATASOURCE_DELETE_GUIDE_RU.md](./DATASOURCE_DELETE_GUIDE_RU.md) - детальное описание

### Чеклист
✅ [DATASOURCE_DELETE_CHECKLIST.md](./DATASOURCE_DELETE_CHECKLIST.md) - быстрый чеклист

### Главная документация
📚 [INDEX_DOCUMENTATION_RU.md](./INDEX_DOCUMENTATION_RU.md) - индекс всей документации

### Data Sources
📋 [DATASOURCES_README_RU.md](./DATASOURCES_README_RU.md) - полный README

### Шпаргалка
🚀 [DATASOURCES_CHEATSHEET_RU.md](./DATASOURCES_CHEATSHEET_RU.md) - команды и примеры

## 🎉 Готово!

Функциональность удаления Data Sources **работает** и готова к использованию!

---

**Вопросы?** Смотрите полную документацию выше или обратитесь к команде.

**Последнее обновление:** 13 ноября 2025
