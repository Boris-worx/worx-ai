# BFS API Configuration Guide

## ✅ API Connection Configured

Your application is now configured to connect to the real BFS API with the credentials from your Postman collection.

## 📋 Current Configuration

### API Details
- **Base URL**: `https://poc-apis-bfs.azurewebsites.net/1.0`
- **Auth Header**: `X-BFS-Auth`
- **API Key**: `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`

### Mode Settings
- **Current Mode**: `DEMO_MODE = true` (Mock Data)
- **Location**: `/lib/api.ts` (Line 8)

## 🔄 Switching Between Demo and Live API

### To Use DEMO Mode (Mock Data)
```typescript
// In /lib/api.ts line 8:
const DEMO_MODE = true;
```
- ✅ No internet connection required
- ✅ Instant responses
- ✅ Safe for testing UI/UX
- ⚠️ Data is not persisted (resets on page refresh)

### To Use LIVE API (Real BFS Server)
```typescript
// In /lib/api.ts line 8:
const DEMO_MODE = false;
```
- ✅ Real data from Cosmos DB
- ✅ Data persists across sessions
- ✅ Full CRUD operations
- ⚠️ Requires internet connection
- ⚠️ API rate limits may apply

## 📡 API Endpoints

All endpoints are configured according to your Postman collection:

### Tenants CRUD Operations

#### 1. Get All Tenants
```
GET /1.0/tenants
Headers: X-BFS-Auth
```

#### 2. Get Single Tenant
```
GET /1.0/tenants/{tenantId}
Headers: X-BFS-Auth
```

#### 3. Create Tenant
```
POST /1.0/tenants
Headers: X-BFS-Auth, Content-Type: application/json
Body: {
  "TenantId": "tenant-{timestamp}",
  "TenantName": "Tenant Name"
}
```
**Note**: Application auto-generates TenantId using format `tenant-{timestamp}`

#### 4. Update Tenant
```
PUT /1.0/tenants/{tenantId}
Headers: 
  - X-BFS-Auth
  - If-Match: "{etag}"
  - Content-Type: application/json
Body: {
  "TenantId": "tenant-1",
  "TenantName": "Updated Name"
}
```
**Important**: `If-Match` header with `_etag` value is required for updates

#### 5. Delete Tenant
```
DELETE /1.0/tenants/{tenantId}
Headers: X-BFS-Auth
```

## 🔐 Authentication

Every API request includes the `X-BFS-Auth` header with your client secret:
```
X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
```

The API validates this header on every request and rejects calls without it.

## 🏷️ ETag Support

For PUT operations, the application automatically:
1. Reads the `_etag` value from the tenant object
2. Adds `If-Match` header with the etag value
3. Sends the update request

**Example**:
```typescript
// Tenant object from API
{
  "TenantId": "tenant-1",
  "TenantName": "Tenant 1",
  "_etag": "e600adff-0000-0300-0000-68df16be0000"
}

// Update request headers
If-Match: "e600adff-0000-0300-0000-68df16be0000"
```

## 🧪 Testing Steps

### 1. Start with Demo Mode
```bash
# Verify DEMO_MODE = true in /lib/api.ts
# Test all CRUD operations with mock data
```

### 2. Switch to Live API
```bash
# Set DEMO_MODE = false in /lib/api.ts
# Refresh the application
# Test operations with real Cosmos DB
```

### 3. Verify Operations
- ✅ Create a new tenant
- ✅ View tenant list
- ✅ Edit tenant name
- ✅ View tenant details
- ✅ Delete tenant
- ✅ Import tenants from JSON

## 📊 Response Format

All API responses follow this format:

### Success Response
```json
{
  "status": {
    "code": 200,
    "message": "Success"
  },
  "data": {
    "tenants": [
      {
        "TenantId": "tenant-1",
        "TenantName": "Tenant 1",
        "CreateTime": "2025-01-15T10:30:00Z",
        "UpdateTime": "2025-01-15T10:30:00Z",
        "_etag": "\"e600adff-0000-0300-0000-68df16be0000\"",
        "_rid": "...",
        "_self": "...",
        "_attachments": "...",
        "_ts": 1234567890
      }
    ]
  }
}
```

### Error Response
```json
{
  "status": {
    "code": 400,
    "message": "Error message here"
  }
}
```

## 🚨 Common Issues

### Issue 1: 401 Unauthorized
**Cause**: Missing or invalid `X-BFS-Auth` header
**Solution**: Verify API key in `/lib/api.ts`

### Issue 2: 412 Precondition Failed
**Cause**: Missing or mismatched `If-Match` header for PUT
**Solution**: Ensure `_etag` is passed correctly from tenant object

### Issue 3: CORS Error
**Cause**: Browser blocking cross-origin requests
**Solution**: API server must have CORS enabled for your domain

### Issue 4: Network Error
**Cause**: Cannot reach API server
**Solution**: 
- Check internet connection
- Verify API URL: `poc-apis-bfs.azurewebsites.net`
- Check if API server is running

## 📝 Notes

1. **TenantId Generation**: The application generates TenantIds client-side using format `tenant-{timestamp}` to ensure uniqueness.

2. **Data Persistence**: 
   - Demo Mode: Data is stored in memory and lost on refresh
   - Live API: Data persists in Cosmos DB

3. **Import Feature**: Works in both modes
   - Demo Mode: Adds to in-memory store
   - Live API: Creates entries via POST requests

4. **Security**: 
   - API key is embedded in code (suitable for internal tools)
   - For production apps, consider using environment variables
   - Never expose API keys in public repositories

## 🔧 Customization

To modify API behavior, edit `/lib/api.ts`:

```typescript
// Change API endpoints
const API_BASE_URL = 'https://your-custom-api.com/1.0';

// Update auth header
const AUTH_HEADER_VALUE = 'your-new-api-key';

// Toggle demo mode
const DEMO_MODE = true; // or false
```

## ✅ Ready to Use!

Your application is fully configured and ready to connect to the BFS API. Simply:
1. Set `DEMO_MODE = false` in `/lib/api.ts`
2. Refresh the application
3. Start managing tenants!

---

**Last Updated**: January 2025  
**API Version**: 1.0  
**Collection**: BFS Postman Collection
