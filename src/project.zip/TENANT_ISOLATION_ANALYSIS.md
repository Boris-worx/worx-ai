# Tenant Isolation - Analysis & Design Review

## User Story Overview

**Provided User Story:** Multi-tenant system where:
1. Each tenant does not have visibility to other tenants
2. Global tenant has global visibility
3. Example tenants: BFS, Meritage, Smith Douglas
4. Data Sources, Data Capture Specifications, Applications, Transaction Specifications, and Cosmos storage can be **global or tenant-specific**
5. Cosmos uses **partition key** for tenant data

### Example Cosmos Structure (from image):

| Tenant | DataSource | Data Capture Spec | Version | Cosmos Container | PartitionKey |
|--------|------------|-------------------|---------|------------------|--------------|
| General Tenant | BidTools | Quotes | 1 | General-Bidtools | General Tenant |
| General Tenant | BidTools | QuoteDetails | 1 | General-Bidtools | General Tenant |
| General Tenant | Databricks | Design | 1 | General-Databricks | General Tenant |
| BFS | Informix | Customer | 1 | BFS-Informix | BFS |
| BFS | AS400 | Customer | 1 | BFS-AS400 | BFS |
| Smith Douglas | Informix | Customer | 1 | SmithDouglas-Informix | SmithDouglas |

## Current Implementation Status

### ✅ What's Working

#### 1. Tenant Management
- ✅ Tenant CRUD operations (Create, Read, Update, Delete)
- ✅ Tenant list display with search/sort/filter
- ✅ Tenant interface with TenantId and TenantName
- ✅ Permission-based access (SuperUser only for tenant management)

#### 2. Tenant Selector
- ✅ Global tenant option ("Global Tenant" with default badge)
- ✅ Tenant dropdown for SuperUser
- ✅ Active tenant persistence in localStorage
- ✅ Visual indication of active tenant
- ✅ Tenant selector appears in all major views:
  - Tenants tab
  - Transaction Onboarding (ModelSchema)
  - Data Source Onboarding
  - Data Plane (Transactions)

#### 3. User Role & Tenant Binding
```typescript
// From App.tsx:
if (user && user.role !== 'superuser' && user.tenantId) {
  setActiveTenantId(user.tenantId); // Lock to user's tenant
  localStorage.setItem('bfs_active_tenant', user.tenantId);
}
```
- ✅ Non-SuperUser users are locked to their tenant
- ✅ SuperUser can switch between global and tenant views

#### 4. Tenant Filtering (Partial)
**TenantsView.tsx:**
```typescript
const filteredTenants = useMemo(() => {
  if (activeTenantId === 'global') {
    return tenants; // Show all
  }
  return tenants.filter(tenant => tenant.TenantId === activeTenantId); // Show only selected
}, [tenants, activeTenantId]);
```

### ❌ What's Missing

#### 1. **No Tenant Field in Data Structures**

Current interfaces are missing tenant identification:

```typescript
// Transaction Interface - NO TenantId field
export interface Transaction {
  TxnId?: string;
  TxnType: string;
  Txn: any;
  // ❌ Missing: TenantId
}

// ModelSchema Interface - NO TenantId field
export interface ModelSchema {
  id: string;
  model: string;
  version: number;
  // ❌ Missing: TenantId or PartitionKey
}

// DataSource Interface - NO TenantId field  
export interface DataSource {
  DataSourceId?: string;
  DataSourceName?: string;
  // ❌ Missing: TenantId
}
```

#### 2. **No Tenant Filtering in API Calls**

API functions don't accept or send tenant context:

```typescript
// Current implementation
export async function getAllTransactions(): Promise<Transaction[]> {
  const response = await fetch(`${API_BASE_URL}/txns`);
  // ❌ No tenant filtering
}

// Should be:
export async function getAllTransactions(tenantId?: string): Promise<Transaction[]> {
  const url = tenantId && tenantId !== 'global'
    ? `${API_BASE_URL}/txns?TenantId=${tenantId}`
    : `${API_BASE_URL}/txns`;
  const response = await fetch(url);
}
```

#### 3. **No Partition Key Handling**

The example shows Cosmos uses partition key for tenant isolation, but:
- ❌ No partition key in data interfaces
- ❌ No partition key in API requests
- ❌ No partition key in headers

#### 4. **No Tenant Context in Data Source/ModelSchema**

According to the provided structure:
- Data Sources should be tenant-specific (e.g., "BFS-Informix", "BFS-AS400")
- ModelSchemas should be tenant-specific (same model for different tenants)
- Current implementation doesn't associate these with tenants

## Recommended Implementation

### Phase 1: Add Tenant Fields to Interfaces

```typescript
// /lib/api.ts

export interface Transaction {
  TxnId?: string;
  TxnType: string;
  Txn: any;
  TenantId?: string;          // ✅ ADD THIS
  PartitionKey?: string;      // ✅ ADD THIS (if API uses it)
  CreateTime?: string;
  UpdateTime?: string;
  _etag?: string;
}

export interface ModelSchema {
  id: string;
  model: string;
  version: number;
  state: string;
  semver: string;
  TenantId?: string;          // ✅ ADD THIS
  PartitionKey?: string;      // ✅ ADD THIS
  dataSourceId?: string;
  jsonSchema: any;
  CreateTime: string;
  UpdateTime: string;
  _etag?: string;
}

export interface DataSource {
  DataSourceId?: string;
  DataSourceName?: string;
  TenantId?: string;          // ✅ ADD THIS
  PartitionKey?: string;      // ✅ ADD THIS
  Type?: string;
  ConnectionString?: string;
  Status?: string;
  CreateTime?: string;
  UpdateTime?: string;
  _etag?: string;
}
```

### Phase 2: Update API Functions with Tenant Parameter

```typescript
// /lib/api.ts

// Transactions
export async function getAllTransactions(tenantId?: string): Promise<Transaction[]> {
  if (DEMO_MODE) {
    // Filter demo data by tenant
    if (tenantId && tenantId !== 'global') {
      return demoTransactions.filter(t => t.TenantId === tenantId);
    }
    return demoTransactions;
  }

  // Build URL with tenant filter
  let url = `${API_BASE_URL}/txns`;
  if (tenantId && tenantId !== 'global') {
    url += `?TenantId=${tenantId}`;
    // OR: url += `?PartitionKey=${tenantId}`;  // if API uses partition key
  }

  const response = await fetch(url, {
    method: "GET",
    headers: getHeaders(),
  });
  // ... rest of the code
}

// Model Schemas
export async function getAllModelSchemas(tenantId?: string): Promise<ModelSchema[]> {
  // Similar implementation
}

// Data Sources
export async function getAllDataSources(tenantId?: string): Promise<DataSource[]> {
  // Similar implementation
}
```

### Phase 3: Update Components to Pass Tenant Context

```typescript
// /App.tsx

// Update data loading functions to use activeTenantId
const refreshTransactions = async () => {
  setIsLoadingTransactions(true);
  try {
    const data = await getAllTransactions(activeTenantId); // ✅ Pass tenant
    setTransactions(data);
  } catch (error: any) {
    toast.error(`Failed to load transactions: ${error.message}`);
  } finally {
    setIsLoadingTransactions(false);
  }
};

const refreshDataSources = async () => {
  setIsLoadingDataSources(true);
  try {
    const data = await getAllDataSources(activeTenantId); // ✅ Pass tenant
    setDataSources(data);
  } catch (error: any) {
    toast.error(`Failed to load data sources: ${error.message}`);
  } finally {
    setIsLoadingDataSources(false);
  }
};

// Reload data when tenant changes
useEffect(() => {
  if (activeTenantId) {
    refreshTransactions();
    refreshDataSources();
    // Reload other data...
  }
}, [activeTenantId]);
```

### Phase 4: Update CREATE Operations with Tenant

```typescript
// When creating new transactions, data sources, etc.
// Include TenantId from activeTenantId

// Example in TransactionCreateDialog
const handleCreate = async () => {
  const newTransaction = {
    TxnType: selectedType,
    Txn: txnData,
    TenantId: activeTenantId !== 'global' ? activeTenantId : undefined, // ✅ Include tenant
  };
  
  await createTransaction(newTransaction);
};
```

### Phase 5: Add Visual Indicators

```typescript
// Show tenant badge in data tables
{row.TenantId && (
  <Badge variant="outline" className="text-xs">
    {row.TenantId === 'General Tenant' ? 'Global' : row.TenantId}
  </Badge>
)}
```

## API Requirements (Need Clarification)

### Questions for Backend Team:

1. **Tenant Field Name:**
   - Is it `TenantId`, `tenantId`, or `PartitionKey`?
   - Where is it in the response JSON?

2. **API Filtering:**
   - Does the API support `?TenantId={id}` query parameter?
   - Or should we use `?PartitionKey={id}`?
   - Or is filtering done via headers?

3. **Global vs Tenant Data:**
   - How is "global" data represented?
   - `TenantId: null` or `TenantId: "General Tenant"` or `TenantId: "global"`?

4. **Container Naming:**
   - Are Cosmos containers named per tenant (e.g., "BFS-Informix")?
   - Or is there one container with partition keys?

5. **Cross-Tenant Data:**
   - Can a SuperUser see all data by omitting TenantId?
   - Or must they query each tenant separately?

## Migration Path

### Step 1: Inspect Real API Response
```bash
# Check what fields the API actually returns
curl -H "X-BFS-Auth: ..." https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/txns | jq '.'
```

Look for:
- `TenantId` field
- `tenantId` field  
- `PartitionKey` field
- `partitionKey` field
- Container information

### Step 2: Update Interfaces Based on Reality
Add the actual field names found in API response.

### Step 3: Test with Single Tenant
1. Create tenant "BFS"
2. Create data source with TenantId = "BFS"
3. Switch to BFS tenant in selector
4. Verify only BFS data shows

### Step 4: Test with Global
1. Switch to "Global Tenant"
2. Verify all data shows (for SuperUser)
3. Verify non-SuperUser sees only their tenant

## Current Workaround (If API Not Ready)

If the backend API doesn't support tenant filtering yet, we can:

### Client-Side Filtering
```typescript
// Filter data on client side after fetching
const getFilteredData = (data: any[], tenantId: string) => {
  if (tenantId === 'global') {
    return data; // Show all
  }
  return data.filter(item => 
    item.TenantId === tenantId || 
    item.tenantId === tenantId ||
    item.PartitionKey === tenantId
  );
};
```

### Mock Tenant Assignment
```typescript
// Temporarily assign tenants to existing data for testing
const enhanceWithTenant = (item: any, index: number): any => {
  const tenants = ['General Tenant', 'BFS', 'Meritage', 'Smith Douglas'];
  return {
    ...item,
    TenantId: tenants[index % tenants.length] // Round-robin assignment
  };
};
```

## Testing Checklist

### Tenant Isolation Tests

- [ ] **SuperUser - Global View**
  - Switch to "Global Tenant"
  - Verify all data from all tenants visible
  - Create new item → should allow choosing tenant

- [ ] **SuperUser - Tenant View**
  - Switch to "BFS" tenant
  - Verify only BFS data visible
  - Create new item → should default to BFS tenant

- [ ] **Non-SuperUser (Admin)**
  - Locked to their tenant (e.g., "BFS")
  - Cannot see tenant selector
  - Only sees BFS data
  - Creates items in BFS tenant automatically

- [ ] **Non-SuperUser (Developer)**
  - Same as Admin
  - Limited permissions but same tenant scope

- [ ] **Non-SuperUser (Viewer)**
  - Read-only access
  - Locked to their tenant
  - Sees only their tenant data

### Data Isolation Tests

- [ ] Create transaction in Tenant A
- [ ] Switch to Tenant B
- [ ] Verify transaction from A is not visible
- [ ] Switch back to Tenant A
- [ ] Verify transaction is visible again

## Summary

### Current State: **Partially Implemented** 🟡

| Feature | Status | Notes |
|---------|--------|-------|
| Tenant CRUD | ✅ Complete | All operations working |
| Tenant Selector UI | ✅ Complete | Global + tenant switching |
| User→Tenant Binding | ✅ Complete | Non-SuperUser locked to tenant |
| Tenant Field in Data | ❌ Missing | No TenantId in Transaction/DataSource/ModelSchema |
| API Tenant Filtering | ❌ Missing | API calls don't filter by tenant |
| Cosmos Partition Key | ❌ Unknown | Not sure if API uses it |
| Visual Tenant Badges | ❌ Missing | Don't show which tenant data belongs to |

### Priority Actions:

1. **🔴 HIGH: Inspect Real API** - Check what tenant fields exist
2. **🔴 HIGH: Add Tenant Fields** - Update interfaces with real field names
3. **🟡 MEDIUM: Update API Calls** - Add tenant parameter to fetch functions
4. **🟡 MEDIUM: Auto-refresh on Tenant Switch** - Reload data when changing tenants
5. **🟢 LOW: Visual Indicators** - Add tenant badges to data rows

### Design Verdict: **Good Foundation, Needs Completion**

The UI/UX design is solid:
- ✅ Tenant selector is well-placed and intuitive
- ✅ Global vs tenant concept is clear
- ✅ Permission model is correct
- ⚠️ Backend integration needs to be completed for true multi-tenancy

The architecture supports the User Story, but the **data layer integration is incomplete**.
