# 🧪 Testing Guide: Apicurio Templates

**Дата:** 27 ноября 2025  
**Время тестирования:** ~5-10 минут

---

## ✅ Что тестируем

После исправлений:
1. ✅ Группа `paradigm.bidtools2` используется (не `paradigm.bidtools`)
2. ✅ Версия `"1"` для `paradigm.bidtools2` (не `"1.0.0"`)
3. ✅ Версия `"1.0.0"` для `bfs.online`
4. ✅ Bid Tools Templates заполняют формы автоматически

---

## 🌐 Тест 1: Browser Testing (5 минут)

### Шаги:

1. **Открыть приложение**
   ```
   http://localhost:5173
   ```

2. **Открыть DevTools**
   - Нажать F12
   - Перейти на вкладку Network
   - Фильтр: XHR

3. **Перейти в Data Source Onboarding**
   - Кликнуть на вкладку "Data Source Onboarding"

4. **Создать новую Specification**
   - Кликнуть "Add Specification"
   - Выбрать "Apicurio Registry"

5. **Проверить запросы к группам**
   
   В Network tab должны быть 2 запроса:
   
   ```
   ✅ GET .../groups/paradigm.bidtools2/artifacts?limit=100
      Status: 200 OK (или 403 - это нормально, будет fallback)
   
   ✅ GET .../groups/bfs.online/artifacts?limit=100
      Status: 200 OK (или 403)
   
   ❌ НЕ должно быть:
      GET .../groups/paradigm.bidtools/artifacts
   ```

6. **Выбрать Bid Tools Template**
   
   В dropdown "Select Template":
   - Найти секцию "📋 Bid Tools Templates"
   - Выбрать любой template, например "QuoteDetails"

7. **Проверить запрос к артефакту**
   
   В Network tab должен появиться запрос:
   
   ```
   ✅ GET .../paradigm.bidtools2/artifacts/TxServices_SQLServer_QuoteDetails.response/versions/1/content
      
   ВАЖНО: Проверить что URL содержит "/versions/1/content"
          (НЕ "/versions/1.0.0/content"!)
   ```

8. **Проверить что форма заполнилась**
   
   После выбора template должны автоматически заполниться поля:
   
   ```
   ✅ Specification ID: TxServices_SQLServer_QuoteDetails.response
   ✅ Display Name: QuoteDetails
   ✅ Description: JSON schema for QuoteDetails
   ✅ Format: json
   ✅ JSON Schema: {...} (должна быть схема)
   ```

9. **Проверить BFS Online Template**
   
   Повторить шаги 4-8, но выбрать template из "📋 BFS Online Templates":
   - Выбрать например "loc"
   - Проверить URL в Network:
   
   ```
   ✅ GET .../bfs.online/artifacts/TxServices_Informix_loc.response/versions/1.0.0/content
      
   ВАЖНО: Для bfs.online должно быть "/versions/1.0.0/content"
   ```

---

## 🔧 Тест 2: curl Testing (5 минут)

### Test paradigm.bidtools2 (версия: 1):

```bash
# Test 1: QuoteDetails
curl "https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/paradigm.bidtools2/artifacts/TxServices_SQLServer_QuoteDetails.response/versions/1/content"

# Ожидаемый результат: JSON schema или 403 Forbidden
# 200 OK = схема получена
# 403 Forbidden = CORS блокирует, но в приложении работает fallback

# Test 2: Quotes
curl "https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/paradigm.bidtools2/artifacts/TxServices_SQLServer_Quotes.response/versions/1/content"

# Test 3: LineTypes CDC
curl "https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/paradigm.bidtools2/artifacts/CDC_SQLServer_LineTypes/versions/1/content"
```

### Test bfs.online (версия: 1.0.0):

```bash
# Test 1: loc
curl "https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/bfs.online/artifacts/TxServices_Informix_loc.response/versions/1.0.0/content"

# Test 2: inv
curl "https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/bfs.online/artifacts/TxServices_Informix_inv.response/versions/1.0.0/content"
```

### Негативный тест (должны FAIL):

```bash
# НЕ должно работать (версия 1.0.0 для paradigm.bidtools2):
curl "https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/paradigm.bidtools2/artifacts/TxServices_SQLServer_QuoteDetails.response/versions/1.0.0/content"

# Ожидаемый результат: 404 Not Found (версия 1.0.0 не существует)

# НЕ должно работать (старая группа):
curl "https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/paradigm.bidtools/artifacts?limit=100"

# Ожидаемый результат: 404 Not Found (группа не существует)
```

---

## 📊 Test Checklist

### Browser Tests:

- [ ] Приложение открывается
- [ ] Data Source Onboarding доступен
- [ ] Create dialog открывается
- [ ] Apicurio Registry выбирается
- [ ] Dropdown показывает "Bid Tools Templates"
- [ ] Dropdown показывает "BFS Online Templates"
- [ ] Network: запрос к paradigm.bidtools2 (не paradigm.bidtools)
- [ ] Network: запрос к bfs.online
- [ ] Выбор Bid Tools Template работает
- [ ] Network: URL содержит /versions/1/content
- [ ] Форма автоматически заполняется
- [ ] Выбор BFS Online Template работает
- [ ] Network: URL содержит /versions/1.0.0/content
- [ ] Форма автоматически заполняется

### curl Tests:

- [ ] paradigm.bidtools2 с версией 1 возвращает данные или 403
- [ ] bfs.online с версией 1.0.0 возвращает данные или 403
- [ ] paradigm.bidtools2 с версией 1.0.0 возвращает 404 ❌
- [ ] старая группа paradigm.bidtools возвращает 404 ❌

### Code Verification:

- [ ] `/lib/apicurio.ts` содержит логику версионирования по groupId
- [ ] Mock данные для paradigm.bidtools2 имеют версию "1"
- [ ] Mock данные для bfs.online имеют версию "1.0.0"
- [ ] Код компилируется без ошибок

---

## 🐛 Expected Issues & Solutions

### Issue 1: 403 Forbidden в Network

```
Статус: ✅ Это нормально!

Причина: 
  Apicurio Registry может требовать authentication
  или CORS блокирует запросы из браузера

Решение:
  Приложение автоматически использует mock данные
  Форма всё равно должна заполниться
```

### Issue 2: Форма не заполняется

```
Статус: ⚠️ Проверить

Шаги:
  1. Открыть Console в DevTools
  2. Найти ошибки (красный текст)
  3. Проверить что запрос идёт к правильному URL:
     - paradigm.bidtools2/.../versions/1/content ✅
     - paradigm.bidtools2/.../versions/1.0.0/content ❌
```

### Issue 3: Старая группа paradigm.bidtools в Network

```
Статус: ❌ БАГ!

Причина:
  Код не обновился или browser cache

Решение:
  1. Hard reload: Ctrl + Shift + R
  2. Clear cache: DevTools → Network → Disable cache
  3. Restart dev server
```

### Issue 4: Dropdown пустой

```
Статус: ⚠️ Проверить

Шаги:
  1. Проверить Console на ошибки
  2. Проверить что searchApicurioArtifacts() выполнилась
  3. Проверить что mock данные возвращаются
  4. Проверить что группировка работает
```

---

## 📝 Test Results Template

```
═══════════════════════════════════════════════════════════
BROWSER TEST RESULTS
═══════════════════════════════════════════════════════════

Date: _______________
Tester: _______________

✅ / ❌  Application loads
✅ / ❌  Data Source Onboarding accessible
✅ / ❌  Create dialog opens
✅ / ❌  Apicurio Registry selectable
✅ / ❌  Templates dropdown shows 2 groups
✅ / ❌  Network: paradigm.bidtools2 request
✅ / ❌  Network: NO paradigm.bidtools request
✅ / ❌  Bid Tools Template selectable
✅ / ❌  Network: versions/1/content URL
✅ / ❌  Form auto-fills from Bid Tools
✅ / ❌  BFS Online Template selectable
✅ / ❌  Network: versions/1.0.0/content URL
✅ / ❌  Form auto-fills from BFS Online

═══════════════════════════════════════════════════════════
CURL TEST RESULTS
═══════════════════════════════════════════════════════════

✅ / ❌  paradigm.bidtools2 + version 1
✅ / ❌  bfs.online + version 1.0.0
✅ / ❌  paradigm.bidtools2 + version 1.0.0 (should fail)
✅ / ❌  paradigm.bidtools (should fail)

═══════════════════════════════════════════════════════════
NOTES
═══════════════════════════════════════════════════════════

_____________________________________________________________
_____________________________________________________________
_____________________________________________________________
```

---

## 🚀 Quick Start (для нетерпеливых)

```bash
# 1. Открыть приложение
# http://localhost:5173

# 2. Открыть DevTools (F12) → Network

# 3. Data Source Onboarding → Add Specification → Apicurio Registry

# 4. Выбрать Bid Tools Template (например QuoteDetails)

# 5. Проверить в Network:
#    ✅ .../paradigm.bidtools2/.../versions/1/content
#    ❌ НЕ должно быть: .../paradigm.bidtools/...
#    ❌ НЕ должно быть: .../versions/1.0.0/content

# 6. Убедиться что форма заполнилась автоматически

# ГОТОВО! Если всё работает - тест пройден ✅
```

---

## 📚 Documentation

| Нужна помощь? | Документ |
|--------------|----------|
| Что исправлено? | `/APICURIO_VERSION_FIX.md` |
| Quick summary | `/VERSION_FIX_SUMMARY.txt` |
| Список артефактов | `/APICURIO_ARTIFACTS_TABLE.md` |
| Cheatsheet | `/APICURIO_CHEATSHEET.md` |
| Полная документация | `/APICURIO_BIDTOOLS2_ЗАМЕНА.md` |

---

**Удачного тестирования! 🚀**

**Дата:** 27 ноября 2025  
**Время:** ~5-10 минут
