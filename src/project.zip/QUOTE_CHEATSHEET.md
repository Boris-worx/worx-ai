# Quote API - Quick Reference Cheatsheet 🚀

## 📍 Endpoint
```
https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/txns
```

## 🔑 Auth Header
```
X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
```

## 🎯 Quick Commands

### CREATE
```bash
curl -X POST 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/txns' \
-H 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
-H 'Content-Type: application/json' \
-d @test-quote-quick.json
```

### READ ALL
```bash
curl 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/txns?TxnType=Quote' \
-H 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
```

### READ ONE
```bash
curl 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/txns/Quote:quick-test-quote-001' \
-H 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
```

### UPDATE
```bash
curl -X PUT 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/txns/Quote:quick-test-quote-001' \
-H 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
-H 'Content-Type: application/json' \
-d '{
  "TxnType": "Quote",
  "Txn": {
    "quoteId": "quick-test-quote-001",
    "exportNotes": "UPDATED",
    "isPublished": true
  }
}'
```

### DELETE
```bash
curl -X DELETE 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/txns/Quote:quick-test-quote-001' \
-H 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
```

## 📝 Minimal Quote Template
```json
{
  "TxnType": "Quote",
  "Txn": {
    "quoteId": "my-quote-id",
    "accountNumber": "579237",
    "erpUserId": "ONLINE"
  }
}
```

## 📊 Postman Collection Template (Official)
```json
{
  "TxnType": "Quote",
  "Txn": {
    "quoteId": "some-unique-id-1",
    "customerRequestedByDate": "2025-07-25T00:00:00.000Z",
    "exportNotes": "Some notes",
    "categories": [
      {"categoryId": "35", "name": null, "description": null},
      {"categoryId": "37", "name": null, "description": null}
    ],
    "accountNumber": "579237",
    "erpUserId": "ONLINE"
  }
}
```

## 🔄 Update Template (from Postman)
```json
{
  "TxnType": "Quote",
  "Txn": {
    "quoteId": "some-unique-id",
    "customerId": "CUST-12345",
    "customerRequestedByDate": "2025-07-25T00:00:00.000Z",
    "exportNotes": "Updated notes",
    "categories": [
      {
        "categoryId": "35",
        "name": "Windows",
        "description": "Window category"
      },
      {
        "categoryId": "37",
        "name": "Doors",
        "description": "Door category"
      }
    ],
    "accountNumber": "579237",
    "erpUserId": "ONLINE",
    "isPublished": true
  }
}
```

## 🌐 Browser Console One-Liner
```javascript
fetch('https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/txns',{method:'POST',headers:{'Content-Type':'application/json','X-BFS-Auth':'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'},body:JSON.stringify({TxnType:"Quote",Txn:{quoteId:"test-"+Date.now(),accountNumber:"579237",erpUserId:"ONLINE"}})}).then(r=>r.json()).then(d=>console.log(d))
```

## ✅ 3-Step Test
1. Open `/test-quote-api.html` in browser
2. Click "Create Quote" 
3. Click "Get All Quotes"

## 🎨 In App
1. Open app → Data Plane tab
2. Select "Quote" from dropdown
3. Click "+ Create New Transaction"
4. Use pre-filled template
5. Change quoteId to unique value
6. Click "Create Transaction"

## 🔍 Verify Success
- Status: `201 Created` (for POST)
- Response has `data.Txn.quoteId`
- Response has `data.Txn._etag`
- Response has `data.Txn.createTime`

## 🐛 Troubleshooting
| Problem | Solution |
|---------|----------|
| 400 Bad Request | Check JSON syntax, ensure quoteId is unique |
| 404 Not Found | Use format `Quote:quoteId` for GET/PUT/DELETE |
| CORS Error | Use HTML tester or run from same origin |
| Unsupported TxnType | Quote not enabled on API - contact API team |

## 📚 More Info
- Full Guide: [QUOTE_TESTING_GUIDE.md](/QUOTE_TESTING_GUIDE.md)
- Russian Guide: [QUOTE_TEST_RU.md](/QUOTE_TEST_RU.md)
- Implementation: [QUOTE_IMPLEMENTATION_SUMMARY.md](/QUOTE_IMPLEMENTATION_SUMMARY.md)
