# ✅ Проблема решена!

## Что было исправлено
Ошибка **400 "Missing tenantId"** при создании Data Capture Specifications полностью устранена.

## Причина
BFS API endpoint `/1.0/data-capture-specs` ожидает JSON в **camelCase**, а приложение отправляло **PascalCase**.

## Исправления
В файле `/lib/api.ts` обновлены 3 функции:

1. **getDataCaptureSpecs** (строка ~1518)
   - Фильтры: `tenantId` и `dataSourceId` (было `TenantId`)

2. **createDataCaptureSpec** (строка ~1556)
   - Весь payload в camelCase

3. **updateDataCaptureSpec** (строка ~1612)
   - Весь payload в camelCase

## Правильный формат
```json
{
  "dataCaptureSpecName": "Quote",
  "tenantId": "BFS",
  "dataSourceId": "bidtools",
  "isActive": true,
  "version": 1,
  "profile": "data-capture",
  "sourcePrimaryKeyField": "quoteId",
  "partitionKeyField": "partitionKey",
  "partitionKeyValue": "BFS-bidtools",
  "allowedFilters": ["quoteId", "customerId"],
  "requiredFields": ["quoteId", "customerId"],
  "containerSchema": { ... }
}
```

## Что теперь работает
✅ GET `/data-capture-specs` с фильтрами  
✅ POST `/data-capture-specs` создание спецификаций  
✅ PUT `/data-capture-specs/{id}` обновление спецификаций  

## Проверка
1. Data Source Onboarding → Выбрать Data Source
2. Create Data Capture Specification
3. Заполнить форму и создать
4. **Успех!** Без ошибок "Missing tenantId"
