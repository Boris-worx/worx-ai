# Role Hierarchy Documentation

## Overview

The BFS Portal application uses a role-based access control (RBAC) system with five distinct roles. This document describes the hierarchy, permissions, and access levels for each role.

## Role Hierarchy

### 1. Portal.SuperUser
- **Application Role**: `superuser`
- **Access Level**: Full access to all sections
- **Permissions**: 
  - ✅ Full CRUD on Tenants (Create, Read, Update, Delete)
  - ✅ Full CRUD on Transaction Onboarding (Model Schema)
  - ✅ Full CRUD on Data Source Onboarding
  - ✅ Full CRUD on Data Plane (Transactions)
- **Use Case**: System administrators who need complete control over all aspects of the platform, including tenant management

### 2. Portal.ViewOnlySuperUser
- **Application Role**: `viewonlysuperuser`
- **Access Level**: Read-only access to all sections
- **Permissions**: 
  - ✅ View Tenants (Read-only)
  - ✅ View Transaction Onboarding (Read-only)
  - ✅ View Data Source Onboarding (Read-only)
  - ✅ View Data Plane (Read-only)
  - ❌ No Create/Update/Delete permissions on any section
- **Use Case**: Auditors, compliance officers, or executives who need visibility across all tenants but should not modify data

### 3. Portal.Admin
- **Application Role**: `admin`
- **Access Level**: Transactions + Data Plane only (NO Tenants)
- **Permissions**: 
  - ❌ No access to Tenants section
  - ✅ Full CRUD on Transaction Onboarding (Model Schema)
  - ✅ Full CRUD on Data Source Onboarding
  - ✅ Full CRUD on Data Plane (Transactions)
- **Use Case**: Tenant administrators who manage their own tenant's configuration and data, but cannot create or modify tenants themselves

### 4. Portal.Developer
- **Application Role**: `developer`
- **Access Level**: Transactions + Data Plane only (NO Tenants)
- **Permissions**: 
  - ❌ No access to Tenants section
  - ✅ Full CRUD on Transaction Onboarding (Model Schema)
  - ✅ Full CRUD on Data Source Onboarding
  - ✅ Full CRUD on Data Plane (Transactions)
- **Use Case**: Developers working on a specific tenant who need to configure integrations and manage transaction data

### 5. Portal.Viewer
- **Application Role**: `viewer`
- **Access Level**: Read-only access to Transactions + Data Plane (NO Tenants)
- **Permissions**: 
  - ❌ No access to Tenants section
  - ✅ View Transaction Onboarding (Read-only)
  - ✅ View Data Source Onboarding (Read-only)
  - ✅ View Data Plane (Read-only)
  - ❌ No Create/Update/Delete permissions
- **Use Case**: Business users or analysts who need to view transaction data and configurations but should not modify anything

## Access Matrix

| Feature | SuperUser | ViewOnlySuperUser | Admin | Developer | Viewer |
|---------|-----------|-------------------|-------|-----------|--------|
| **Tenants** | ✅ Full CRUD | ✅ Read-only | ❌ No access | ❌ No access | ❌ No access |
| **Transaction Onboarding** | ✅ Full CRUD | ✅ Read-only | ✅ Full CRUD | ✅ Full CRUD | ✅ Read-only |
| **Data Source Onboarding** | ✅ Full CRUD | ✅ Read-only | ✅ Full CRUD | ✅ Full CRUD | ✅ Read-only |
| **Data Plane** | ✅ Full CRUD | ✅ Read-only | ✅ Full CRUD | ✅ Full CRUD | ✅ Read-only |

## Azure AD Configuration

To assign these roles to users in Azure AD:

1. Navigate to Azure Portal → Azure Active Directory → App Registrations
2. Select your BFS Portal application
3. Go to "App roles" section
4. Create the following app roles:

### SuperUser Role
```json
{
  "displayName": "SuperUser",
  "description": "Full access to everything including tenant management",
  "value": "Portal.SuperUser",
  "allowedMemberTypes": ["User"],
  "isEnabled": true
}
```

### ViewOnlySuperUser Role
```json
{
  "displayName": "View-Only SuperUser",
  "description": "Read-only access to everything including tenants",
  "value": "Portal.ViewOnlySuperUser",
  "allowedMemberTypes": ["User"],
  "isEnabled": true
}
```

### Admin Role
```json
{
  "displayName": "Admin",
  "description": "Read/write access for transactions and data plane only",
  "value": "Portal.Admin",
  "allowedMemberTypes": ["User"],
  "isEnabled": true
}
```

### Developer Role
```json
{
  "displayName": "Developer",
  "description": "Read/write access for transactions and data plane only",
  "value": "Portal.Developer",
  "allowedMemberTypes": ["User"],
  "isEnabled": true
}
```

### Viewer Role
```json
{
  "displayName": "Viewer",
  "description": "Read-only access for transactions and data plane only",
  "value": "Portal.Viewer",
  "allowedMemberTypes": ["User"],
  "isEnabled": true
}
```

## Testing Roles Locally

For local development and testing, you can use the built-in test credentials:

- **SuperUser**: `superuser` / `super123`
- **View-Only SuperUser**: `viewonlysuperuser` / `viewsuper123`
- **Admin**: `admin` / `admin123`
- **Developer**: `developer` / `dev123`
- **Viewer**: `viewer` / `view123`

### Role Testing Dialog

The application includes a Role Testing Dialog accessible from the user menu. This allows you to:

1. Switch between different roles without logging out
2. Test permissions and UI behavior for each role
3. Return to your real Azure role at any time

To use it:
1. Click on the user icon in the top-right corner
2. Select "Change Role & Access"
3. Choose a role to test
4. Click "Apply Changes"
5. (Azure users only) Click "Reset" to return to your real role

## Implementation Details

### AuthContext
- `UserRole` type: `'superuser' | 'viewonlysuperuser' | 'admin' | 'developer' | 'viewer'`
- `AccessLevel` type: `'All' | AccessSection[]`
- `AccessSection` type: `'Tenants' | 'Transactions' | 'Data Plane'`

### Permission Checks
- SuperUser and ViewOnlySuperUser: `access: 'All'`
- Admin, Developer, Viewer: `access: ['Transactions', 'Data Plane']`

### CRUD Permissions
- Create/Edit/Delete: `superuser`, `admin`, `developer`
- Read-only: `viewonlysuperuser`, `viewer`

## Migration from Old System

If you're migrating from the old role system:

**Old Roles** → **New Roles**
- `Portal.Admin` → `Portal.SuperUser` (if they need tenant access) or `Portal.Admin` (if tenant-level only)
- `Portal.Editor` → `Portal.Developer` or `Portal.Admin`
- `Portal.Reader` → `Portal.Viewer` or `Portal.ViewOnlySuperUser`

## Best Practices

1. **Use SuperUser sparingly**: Only assign to users who truly need tenant management capabilities
2. **Prefer Admin/Developer for tenant users**: These roles provide full control within a tenant's scope
3. **Use Viewer for reporting**: Analysts and business users should use the Viewer role
4. **ViewOnlySuperUser for compliance**: Auditors should use this role for cross-tenant visibility
5. **Principle of Least Privilege**: Always assign the minimum role necessary for a user's job function

## Security Considerations

- Tenant access is restricted to SuperUser roles only
- All roles require Azure AD authentication in production
- Local test credentials should be disabled in production environments
- Role changes through the test dialog are temporary and reset on logout
