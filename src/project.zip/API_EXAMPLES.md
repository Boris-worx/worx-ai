# API Examples

Complete API request/response examples for integration with the BFS Platform.

## 🔐 Authentication

All API requests require the X-BFS-Auth header:

```
X-BFS-Auth: your-api-key-from-postman-collection
```

## 📋 Tenants API

### Get All Tenants (User Story 1)

**Request:**
```http
GET /1.0/tenants
X-BFS-Auth: your-api-key
Content-Type: application/json
```

**Response:**
```json
{
  "status": {
    "code": 200,
    "message": "Successful"
  },
  "data": {
    "tenants": [
      {
        "TenantId": "tenant-1",
        "TenantName": "Tenant 1",
        "CreateTime": "2025-10-02T22:11:27.902156",
        "UpdateTime": "2025-10-02T22:11:27.902156",
        "_rid": "1tsVAIBajWwBAAAAAAAAAA==",
        "_self": "dbs/1tsVAA==/colls/1tsVAIBajWw=/docs/1tsVAIBajWwBAAAAAAAAAA==/",
        "_etag": "\"5400c5bc-0000-0300-0000-68def8900000\"",
        "_attachments": "attachments/",
        "_ts": 1759443088
      },
      {
        "TenantId": "tenant-2",
        "TenantName": "Tenant 2",
        "CreateTime": "2025-10-02T22:37:15.580991",
        "UpdateTime": "2025-10-02T22:37:15.580991",
        "_rid": "1tsVAIBajWwCAAAAAAAAAA==",
        "_self": "dbs/1tsVAA==/colls/1tsVAIBajWw=/docs/1tsVAIBajWwCAAAAAAAAAA==/",
        "_etag": "\"550083ec-0000-0300-0000-68defea00000\"",
        "_attachments": "attachments/",
        "_ts": 1759444640
      }
    ]
  }
}
```

---

### Create Tenant (User Story 2)

**Request:**
```http
POST /1.0/tenants
X-BFS-Auth: your-api-key
Content-Type: application/json

{
  "TenantName": "New Supplier Company"
}
```

**Response:**
```json
{
  "status": {
    "code": 200,
    "message": "Tenant created successfully"
  },
  "data": {
    "TenantId": "tenant-4",
    "TenantName": "New Supplier Company",
    "CreateTime": "2025-10-03T14:30:00.000000",
    "UpdateTime": "2025-10-03T14:30:00.000000",
    "_rid": "1tsVAIBajWwEAAAAAAAAAA==",
    "_self": "dbs/1tsVAA==/colls/1tsVAIBajWw=/docs/1tsVAIBajWwEAAAAAAAAAA==/",
    "_etag": "\"56008627-0000-0300-0000-68deffe10000\"",
    "_attachments": "attachments/",
    "_ts": 1759444961
  }
}
```

**Key Points:**
- Request only sends `TenantName`
- Response includes system-generated `TenantId`
- `_etag` is provided for future updates/deletes

---

### Delete Tenant (User Story 3)

**Request:**
```http
DELETE /1.0/tenants/tenant-4
X-BFS-Auth: your-api-key
If-Match: "56008627-0000-0300-0000-68deffe10000"
Content-Type: application/json
```

**Response:**
```json
{
  "status": {
    "code": 200,
    "message": "Tenant deleted successfully"
  }
}
```

**Key Points:**
- `If-Match` header MUST contain the `_etag` value
- Include quotes around etag value
- No data object in response for DELETE

---

### Get Tenant by ID (Detail View)

**Request:**
```http
GET /1.0/tenants/tenant-1
X-BFS-Auth: your-api-key
Content-Type: application/json
```

**Response:**
```json
{
  "status": {
    "code": 200,
    "message": "Successful"
  },
  "data": {
    "TenantId": "tenant-1",
    "TenantName": "Tenant 1",
    "CreateTime": "2025-10-02T22:11:27.902156",
    "UpdateTime": "2025-10-02T22:11:27.902156",
    "_rid": "1tsVAIBajWwBAAAAAAAAAA==",
    "_self": "dbs/1tsVAA==/colls/1tsVAIBajWw=/docs/1tsVAIBajWwBAAAAAAAAAA==/",
    "_etag": "\"5400c5bc-0000-0300-0000-68def8900000\"",
    "_attachments": "attachments/",
    "_ts": 1759443088
  }
}
```

**Usage:**
- Click on TenantID in the table to trigger
- Display all fields in detail dialog
- Show Cosmos DB metadata

---

### Update Tenant (Edit)

**Request:**
```http
PUT /1.0/tenants/tenant-1
X-BFS-Auth: your-api-key
If-Match: "5400c5bc-0000-0300-0000-68def8900000"
Content-Type: application/json

{
  "TenantName": "Updated Tenant Name"
}
```

**Response:**
```json
{
  "status": {
    "code": 200,
    "message": "Tenant updated successfully"
  },
  "data": {
    "TenantId": "tenant-1",
    "TenantName": "Updated Tenant Name",
    "CreateTime": "2025-10-02T22:11:27.902156",
    "UpdateTime": "2025-10-03T15:30:00.000000",
    "_rid": "1tsVAIBajWwBAAAAAAAAAA==",
    "_self": "dbs/1tsVAA==/colls/1tsVAIBajWw=/docs/1tsVAIBajWwBAAAAAAAAAA==/",
    "_etag": "\"new-etag-after-update\"",
    "_attachments": "attachments/",
    "_ts": 1759450000
  }
}
```

**Key Points:**
- `If-Match` header MUST contain current `_etag` value
- Only TenantName can be updated (TenantId is immutable)
- Response includes new `_etag` and updated `UpdateTime`
- New `_ts` timestamp reflects the update

---

## 🔄 Transactions API

### Get All Transactions (User Story 4)

**Request:**
```http
GET /1.0/transactions
X-BFS-Auth: your-api-key
Content-Type: application/json
```

**Response:**
```json
{
  "status": {
    "code": 200,
    "message": "Successful"
  },
  "data": {
    "transactions": [
      {
        "TransactionId": "txn-1",
        "TransactionName": "Customer",
        "RequestJSON": {
          "type": "Customer",
          "action": "create",
          "parameters": {
            "customerName": "string",
            "email": "string",
            "phone": "string"
          }
        },
        "ResponseJSON": {
          "status": {
            "code": 200,
            "message": "Customer created successfully"
          },
          "data": {
            "customerId": "string",
            "customerName": "string",
            "createdDate": "2025-01-15T00:00:00Z"
          }
        },
        "CreateTime": "2025-01-10T08:30:00Z",
        "UpdateTime": "2025-01-10T08:30:00Z",
        "_etag": "\"abc123def456\""
      },
      {
        "TransactionId": "txn-2",
        "TransactionName": "Customer Aging",
        "RequestJSON": { ... },
        "ResponseJSON": { ... },
        "_etag": "\"def456ghi789\""
      }
      // ... (16 transactions total)
    ]
  }
}
```

---

### Get Transaction by ID (User Story 5)

**Request:**
```http
GET /1.0/transactions/txn-1
X-BFS-Auth: your-api-key
Content-Type: application/json
```

**Response:**
```json
{
  "status": {
    "code": 200,
    "message": "Successful"
  },
  "data": {
    "TransactionId": "txn-1",
    "TransactionName": "Customer",
    "RequestJSON": {
      "type": "Customer",
      "action": "create",
      "parameters": {
        "customerName": "ABC Company",
        "email": "contact@abc.com",
        "phone": "+1-555-0123",
        "address": {
          "street": "123 Main St",
          "city": "New York",
          "state": "NY",
          "zipCode": "10001"
        },
        "taxId": "12-3456789",
        "paymentTerms": "NET30"
      }
    },
    "ResponseJSON": {
      "status": {
        "code": 200,
        "message": "Customer created successfully"
      },
      "data": {
        "customerId": "CUST-12345",
        "customerName": "ABC Company",
        "email": "contact@abc.com",
        "phone": "+1-555-0123",
        "status": "active",
        "creditLimit": 50000.00,
        "balance": 0.00,
        "createdDate": "2025-01-15T10:00:00Z",
        "createdBy": "system",
        "_etag": "\"customer-etag-001\""
      }
    },
    "CreateTime": "2025-01-10T08:30:00Z",
    "UpdateTime": "2025-01-10T08:30:00Z",
    "_etag": "\"abc123def456\""
  }
}
```

**Usage in UI:**
- Display `RequestJSON` in "Request JSON" tab
- Display `ResponseJSON` in "Response JSON" tab
- Show metadata (CreateTime, _etag) below tabs

---

### Create Transaction (User Story 6)

**Request:**
```http
POST /1.0/transactions
X-BFS-Auth: your-api-key
Content-Type: application/json

{
  "TransactionName": "New Transaction Type",
  "RequestJSON": {
    "type": "NewTransaction",
    "action": "create",
    "parameters": {
      "field1": "value1",
      "field2": "value2"
    }
  },
  "ResponseJSON": {
    "status": {
      "code": 200,
      "message": "Transaction processed successfully"
    },
    "data": {
      "transactionId": "TXN-001",
      "result": "success"
    }
  }
}
```

**Response:**
```json
{
  "status": {
    "code": 200,
    "message": "Transaction created successfully"
  },
  "data": {
    "TransactionId": "txn-17",
    "TransactionName": "New Transaction Type",
    "RequestJSON": {
      "type": "NewTransaction",
      "action": "create",
      "parameters": {
        "field1": "value1",
        "field2": "value2"
      }
    },
    "ResponseJSON": {
      "status": {
        "code": 200,
        "message": "Transaction processed successfully"
      },
      "data": {
        "transactionId": "TXN-001",
        "result": "success"
      }
    },
    "CreateTime": "2025-10-03T15:45:00.000000",
    "UpdateTime": "2025-10-03T15:45:00.000000",
    "_etag": "\"new-transaction-etag\""
  }
}
```

**Key Points:**
- RequestJSON and ResponseJSON can be any valid JSON
- System generates TransactionId
- Transaction appears in list after creation

---

## ❌ Error Responses

### Invalid Authentication

**Request:**
```http
GET /1.0/tenants
X-BFS-Auth: invalid-key
```

**Response:**
```json
{
  "status": {
    "code": 401,
    "message": "Invalid authentication credentials"
  }
}
```

---

### Missing Required Field

**Request:**
```http
POST /1.0/tenants
X-BFS-Auth: your-api-key
Content-Type: application/json

{
  "TenantName": ""
}
```

**Response:**
```json
{
  "status": {
    "code": 400,
    "message": "TenantName is required and cannot be empty"
  }
}
```

---

### Missing ETag on Delete

**Request:**
```http
DELETE /1.0/tenants/tenant-1
X-BFS-Auth: your-api-key
```

**Response:**
```json
{
  "status": {
    "code": 412,
    "message": "If-Match header with _etag is required for delete operations"
  }
}
```

---

### ETag Mismatch (Optimistic Concurrency)

**Request:**
```http
DELETE /1.0/tenants/tenant-1
X-BFS-Auth: your-api-key
If-Match: "old-etag-value"
```

**Response:**
```json
{
  "status": {
    "code": 412,
    "message": "The resource has been modified. Please refresh and try again."
  }
}
```

---

### Resource Not Found

**Request:**
```http
GET /1.0/transactions/txn-999
X-BFS-Auth: your-api-key
```

**Response:**
```json
{
  "status": {
    "code": 404,
    "message": "Transaction with ID 'txn-999' not found"
  }
}
```

---

### Server Error

**Response:**
```json
{
  "status": {
    "code": 500,
    "message": "Internal server error. Please try again later."
  }
}
```

---

## 📝 Notes for API Implementation

### Response Structure Requirements
All API responses MUST follow this structure:
```json
{
  "status": {
    "code": number,      // HTTP status code
    "message": string    // Human-readable message
  },
  "data": object | null  // Response data (null for errors)
}
```

### ETag Handling
- All Cosmos DB documents include `_etag` field
- Format: `"quoted-string-value"`
- Required for PUT and DELETE operations
- Send in `If-Match` header with quotes
- Ensures optimistic concurrency control

### Tenant ID Generation
- System generates unique TenantId
- Format: `tenant-{number}` or custom format
- Client only sends TenantName
- Server returns complete tenant object with ID

### Transaction ID Generation
- System generates unique TransactionId
- Format: `txn-{number}` or custom format
- Client sends name and JSON files
- Server returns complete transaction object

### JSON Schema Validation
- RequestJSON and ResponseJSON can be any valid JSON
- No schema validation required
- Stored as-is in Cosmos DB
- Retrieved exactly as stored

### Cosmos DB Fields
These fields are auto-generated by Cosmos:
- `_rid` - Resource ID
- `_self` - Self link
- `_etag` - Entity tag for concurrency
- `_attachments` - Attachments link
- `_ts` - Timestamp

Client should ignore but preserve these in responses.

---

## 🧪 Testing with Postman

### Import Collection
1. Use provided Postman collection
2. Set environment variables:
   - `base_url`: Your API base URL
   - `auth_key`: Your X-BFS-Auth key

### Test Sequence

**1. Get Tenants**
```
GET {{base_url}}/tenants
Verify: Returns list of tenants
```

**2. Create Tenant**
```
POST {{base_url}}/tenants
Body: { "TenantName": "Test Tenant" }
Verify: Returns new tenant with ID
Save: TenantId and _etag for next step
```

**3. Delete Tenant**
```
DELETE {{base_url}}/tenants/{{TenantId}}
Headers: If-Match: {{_etag}}
Verify: Returns 200 OK
```

**4. Get Transactions**
```
GET {{base_url}}/transactions
Verify: Returns 16 transactions
```

**5. Get Transaction Details**
```
GET {{base_url}}/transactions/txn-1
Verify: Returns RequestJSON and ResponseJSON
```

**6. Create Transaction**
```
POST {{base_url}}/transactions
Body: See Create Transaction example above
Verify: Returns new transaction with ID
```

---

This completes the API documentation for BFS Platform Management!
