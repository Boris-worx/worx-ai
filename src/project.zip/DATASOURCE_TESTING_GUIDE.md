# Data Source Onboarding - Testing Guide

## Как протестировать функциональность

### 1. Просмотр Data Sources

**Шаги**:
1. Откройте приложение
2. Войдите с любой ролью (admin/editor/viewer)
3. Перейдите на вкладку "Data Source Onboarding"
4. Должна отобразиться таблица с Data Sources или пустое состояние

**Проверка**:
- ✅ Таблица загружается
- ✅ Отображаются колонки: DatasourceId, DatasourceName, Type, Status, CreateTime
- ✅ Данные отсортированы по дате создания (новые сверху)
- ✅ Кнопка "Refresh" работает

### 2. Создание Data Source

**Требования**: Роль `admin` или `editor`

**Шаги**:
1. Нажмите "Add Data Source"
2. Заполните форму:
   - **Data Source Name** (обязательно): `Databricks` или любое название
   - **Type** (опционально): `NoSQL`, `SQL`, `REST API` и т.д.
   - **Connection String** (опционально): строка подключения
   - **Description** (опционально): описание
3. Нажмите "Create"

**Проверка**:
- ✅ Запрос POST отправляется на `/1.0/datasources`
- ✅ Тело запроса содержит только `DatasourceName` (и опциональные поля если заполнены)
- ✅ API возвращает созданный Data Source с сгенерированным `DatasourceId`
- ✅ Новый Data Source появляется в таблице (вверху списка)
- ✅ Появляется уведомление об успешном создании

**Консоль (F12)**:
```
📤 POST Data Source Request:
  URL: https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/datasources
  Body: {
    "DatasourceName": "Databricks"
  }
📥 Response status: 200 OK
✅ Success response: {...}
Created data source: {...}
```

### 3. Редактирование Data Source

**Требования**: Роль `admin` или `editor`

**Шаги**:
1. Нажмите иконку карандаша (Edit) рядом с Data Source
2. Измените любые поля (например, название или описание)
3. Нажмите "Save Changes"

**Проверка**:
- ✅ Запрос PUT отправляется на `/1.0/datasources/{id}`
- ✅ Используется правильный ETag из `_etag` поля
- ✅ Данные обновляются в таблице
- ✅ Появляется уведомление об успешном обновлении

**Консоль (F12)**:
```
📝 PUT Data Source Request:
  DataSourceId: datasource_59cbb57b-ed55-40b0-9439-dc5134634d69
  URL: https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/datasources/...
  ETag: "67002acc-0000-0100-0000-68ffd4260000"
  Body: {
    "DatasourceId": "...",
    "DatasourceName": "Updated Name",
    ...
  }
```

### 4. Удаление Data Source

**Требования**: Роль `admin` только

**Шаги**:
1. Нажмите иконку корзины (Delete) рядом с Data Source
2. Подтвердите удаление в диалоге

**Проверка**:
- ✅ Запрос DELETE отправляется на `/1.0/datasources/{id}`
- ✅ Используется правильный ETag
- ✅ Data Source исчезает из таблицы
- ✅ Появляется уведомление об успешном удалении

**Консоль (F12)**:
```
🗑️ DELETE Data Source Request:
  DataSourceId: datasource_59cbb57b-ed55-40b0-9439-dc5134634d69
  URL: https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/datasources/...
  ETag: "67002acc-0000-0100-0000-68ffd4260000"
📥 Response status: 200 OK
✅ Data source deleted successfully
```

### 5. Просмотр деталей

**Требования**: Любая роль

**Шаги**:
1. Нажмите иконку глаза (View) рядом с Data Source
2. Откроется диалог с детальной информацией

**Проверка**:
- ✅ Все поля отображаются корректно
- ✅ `ConnectionString` скрыт (показаны точки)
- ✅ Даты отформатированы правильно
- ✅ Cosmos DB поля (_etag, _rid и т.д.) не отображаются

### 6. Настройка колонок

**Требования**: Любая роль

**Шаги**:
1. Нажмите иконку настроек (справа от "Add Data Source")
2. Включите/выключите нужные колонки
3. Закройте диалог

**Проверка**:
- ✅ Таблица обновляется мгновенно
- ✅ Настройки сохраняются в localStorage
- ✅ После перезагрузки страницы настройки сохраняются
- ✅ Колонка `DatasourceId` заблокирована (нельзя отключить)

### 7. Контроль доступа

**Проверка прав**:

| Роль | Просмотр | Создание | Редактирование | Удаление |
|------|----------|----------|----------------|----------|
| Admin | ✅ | ✅ | ✅ | ✅ |
| Editor | ✅ | ✅ | ✅ | ❌ |
| Viewer | ✅ | ❌ | ❌ | ❌ |

**Тест**:
1. Войдите с ролью "Editor" через Profile Dialog
2. Должны быть доступны кнопки "Add Data Source" и "Edit"
3. Не должна быть видна кнопка "Delete"
4. Войдите с ролью "Viewer"
5. Должна быть видна только кнопка "View"

### 8. Обработка ошибок

**Тест CORS ошибки**:
1. Убедитесь, что CORS настроен на API
2. Если CORS заблокирован, приложение должно показать понятную ошибку
3. Проверьте консоль - не должно быть страшных ошибок

**Тест валидации**:
1. Попробуйте создать Data Source без названия
2. Должна появиться ошибка: "Data Source Name is required"

**Тест ETag**:
1. Откройте один Data Source в двух вкладках
2. Отредактируйте в первой вкладке
3. Попробуйте отредактировать во второй вкладке
4. Должна появиться ошибка о конфликте версий

## Полезные curl команды для тестирования API напрямую

### GET - Получить все Data Sources
```bash
curl --location 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/datasources' \
--header 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
```

### POST - Создать Data Source
```bash
curl --location 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/datasources' \
--header 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
--header 'Content-Type: application/json' \
--data '{
    "DatasourceName": "Databricks"
}'
```

### PUT - Обновить Data Source
```bash
curl --location --request PUT 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/datasources/datasource_59cbb57b-ed55-40b0-9439-dc5134634d69' \
--header 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
--header 'If-Match: "67002acc-0000-0100-0000-68ffd4260000"' \
--header 'Content-Type: application/json' \
--data '{
    "DatasourceId": "datasource_59cbb57b-ed55-40b0-9439-dc5134634d69",
    "DatasourceName": "Databricks Updated",
    "Type": "NoSQL",
    "Description": "Updated description"
}'
```

### DELETE - Удалить Data Source
```bash
curl --location --request DELETE 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/datasources/datasource_59cbb57b-ed55-40b0-9439-dc5134634d69' \
--header 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
--header 'If-Match: "67002acc-0000-0100-0000-68ffd4260000"'
```

## Известные особенности

1. **Имена полей**: API использует `DatasourceId` и `DatasourceName` (с маленькой буквой 's')
2. **Генерация ID**: API автоматически генерирует `DatasourceId` при создании
3. **ETag обязателен**: Для PUT/DELETE операций требуется ETag из поля `_etag`
4. **Формат ID**: `datasource_{UUID}` (например, `datasource_59cbb57b-ed55-40b0-9439-dc5134634d69`)
5. **Автозагрузка**: Data Sources загружаются автоматически при старте приложения

## Отладка

Если что-то не работает:

1. Откройте консоль браузера (F12)
2. Проверьте вкладку "Network" для HTTP запросов
3. Проверьте вкладку "Console" для логов приложения
4. Убедитесь, что CORS настроен правильно на API
5. Проверьте, что используется правильный Auth header
6. Проверьте формат данных в запросах/ответах
