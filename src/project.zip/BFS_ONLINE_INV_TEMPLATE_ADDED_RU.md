# ✅ Добавлен новый BFS Online Template: inv (Inventory)

## Что добавлено

Новый шаблон **inv** (Inventory) в группе **BFS Online Templates** для создания Data Capture Specifications.

## Детали шаблона

### Идентификация
- **Artifact ID:** `TxServices_Informix_inv.response`
- **Group ID:** `bfs.online`
- **Название:** `inv`
- **Описание:** Response schema for Informix TxServices inv (Inventory)
- **Тип:** JSON
- **Версия:** 1.0.0

### Структура данных (27 полей)

#### Основные поля инвентаря
```typescript
invid: string | null           // Inventory ID (Primary Key)
invdes: string | null          // Inventory Description
ivstat: string | null          // Inventory Status
```

#### Классификационные коды
```typescript
clsscd1: string | null         // Classification Code 1
clsscd2: string | null         // Classification Code 2
clsscd3: string | null         // Classification Code 3
clsscd4: string | null         // Classification Code 4
clsscd5: string | null         // Classification Code 5
prclsscd: string | null        // Price Classification Code
```

#### Единицы измерения и упаковка
```typescript
unms: string | null            // Unit of Measure
factor: string | null          // Factor (base64 encoded)
stdpkg: string | null          // Standard Package
disqty: string | null          // Display Quantity
```

#### Организационные данные
```typescript
bomtype: string | null         // Bill of Materials Type
buyerid: string | null         // Buyer ID
apnum: string | null           // AP Number
loccd: string | null           // Location Code
gltabid: string | null         // GL Table ID
```

#### Ценообразование и вес
```typescript
invwt: string | null           // Inventory Weight (base64 encoded)
unprc: string | null           // Unit Price (base64 encoded)
nunprc: string | null          // Net Unit Price (base64 encoded)
```

#### Даты
```typescript
estdt: integer | null          // Established Date
lactdt: integer | null         // Last Activity Date
```

#### UPC коды
```typescript
upccode1: string | null        // UPC Code 1
upccode2: string | null        // UPC Code 2
```

#### Единицы измерения для расчетов
```typescript
cstunms: string | null         // Cost Unit of Measure
prcunms: string | null         // Price Unit of Measure
```

### Метаданные

#### Primary Key
```json
"sourcePrimaryKeyField": {
  "type": "string",
  "const": "invid"
}
```

#### Composite Primary Keys (опционально)
```json
"sourcePrimaryKeyFields": {
  "type": "array",
  "items": {
    "type": "string",
    "enum": ["clsscd2", "invid", "ivstat"]
  }
}
```

## Автозаполнение формы

При выборе шаблона **inv** автоматически заполняются:

```typescript
Spec Name: "Inv"
Container Name: "Invs"
Source Primary Key Field: "invid"  // Извлекается из schema.const
Partition Key Field: "id"
Allowed Filters: [
  "invid", "invdes", "ivstat", "clsscd1", "clsscd2", "clsscd3",
  "clsscd4", "clsscd5", "prclsscd", "unms", "factor", "stdpkg",
  "disqty", "bomtype", "buyerid", "apnum", "loccd", "invwt",
  "unprc", "nunprc", "estdt", "lactdt", "upccode1", "upccode2",
  "gltabid", "cstunms", "prcunms"
]
```

## Особенности схемы

### Base64 Encoded Fields
Следующие поля кодируются в base64:
- `factor` - коэффициент пересчета
- `invwt` - вес товара
- `unprc` - цена за единицу
- `nunprc` - чистая цена за единицу

### Nested Structure (BFS Online)
Схема использует вложенную структуру Informix:
```json
{
  "TxnType": "string",
  "Txn": {
    "invid": "...",
    "invdes": "...",
    "metaData": { ... },
    "createTime": "...",
    "updateTime": "..."
  }
}
```

## Использование

### 1. Откройте Data Source Onboarding
Navigate to **Data Source Onboarding** tab

### 2. Выберите Data Source
Click on a Data Source и нажмите **"Create Spec"**

### 3. Выберите BFS Online Template
В dropdown **"🗄️ BFS Online Templates"** выберите **"inv"**

### 4. Проверьте автозаполненные данные
```
✅ Spec Name: Inv
✅ Container Name: Invs
✅ Source Primary Key Field: invid (из const)
✅ Partition Key Field: id
✅ Allowed Filters: 27 полей
✅ Container Schema: полная JSON схема
```

### 5. Настройте Required Fields
Выберите обязательные поля (рекомендуется: `invid`)

### 6. Создайте спецификацию
Click **"Create Specification"**

## Файлы

- **Изменен:** `/lib/apicurio.ts`
  - Добавлен артефакт в `getMockApicurioArtifacts()` (строки 280-287)
  - Добавлена схема в `getMockArtifactSchema()` (строки 740-815)
  - Обновлен count: `10` → `11`
  - Обновлено сообщение: `7 available` → `11 available`

## Совместимость

✅ **Извлечение sourcePrimaryKeyField из const** - работает корректно  
✅ **Nested structure (BFS Online)** - поддерживается  
✅ **Composite primary keys** - поддерживается через sourcePrimaryKeyFields  
✅ **Base64 encoded fields** - отмечены в схеме  
✅ **camelCase conversion** - все поля преобразуются при отправке в BFS API  

## Проверка

1. Откройте **Data Source Onboarding**
2. Нажмите **"Create Spec"** для любого Data Source
3. В dropdown должно быть **11 templates** вместо 10
4. В группе **"🗄️ BFS Online Templates"** должен быть шаблон **"inv"**
5. При выборе **"inv"** форма должна автозаполниться 27 полями
6. Поле **"Source Primary Key Field"** должно быть **"invid"**

## Пример использования

### Создание Inventory Data Capture Spec
```json
{
  "dataCaptureSpecName": "Inv",
  "containerName": "Invs",
  "tenantId": "1018-tenant",
  "dataSourceId": "ds-informix-prod",
  "sourcePrimaryKeyField": "invid",
  "partitionKeyField": "id",
  "partitionKeyValue": "",
  "allowedFilters": ["invid", "invdes", "ivstat", "clsscd1", ...],
  "requiredFields": ["invid"],
  "containerSchema": { ... }
}
```

### Результат в Data Plane
Transaction Type: **"Inv"**  
Container: **"Invs"**  
Queryable Fields: 27 полей  
Primary Key: **"invid"**

## Статус
🟢 **Готово** - Шаблон inv добавлен и готов к использованию
