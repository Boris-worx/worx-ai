# 🚀 Quick Start - BFS Tenant Management

## ⚡ 3 Steps to Go Live

### Step 1: Open Configuration File
```bash
Open: /lib/api.ts
```

### Step 2: Change Line 8
```typescript
// FROM:
const DEMO_MODE = true;

// TO:
const DEMO_MODE = false;
```

### Step 3: Refresh App
```bash
Ctrl+R (or Cmd+R on Mac)
```

## ✅ You're Live!

Your app is now connected to:
- **API**: `poc-apis-bfs.azurewebsites.net`
- **Database**: Cosmos DB
- **Auth**: Secured with X-BFS-Auth header

## 🎯 What You Can Do

### Create Tenant
1. Click "Add New Tenant" button
2. Enter tenant name
3. System auto-generates TenantId
4. Saves to Cosmos DB ✓

### Import Tenants
1. Click "Import JSON" button
2. Upload JSON file (array or API format)
3. All tenants created in Cosmos DB ✓

### Edit Tenant
1. Click "Edit" on any tenant
2. Change name
3. System handles ETag automatically ✓

### Delete Tenant
1. Click "Delete" on any tenant
2. Confirm deletion
3. Removed from Cosmos DB ✓

### View Details
1. Click on any TenantId
2. See full tenant information
3. View metadata (_etag, _rid, timestamps) ✓

## 📋 API Features

✅ **Automatic Auth**: Every request includes X-BFS-Auth header  
✅ **ETag Handling**: If-Match header auto-added for updates  
✅ **Error Handling**: Clear error messages for API failures  
✅ **Loading States**: Visual feedback during API calls  
✅ **Response Parsing**: Handles BFS API response format  

## 🔄 Switch Back to Demo

Need to test without API?
```typescript
// /lib/api.ts line 8
const DEMO_MODE = true;
```

## 🆘 Need Help?

See detailed guide: `/BFS_API_SETUP.md`

---

**Ready in 30 seconds!** 🎉
