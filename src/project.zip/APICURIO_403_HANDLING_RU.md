# ✅ Исправлена обработка ошибок 403 от Apicurio Registry

## Проблема
При работе приложения в браузере появлялось сообщение об ошибке:
```
❌ Apicurio API error: 403
```

Хотя fallback на локальные mock данные работал корректно, ошибка показывалась в консоли как критическая, что могло вводить в заблуждение.

## Причина
Ошибка 403 (Forbidden) от Apicurio Registry является **ожидаемым поведением** в браузерных окружениях из-за:
- CORS политик
- Ограничений доступа к внешнему API
- Сетевых настроек

Приложение имеет встроенный fallback механизм, который автоматически переключается на локальные шаблоны (11 templates), но сообщение об ошибке показывалось до активации fallback.

## Решение
Изменен уровень логирования для 403 ошибок с **error** на **info**:

### До:
```typescript
if (!response.ok) {
  console.error('❌ Apicurio API error:', response.status, response.statusText);
  
  if (response.status === 403) {
    console.log('📦 Using local schema template (Apicurio access forbidden):', extractArtifactName(artifactId));
    return getMockArtifactSchema(artifactId);
  }
  // ...
}
```

### После:
```typescript
if (!response.ok) {
  // Handle 403 Forbidden specifically - this is expected in browser environments
  if (response.status === 403) {
    console.log('📦 Access forbidden (using local template):', extractArtifactName(artifactId));
    return getMockArtifactSchema(artifactId);
  }
  
  console.error('❌ Apicurio API error:', response.status, response.statusText);
  // ...
}
```

## Результат
Теперь при получении 403 ошибки:
1. ✅ Не показывается красное сообщение об ошибке
2. ✅ Показывается информационное сообщение: `📦 Access forbidden (using local template): [template_name]`
3. ✅ Автоматически загружается локальный шаблон из `getMockArtifactSchema()`
4. ✅ Пользователь видит корректное сообщение о том, что используются локальные данные

## Консольные сообщения

### Успешная загрузка артефактов
```
📦 Fetching from group: paradigm.bidtools
📦 Response status (paradigm.bidtools): 200
📦 Loaded 7 artifacts from paradigm.bidtools group
📦 Fetching from group: bfs.online
📦 Response status (bfs.online): 200
📦 Loaded 4 artifacts from bfs.online group
📦 Total artifacts loaded: 11
```

### Fallback на локальные шаблоны (403)
```
📦 Fetching from group: paradigm.bidtools
📦 Response status (paradigm.bidtools): 403
📦 Access forbidden (403) for group: paradigm.bidtools
📦 Fetching from group: bfs.online
📦 Response status (bfs.online): 403
📦 Access forbidden (403) for group: bfs.online
📦 No artifacts loaded, using local Apicurio templates
```

### Загрузка конкретного шаблона (403)
```
📦 Fetching artifact from: https://apicurio-poc.../TxServices_Informix_inv.response/versions/latest/content
📦 Access forbidden (using local template): inv
```

### Fallback на локальные шаблоны (CORS)
```
📦 Using local Apicurio templates (11 available) - CORS blocked
```

## Файлы

**Изменен:** `/lib/apicurio.ts`
- Функция `getApicurioArtifact()` (строки 307-315)
- Изменен порядок проверки статуса 403 (проверяется **до** вывода ошибки)
- Добавлен комментарий о том, что 403 является ожидаемым поведением

## Совместимость

✅ **Локальные шаблоны работают** - 11 templates доступны offline  
✅ **Кэширование работает** - localStorage + in-memory cache (30 минут)  
✅ **Все существующие шаблоны доступны:**
- Bid Tools Templates: 7 шаблонов
- BFS Online Templates: 4 шаблона (loc, loc1, stcode, inv)

## Тестирование

### 1. Проверка в нормальном режиме
```javascript
// Открыть консоль браузера
// Navigate to Data Source Onboarding
// Click "Create Spec"
// Должно показать: "📦 Using local Apicurio templates (11 available) - CORS blocked"
// Или: "📦 Access forbidden (403) for group: ..."
```

### 2. Проверка загрузки шаблона
```javascript
// Выбрать любой шаблон из dropdown (например, "inv")
// Консоль должна показать: "📦 Access forbidden (using local template): inv"
// Форма должна автозаполниться корректными данными
```

### 3. Проверка fallback механизма
```javascript
// Все 11 шаблонов должны быть доступны в dropdown
// При выборе любого шаблона форма должна автозаполниться
// Не должно быть красных ошибок в консоли
```

## Статус
🟢 **Исправлено** - Ошибки 403 теперь обрабатываются как информационные сообщения

## См. также
- `/lib/apicurio.ts` - Функции работы с Apicurio Registry
- `/BFS_ONLINE_INV_TEMPLATE_ADDED_RU.md` - Документация по новому шаблону inv
- `/SOURCEPRIMARYKEYFIELD_CONST_EXTRACTION_RU.md` - Извлечение primary key из схем
