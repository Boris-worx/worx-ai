# Application Flow Guide

Visual guide to understand how the BFS Platform Management application works.

## 🎯 Main Application Structure

```
┌─────────────────────────────────────────────────────────┐
│              BFS Platform Management                     │
│         [Demo Mode Banner if applicable]                 │
├─────────────────────────────────────────────────────────┤
│                                                          │
│  ┌──────────┐  ┌──────────────┐                        │
│  │ Tenants  │  │ Transactions │                         │
│  └──────────┘  └──────────────┘                         │
│       ↑                ↑                                 │
│       └────────────────┴─── Tab Navigation              │
│                                                          │
└─────────────────────────────────────────────────────────┘
```

## 📊 Tenants Tab (User Stories 1-3)

```
┌─────────────────────────────────────────────────────────┐
│  Tenant Management                                       │
│  View and manage supplier tenants on the BFS platform   │
├─────────────────────────────────────────────────────────┤
│                                                          │
│  [Add New Tenant]  [Refresh]                            │
│                                                          │
│  🔍 Search tenants...                    [Clear]        │
│                                                          │
│  ┌────────────┬───────────────┬──────────────────┐      │
│  │ TenantID ↕ │ TenantName ↕  │ Actions          │      │
│  ├────────────┼───────────────┼──────────────────┤      │
│  │ tenant-1   │ Tenant 1      │ [Edit] [Delete]  │      │
│  │ tenant-2   │ Tenant 2      │ [Edit] [Delete]  │      │
│  │ tenant-3   │ Tenant 3      │ [Edit] [Delete]  │      │
│  └────────────┴───────────────┴──────────────────┘      │
│     ↑ Click to view details                             │
│                                                          │
│  Showing 3 of 3 items                                   │
│                                                          │
└─────────────────────────────────────────────────────────┘

User Actions:
[Add New Tenant] → Opens Dialog → Enter Name → Creates Tenant
[Edit] → Opens Dialog → Update Name → Saves Changes
[Delete] → Confirmation → Removes Tenant
TenantID (link) → Opens Detail Dialog → Shows All Metadata
🔍 Search → Filters table in real-time
Column Headers (↕) → Sorts ascending/descending
```

### Flow: Create New Tenant (User Story 2)

```
1. Click "Add New Tenant"
         ↓
┌─────────────────────────┐
│  Add New Tenant         │
├─────────────────────────┤
│                         │
│  Tenant Name:           │
│  [_________________]    │
│                         │
│  [Cancel] [Create]      │
└─────────────────────────┘
         ↓
2. Enter "New Company"
         ↓
3. Click "Create Tenant"
         ↓
4. POST /tenants { TenantName: "New Company" }
         ↓
5. Receive { TenantId: "tenant-4", TenantName: "New Company" }
         ↓
6. Table updates with new row
         ↓
7. ✅ Success toast notification
```

### Flow: Delete Tenant (User Story 3)

```
1. Click [Delete] button on tenant row
         ↓
┌─────────────────────────────────┐
│  Are you sure?                  │
├─────────────────────────────────┤
│  This will permanently delete   │
│  "Tenant 2" (ID: tenant-2).     │
│  This action cannot be undone.  │
│                                 │
│  [Cancel]  [Delete Tenant]      │
└─────────────────────────────────┘
         ↓
2. Click "Delete Tenant"
         ↓
3. DELETE /tenants/tenant-2 (with If-Match: etag)
         ↓
4. Receive 200 OK
         ↓
5. Row removed from table
         ↓
6. ✅ Success toast notification
```

## 🔄 Transactions Tab (User Stories 4-6)

```
┌─────────────────────────────────────────────────────────┐
│  ERP Transactions                                        │
│  View and manage the 16 ERP transaction types           │
├─────────────────────────────────────────────────────────┤
│                                                          │
│  [Add New Transaction]  [Refresh]                       │
│                                                          │
│  🔍 Search transactions...              [Clear]         │
│                                                          │
│  ┌─────────────────────────────────────┐               │
│  │ Transaction Name ↕                  │               │
│  ├─────────────────────────────────────┤               │
│  │ Customer                      ←──── Click to view   │
│  │ Customer Aging                      │               │
│  │ Invoice                             │               │
│  │ Payment                             │               │
│  │ Purchase Order                      │               │
│  │ Sales Order                         │               │
│  │ Vendor                              │               │
│  │ ... (16 total)                      │               │
│  └─────────────────────────────────────┘               │
│                                                          │
│  Showing 16 of 16 items                                 │
│                                                          │
└─────────────────────────────────────────────────────────┘
```

### Flow: View Transaction Details (User Story 5)

```
1. Click on "Customer" row
         ↓
┌─────────────────────────────────────────────────────────┐
│  Customer                            Transaction ID: ... │
├─────────────────────────────────────────────────────────┤
│                                                          │
│  [Request JSON]  [Response JSON]  ←─── Tabs             │
│  ────────────    ───────────────                        │
│                                                          │
│  ┌────────────────────────────────────────────────┐    │
│  │ {                                              │    │
│  │   "type": "Customer",                          │    │
│  │   "action": "create",                          │    │
│  │   "parameters": {                              │    │
│  │     "customerName": "ABC Company",             │    │
│  │     "email": "contact@abc.com"                 │    │
│  │   }                                            │    │
│  │ }                                              │    │
│  └────────────────────────────────────────────────┘    │
│                                                          │
│  Created: 10/15/2025, 10:00:00 AM                      │
│  ETag: "abc123def456"                                   │
│                                                          │
└─────────────────────────────────────────────────────────┘

Click [Response JSON] tab to see response structure
```

### Flow: Add New Transaction (User Story 6)

```
1. Click "Add New Transaction"
         ↓
┌─────────────────────────────────────────────────────────┐
│  Add New Transaction                                     │
├─────────────────────────────────────────────────────────┤
│                                                          │
│  Transaction Name:                                       │
│  [_________________]                                     │
│                                                          │
│  API Request JSON:                                       │
│  ┌───────────────────────────────────────────────┐     │
│  │           📄                                   │     │
│  │   Upload JSON file containing the             │     │
│  │   API request structure                       │     │
│  │                                               │     │
│  │   [Upload Request JSON]                       │     │
│  └───────────────────────────────────────────────┘     │
│                                                          │
│  Transaction Response JSON:                              │
│  ┌───────────────────────────────────────────────┐     │
│  │           📄                                   │     │
│  │   Upload JSON file containing the             │     │
│  │   transaction response structure              │     │
│  │                                               │     │
│  │   [Upload Response JSON]                      │     │
│  └───────────────────────────────────────────────┘     │
│                                                          │
│  [Cancel]  [Create Transaction]                         │
└─────────────────────────────────────────────────────────┘
         ↓
2. Enter "New Transaction"
         ↓
3. Click "Upload Request JSON" → Select sample-request.json
         ↓
   ✅ Request JSON loaded
   Preview shown in card
         ↓
4. Click "Upload Response JSON" → Select sample-response.json
         ↓
   ✅ Response JSON loaded
   Preview shown in card
         ↓
5. Click "Create Transaction"
         ↓
6. POST /transactions
   {
     TransactionName: "New Transaction",
     RequestJSON: { ... },
     ResponseJSON: { ... }
   }
         ↓
7. Receive 200 OK with new transaction
         ↓
8. Transaction appears in list
         ↓
9. ✅ Success toast notification
```

### Flow: Edit Tenant

```
1. Click [Edit] button on tenant row
         ↓
┌─────────────────────────────────┐
│  Edit Tenant                    │
├─────────────────────────────────┤
│                                 │
│  Tenant ID:                     │
│  [tenant-1] (disabled)          │
│  Note: ID cannot be changed     │
│                                 │
│  Tenant Name:                   │
│  [Updated Name_______]          │
│                                 │
│  ETag: "5400c5bc..."            │
│  Last Updated: 10/2/2025        │
│                                 │
│  [Cancel]  [Update Tenant]      │
└─────────────────────────────────┘
         ↓
2. Change tenant name
         ↓
3. Click "Update Tenant"
         ↓
4. PUT /tenants/tenant-1 (with If-Match: etag)
   Body: { TenantName: "Updated Name" }
         ↓
5. Receive updated tenant with new _etag
         ↓
6. Table row updates with new name
         ↓
7. ✅ Success toast notification
```

### Flow: View Tenant Details

```
1. Click on TenantID link (e.g., "tenant-1")
         ↓
┌─────────────────────────────────────────────────────────┐
│  Tenant 1                                                │
│  Complete tenant information from Cosmos DB              │
├─────────────────────────────────────────────────────────┤
│                                                          │
│  Primary Information                                     │
│  ┌────────────────────────────────────────────────┐    │
│  │ Tenant ID:    tenant-1                         │    │
│  │ Tenant Name:  Tenant 1                         │    │
│  └────────────────────────────────────────────────┘    │
│                                                          │
│  Timestamps                                              │
│  ┌────────────────────────────────────────────────┐    │
│  │ Created:  10/02/2025, 10:11:27 PM             │    │
│  │ Updated:  10/02/2025, 10:11:27 PM             │    │
│  │ _ts:      1759443088 (10/02/2025...)          │    │
│  └────────────────────────────────────────────────┘    │
│                                                          │
│  Cosmos DB Metadata                                      │
│  ┌────────────────────────────────────────────────┐    │
│  │ Resource ID:  1tsVAIBajWwBAAAAAAAAAA==        │    │
│  │ ETag:         "5400c5bc-0000-..."             │    │
│  │               [Concurrency Control]            │    │
│  │ Self Link:    dbs/1tsVAA==/colls/...          │    │
│  │ Attachments:  attachments/                     │    │
│  └────────────────────────────────────────────────┘    │
│                                                          │
│  Raw JSON                                                │
│  ┌────────────────────────────────────────────────┐    │
│  │ {                                              │    │
│  │   "TenantId": "tenant-1",                      │    │
│  │   "TenantName": "Tenant 1",                    │    │
│  │   ... (all fields)                             │    │
│  │ }                                              │    │
│  └────────────────────────────────────────────────┘    │
│                                                          │
└─────────────────────────────────────────────────────────┘

Dialog is scrollable for all content
```

## 🔍 Search & Sort Features

### Search Flow
```
Type in search box: "customer"
         ↓
Table filters in real-time
         ↓
Shows: "Customer", "Customer Aging"
Hides: All other transactions
         ↓
Counter updates: "Showing 2 of 16 items (filtered)"
```

### Sort Flow
```
Click column header (e.g., "TenantName")
         ↓
First click: Sort A→Z (ascending) ↑
         ↓
Second click: Sort Z→A (descending) ↓
         ↓
Third click: Remove sort (original order) ↕
```

## 🎨 Visual States

### Loading State
```
┌─────────────────────────────────┐
│  [↻ Loading...]  (disabled)     │
│                                 │
│  Table shows previous data      │
└─────────────────────────────────┘
```

### Empty State
```
┌─────────────────────────────────┐
│                                 │
│         📋                      │
│   No tenants found.             │
│   Click 'Add New Tenant'        │
│   to create one.                │
│                                 │
└─────────────────────────────────┘
```

### Success State
```
Toast notification (top-right):
┌─────────────────────────────────┐
│ ✅ Tenant created successfully  │
└─────────────────────────────────┘
Auto-dismisses after 3 seconds
```

### Error State
```
Toast notification (top-right):
┌─────────────────────────────────┐
│ ❌ Failed to create tenant      │
│    Invalid tenant name          │
└─────────────────────────────────┘
Displays API error message
```

## 🔄 API Call Flow

```
User Action
    ↓
Component Handler
    ↓
API Function (/lib/api.ts)
    ↓
Check: Demo Mode?
    ├─ Yes → Return mock data (500ms delay)
    └─ No  → Make real API call
              ↓
          Add Headers:
          - X-BFS-Auth: key
          - Content-Type: json
          - If-Match: etag (if needed)
              ↓
          Send Request
              ↓
          Receive Response
              ↓
          Check: Success?
              ├─ Yes → Return data
              │        ↓
              │    Update UI
              │        ↓
              │    Show success toast
              │
              └─ No → Throw error
                       ↓
                   Catch in component
                       ↓
                   Show error toast
                       ↓
                   Display status.message
```

## 📱 Responsive Behavior

```
Desktop (> 1024px):
┌─────────────────────────────────────────┐
│  Full width table                       │
│  All columns visible                    │
│  Side-by-side buttons                   │
└─────────────────────────────────────────┘

Tablet (768px - 1024px):
┌─────────────────────────────┐
│  Constrained width          │
│  All columns visible        │
│  Wrapped buttons            │
└─────────────────────────────┘

Mobile (< 768px):
┌─────────────────┐
│  Full width     │
│  Scrollable     │
│  Stacked        │
│  buttons        │
└─────────────────┘
```

## 🎯 Key Interactions Summary

| Action | Location | Result |
|--------|----------|--------|
| Click Tab | Top navigation | Switch between Tenants/Transactions |
| Type in Search | Above table | Filter results in real-time |
| Click Column Header | Table header | Sort data ascending/descending |
| Click TenantID | Tenant table | Open detail dialog with all metadata |
| Click Transaction Row | Transaction table | Open detail dialog with JSON |
| Click Add Button | Top of card | Open creation form |
| Click Edit Button | Tenant table row | Open edit form |
| Click Delete Button | Table row | Open confirmation dialog |
| Upload File | Transaction form | Parse and preview JSON |
| Click Refresh | Top of card | Reload data from API |

---

This visual guide helps understand the complete user journey through the application!
