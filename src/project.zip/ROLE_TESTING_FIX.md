# Role Testing Fix - Test Mode Now Works! 🎉

## Problem

При попытке сменить роль через "Change Role", страница перезагружалась и отображалась реальная роль с Azure AD бекенда, игнорируя выбранную тестовую роль.

### Что происходило:
```
1. User выбирает "Editor" в Change Role
   ↓
2. Роль сохраняется в localStorage
   ↓
3. Страница перезагружается
   ↓
4. AuthContext вызывает fetchAzureAuthData()
   ↓
5. ❌ Azure возвращает реальную роль (например, "admin")
   ↓
6. ❌ Реальная роль ПЕРЕЗАПИСЫВАЕТ тестовую в localStorage
   ↓
7. ❌ Показывается реальная роль вместо тестовой
```

## Solution

Добавлен флаг **Test Mode** в localStorage (`bfs_test_role`), который проверяется при инициализации и предотвращает перезапись тестовой роли.

### Теперь работает так:
```
1. User выбирает "Editor" в Change Role
   ↓
2. Роль сохраняется в localStorage
   ↓
3. Устанавливается флаг: localStorage.setItem('bfs_test_role', 'edit')
   ↓
4. Страница перезагружается
   ↓
5. AuthContext проверяет наличие флага 'bfs_test_role'
   ↓
6. ✅ ЕСЛИ флаг есть → использует роль из localStorage
   ↓
7. ✅ Показывается тестовая роль!
   ↓
8. ✅ User видит UI с правами Editor
```

## Changes Made

### 1. AuthContext (`/components/AuthContext.tsx`)

Добавлена проверка Test Mode перед вызовом Azure AD:

```typescript
useEffect(() => {
  const initAuth = async () => {
    setIsLoadingAuth(true);
    
    // ✅ NEW: Check if user is in test mode
    const testRole = localStorage.getItem('bfs_test_role');
    const storedUser = localStorage.getItem('bfs_user');
    
    if (testRole && storedUser) {
      try {
        const parsedUser = JSON.parse(storedUser);
        // Use the test role instead of real Azure role
        if (parsedUser.isAzureAuth) {
          console.log('Using test role:', testRole);
          setUser(parsedUser);  // ← Используем тестовую роль!
          setIsLoadingAuth(false);
          return;  // ← Не вызываем Azure AD!
        }
      } catch (error) {
        console.error('Failed to parse stored user:', error);
      }
    }
    
    // Try Azure AD authentication (only if not in test mode)
    try {
      const azureUser = await fetchAzureAuthData();
      // ...
    }
  };
}, []);
```

### 2. RoleTestDialog (`/components/RoleTestDialog.tsx`)

#### Добавлен Test Mode флаг:

```typescript
const handleRoleChange = (role: UserRole) => {
  setSelectedRole(role);
  
  if (user?.isAzureAuth) {
    const updatedUser = {
      ...user,
      role: role,
      azureRole: role === 'admin' ? 'Portal.Admin' : role === 'edit' ? 'Portal.Editor' : 'Portal.Reader',
    };
    localStorage.setItem('bfs_user', JSON.stringify(updatedUser));
    
    // ✅ NEW: Set test mode flag
    localStorage.setItem('bfs_test_role', role);
    
    // Reload the page to apply the role change
    setTimeout(() => {
      window.location.reload();
    }, 500);
  }
};
```

#### Добавлена кнопка Reset для возврата к реальной роли:

```typescript
const handleResetToRealRole = () => {
  // Remove test mode flag
  localStorage.removeItem('bfs_test_role');
  
  // Reload to fetch real Azure role
  window.location.reload();
};
```

#### Добавлен UI для Test Mode:

```tsx
{/* Current Role */}
<div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
  <p className="text-xs mb-1">
    <strong>Current Role:</strong>
  </p>
  <div className="flex items-center gap-2">
    <Badge className={getRoleBadgeColor(user?.role || 'view')}>
      {user?.role || 'view'}
    </Badge>
    {user?.isAzureAuth && user.azureRole && (
      <span className="text-xs text-muted-foreground">
        ({user.azureRole})
      </span>
    )}
    {/* ✅ NEW: Test Mode Badge */}
    {isTestMode && (
      <Badge variant="outline" className="text-xs bg-yellow-50 text-yellow-800 border-yellow-300">
        Test Mode
      </Badge>
    )}
  </div>
</div>

{/* ✅ NEW: Reset Button */}
{user?.isAzureAuth && isTestMode && (
  <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
    <div className="flex items-center justify-between gap-3">
      <div className="flex-1">
        <p className="text-xs mb-1">
          <strong>Testing Mode Active</strong>
        </p>
        <p className="text-xs text-muted-foreground">
          You're currently testing a different role. Click to return to your real Azure role.
        </p>
      </div>
      <Button
        size="sm"
        variant="outline"
        onClick={handleResetToRealRole}
        className="shrink-0"
      >
        <RotateCcw className="h-4 w-4 mr-2" />
        Reset
      </Button>
    </div>
  </div>
)}
```

### 3. UserMenu (`/components/UserMenu.tsx`)

#### Добавлен визуальный индикатор Test Mode:

```tsx
{/* ✅ NEW: Test Mode Indicator on Icon */}
{isTestMode && (
  <span className="absolute -top-1 -right-1 flex h-3 w-3">
    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-yellow-400 opacity-75"></span>
    <span className="relative inline-flex rounded-full h-3 w-3 bg-yellow-500"></span>
  </span>
)}

{/* ✅ NEW: Test Mode Badge in Menu */}
{isTestMode && (
  <div className="flex items-center gap-1 mt-1">
    <span className="relative flex h-2 w-2">
      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-yellow-400 opacity-75"></span>
      <span className="relative inline-flex rounded-full h-2 w-2 bg-yellow-500"></span>
    </span>
    <span className="text-xs font-medium text-yellow-600">Test Mode Active</span>
  </div>
)}
```

## Visual Indicators

### 1. User Profile Icon
Когда Test Mode активен, на иконке профиля появляется **пульсирующий жёлтый индикатор** в правом верхнем углу.

### 2. User Menu Dropdown
В меню показывается:
- **"Test Mode Active"** badge с пульсирующей точкой
- Текущая тестовая роль
- Azure роль (для справки)

### 3. Change Role Dialog
- **"Test Mode"** badge рядом с текущей ролью
- **Зелёная панель с кнопкой "Reset"** для возврата к реальной роли
- Обновлённое предупреждение с информацией о Reset кнопке

## How It Works Now

### Switching to Test Role:

```
1. Кликаешь на иконку профиля 👤
   ↓
2. Выбираешь "Change Role"
   ↓
3. Кликаешь на "Editor (Portal.Editor)"
   ↓
4. Диалог сохраняет:
   - localStorage.setItem('bfs_user', updatedUser)
   - localStorage.setItem('bfs_test_role', 'edit')  ← Флаг!
   ↓
5. Страница перезагружается
   ↓
6. AuthContext видит флаг 'bfs_test_role'
   ↓
7. ✅ Использует роль из localStorage
   ↓
8. ✅ НЕ вызывает Azure AD
   ↓
9. ✅ UI отображается с правами Editor!
   ↓
10. На иконке профиля появляется жёлтый индикатор 🟡
```

### Returning to Real Role:

```
1. Кликаешь на иконку профиля 👤 (с жёлтым индикатором)
   ↓
2. Видишь "Test Mode Active" в меню
   ↓
3. Выбираешь "Change Role"
   ↓
4. Видишь зелёную панель "Testing Mode Active"
   ↓
5. Кликаешь кнопку "Reset"
   ↓
6. localStorage.removeItem('bfs_test_role')  ← Удаляем флаг
   ↓
7. Страница перезагружается
   ↓
8. AuthContext НЕ видит флаг 'bfs_test_role'
   ↓
9. ✅ Вызывает fetchAzureAuthData()
   ↓
10. ✅ Получает реальную роль с Azure AD
   ↓
11. ✅ UI отображается с реальной ролью!
   ↓
12. Жёлтый индикатор исчезает
```

## Testing Steps

### Test 1: Switch to Editor Role
```bash
1. Login as Azure AD user with "Portal.Admin" role
2. Verify you can see "Create New Tenant" button
3. Click profile icon → "Change Role"
4. Select "Editor (Portal.Editor)"
5. Wait for page reload
6. ✅ Verify "Create New Tenant" button is HIDDEN
7. ✅ Verify yellow indicator on profile icon
8. ✅ Verify "Test Mode Active" in user menu
9. ✅ Edit and Delete should still work
```

### Test 2: Switch to Reader Role
```bash
1. While in Editor test mode
2. Click profile icon → "Change Role"
3. Select "Reader (Portal.Reader)"
4. Wait for page reload
5. ✅ Verify ALL action buttons are disabled
6. ✅ Verify yellow indicator on profile icon
7. ✅ Verify "Test Mode Active" in user menu
8. ✅ Only view mode available
```

### Test 3: Reset to Real Role
```bash
1. While in Reader test mode
2. Click profile icon → "Change Role"
3. See green panel "Testing Mode Active"
4. Click "Reset" button
5. Wait for page reload
6. ✅ Verify "Create New Tenant" button is BACK
7. ✅ Verify yellow indicator is GONE
8. ✅ Verify "Test Mode Active" is GONE
9. ✅ Verify you have full admin rights
```

### Test 4: Persistence
```bash
1. Switch to Editor role
2. Wait for page reload
3. ✅ Verify Editor UI
4. Manually refresh the page (F5)
5. ✅ Verify STILL in Editor mode
6. ✅ Test mode persists across refreshes
7. Click Reset
8. ✅ Back to real role
```

## localStorage Structure

### When in Test Mode:
```javascript
{
  "bfs_user": {
    "username": "boris",
    "email": "Boris.Belov@myparadigm.com",
    "role": "edit",  // ← Test role
    "azureRole": "Portal.Editor",  // ← Test Azure role
    "isAzureAuth": true
  },
  "bfs_test_role": "edit"  // ← Flag that indicates test mode
}
```

### When NOT in Test Mode:
```javascript
{
  "bfs_user": {
    "username": "boris",
    "email": "Boris.Belov@myparadigm.com",
    "role": "admin",  // ← Real role from Azure
    "azureRole": "Portal.Admin",  // ← Real Azure role
    "isAzureAuth": true
  }
  // NO "bfs_test_role" key
}
```

## Benefits

✅ **Test Mode теперь работает!** - Роли не перезаписываются при reload
✅ **Визуальные индикаторы** - Всегда знаешь что в Test Mode
✅ **Простой возврат** - Одна кнопка "Reset" для возврата к реальной роли
✅ **Персистентность** - Test Mode сохраняется при refresh страницы
✅ **Чистый UX** - Понятно когда тестируешь, когда работаешь

## Files Changed

1. `/components/AuthContext.tsx`
   - Добавлена проверка флага `bfs_test_role` перед Azure AD вызовом
   - Если флаг есть, используется роль из localStorage

2. `/components/RoleTestDialog.tsx`
   - Добавлена установка флага `bfs_test_role` при смене роли
   - Добавлена функция `handleResetToRealRole()`
   - Добавлен UI для Test Mode badge и Reset кнопки

3. `/components/UserMenu.tsx`
   - Добавлен пульсирующий индикатор на иконке профиля
   - Добавлен "Test Mode Active" badge в меню

4. `/ROLE_TESTING_FIX.md` (этот файл)
   - Документация изменений

## Summary

Проблема с перезаписью тестовой роли **полностью решена**! Теперь можно безопасно тестировать UI с разными ролями, и они будут сохраняться даже после перезагрузки страницы. Визуальные индикаторы всегда показывают когда вы в Test Mode, а кнопка Reset позволяет легко вернуться к реальной роли.

🎉 **Role Testing теперь работает идеально!**
