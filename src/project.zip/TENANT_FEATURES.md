# Tenant Management Features

Complete guide to all tenant management capabilities in the BFS Platform Management application.

## 🎯 Overview

The Tenant Management tab provides comprehensive CRUD operations with detailed metadata viewing:

1. **Create** - Add new tenants with auto-generated IDs
2. **Read** - View tenant list and detailed information
3. **Update** - Edit tenant names
4. **Delete** - Remove tenants from the platform

All operations use optimistic concurrency control via ETag headers.

---

## 📋 Features

### 1. View Tenant List

**Main table display with:**
- TenantID (clickable link - see #3)
- TenantName
- Sort by any column (click header)
- Search/filter in real-time
- Actions: Edit and Delete buttons

```
┌────────────┬───────────────┬──────────────────┐
│ TenantID ↕ │ TenantName ↕  │ Actions          │
├────────────┼───────────────┼──────────────────┤
│ tenant-1   │ Tenant 1      │ [Edit] [Delete]  │
│ tenant-2   │ Tenant 2      │ [Edit] [Delete]  │
└────────────┴───────────────┴──────────────────┘
```

**API:**
```http
GET /tenants
Response: List of all tenants
```

---

### 2. Create New Tenant

**User Story 2 Implementation**

**Steps:**
1. Click "Add New Tenant" button
2. Enter TenantName
3. System generates unique TenantID
4. New tenant appears in table

**Features:**
- Auto-generated TenantID
- Validation (name required)
- Success toast notification
- Automatic table update

**API:**
```http
POST /tenants
Body: { "TenantName": "New Company" }
Response: { TenantId: "tenant-4", TenantName: "New Company", ... }
```

---

### 3. View Tenant Details

**NEW FEATURE - Click TenantID to view complete information**

**What's Displayed:**

#### Primary Information
- TenantId
- TenantName

#### Timestamps
- CreateTime (formatted date)
- UpdateTime (formatted date)
- _ts (Unix timestamp with conversion)

#### Cosmos DB Metadata
- **_rid** - Resource ID
- **_etag** - Entity tag (with "Concurrency Control" badge)
- **_self** - Self link
- **_attachments** - Attachments path

#### Raw JSON
- Complete JSON object for debugging
- All fields preserved

**Dialog Features:**
- Scrollable content
- Formatted display
- Copy-friendly monospace fonts
- Clear field labels

**API:**
```http
GET /tenants/{tenantId}
Response: Complete tenant object with all Cosmos DB fields
```

**Example Response:**
```json
{
  "status": {
    "code": 200,
    "message": "Successful"
  },
  "data": {
    "TenantId": "tenant-2",
    "TenantName": "Tenant 2",
    "CreateTime": "2025-10-02T22:37:15.580991",
    "UpdateTime": "2025-10-02T22:37:15.580991",
    "_rid": "1tsVAIBajWwCAAAAAAAAAA==",
    "_self": "dbs/1tsVAA==/colls/1tsVAIBajWw=/docs/1tsVAIBajWwCAAAAAAAAAA==/",
    "_etag": "\"550083ec-0000-0300-0000-68defea00000\"",
    "_attachments": "attachments/",
    "_ts": 1759444640
  }
}
```

---

### 4. Edit Tenant

**NEW FEATURE - Update tenant information**

**Steps:**
1. Click "Edit" button on any tenant row
2. Dialog opens with current values
3. Update TenantName (TenantID is disabled)
4. Click "Update Tenant"
5. Table updates with new values

**Features:**
- TenantID field shown but disabled (IDs are immutable)
- Current values pre-filled
- ETag displayed for reference
- Last update time shown
- Validation (name required)
- Optimistic concurrency (uses _etag)

**API:**
```http
PUT /tenants/{tenantId}
Headers: If-Match: "_etag_value"
Body: { "TenantName": "Updated Name" }
Response: Updated tenant with new _etag
```

**Note:** TenantID cannot be changed in Cosmos DB. If ID change is needed, delete and recreate the tenant.

---

### 5. Delete Tenant

**User Story 3 Implementation**

**Steps:**
1. Click "Delete" button
2. Confirmation dialog appears
3. Review tenant details
4. Confirm deletion
5. Tenant removed from table

**Features:**
- Confirmation required
- Shows tenant name and ID in confirmation
- Warning message
- Uses ETag for concurrency control
- Success toast on completion

**API:**
```http
DELETE /tenants/{tenantId}
Headers: If-Match: "_etag_value"
Response: 200 OK
```

---

## 🔐 Concurrency Control

All update and delete operations use **Optimistic Concurrency Control** via ETags:

### How it Works

1. **Read:** Every tenant object includes an `_etag` field
2. **Update/Delete:** Send the `_etag` value in `If-Match` header
3. **Validation:** Cosmos DB verifies the etag matches
4. **Success:** Operation completes, new etag generated
5. **Conflict:** If etag doesn't match (someone else updated), operation fails

### Example Flow

```
User A loads tenant → _etag: "v1"
User B loads tenant → _etag: "v1"
User A updates     → Success! New _etag: "v2"
User B tries update → FAIL! Has "v1" but current is "v2"
User B must reload tenant and retry
```

### In the UI

- Edit form shows current etag
- If update fails with 412 error, user sees:
  ```
  ❌ The resource has been modified. 
     Please refresh and try again.
  ```
- User can refresh and retry with new etag

---

## 📊 Data Model

### Tenant Object Structure

```typescript
interface Tenant {
  // Primary fields (user-controlled)
  TenantId: string;        // Unique identifier (immutable)
  TenantName: string;      // Display name (editable)
  
  // Timestamps
  CreateTime?: string;     // ISO 8601 format
  UpdateTime?: string;     // ISO 8601 format
  
  // Cosmos DB metadata (system-controlled)
  _rid?: string;          // Resource ID
  _self?: string;         // Self link
  _etag?: string;         // Entity tag for concurrency
  _attachments?: string;  // Attachments path
  _ts?: number;           // Unix timestamp
}
```

---

## 🎨 UI Components

### Components Used

1. **TenantsView.tsx** - Main container
   - Manages state
   - Handles all operations
   - Coordinates dialogs

2. **DataTable.tsx** - Reusable table
   - Sort/Search/Filter
   - Action buttons
   - Responsive layout

3. **TenantDetail.tsx** - Detail dialog
   - Shows all metadata
   - Formatted display
   - Raw JSON view

4. **TenantEditForm.tsx** - Edit dialog
   - Form validation
   - Etag handling
   - Update logic

5. **AlertDialog** - Delete confirmation
   - Warning message
   - Confirm/Cancel actions

---

## 💡 Usage Tips

### Best Practices

1. **Always check details before deleting**
   - Click TenantID to review
   - Verify it's the correct tenant

2. **Handle concurrent edits gracefully**
   - If update fails, refresh data
   - Retry with new etag

3. **Use search for large lists**
   - Type in search box
   - Filters in real-time

4. **Sort for organization**
   - Click column headers
   - Sort by ID or Name

### Common Workflows

#### Onboard New Supplier
```
1. Click "Add New Tenant"
2. Enter supplier name
3. Note generated TenantID
4. Share TenantID with supplier
```

#### Update Supplier Name
```
1. Find tenant in list
2. Click "Edit"
3. Update name
4. Click "Update Tenant"
```

#### Audit Tenant Configuration
```
1. Click TenantID link
2. Review all metadata
3. Check timestamps
4. Verify etag value
```

#### Decommission Supplier
```
1. Click TenantID to verify
2. Click "Delete"
3. Confirm in dialog
4. Tenant removed from platform
```

---

## 🔧 Technical Details

### API Headers

All requests include:
```
X-BFS-Auth: your-api-key
Content-Type: application/json
If-Match: "_etag_value"  // For PUT/DELETE only
```

### Error Handling

| Error Code | Meaning | UI Response |
|------------|---------|-------------|
| 400 | Bad Request (validation) | Show error message |
| 401 | Unauthorized | Show auth error |
| 404 | Tenant not found | Show not found error |
| 412 | Precondition Failed (etag mismatch) | Ask to refresh |
| 500 | Server Error | Show server error |

### Demo Mode

When running in demo mode (default):
- All operations work in-memory
- Data persists during session
- Resets on page refresh
- No real API calls made

---

## 🎯 Feature Checklist

- ✅ View all tenants in table
- ✅ Sort by TenantID or TenantName
- ✅ Search/filter tenants
- ✅ Create new tenant with auto-generated ID
- ✅ Click TenantID to view full details
- ✅ See all Cosmos DB metadata
- ✅ View raw JSON
- ✅ Edit tenant name
- ✅ Delete tenant with confirmation
- ✅ Optimistic concurrency with ETags
- ✅ Toast notifications for all operations
- ✅ Responsive design
- ✅ Demo mode for development
- ✅ Real API integration ready

---

This completes the tenant management feature documentation!