# Apicurio Integration - Чек-лист проверки

## ✅ Текущий статус (27 ноября 2025)

### Код

| Задача | Статус | Файл | Примечания |
|--------|--------|------|------------|
| Очистка mock данных из `getApicurioArtifactContent` | ✅ Готово | `/lib/api.ts` | Строки 2327-2361 |
| Все функции работают с v3 API | ✅ Готово | `/lib/api.ts` | 6 функций |
| Нет компиляционных ошибок | ✅ Готово | - | Код компилируется |
| Feature flags удалены | ✅ Готово | - | `USE_MOCK_APICURIO` больше нет |
| UI компоненты обновлены | ✅ Готово | `/components/*.tsx` | DataCaptureSpecCreateDialog и др. |

### Документация

| Документ | Статус | Актуальность |
|----------|--------|--------------|
| `/APICURIO-REAL-API-ТОЛЬКО.md` | ✅ Новый | ⭐ Актуально - читать в первую очередь |
| `/СЛЕДУЮЩИЕ_ШАГИ_APICURIO_RU.md` | ✅ Новый | ⭐ Дорожная карта |
| `/APICURIO_CHECKLIST_RU.md` | ✅ Новый | ⭐ Этот файл |
| `/APICURIO-MOCK-DATA-FIX.md` | ⚠️ Устарел | Mock данные больше не используются |
| `/APICURIO-STATUS.md` | ⚠️ Устарел | Упоминает `USE_MOCK_APICURIO = true` |
| `/README-APICURIO.md` | ⚠️ Устарел | Упоминает mock mode |
| `/APICURIO-INTEGRATION.md` | ✅ Частично | Технические детали еще актуальны |
| `/APICURIO-CORS-SOLUTION.md` | ✅ Актуально | CORS решения критичны сейчас |

---

## 🧪 Тестирование

### Быстрая проверка (5 минут)

#### ✅ Тест 1: API доступен
```bash
# В терминале
curl https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/search/artifacts?name=Value

# Ожидаемый результат: JSON с "count" и "artifacts"
```

#### ✅ Тест 2: CORS работает
```javascript
// В Browser Console
fetch('https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/search/artifacts?name=Value')
  .then(r => r.json())
  .then(d => console.log('✅ CORS OK, artifacts:', d.count))
  .catch(e => console.error('❌ CORS Error:', e.message));
```

**Результат:**
- ✅ Если видите "✅ CORS OK, artifacts: X" - всё работает
- ❌ Если "CORS Error" - нужна конфигурация (см. `/APICURIO-CORS-SOLUTION.md`)

#### ✅ Тест 3: UI загрузка схем
```
1. Открыть app
2. Перейти: Data Source Onboarding
3. Найти любой data source
4. Нажать: "Add Specification"
5. Дождаться загрузки (2-3 сек)
6. Открыть Browser DevTools → Console
```

**Проверить в консоли:**
```
✅ Хорошо:
📡 Fetching schemas for data source: {name} (v3 API)...
✅ Found X schemas (JSON + AVRO) for {name}

❌ Плохо:
❌ Failed to fetch artifacts: 404 Not Found
❌ Error fetching schemas: TypeError: Failed to fetch
```

### Полное тестирование (30 минут)

#### ✅ Сценарий 1: Создание Data Capture Spec

**Шаги:**
1. Data Source Onboarding → Найти "BFS.online"
2. Нажать "Add Specification"
3. Выбрать схему из dropdown (если есть)
4. Проверить что форма заполнилась автоматически
5. Дополнить required поля
6. Нажать "Create Specification"

**Проверки:**
- [ ] Dropdown со схемами появился
- [ ] Схемы загрузились из Apicurio (не mock)
- [ ] Форма auto-fill работает
- [ ] Спецификация создается успешно
- [ ] Появилась в таблице

**Console logs:**
```
📡 Fetching schemas for data source: BFS.online (v3 API)...
  URL: https://apicurio-poc...
✅ Found 3 schemas (JSON + AVRO) for BFS.online
📡 Fetching Apicurio artifact content (v3 API): bfs.QuoteDetails.json
  URL: https://apicurio-poc...
✅ Fetched schema for bfs.QuoteDetails.json
  Schema preview: {"$schema":"http://json-schema.org/draft-07/schema#"...
```

#### ✅ Сценарий 2: Discovery Dialog

**Шаги:**
1. Data Source Onboarding → Menu (⋮) → "Discover Specifications"
2. Дождаться загрузки
3. Проверить список артефактов

**Проверки:**
- [ ] Dialog открывается
- [ ] Артефакты загружаются из реального API
- [ ] Отображаются группы (если есть в v3)
- [ ] Можно нажать "View" на артефакте
- [ ] Schema копируется в clipboard

**Console logs:**
```
📡 Discovering all Data Source Specifications from Apicurio (v3 API)...
📡 Fetching all Apicurio artifacts (v3 API) with search query: "Value"...
✅ Found 25 artifacts in Apicurio Registry
✅ Total discovered: 25 artifacts
  Breakdown by type: { AVRO: 18, JSON: 7 }
```

#### ✅ Сценарий 3: Error Handling

**Шаги:**
1. Отключить Apicurio Registry (или блокировать в DevTools)
2. Попытаться создать Data Capture Spec
3. Проверить обработку ошибок

**Проверки:**
- [ ] Не вылетает приложение
- [ ] Показывается понятное сообщение об ошибке
- [ ] Console показывает детали ошибки
- [ ] Можно продолжить работу (fallback на ручной ввод)

**Console logs:**
```
📡 Fetching schemas for data source: BFS.online (v3 API)...
❌ Failed to fetch artifacts: 503 Service Unavailable
Error fetching schemas for BFS.online: Error: Failed to fetch artifacts...
```

---

## 🚨 Известные проблемы

### 1. CORS может быть не настроен

**Симптомы:**
```
❌ TypeError: Failed to fetch
❌ CORS policy: No 'Access-Control-Allow-Origin' header
```

**Решение:**
- Проверить CORS на Apicurio Registry
- Временно: browser extension (только dev!)
- Production: backend proxy или CORS конфигурация

**Файл:** `/APICURIO-CORS-SOLUTION.md`

### 2. Артефакты могут быть не в ожидаемом формате

**Симптомы:**
```
✅ Found 0 schemas (JSON + AVRO) for BFS.online
```

**Причины:**
- Нет артефактов с таким именем в Apicurio
- Артефакты имеют другой тип (не JSON/AVRO)
- Неправильный search query

**Решение:**
- Проверить содержимое Apicurio Registry
- Скорректировать search query
- Проверить фильтрацию по artifactType

### 3. JSON Schema может быть невалидной

**Симптомы:**
```
✅ Fetched schema for {artifactId}
❌ Error parsing schema: ...
```

**Причины:**
- Schema не в JSON Schema Draft 2020-12 формате
- AVRO schema вместо JSON Schema
- Неполная или поврежденная schema

**Решение:**
- Валидировать schema перед использованием
- Добавить schema transformation если нужно
- Документировать требования к формату

---

## 📋 Checklist перед коммитом

### Разработка

- [x] ✅ Все mock данные удалены из `getApicurioArtifactContent`
- [x] ✅ Код компилируется без ошибок
- [x] ✅ TypeScript types корректны
- [ ] ⏳ Все API функции протестированы
- [ ] ⏳ Error handling работает корректно
- [ ] ⏳ Console logs информативны

### Документация

- [x] ✅ Создан `/APICURIO-REAL-API-ТОЛЬКО.md`
- [x] ✅ Создан `/СЛЕДУЮЩИЕ_ШАГИ_APICURIO_RU.md`
- [x] ✅ Создан `/APICURIO_CHECKLIST_RU.md`
- [ ] ⏳ Обновлен README.md с актуальной информацией
- [ ] ⏳ Помечены устаревшие документы

### Тестирование

- [ ] ⏳ CORS протестирован
- [ ] ⏳ Все API endpoints работают
- [ ] ⏳ UI loading states корректны
- [ ] ⏳ Error states отображаются правильно
- [ ] ⏳ Data Capture Spec создание работает end-to-end

### Production готовность

- [ ] 🔜 CORS настроен на Apicurio
- [ ] 🔜 Error monitoring настроен
- [ ] 🔜 Performance acceptable
- [ ] 🔜 Security audit пройден
- [ ] 🔜 User acceptance testing завершен

---

## 🎯 Immediate Next Actions

### Приоритет 1: Критично (сегодня)
1. ✅ **Завершено:** Очистка mock данных
2. ⏳ **Тестирование:** Проверить CORS (Тест 2 выше)
3. ⏳ **Тестирование:** Создать Data Capture Spec (Сценарий 1)

### Приоритет 2: Важно (эта неделя)
4. 🔜 Автоматическое создание ModelSchema из Data Capture Spec
5. 🔜 UI обновления для Data Plane
6. 🔜 Тестирование полного flow

### Приоритет 3: Полезно (следующая неделя)
7. 🔜 Валидация транзакций по схемам
8. 🔜 Версионирование схем
9. 🔜 Bulk import

---

## 💡 Quick Reference

### Apicurio v3 API Endpoints
```
Base URL: https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3

Search:  GET /search/artifacts?name={query}
Get:     GET /artifacts/{artifactId}
Create:  POST /groups/{groupId}/artifacts
```

### Ключевые файлы
```
/lib/api.ts                         - Все Apicurio функции (2200-2450)
/components/DataCaptureSpecCreateDialog.tsx  - UI для создания specs
/components/DataSourcesView.tsx     - Data Source Onboarding view
/lib/apicurio.ts                    - Helper функции для Apicurio
```

### Console команды для debugging
```javascript
// Check Apicurio connection
fetch('https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/search/artifacts?name=Value')
  .then(r => r.json())
  .then(d => console.table(d.artifacts));

// Get specific artifact
fetch('https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/artifacts/bfs.QuoteDetails.json')
  .then(r => r.json())
  .then(d => console.log(JSON.stringify(d, null, 2)));
```

---

## 📞 Помощь и поддержка

### Если что-то не работает:

1. **Проверить консоль браузера** - все ошибки логируются с emoji icons
2. **Проверить Network tab** - увидеть actual API calls
3. **Проверить `/APICURIO-CORS-SOLUTION.md`** - решения для CORS
4. **Проверить `/СЛЕДУЮЩИЕ_ШАГИ_APICURIO_RU.md`** - раздел "Troubleshooting"

### Логи для отладки:
```
📡 = Начало API вызова
✅ = Успешное завершение
❌ = Ошибка
⚠️ = Предупреждение
🔄 = Fallback или retry
```

---

**Последнее обновление:** 27 ноября 2025  
**Следующая проверка:** После CORS тестирования  
**Ответственный:** Продолжить с Phase 1 тестирования
