# Role Testing Guide

## Overview

The BFS application now includes a **Role Testing** feature that allows developers and testers to quickly switch between different permission levels to see how the interface looks and behaves for each role.

## How to Access

1. Click on the **User Profile Icon** in the top right corner
2. In the dropdown menu, you'll see two action buttons:
   - **🔄 Change Role** - Opens the role testing dialog
   - **🚪 Log Out** - Signs out (redirects to `/.auth/logout` for Azure users)

## Role Testing Dialog

The "Change Role" dialog displays:

### Current Role
Shows your active role with a visual badge:
- **admin** (red badge) - Full access
- **edit** (blue badge) - Limited access
- **view** (gray badge) - Read-only

### Available Roles

You can switch to any of these roles for testing:

#### 1. **Admin (Portal.Admin)**
- 🛡️ **Icon**: Shield
- **Permissions**: Full access
  - ✓ View all data
  - ✓ Create new records
  - ✓ Edit existing records
  - ✓ Delete records

#### 2. **Editor (Portal.Editor)**
- ✏️ **Icon**: Edit
- **Permissions**: Limited access
  - ✓ View all data
  - ✗ Create new records (admin only)
  - ✓ Edit existing records
  - ✓ Delete records

#### 3. **Reader (Portal.Reader)**
- 👁️ **Icon**: Eye
- **Permissions**: View only
  - ✓ View all data
  - ✗ Create new records
  - ✗ Edit existing records
  - ✗ Delete records

## How It Works

### For Azure AD Users
1. Click on a role to test
2. The app temporarily overrides your role in localStorage
3. **The page will reload** to apply the changes
4. Your Azure AD role remains unchanged on the server
5. This is purely a frontend override for testing UI

### For Local Development Users
1. Click on a role to test
2. The app logs you in with the corresponding test credentials:
   - **Admin**: `admin` / `admin123`
   - **Editor**: `editor` / `edit123`
   - **Reader**: `viewer` / `view123`
3. No page reload needed
4. You're logged in as that user immediately

## Visual Indicators

### Role Selection UI
- **Current role** has a blue border and blue background
- **Hoverable roles** have a gray border that turns blue on hover
- Each role shows an icon, name, and description
- A "Current" badge appears on your active role

### User Menu
The dropdown menu shows:
- Username
- Email (for Azure users)
- Azure role (e.g., "Portal.Admin" for Azure users)
- Access level badge (colored by role)

## Testing Different UIs

After changing roles, you can test:

### Admin View
- "Create New Tenant" button visible
- All edit and delete actions available
- Full column configuration
- All import/export features

### Editor View
- "Create New Tenant" button **hidden**
- Edit and delete actions available
- Full column configuration
- Import/export features available

### Reader View
- "Create New Tenant" button **hidden**
- Edit and delete actions **disabled/hidden**
- View mode only
- Limited interaction

## Important Notes

⚠️ **Testing Only**: This feature is designed for UI/UX testing purposes only.

### For Developers
- Use this to verify that role-based permissions work correctly
- Test that buttons/actions are properly hidden or disabled
- Verify that UI responds appropriately to each role

### For Azure AD Users
- Changing roles here doesn't affect your actual Azure AD role
- This is a temporary frontend override
- The page will reload when you change roles
- Your real permissions remain unchanged on the backend

### For Security
- Backend API should **always** validate permissions server-side
- Don't rely solely on frontend role checks
- Frontend role switching is only for UI testing
- Real authorization happens on the backend

## Logout Process

### Azure AD Users
1. Click "Sign Out from Azure"
2. Local session is cleared
3. Redirected to `/.auth/logout`
4. Azure AD session is terminated
5. You'll need to log in again

### Local Users
1. Click "Log Out"
2. Local session is cleared
3. Login dialog appears
4. You can log in with any test credentials

## Use Cases

### 1. **UI/UX Verification**
```
1. Log in as Admin
2. Open "Change Role" dialog
3. Switch to "Reader"
4. Verify that create/edit/delete buttons are hidden
5. Switch back to Admin
6. Verify buttons reappear
```

### 2. **Permission Testing**
```
1. As Admin, create a new tenant
2. Switch to Editor role
3. Try to edit the tenant (should work)
4. Verify "Create" button is hidden
5. Switch to Reader
6. Verify you can only view data
```

### 3. **Stakeholder Demo**
```
1. Show Admin view with full features
2. Switch to Editor to show limited access
3. Switch to Reader to show view-only mode
4. Explain permission differences visually
```

## Troubleshooting

### Issue: Role didn't change
- **For Azure users**: Wait for the page to reload
- **For local users**: Check browser console for errors
- Clear localStorage and try again

### Issue: Page keeps reloading
- This is expected for Azure AD users
- The reload applies the role change
- Only happens once per role switch

### Issue: Can't switch roles
- Ensure you're not clicking on your current role (it's disabled)
- Check that JavaScript is enabled
- Try refreshing the page

## Technical Implementation

### Files
- `/components/UserMenu.tsx` - User profile dropdown with role switching
- `/components/RoleTestDialog.tsx` - Role selection dialog
- `/components/AuthContext.tsx` - Authentication and role management
- `/lib/azure-auth.ts` - Azure AD integration

### How It Works Internally

#### For Azure AD:
```typescript
// Temporarily override role in localStorage
const updatedUser = {
  ...user,
  role: 'edit',
  azureRole: 'Portal.Editor'
};
localStorage.setItem('bfs_user', JSON.stringify(updatedUser));
window.location.reload();
```

#### For Local:
```typescript
// Log in with test credentials
login('editor', 'edit123');
```

## Best Practices

1. **Always test all three roles** when implementing new features
2. **Verify both UI and backend** enforce permissions correctly
3. **Use consistent role naming** across frontend and backend
4. **Document permission requirements** for each feature
5. **Test edge cases** (e.g., switching roles mid-action)

## Example Workflow

```
Developer implementing a new feature:

1. Implement feature as Admin
2. Add role checks for button visibility
3. Test with "Change Role":
   - Switch to Editor → Verify expected behavior
   - Switch to Reader → Verify view-only mode
4. Test API calls with actual role permissions
5. Document which roles can access the feature
```

## Related Documentation

- [Azure AD Integration Guide](AZURE_AD_INTEGRATION.md)
- [Quick Reference](AZURE_AD_QUICK_REFERENCE.md)
- [API Documentation](API_CONNECTION_INFO.md)

## Support

For issues or questions about role testing:
1. Check browser console for errors
2. Verify localStorage contains `bfs_user` key
3. Clear cache and try again
4. Check that AuthContext is properly configured
