# Transactions View - Sidebar Layout

## ✅ Two-Column Layout with Sidebar

TransactionsView now has a **sidebar layout**: transaction list on the left, JSON details on the right.

---

## 🎯 New Layout

### Visual Structure:
```
┌─────────────────────────────────────────────────────────────────┐
│ ERP Transactions                                                 │
│ [Add New] [Refresh]                                             │
├──────────────────┬──────────────────────────────────────────────┤
│ SEARCH           │                                              │
│ [🔍 Filter...]   │                                              │
│                  │                                              │
│ TRANSACTIONS (16)│        CUSTOMER                             │
│ ┌──────────────┐│        Transaction ID: txn-1                │
│ │ Customer     ││        ┌────────────────────────────────┐   │
│ │ txn-1        ││        │ [Request] [Response]           │   │
│ └──────────────┘│        ├────────────────────────────────┤   │
│ ┌──────────────┐│        │ {                              │   │
│ │ Customer     ││        │   "type": "Customer",          │   │
│ │   Aging      ││        │   "action": "create",          │   │
│ │ txn-2        ││        │   "parameters": {              │   │
│ └──────────────┘│        │     ...                        │   │
│ ┌──────────────┐│        │   }                            │   │
│ │ Invoice      ││        │ }                              │   │
│ │ txn-3        ││        │                                │   │
│ └──────────────┘│        │                              ↓ │   │
│ ...              │        └────────────────────────────────┘   │
│                  │                                              │
│ (scrollable)     │        Created: 1/10/2025                   │
│                  │        ETag: "abc123..."                    │
└──────────────────┴──────────────────────────────────────────────┘
   350px wide          Flexible width
```

---

## 📊 Layout Details

### Left Column (350px):
```
┌──────────────────┐
│ Search           │
│ [🔍 Filter...]   │
│                  │
│ Transactions (16)│
│ ┌──────────────┐│
│ │ ✓ Customer   ││ ← Selected (blue)
│ │   txn-1      ││
│ └──────────────┘│
│ ┌──────────────┐│
│ │ Invoice      ││ ← Not selected (gray)
│ │ txn-2        ││
│ └──────────────┘│
│ ...              │
│                  │
│ (scrolls up to   │
│  600px height)   │
└──────────────────┘
```

**Features:**
- Fixed 350px width
- Search at top
- Badge shows count
- Scrollable list (600px height)
- Each button shows:
  - Transaction Name
  - Transaction ID (small, monospace)

### Right Column (Flexible):
```
┌────────────────────────────────────┐
│ Customer                           │
│ Transaction ID: txn-1              │
├────────────────────────────────────┤
│ [Request JSON] [Response JSON]     │
├────────────────────────────────────┤
│ {                                  │
│   "type": "Customer",              │
│   "action": "create",              │
│   ...                              │
│ }                                  │
│                                    │
│ (scrolls up to 500px height)     ↓ │
├────────────────────────────────────┤
│ Created: 1/10/2025                 │
│ ETag: "abc123..."                  │
└────────────────────────────────────┘
```

**Features:**
- Takes remaining width
- Tabs for Request/Response
- Scrollable JSON (500px height)
- Metadata at bottom

---

## 🎨 Responsive Behavior

### Desktop (> 1024px):
```css
grid-cols-[350px_1fr]
```
- Left: 350px fixed
- Right: Remaining space

### Tablet/Mobile (< 1024px):
```css
grid-cols-1
```
- Stack vertically
- Left column full width
- Right column full width
- Same functionality

---

## 🔍 Features

### Search:
- ✅ Filters transaction list
- ✅ Real-time filtering
- ✅ Clear button (X)
- ✅ Shows filtered count

### Transaction Buttons:
- ✅ Full-width clickable
- ✅ Two-line layout:
  - Line 1: Transaction Name (bold)
  - Line 2: Transaction ID (small, gray, mono)
- ✅ Selected state: Blue background
- ✅ Hover state: Gray background
- ✅ Auto-select first transaction

### JSON Display:
- ✅ Tabs: Request / Response
- ✅ Formatted JSON
- ✅ Scrollable (500px)
- ✅ Syntax wrapping
- ✅ Metadata below

---

## 💡 Benefits

### Better UX:
- ✅ No dropdown - see all transactions at once
- ✅ Quick switching - one click
- ✅ More screen space for JSON
- ✅ Natural left-to-right flow

### Efficient Navigation:
- ✅ Scan list visually
- ✅ Use search to filter
- ✅ Click to view instantly
- ✅ No dialog popups

### Professional Layout:
- ✅ Common sidebar pattern (like email, file explorer)
- ✅ Clean separation of list and details
- ✅ Looks like enterprise app

---

## 🧪 How to Use

### View Transaction:
```
1. See list on left
2. Click "Customer"
3. Details appear on right
```

### Search:
```
1. Type "inv" in search
2. List filters to "Invoice"
3. Click to view
```

### Switch Transaction:
```
1. Click "Payment" in list
2. Details update instantly
3. Previous selection deselected
```

### View Request/Response:
```
1. Select transaction
2. Request JSON shown by default
3. Click "Response JSON" tab
4. Switch back easily
```

---

## 🎨 Visual States

### Transaction Button States:

**Selected:**
```
┌──────────────────┐
│ Customer     ★   │ ← Blue background
│ txn-1            │    White text
└──────────────────┘
```

**Not Selected (Hover):**
```
┌──────────────────┐
│ Invoice          │ ← Light gray background
│ txn-2            │    Dark text
└──────────────────┘
```

**Not Selected (Normal):**
```
┌──────────────────┐
│ Payment          │ ← Transparent background
│ txn-3            │    Dark text
└──────────────────┘
```

---

## 📐 Grid Layout Code

```tsx
<div className="grid grid-cols-1 lg:grid-cols-[350px_1fr] gap-6">
  {/* Left Column */}
  <div className="space-y-4">
    {/* Search */}
    {/* Transaction List */}
  </div>
  
  {/* Right Column */}
  <div>
    {/* Transaction Details */}
  </div>
</div>
```

**Breakpoints:**
- `lg:` = 1024px and up → Two columns
- Below 1024px → Single column (stack)

---

## 🔧 Component Structure

```
TransactionsView
│
├─ Action Buttons
│  ├─ Add New Transaction
│  └─ Refresh
│
├─ Two Column Grid
│  │
│  ├─ Left Column (350px)
│  │  │
│  │  ├─ Search Field
│  │  │  ├─ Search icon
│  │  │  ├─ Input
│  │  │  └─ Clear button
│  │  │
│  │  └─ Transaction List Card
│  │     ├─ Header (count badge)
│  │     └─ ScrollArea (600px)
│  │        └─ Buttons (16)
│  │
│  └─ Right Column (flexible)
│     │
│     └─ Details Card
│        ├─ Header (name + ID)
│        ├─ Tabs
│        │  ├─ Request JSON
│        │  └─ Response JSON
│        └─ Metadata
```

---

## ✅ Testing

### Test 1: Initial Load
```
1. Open Transactions tab

Expected:
✅ Left: List of 16 transactions
✅ "Customer" selected (blue)
✅ Right: Customer JSON showing
```

### Test 2: Click Transaction
```
1. Click "Invoice" in left list

Expected:
✅ "Invoice" becomes blue
✅ "Customer" becomes gray
✅ Right side updates to Invoice JSON
✅ Instant update
```

### Test 3: Search
```
1. Type "pay" in search

Expected:
✅ List filters to "Payment"
✅ Badge shows "1 of 16"
✅ Click to view
```

### Test 4: Scroll List
```
1. Scroll in left panel

Expected:
✅ List scrolls smoothly
✅ Up to 600px
✅ Right side stays in place
```

### Test 5: Scroll JSON
```
1. Scroll in right panel JSON

Expected:
✅ JSON scrolls
✅ Up to 500px
✅ Left side stays in place
```

### Test 6: Tabs
```
1. Click "Response JSON"

Expected:
✅ Tab switches
✅ Response JSON appears
✅ Same transaction selected
```

### Test 7: Responsive
```
1. Resize browser to < 1024px

Expected:
✅ Columns stack vertically
✅ Search on top
✅ List below
✅ Details below list
```

---

## 🎯 Summary

**Changed from:**
- Dropdown selector → Sidebar list

**New layout:**
- Left: Transaction list (350px, scrollable)
- Right: JSON details (flexible width)

**Benefits:**
- See all transactions at once
- Quick visual scanning
- Professional sidebar pattern
- More space for JSON
- Faster navigation

**Perfect for managing multiple transactions!** 🎉
