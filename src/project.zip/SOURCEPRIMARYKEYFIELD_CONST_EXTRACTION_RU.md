# ✅ Исправление извлечения sourcePrimaryKeyField из JSON схем

## Проблема
При создании Data Capture Specifications поле `sourcePrimaryKeyField` генерировалось автоматически из имени спецификации (например, `workflowCustomerId`), игнорируя значение, определенное в JSON схеме через `const`.

## JSON Schema структура
В Apicurio Registry схемах поле `sourcePrimaryKeyField` может быть определено следующим образом:

```json
{
  "properties": {
    "Txn": {
      "properties": {
        "metaData": {
          "properties": {
            "sources": {
              "type": "array",
              "items": {
                "properties": {
                  "sourcePrimaryKeyField": {
                    "type": "string",
                    "const": "incode"  // ← Фиксированное значение
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
```

## Решение
Добавлена функция `extractSourcePrimaryKeyField`, которая:

1. **Проверяет обе структуры схем:**
   - Nested (BFS Online): `schema.properties.Txn.properties.metaData`
   - Flat (Bid Tools): `schema.properties.metaData`

2. **Навигация к полю:**
   ```typescript
   metaData.properties.sources.items.properties.sourcePrimaryKeyField
   ```

3. **Извлекает значение из `const`:**
   ```typescript
   if (sourcePrimaryKeyField.const) {
     return sourcePrimaryKeyField.const;  // "incode"
   }
   ```

4. **Fallback к автогенерации:**
   ```typescript
   sourcePrimaryKeyField: extractedPrimaryKeyField || primaryKeyField
   ```

## Логика приоритета
```typescript
// 1. Если найдено const значение - используем его
extractedPrimaryKeyField = "incode"  // из schema.const

// 2. Иначе генерируем из имени спецификации
primaryKeyField = "workflowCustomerId"  // из specName

// 3. Результат
sourcePrimaryKeyField = extractedPrimaryKeyField || primaryKeyField
```

## Debug логи
```typescript
console.log('✅ Found sourcePrimaryKeyField.const:', sourcePrimaryKeyField.const);
console.log('🔍 Extracted sourcePrimaryKeyField:', extractedPrimaryKeyField);
```

## Файлы
- **Изменен:** `/components/DataCaptureSpecCreateDialog.tsx`
- **Функция:** `extractSourcePrimaryKeyField()` (строки 212-235)
- **Использование:** строка 293

## Тестирование
1. Откройте Data Source Onboarding
2. Выберите Data Source и нажмите "Create Spec"
3. Выберите BFS Online Template (например, с `const: "incode"`)
4. Проверьте консоль браузера:
   ```
   ✅ Found sourcePrimaryKeyField.const: incode
   🔍 Extracted sourcePrimaryKeyField: incode
   ```
5. Убедитесь, что поле "Source Primary Key Field" автоматически заполнено значением `incode`

## Совместимость
✅ Bid Tools Templates (flat structure) - работает  
✅ BFS Online Templates (nested structure) - работает  
✅ Schemas без const значения - fallback к автогенерации  
✅ Существующие спецификации - не затронуты  

## Примеры значений
| Schema Type | Const Value | Generated Value | Final Value |
|-------------|-------------|-----------------|-------------|
| BFS Online CDC | `incode` | `workflowCustomerId` | `incode` ✅ |
| Bid Tools | `stcode` | `quotePackId` | `stcode` ✅ |
| Custom | (нет) | `reasonCodeId` | `reasonCodeId` ✅ |

## Статус
🟢 **Готово** - Извлечение sourcePrimaryKeyField из const работает корректно для обеих структур схем