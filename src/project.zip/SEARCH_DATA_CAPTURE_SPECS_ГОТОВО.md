# Поиск в Data Capture Specifications - Готово ✅

## Что было добавлено

Добавлены поля поиска для левой колонки (Models) и правой таблицы (Specifications) в разделе Data Capture Specifications.

## Изменения

### 1. Добавлены state переменные для поиска

```tsx
const [modelSearch, setModelSearch] = useState('');
const [specificationSearch, setSpecificationSearch] = useState('');
```

### 2. Добавлена фильтрация моделей

```tsx
// Filter models by search
const filteredModels = models.filter(model => 
  model.toLowerCase().includes(modelSearch.toLowerCase())
);
```

### 3. Добавлена фильтрация спецификаций

```tsx
// Filter specifications by search
const searchFilteredSpecs = filteredSpecs.filter(spec => 
  spec.modelSchemaId.toLowerCase().includes(specificationSearch.toLowerCase()) ||
  spec.model.toLowerCase().includes(specificationSearch.toLowerCase()) ||
  spec.semver.toLowerCase().includes(specificationSearch.toLowerCase()) ||
  spec.tenantId.toLowerCase().includes(specificationSearch.toLowerCase()) ||
  spec.tenantName.toLowerCase().includes(specificationSearch.toLowerCase()) ||
  spec.dataSourceName.toLowerCase().includes(specificationSearch.toLowerCase())
);
```

### 4. Добавлено поле поиска над левой колонкой

```tsx
<div className="space-y-2">
  <div className="relative">
    <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
    <Input
      placeholder="Search models..."
      value={modelSearch}
      onChange={(e) => setModelSearch(e.target.value)}
      className="pl-9 h-9"
    />
  </div>
  <Card className="border-2">
    {/* Models list */}
  </Card>
</div>
```

### 5. Добавлено поле поиска над правой таблицей

```tsx
<div className="min-w-0 space-y-2">
  <div className="relative">
    <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
    <Input
      placeholder="Search specifications..."
      value={specificationSearch}
      onChange={(e) => setSpecificationSearch(e.target.value)}
      className="pl-9 h-9"
    />
  </div>
  <div className="border rounded-lg overflow-x-auto">
    {/* Table */}
  </div>
</div>
```

### 6. Добавлены empty states

**Для моделей:**
```tsx
{filteredModels.length > 0 ? (
  // Models list
) : (
  <div className="text-center py-8 text-xs text-muted-foreground">
    No models found
  </div>
)}
```

**Для спецификаций:**
```tsx
{searchFilteredSpecs.length > 0 ? (
  // Table rows
) : (
  <tr>
    <td colSpan={7} className="text-center py-8 text-sm text-muted-foreground">
      No specifications found
    </td>
  </tr>
)}
```

### 7. Добавлен импорт SearchIcon

```tsx
import { SearchIcon } from './icons/SearchIcon';
```

## Функциональность

### Левая колонка (Models)
- ✅ Поиск по названию модели (Quote, Customer, Location и т.д.)
- ✅ Регистронезависимый поиск
- ✅ Empty state когда ничего не найдено

### Правая таблица (Specifications)
- ✅ Поиск по всем колонкам:
  - Model Schema ID
  - Model
  - Version
  - Tenant ID
  - Tenant Name
  - Data Source Name
- ✅ Регистронезависимый поиск
- ✅ Empty state когда ничего не найдено

## Улучшения UX

1. **Визуальная иерархия** - поисковые поля выравнены с соответствующими секциями
2. **Единообразие** - стиль поиска совпадает с другими компонентами приложения
3. **Мгновенный отклик** - фильтрация происходит в реальном времени при вводе
4. **Понятные placeholder-ы** - "Search models..." и "Search specifications..."
5. **Icon в поле поиска** - SearchIcon для визуальной подсказки

## Скриншот структуры

```
Data Capture Specifications                 [+ Add Specification]
┌─────────────────────┬──────────────────────────────────────────┐
│ [Search models...] │ [Search specifications...]               │
│ ┌─────────────────┐ │ ┌──────────────────────────────────────┐ │
│ │ Quote           │ │ │ Model Schema ID | Model | Version ... │ │
│ │                 │ │ │ Quote:1        | Quote | 1.0.0    ... │ │
│ │                 │ │ │ Quote:2        | Quote | 2.0.0    ... │ │
│ │                 │ │ │ Quote:3        | Quote | 3.0.0    ... │ │
│ └─────────────────┘ │ └──────────────────────────────────────┘ │
└─────────────────────┴──────────────────────────────────────────┘
```

## Тестирование

### Как протестировать:
1. Откройте вкладку "Data Source Onboarding"
2. Разверните любой Data Source (например, "Bidtools")
3. В разделе "Data Capture Specifications" увидите два поля поиска:
   - Слева над списком моделей
   - Справа над таблицей спецификаций
4. Введите текст в поле поиска моделей - список фильтруется
5. Введите текст в поле поиска спецификаций - таблица фильтруется
6. Попробуйте очистить поля - все элементы вернутся

### Примеры поиска:
- **Модели:** "quote", "Quo", "QUOTE" (регистр не важен)
- **Спецификации:** "Quote:1", "tenant-1", "Bidtools", "1.0.0"

## Результат

✅ Левая колонка имеет поиск моделей
✅ Правая таблица имеет поиск спецификаций  
✅ Поля выровнены на одном уровне
✅ Empty states добавлены
✅ Фильтрация работает в реальном времени
✅ Код чистый и понятный
