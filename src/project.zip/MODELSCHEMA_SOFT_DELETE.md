# 🔄 Model Schema Soft Delete Implementation

## ✅ Status: IMPLEMENTED

Model Schema теперь использует **soft delete** вместо hard delete.

## 🎯 Problem

```
❌ Error: "Unsupported TxnType" when trying to DELETE ModelSchema
```

**Root Cause**: API не поддерживает hard delete для ModelSchema (это правильное поведение для схем данных).

## 💡 Solution: Soft Delete

Вместо физического удаления, схема помечается как `state: "deleted"`.

### **Workflow**

```
┌─────────────────────────────────────────────────────────────┐
│ 1. User Clicks Delete Button                               │
└─────────────────────┬───────────────────────────────────────┘
                      ↓
┌─────────────────────────────────────────────────────────────┐
│ 2. Try: DELETE /txns/ModelSchema:Location:1                │
│    Response: 400 "Unsupported TxnType"                     │
└─────────────────────┬───────────────────────────────────────┘
                      ↓
┌─────────────────────────────────────────────────────────────┐
│ 3. Fallback: Soft Delete                                   │
│    - GET current schema data                               │
│    - Update with state: "deleted"                          │
│    - PUT /txns/ModelSchema:Location:1                      │
└─────────────────────┬───────────────────────────────────────┘
                      ↓
┌─────────────────────────────────────────────────────────────┐
│ 4. Success!                                                 │
│    - Schema marked as deleted in database                  │
│    - UI filters out deleted schemas                        │
│    - User sees schema removed from table                   │
└─────────────────────────────────────────────────────────────┘
```

## 🔧 Implementation

### **1. API Layer (`/lib/api.ts`)**

```typescript
export async function deleteModelSchema(schemaId: string, etag: string): Promise<void> {
  try {
    // Try hard delete first
    const response = await fetch(`${API_BASE_URL}/txns/${txnId}`, {
      method: "DELETE",
      headers: getHeaders(etag),
    });

    if (!response.ok) {
      const errorData = await response.json();
      
      // If "Unsupported TxnType", do soft delete instead
      if (errorData.status?.message === 'Unsupported TxnType') {
        console.log('ℹ️ Hard delete not supported, trying soft delete');
        
        // 1. Get current schema
        const getCurrentResponse = await fetch(
          `${API_BASE_URL}/txns/${txnId}`,
          { method: "GET" }
        );
        const currentData = await getCurrentResponse.json();
        
        // 2. Extract id WITHOUT the "ModelSchema:" prefix
        // Example: "ModelSchema:Location:1" -> "Location:1"
        const idWithoutPrefix = txnId.replace(/^ModelSchema:/, '');
        
        // 3. Update with state: "deleted"
        const updatedSchema = {
          ...currentData.data.Txn,
          id: idWithoutPrefix, // Use id WITHOUT prefix
          state: "deleted",
        };
        
        // 4. PUT to mark as deleted
        await fetch(`${API_BASE_URL}/txns/${txnId}`, {
          method: "PUT",
          headers: getHeaders(etag),
          body: JSON.stringify({
            TxnType: "ModelSchema",
            Txn: updatedSchema,
          }),
        });
        
        console.log('✅ Model schema soft deleted');
        return;
      }
      
      throw new Error(errorData.status?.message);
    }
  } catch (error) {
    console.error("deleteModelSchema error:", error);
    throw error;
  }
}
```

### **2. UI Layer (`/components/ModelSchemaView.tsx`)**

```typescript
// Filter out deleted schemas when loading
const loadGlobalSchemas = async () => {
  const schemas = await getAllModelSchemas();
  
  // Hide deleted schemas
  const activeSchemas = schemas.filter(s => s.state !== 'deleted');
  
  setGlobalSchemas(activeSchemas);
};

// Badge for deleted state (if shown)
const getStateBadge = (state: string) => {
  switch (state.toLowerCase()) {
    case 'active':
      return <Badge className="bg-green-600">Active</Badge>;
    case 'deleted':
      return <Badge className="bg-gray-300 text-gray-600">Deleted</Badge>;
    // ...
  }
};
```

## 📊 Comparison: Hard vs Soft Delete

| Aspect | Hard Delete | Soft Delete (Implemented) |
|--------|-------------|---------------------------|
| **Database** | Row removed | Row kept with `state: "deleted"` |
| **API Support** | ❌ Not supported | ✅ Supported (via PUT) |
| **Reversible** | ❌ No | ✅ Yes (change state back) |
| **Data Integrity** | ⚠️ May break references | ✅ Maintains references |
| **Audit Trail** | ❌ Lost | ✅ Preserved |
| **Best Practice** | ❌ Not for schemas | ✅ Recommended for schemas |

## 🎨 User Experience

### **Before (Error)**
```
User clicks Delete
→ ❌ Error: "Unsupported TxnType"
→ Schema still visible
→ User confused
```

### **After (Soft Delete)**
```
User clicks Delete
→ ℹ️ Console: "Hard delete not supported, trying soft delete"
→ ✅ Success: "Model schema deleted successfully"
→ Schema disappears from table
→ Happy user! 🎉
```

## 🔍 Console Output

### **Successful Soft Delete**
```
🗑️ DELETE Model Schema Request:
  SchemaId: Location:1
  TxnId: ModelSchema:Location:1
  URL: https://api.../txns/ModelSchema:Location:1
  ETag: "12345..."

📥 Response status: 400 Bad Request
❌ Error response: {"status":{"code":400,"message":"Unsupported TxnType"},"data":{}}

ℹ️ Hard delete not supported, trying soft delete (state: "deleted")
📝 Soft delete: updating state to "deleted"
✅ Model schema soft deleted (state: "deleted")
```

## 🧪 Testing

### **Test Scenario**

1. **Open Model Schema tab**
2. **Click Delete on any schema** (e.g., Location:1)
3. **Confirm deletion**
4. **Expected Results**:
   - ✅ Console shows soft delete fallback message
   - ✅ Success toast appears
   - ✅ Schema disappears from table
   - ✅ Table auto-refreshes
   - ✅ Schema has `state: "deleted"` in database

### **Verify in API**

```bash
# GET request to see all schemas (including deleted)
GET /txns?TxnType=ModelSchema

# Response will include:
{
  "TxnId": "ModelSchema:Location:1",
  "Txn": {
    "model": "Location",
    "version": 1,
    "state": "deleted",  ← Marked as deleted
    ...
  }
}
```

## 🔮 Future Enhancements

Возможные улучшения:

1. **Show Deleted Schemas**
   ```typescript
   const [showDeleted, setShowDeleted] = useState(false);
   
   const visibleSchemas = schemas.filter(s => 
     showDeleted || s.state !== 'deleted'
   );
   ```

2. **Restore Deleted Schemas**
   ```typescript
   const restoreSchema = async (schemaId: string) => {
     await updateModelSchema(schemaId, {
       ...currentData,
       state: "active"  // Change back to active
     }, etag);
   };
   ```

3. **Bulk Delete**
   ```typescript
   const deleteMultipleSchemas = async (schemaIds: string[]) => {
     await Promise.all(
       schemaIds.map(id => deleteModelSchema(id, etag))
     );
   };
   ```

4. **Permanent Delete** (with confirmation)
   - Only for SuperUser role
   - Requires double confirmation
   - Shows warning about breaking references

## ✅ Benefits of Soft Delete

1. **Data Safety**: Schemas never permanently lost
2. **Reversible**: Can be restored if deleted by mistake
3. **Audit Trail**: History of all schemas maintained
4. **Data Integrity**: References to schemas don't break
5. **Best Practice**: Industry standard for schema management

## 📝 Notes

- Soft delete is the **correct approach** for ModelSchema
- Hard delete would break data integrity for transactions referencing the schema
- UI automatically hides deleted schemas for clean UX
- Deleted schemas can be restored through API if needed
- SuperUser can potentially see deleted schemas in future update

---

**Status**: Production Ready ✅  
**Last Updated**: Oct 29, 2025
