# Тестирование Quote API - Быстрый Старт

## 🎯 Цель
Проверить полный CRUD функционал для Quote транзакций через BFS API.

## 📋 Методы Тестирования

### Метод 1: HTML Тестер (Рекомендуется)
1. Откройте файл `/test-quote-api.html` в браузере
2. Используйте интерфейс для тестирования всех операций:
   - **Create** - создание Quote с автогенерацией ID
   - **Get All** - получение списка всех Quote
   - **Get One** - получение конкретной Quote по ID
   - **Update** - обновление существующей Quote
   - **Delete** - удаление Quote

**Преимущества:**
- Визуальный интерфейс
- Автоматическое заполнение полей
- Цветной вывод результатов
- Подставка созданных ID в другие операции

### Метод 2: В Приложении
1. Запустите приложение (`npm run dev`)
2. Перейдите на вкладку **Data Plane**
3. Выберите **Quote** в выпадающем списке типов транзакций
4. Нажмите **Create New Transaction** (кнопка Plus)
5. Используйте предзаполненный шаблон:

```json
{
  "quoteId": "QUOTE-1730187533596",
  "customerId": null,
  "customerRequestedByDate": "2025-11-28T00:00:00.000Z",
  "exportNotes": "Quote notes",
  "categories": [
    {
      "categoryId": "35",
      "name": null,
      "description": null
    },
    {
      "categoryId": "37",
      "name": null,
      "description": null
    }
  ],
  "accountNumber": "579237",
  "erpUserId": "ONLINE",
  "isPublished": false
}
```

6. Измените `quoteId` на уникальное значение
7. Нажмите **Create Transaction**
8. Проверьте toast уведомление об успехе
9. Обновите список - должна появиться новая Quote

### Метод 3: Консоль Браузера
Откройте DevTools Console (F12) и выполните:

```javascript
// Создание Quote
fetch('https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/txns', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'X-BFS-Auth': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
  },
  body: JSON.stringify({
    TxnType: "Quote",
    Txn: {
      quoteId: "test-quote-" + Date.now(),
      customerRequestedByDate: "2025-07-25T00:00:00.000Z",
      exportNotes: "Тестовая цитата",
      categories: [
        { categoryId: "35", name: null, description: null },
        { categoryId: "37", name: null, description: null }
      ],
      accountNumber: "579237",
      erpUserId: "ONLINE"
    }
  })
})
.then(r => r.json())
.then(data => {
  console.log('✓ Quote создана:', data);
  console.log('Quote ID:', data.data?.Txn?.quoteId);
})
.catch(err => console.error('✗ Ошибка:', err));
```

## ✅ Чеклист Проверки

### Создание (CREATE)
- [ ] Quote создается с валидными данными
- [ ] API возвращает статус 201 Created
- [ ] Ответ содержит все поля канонической модели
- [ ] `quoteId` сохраняется корректно
- [ ] `createTime` и `updateTime` установлены
- [ ] `_etag` присутствует в ответе

### Получение Списка (GET ALL)
- [ ] GET `/txns?TxnType=Quote` возвращает массив Quote
- [ ] Формат ответа: `{status: {...}, data: {TxnType: "Quote", Txns: [...]}}`
- [ ] Все созданные Quote присутствуют в списке
- [ ] TxnId формируется в формате "Quote:quoteId"

### Получение Одной (GET ONE)
- [ ] GET `/txns/Quote:quoteId` возвращает конкретную Quote
- [ ] Все поля присутствуют
- [ ] Данные совпадают с созданными

### Обновление (UPDATE)
- [ ] PUT `/txns/Quote:quoteId` обновляет Quote
- [ ] Изменения сохраняются (например, `exportNotes`, `isPublished`)
- [ ] `updateTime` обновляется
- [ ] `_etag` изменяется

### Удаление (DELETE)
- [ ] DELETE `/txns/Quote:quoteId` удаляет Quote
- [ ] Quote исчезает из списка
- [ ] Попытка GET удаленной Quote возвращает ошибку 404

## 📊 Формат Ответа API

### Успешное Создание
```json
{
  "status": {
    "code": 201,
    "message": "Created"
  },
  "data": {
    "TxnType": "Quote",
    "Txn": {
      "quoteId": "test-quote-1730187533",
      "customerId": null,
      "isPublished": null,
      "exportNotes": "Quote notes",
      "customerRequestedByDate": "2025-11-28T00:00:00+00:00",
      "categories": [...],
      "accountNumber": "579237",
      "erpUserId": "ONLINE",
      "createTime": "2025-10-29T07:38:53.596946",
      "updateTime": "2025-10-29T07:38:53.596946",
      "_etag": "\"2f001495-0000-0100-0000-6901c48d0000\"",
      "_ts": 1761723533,
      // ... множество других полей из канонической модели
    }
  }
}
```

## 🐛 Отладка

### Проверка Логов в Консоли
В приложении при создании Quote вы увидите:
```
POST Transaction Request:
  URL: https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/txns
  Headers: {Content-Type: 'application/json', X-BFS-Auth: '...'}
  Body: {TxnType: "Quote", Txn: {...}}

Response received:
  Status: 201 Created

Created transaction: {TxnId: "Quote:test-quote-1", ...}
```

### Типичные Ошибки

#### "quoteId is required"
- Убедитесь, что поле `quoteId` заполнено и уникально

#### "Unsupported TxnType"
- Проверьте, что API поддерживает Quote (должен быть включен на стороне txservices)

#### CORS Error
- Убедитесь, что браузер не блокирует запросы
- HTML тестер обходит CORS через прямые fetch запросы

#### 404 Not Found при GET
- Проверьте формат TxnId: должен быть "Quote:quoteId"
- Убедитесь, что Quote существует

## 🔍 Проверка Трансформации Данных

Приложение автоматически трансформирует API ответ:

**API возвращает:**
```json
{
  "data": {
    "Txns": [
      {"quoteId": "Q1", "exportNotes": "..."}
    ]
  }
}
```

**Приложение преобразует в:**
```json
[
  {
    "TxnId": "Quote:Q1",
    "TxnType": "Quote",
    "Txn": {"quoteId": "Q1", "exportNotes": "..."},
    "CreateTime": "...",
    "_etag": "..."
  }
]
```

Это гарантирует единообразие с другими типами транзакций (Customer, Location).

## 📝 Следующие Шаги

После успешного тестирования Quote:
1. ✅ Проверьте ReasonCode (аналогичный процесс)
2. ⏳ Ждите включения QuotePacks, QuoteDetails на стороне API
3. ⏳ Протестируйте compose функциональность
4. ⏳ Проверьте связи Quote с Customer и Location

## 📚 Дополнительная Документация
- [QUOTE_TESTING_GUIDE.md](/QUOTE_TESTING_GUIDE.md) - Полное руководство на английском
- [TRANSACTION_CREATE_JSON_GUIDE_RU.md](/TRANSACTION_CREATE_JSON_GUIDE_RU.md) - Создание транзакций
- [API_EXAMPLES.md](/API_EXAMPLES.md) - Примеры API запросов
