# Applications - Тестовые данные обновлены

## Что изменено

### 1. Обновлены тестовые данные приложений

Заменили старые данные (Bidtools, Databricks) на новые:

```typescript
const mockApplications: Application[] = [
  {
    ApplicationId: 'app-001',
    ApplicationName: 'myBLDR',
    Version: '1.0',
    CreateTime: '2025-10-30T00:00:00Z',  // 10/30/2025
    ...
  },
  {
    ApplicationId: 'app-002',
    ApplicationName: 'Will Call',
    Version: '2.1',
    CreateTime: '2025-10-31T00:00:00Z',  // 10/31/2025
    ...
  },
];
```

### 2. Обновлены колонки таблицы

Теперь отображаются следующие колонки (как на скриншоте):

| Application | Version | Date       | Action          |
|-------------|---------|------------|-----------------|
| myBLDR      | 1.0     | 10/30/2025 | View/Edit/Delete|
| Will Call   | 2.1     | 10/31/2025 | View/Edit/Delete|

**Дефолтные колонки:**
```typescript
const getDefaultColumns = (): ColumnConfig[] => [
  { key: 'ApplicationName', label: 'Application', enabled: true, locked: true },
  { key: 'Version', label: 'Version', enabled: true },
  { key: 'CreateTime', label: 'Date', enabled: true },
  // Остальные скрыты по умолчанию
];
```

### 3. Добавлено форматирование даты

Создана функция `formatCellValue` которая:
- Форматирует даты как `MM/DD/YYYY` (например: 10/30/2025)
- Показывает статусы как Badge
- Обрабатывает пустые значения как `—`

```typescript
const formatCellValue = (value: any, key: string): React.ReactNode => {
  if (key === 'CreateTime' || key === 'UpdateTime') {
    const date = new Date(value);
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const year = date.getFullYear();
    return `${month}/${day}/${year}`;
  }
  // ...
};
```

### 4. Обновлен заголовок

Изменен с "Applications" на "Application Onboarding:" (как на скриншоте)

```typescript
<CardTitle className="flex items-center gap-2 text-[18px]">
  Application Onboarding:
</CardTitle>
```

### 5. Обновлены Transaction Specifications

Для каждого приложения добавлены соответствующие спецификации:

**myBLDR:**
- Quotes (1.0, 10/30/2025)
- Customers (1.0, 10/30/2025)

**Will Call:**
- Orders (2.1, 10/31/2025)
- Inventory (2.1, 10/31/2025)

### 6. Обновлена версия localStorage

Версия изменена с `'1'` на `'2'` чтобы сбросить старые настройки колонок.

## Отображение в UI

### Главная таблица:
```
Application Onboarding:

+-------------+---------+------------+------------------+
| Application | Version | Date       | Action           |
+-------------+---------+------------+------------------+
| myBLDR      | 1.0     | 10/30/2025 | View/Edit/Delete |
| Will Call   | 2.1     | 10/31/2025 | View/Edit/Delete |
+-------------+---------+------------+------------------+
```

### Actions (в каждой строке):
- **View** - просмотр деталей приложения
- **Edit** - редактирование названия
- **Delete** - удаление приложения

### Expandable Row (Transaction Specifications):
При раскрытии строки показываются спецификации транзакций для этого приложения.

## Проверка

### Что нужно проверить:
1. ✅ Таблица показывает колонки: Application, Version, Date, Action
2. ✅ myBLDR - версия 1.0, дата 10/30/2025
3. ✅ Will Call - версия 2.1, дата 10/31/2025
4. ✅ Даты отформатированы как MM/DD/YYYY
5. ✅ Заголовок "Application Onboarding:"
6. ✅ Кнопка "+ Add Application" доступна для superuser/admin/developer
7. ✅ Actions (View/Edit/Delete) работают корректно

## Результат

Вкладка Applications теперь соответствует скриншоту с тестовыми данными:
- 📱 myBLDR (v1.0) - 10/30/2025
- 📞 Will Call (v2.1) - 10/31/2025
