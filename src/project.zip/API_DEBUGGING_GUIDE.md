# 🔍 API Debugging Guide

## ✅ Changes Made

### 1. Auto-load on Start
- App now automatically loads tenants when in Live API mode
- Shows success/info toast with tenant count

### 2. Enhanced Logging
All API calls now log to browser console (F12):
```
🌐 Fetching tenants from: https://poc-apis-bfs.azurewebsites.net/1.0/tenants
📡 Response status: 200 OK
📦 Raw API Response: {"data":{"tenants":[...]}}
📊 Parsed API Response: {...}
✅ Extracted tenants: 5
```

### 3. Flexible Response Parsing
Now supports multiple API response formats:
- `[...]` - Direct array
- `{ data: { tenants: [...] } }` - Standard format
- `{ data: [...] }` - Data as array
- `{ tenants: [...] }` - Simple object
- `{ value: [...] }` - Azure API format

## 🧪 Debugging Steps

### Step 1: Open Browser Console
Press `F12` or `Ctrl+Shift+I` (Windows/Linux) or `Cmd+Option+I` (Mac)

### Step 2: Check Console Logs
Look for:
```
🌐 Fetching tenants from: ...
📡 Response status: ...
📦 Raw API Response: ...
```

### Step 3: Identify the Issue

#### ✅ Success (200 OK)
```
📡 Response status: 200 OK
✅ Extracted tenants: 5
```
**Result**: Tenants should appear in UI

#### ❌ Error 401 (Unauthorized)
```
📡 Response status: 401 Unauthorized
```
**Fix**: Check API key in `/lib/api.ts` line 5-6

#### ❌ Error 404 (Not Found)
```
📡 Response status: 404 Not Found
```
**Fix**: Check API URL in `/lib/api.ts` line 2-3

#### ❌ CORS Error
```
Access to fetch at 'https://...' has been blocked by CORS policy
```
**Fix**: API server must enable CORS for your domain

#### ❌ Empty Response
```
📡 Response status: 200 OK
✅ Extracted tenants: 0
```
**Result**: No tenants in database yet
**Action**: Import from Postman Collection

## 📊 Expected API Response Format

The API should return one of these formats:

### Format 1: Standard (Recommended)
```json
{
  "status": {
    "code": 200,
    "message": "Success"
  },
  "data": {
    "tenants": [
      {
        "TenantId": "tenant-1",
        "TenantName": "Company A",
        "_etag": "\"abc123\"",
        "CreateTime": "2025-01-01T00:00:00Z",
        "UpdateTime": "2025-01-01T00:00:00Z"
      }
    ]
  }
}
```

### Format 2: Simple Array
```json
[
  {
    "TenantId": "tenant-1",
    "TenantName": "Company A"
  }
]
```

### Format 3: Data Array
```json
{
  "data": [
    {
      "TenantId": "tenant-1",
      "TenantName": "Company A"
    }
  ]
}
```

## 🛠️ Common Fixes

### Fix 1: Wrong API Key
```typescript
// /lib/api.ts line 5-6
const AUTH_HEADER_VALUE =
  "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855";
```

### Fix 2: Wrong API URL
```typescript
// /lib/api.ts line 2-3
const API_BASE_URL =
  "https://poc-apis-bfs.azurewebsites.net/1.0";
```

### Fix 3: CORS Issue
Contact API administrator to add your domain to allowed origins

### Fix 4: Network Issue
- Check internet connection
- Verify API server is running
- Try accessing API URL directly in browser

## 🔄 Testing Workflow

1. **Open Console** (F12)
2. **Refresh Page** (Ctrl+R)
3. **Check Logs**:
   - Look for `🌐 Fetching tenants...`
   - Check response status
   - See extracted count
4. **If Error**: Read error message in console
5. **If Empty**: Import from Postman Collection

## ✅ Success Indicators

You'll know it's working when you see:
1. ✅ Console shows `200 OK`
2. ✅ Console shows `Extracted tenants: X` (X > 0)
3. ✅ Toast shows "Loaded X tenant(s) from API"
4. ✅ Tenants appear in table

## 📝 Reporting Issues

If you see an error, provide:
1. Console screenshot (F12)
2. Full error message
3. Network tab details (F12 → Network → tenants request)
4. Response preview from Network tab

---

**Current Status**: 
- ✅ API configured
- ✅ Enhanced logging added
- ✅ Auto-load enabled
- ✅ Ready to debug

**Next Step**: Open console (F12) and refresh page to see logs!
