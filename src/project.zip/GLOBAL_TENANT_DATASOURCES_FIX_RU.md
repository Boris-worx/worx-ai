# Исправление отображения Data Sources для Global Tenant

## Проблема

При фильтрации по GLOBAL TENANT пользователь не видел data sources из других тенантов. Например, data source "check-delete" (принадлежащий тенанту BFS) был виден при фильтрации по BFS, но не был виден при фильтрации по GLOBAL TENANT.

### Ожидаемое поведение
- **GLOBAL TENANT** должен видеть ВСЕ data sources из ВСЕХ тенантов
- **Конкретный тенант** (например, BFS) должен видеть только свои data sources

## Причина проблемы

В файле `/App.tsx` функция `refreshDataSources()` делала следующее:

```typescript
// Старый код
const tenantIdFilter = activeTenantId !== 'global' ? activeTenantId : undefined;
const dataSourcesData = await getAllDataSources(tenantIdFilter);
```

Когда `activeTenantId === 'global'`, передавался `undefined`, что означало запрос к API БЕЗ фильтра. Однако BFS API при запросе без фильтра `?Filters={"TenantId":"..."}` НЕ возвращает data sources из всех тенантов - он возвращает только те, которые не имеют TenantId или являются глобальными.

## Решение

Изменена логика загрузки data sources для глобального тенанта:

### 1. Изменена функция `refreshDataSources()` в `/App.tsx`

```typescript
// Новый код
if (activeTenantId === 'global') {
  // Для глобального тенанта, загружаем data sources из ВСЕХ тенантов и объединяем их
  console.log('📡 Fetching data sources for GLOBAL tenant (all tenants)...');
  
  // Получаем data sources для каждого тенанта
  const promises = tenants.map(async (tenant) => {
    try {
      const tenantDataSources = await getAllDataSources(tenant.TenantId);
      console.log(`✅ Loaded ${tenantDataSources.length} data sources for tenant ${tenant.TenantId}`);
      return tenantDataSources;
    } catch (error) {
      console.error(`❌ Failed to load data sources for tenant ${tenant.TenantId}:`, error);
      return [];
    }
  });
  
  // Ждем завершения всех запросов
  const results = await Promise.all(promises);
  allDataSources = results.flat();
  
  console.log(`✅ Total data sources from all tenants: ${allDataSources.length}`);
} else {
  // Для конкретного тенанта, загружаем только его data sources
  allDataSources = await getAllDataSources(activeTenantId);
  console.log(`✅ Loaded ${allDataSources.length} data sources for tenant ${activeTenantId}`);
}
```

### 2. Исправлена последовательность загрузки данных

Изменены useEffect хуки для правильной последовательности:

```typescript
// Сначала загружаем тенанты
useEffect(() => {
  refreshTenants();
}, []);

// Затем загружаем data sources когда тенанты уже загружены
useEffect(() => {
  if (activeTenantId && tenants.length > 0) {
    refreshDataSources();
  }
}, [activeTenantId, tenants]);
```

## Результат

Теперь при выборе GLOBAL TENANT:
1. Приложение делает отдельный запрос к API для КАЖДОГО тенанта
2. Все полученные data sources объединяются в один список
3. Пользователь видит ВСЕ data sources из ВСЕХ тенантов

При выборе конкретного тенанта (например, BFS):
1. Приложение делает один запрос с фильтром `?Filters={"TenantId":"BFS"}`
2. Пользователь видит только data sources этого тенанта

## Логирование

В консоли теперь можно увидеть подробную информацию о загрузке:

```
📡 Fetching data sources for GLOBAL tenant (all tenants)...
✅ Loaded 5 data sources for tenant BFS
✅ Loaded 3 data sources for tenant Meritage
✅ Loaded 2 data sources for tenant PIM
✅ Total data sources from all tenants: 10
```

## Тестирование

### Проверка через UI

1. Откройте вкладку **Data Sources**
2. Выберите **GLOBAL TENANT** в селекторе тенантов
3. Убедитесь, что видны data sources из ВСЕХ тенантов
4. Выберите конкретный тенант (например, **BFS**)
5. Убедитесь, что видны только data sources этого тенанта
6. Проверьте в консоли браузера логи загрузки

### Проверка через API

Запросы для разных тенантов:

```bash
# BFS tenant
curl -X GET "https://dp-eastus-poc-txservices-apis.azurewebsites.net/datasources?Filters=%7B%22TenantId%22%3A%22BFS%22%7D" \
  -H "X-BFS-Auth: dummytoken123"

# Meritage tenant
curl -X GET "https://dp-eastus-poc-txservices-apis.azurewebsites.net/datasources?Filters=%7B%22TenantId%22%3A%22Meritage%22%7D" \
  -H "X-BFS-Auth: dummytoken123"

# PIM tenant
curl -X GET "https://dp-eastus-poc-txservices-apis.azurewebsites.net/datasources?Filters=%7B%22TenantId%22%3A%22PIM%22%7D" \
  -H "X-BFS-Auth: dummytoken123"
```

## Связанные файлы

- `/App.tsx` - основная логика загрузки и фильтрации
- `/lib/api.ts` - функция `getAllDataSources(tenantId?: string)`
- `/components/DataSourcesView.tsx` - компонент отображения data sources
- `/components/TenantSelector.tsx` - селектор тенантов

## Дата исправления

13 ноября 2025

## Автор

BFS Portal Development Team
