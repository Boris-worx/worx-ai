# Quote Types Активированы ✅

## 📋 Обзор

Три новых типа транзакций для Quote-системы теперь доступны в Data Plane:

1. **QuoteDetails** - Детали/строки котировки
2. **QuotePack** - Пакет котировок  
3. **QuotePackOrder** - Заказ пакета котировок

## 🔄 Порядок Включения

Рекомендуемый порядок использования (как в канонической модели):
```
QuoteDetails → QuotePack → QuotePackOrder
```

**Обоснование**: QuoteDetails является строкой в QuotePack в канонической модели.

Однако все три типа можно использовать независимо, если это нужно для вашего процесса.

---

## 📝 QuoteDetails - Детали Котировки

### Назначение
Представляет отдельную строку/элемент в котировке (line item).

### Шаблон JSON
```json
{
  "quoteDetailId": "QD-1730246789123",
  "quoteId": null,
  "lineNumber": 1,
  "itemId": null,
  "itemDescription": "",
  "quantity": 1,
  "unitPrice": 0,
  "discount": 0,
  "totalPrice": 0,
  "notes": null
}
```

### Основные Поля
| Поле | Тип | Описание |
|------|-----|----------|
| `quoteDetailId` | string | Уникальный ID строки котировки |
| `quoteId` | string | ID родительской котировки |
| `lineNumber` | number | Номер строки в котировке |
| `itemId` | string | ID товара/услуги |
| `itemDescription` | string | Описание товара |
| `quantity` | number | Количество |
| `unitPrice` | number | Цена за единицу |
| `discount` | number | Скидка |
| `totalPrice` | number | Итоговая цена |
| `notes` | string | Примечания |

### API Endpoints
```bash
# Create
POST /1.0/txns
{
  "TxnType": "QuoteDetails",
  "Txn": { ... }
}

# Get All
GET /1.0/txns?TxnType=QuoteDetails

# Get One
GET /1.0/txns/QuoteDetails:QD-123456

# Update
PUT /1.0/txns/QuoteDetails:QD-123456

# Delete
DELETE /1.0/txns/QuoteDetails:QD-123456
```

### Пример Создания
```javascript
{
  "TxnType": "QuoteDetails",
  "Txn": {
    "quoteDetailId": "QD-001",
    "quoteId": "QUOTE-12345",
    "lineNumber": 1,
    "itemId": "ITEM-789",
    "itemDescription": "Premium Window Frame",
    "quantity": 10,
    "unitPrice": 150.00,
    "discount": 5,
    "totalPrice": 1425.00,
    "notes": "Custom size 36x48"
  }
}
```

---

## 📦 QuotePack - Пакет Котировок

### Назначение
Группирует несколько QuoteDetails в один пакет/комплект.

### Шаблон JSON
```json
{
  "quotePackId": "QP-1730246789123",
  "quoteId": null,
  "packName": "",
  "packDescription": "",
  "totalAmount": 0,
  "quoteDetails": [],
  "isActive": true
}
```

### Основные Поля
| Поле | Тип | Описание |
|------|-----|----------|
| `quotePackId` | string | Уникальный ID пакета |
| `quoteId` | string | ID родительской котировки |
| `packName` | string | Название пакета |
| `packDescription` | string | Описание пакета |
| `totalAmount` | number | Общая сумма пакета |
| `quoteDetails` | array | Массив ID QuoteDetails |
| `isActive` | boolean | Активен ли пакет |

### API Endpoints
```bash
# Create
POST /1.0/txns
{
  "TxnType": "QuotePack",
  "Txn": { ... }
}

# Get All
GET /1.0/txns?TxnType=QuotePack

# Get One
GET /1.0/txns/QuotePack:QP-123456

# Update
PUT /1.0/txns/QuotePack:QP-123456

# Delete
DELETE /1.0/txns/QuotePack:QP-123456
```

### Пример Создания
```javascript
{
  "TxnType": "QuotePack",
  "Txn": {
    "quotePackId": "QP-001",
    "quoteId": "QUOTE-12345",
    "packName": "Standard Window Package",
    "packDescription": "Includes frames, glass, and installation",
    "totalAmount": 5500.00,
    "quoteDetails": [
      "QD-001",
      "QD-002",
      "QD-003"
    ],
    "isActive": true
  }
}
```

---

## 🛒 QuotePackOrder - Заказ Пакета

### Назначение
Представляет заказ на основе пакета котировок.

### Шаблон JSON
```json
{
  "quotePackOrderId": "QPO-1730246789123",
  "quotePackId": null,
  "orderId": null,
  "orderDate": "2025-10-29T00:00:00.000Z",
  "customerId": null,
  "totalAmount": 0,
  "status": "pending",
  "notes": null
}
```

### Основные Поля
| Поле | Тип | Описание |
|------|-----|----------|
| `quotePackOrderId` | string | Уникальный ID заказа |
| `quotePackId` | string | ID пакета котировок |
| `orderId` | string | ID заказа в системе |
| `orderDate` | string | Дата заказа (ISO 8601) |
| `customerId` | string | ID клиента |
| `totalAmount` | number | Общая сумма заказа |
| `status` | string | Статус (pending, approved, completed, cancelled) |
| `notes` | string | Примечания к заказу |

### API Endpoints
```bash
# Create
POST /1.0/txns
{
  "TxnType": "QuotePackOrder",
  "Txn": { ... }
}

# Get All
GET /1.0/txns?TxnType=QuotePackOrder

# Get One
GET /1.0/txns/QuotePackOrder:QPO-123456

# Update
PUT /1.0/txns/QuotePackOrder:QPO-123456

# Delete
DELETE /1.0/txns/QuotePackOrder:QPO-123456
```

### Пример Создания
```javascript
{
  "TxnType": "QuotePackOrder",
  "Txn": {
    "quotePackOrderId": "QPO-001",
    "quotePackId": "QP-001",
    "orderId": "ORD-54321",
    "orderDate": "2025-10-29T10:30:00.000Z",
    "customerId": "CUST-12345",
    "totalAmount": 5500.00,
    "status": "approved",
    "notes": "Rush order - needed by end of week"
  }
}
```

---

## 🎯 Как Использовать

### В Приложении

1. **Откройте Data Plane вкладку**
2. **Выберите тип транзакции из dropdown**:
   - QuoteDetails
   - QuotePack
   - QuotePackOrder
3. **Нажмите "+ Create New Transaction"**
4. **Отредактируйте JSON шаблон**
5. **Нажмите "Create Transaction"**

### Через API (curl)

#### Создать QuoteDetails
```bash
curl -X POST 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/txns' \
-H 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
-H 'Content-Type: application/json' \
-d '{
  "TxnType": "QuoteDetails",
  "Txn": {
    "quoteDetailId": "QD-TEST-001",
    "quoteId": "QUOTE-12345",
    "lineNumber": 1,
    "itemDescription": "Test Item",
    "quantity": 1,
    "unitPrice": 100.00,
    "totalPrice": 100.00
  }
}'
```

#### Создать QuotePack
```bash
curl -X POST 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/txns' \
-H 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
-H 'Content-Type: application/json' \
-d '{
  "TxnType": "QuotePack",
  "Txn": {
    "quotePackId": "QP-TEST-001",
    "quoteId": "QUOTE-12345",
    "packName": "Test Package",
    "totalAmount": 1000.00,
    "isActive": true
  }
}'
```

#### Создать QuotePackOrder
```bash
curl -X POST 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/txns' \
-H 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
-H 'Content-Type: application/json' \
-d '{
  "TxnType": "QuotePackOrder",
  "Txn": {
    "quotePackOrderId": "QPO-TEST-001",
    "quotePackId": "QP-TEST-001",
    "orderDate": "2025-10-29T12:00:00.000Z",
    "status": "pending",
    "totalAmount": 1000.00
  }
}'
```

---

## 🔗 Связи Между Типами

```
Quote
  ↓
QuoteDetails (line items)
  ↓
QuotePack (groups details)
  ↓
QuotePackOrder (order from pack)
```

### Пример Полного Процесса

1. **Создать Quote**
   ```
   Quote:QUOTE-12345
   ```

2. **Добавить QuoteDetails** (несколько строк)
   ```
   QuoteDetails:QD-001 → quoteId: QUOTE-12345
   QuoteDetails:QD-002 → quoteId: QUOTE-12345
   QuoteDetails:QD-003 → quoteId: QUOTE-12345
   ```

3. **Создать QuotePack** (объединить детали)
   ```
   QuotePack:QP-001 → quoteId: QUOTE-12345, quoteDetails: [QD-001, QD-002, QD-003]
   ```

4. **Создать QuotePackOrder** (оформить заказ)
   ```
   QuotePackOrder:QPO-001 → quotePackId: QP-001
   ```

---

## ✅ Проверка

### Убедиться что типы доступны

1. Откройте приложение
2. Перейдите на вкладку **Data Plane**
3. Откройте dropdown "Select Transaction Type"
4. Проверьте наличие:
   - ✅ QuoteDetails
   - ✅ QuotePack
   - ✅ QuotePackOrder

### Протестировать создание

1. Выберите **QuoteDetails**
2. Нажмите **"+ Create New Transaction"**
3. Проверьте что JSON шаблон загружен
4. Измените `quoteDetailId` на уникальное значение
5. Нажмите **"Create Transaction"**
6. Проверьте успешное создание (toast notification)

Повторите для QuotePack и QuotePackOrder.

---

## 🎨 В UI Приложения

### Где Находятся

**Data Plane** → Dropdown "Select Transaction Type":
- Customer
- Customer Aging
- Location
- Quote
- **QuoteDetails** ← НОВЫЙ
- **QuotePack** ← НОВЫЙ
- **QuotePackOrder** ← НОВЫЙ
- ReasonCode
- (остальные типы...)

### Как Выглядит

Типы отображаются в том же формате что и другие типы транзакций, с полной поддержкой:
- ✅ Create (Создание)
- ✅ Read/View (Просмотр)
- ✅ Update (Редактирование)
- ✅ Delete (Удаление)
- ✅ Auto-refresh после операций
- ✅ JSON templates
- ✅ ETag handling

---

## 🧪 Тестирование

### Быстрый Тест 1: QuoteDetails

```bash
# 1. Create
curl -X POST 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/txns' \
-H 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
-H 'Content-Type: application/json' \
-d '{
  "TxnType": "QuoteDetails",
  "Txn": {
    "quoteDetailId": "QD-'$(date +%s)'",
    "itemDescription": "Test Item",
    "quantity": 1,
    "unitPrice": 50
  }
}'

# 2. List All
curl 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/txns?TxnType=QuoteDetails' \
-H 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'

# 3. Get One (замените ID)
curl 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/txns/QuoteDetails:QD-123456' \
-H 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
```

### Быстрый Тест 2: QuotePack

```bash
# Create
curl -X POST 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/txns' \
-H 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
-H 'Content-Type: application/json' \
-d '{
  "TxnType": "QuotePack",
  "Txn": {
    "quotePackId": "QP-'$(date +%s)'",
    "packName": "Test Pack",
    "isActive": true
  }
}'

# List All
curl 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/txns?TxnType=QuotePack' \
-H 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
```

### Быстрый Тест 3: QuotePackOrder

```bash
# Create
curl -X POST 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/txns' \
-H 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
-H 'Content-Type: application/json' \
-d '{
  "TxnType": "QuotePackOrder",
  "Txn": {
    "quotePackOrderId": "QPO-'$(date +%s)'",
    "orderDate": "'$(date -u +"%Y-%m-%dT%H:%M:%S.000Z")'",
    "status": "pending"
  }
}'

# List All
curl 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/txns?TxnType=QuotePackOrder' \
-H 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
```

---

## 📊 Статус Имплементации

| Компонент | Статус | Примечания |
|-----------|--------|------------|
| API Types List | ✅ Готово | Добавлены в `TRANSACTION_TYPES` |
| JSON Templates | ✅ Готово | Шаблоны для всех 3 типов |
| UI Dropdown | ✅ Готово | Автоматически обновлен |
| Create Dialog | ✅ Готово | Поддерживает все типы |
| View/Edit/Delete | ✅ Готово | Унаследовано от базовой системы |
| Documentation | ✅ Готово | Этот файл |

---

## 🚀 Готово к Использованию

Все три типа теперь полностью интегрированы в систему и готовы к использованию:

✅ **QuoteDetails** - Для создания строк котировки
✅ **QuotePack** - Для группировки деталей в пакеты
✅ **QuotePackOrder** - Для создания заказов из пакетов

**Следующие Шаги**:
1. Протестируйте создание каждого типа в UI
2. Проверьте API endpoints через curl/Postman
3. Создайте пример полного процесса (Quote → Details → Pack → Order)
4. Настройте валидацию связей между типами (опционально)

---

## 📖 Связанные Документы

- [QUOTE_CHEATSHEET.md](/QUOTE_CHEATSHEET.md) - Quick reference для Quote API
- [QUOTE_TESTING_GUIDE.md](/QUOTE_TESTING_GUIDE.md) - Полное руководство по тестированию
- [QUOTE_TEST_RU.md](/QUOTE_TEST_RU.md) - Русское руководство
- [POSTMAN_COLLECTION_VERIFICATION.md](/POSTMAN_COLLECTION_VERIFICATION.md) - Верификация Postman коллекции
- [API_EXAMPLES.md](/API_EXAMPLES.md) - Примеры API вызовов

---

**Дата активации**: 29 октября 2025
**Версия приложения**: Latest
**API Version**: 1.0
