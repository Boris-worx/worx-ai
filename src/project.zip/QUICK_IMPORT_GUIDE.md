# Quick Tenant Import Guide

## 🚀 How to Import Tenants in 3 Steps

### Step 1: Prepare JSON File

Create a file with this format:
```json
[
  { "TenantName": "Company A" },
  { "TenantName": "Company B" },
  { "TenantName": "Company C" }
]
```

**Use sample file:** `/sample-tenants-import.json`

---

### Step 2: Upload File

1. Click **"Tenants"** tab
2. Click **"Import JSON"** button
3. Click **"Upload JSON File"**
4. Select your JSON file

---

### Step 3: Import

1. Review preview (shows first 3 tenants)
2. Click **"Import Tenants"**
3. Wait for completion
4. See results (success/failure count)

---

## ✅ What You Get

- **Bulk Creation:** Import 5, 10, 50+ tenants at once
- **Auto-Generated IDs:** System creates TenantID for each
- **Error Handling:** Continue importing even if some fail
- **API Protected:** All calls include X-BFS-Auth header
- **Results:** See which succeeded and which failed

---

## 📝 Rules

✅ **Must be:**
- Valid JSON file
- Array of objects
- Each has TenantName field

❌ **Don't include:**
- TenantID (auto-generated)
- Extra fields (ignored)

---

## 🔒 API Security

**All requests include required headers:**
- ✅ `X-BFS-Auth: your-api-key`
- ✅ `Content-Type: application/json`
- ✅ `If-Match: etag` (only for PUT/DELETE, not for import)

**Import uses POST /tenants** (no ETag needed)

---

## 🎯 Example

**Your JSON:**
```json
[
  { "TenantName": "Acme Corp" },
  { "TenantName": "TechStart Inc" }
]
```

**After Import:**
```
✅ Successfully imported: 2

Table now shows:
- Acme Corp (tenant-123)
- TechStart Inc (tenant-124)
```

---

## 📚 More Info

- **Full Guide:** `/TENANT_IMPORT_GUIDE.md`
- **Verification:** `/TENANT_IMPORT_VERIFICATION.md`
- **Sample File:** `/sample-tenants-import.json`

---

**That's it! Start importing!** 🎉
