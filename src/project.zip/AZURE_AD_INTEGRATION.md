# Azure AD Authentication Integration

This document describes how the BFS application integrates with Microsoft Azure AD authentication.

## Overview

The application supports two authentication modes:

1. **Azure AD Authentication** (Production) - Uses Microsoft Entra ID (Azure AD) with role-based access control (RBAC)
2. **Local Authentication** (Development) - Uses username/password credentials for testing

## ✅ Role-Based Access Control (RBAC)

**Important:** This application uses **Microsoft Entra ID roles** (not custom claims) to control both permissions and section access. This follows Microsoft's standard RBAC pattern and is fully compatible with Azure AD schema.

For detailed information on setting up and using roles, see [AZURE_RBAC_GUIDE.md](./AZURE_RBAC_GUIDE.md).

## Azure AD Role Mapping

The application automatically maps Azure AD roles to internal permission levels:

### Permission Roles

| Azure AD Role | Internal Role | Permissions |
|--------------|---------------|-------------|
| `Portal.Admin` | `admin` | Full access: View, Create, Edit, Delete |
| `Portal.Editor` | `edit` | Limited access: View, Edit, Delete (no Create) |
| `Portal.Reader` | `view` | Read-only access: View only |

### Section Access Roles

| Azure AD Role | Accessible Sections |
|--------------|-------------------|
| `Portal.Admin` | All sections (Tenants, Transactions, Data Plane) |
| `Portal.Editor` | All sections (Tenants, Transactions, Data Plane) |
| `Portal.Reader` | All sections (Tenants, Transactions, Data Plane) |
| `Portal.Tenants` | Tenants section only |
| `Portal.Transactions` | Transactions section only |
| `Portal.DataPlane` | Data Plane section only |

**Note:** Users can have multiple roles. For example:
- `["Portal.Editor", "Portal.Tenants"]` = Edit permissions on Tenants section only
- `["Portal.Tenants", "Portal.Transactions"]` = View-only access to Tenants and Transactions

## How It Works

### 1. Authentication Flow

When the application loads:

1. The app checks for Azure AD authentication by calling `/.auth/me`
2. If authenticated, it extracts the user's email, name, and **roles** from the `user_claims` array
3. All assigned roles are parsed to determine:
   - Permission level (admin/edit/view)
   - Section access (which tabs are visible)
4. User information is stored in localStorage and displayed in the UI

### 2. Role Extraction

The application extracts **all roles** assigned to the user:

```typescript
// Find ALL role claims (Azure AD can return multiple)
const roleClaims = claims.filter((c) => 
  c.typ === 'roles' || 
  c.typ === 'http://schemas.microsoft.com/ws/2008/06/identity/claims/role'
);

// Example: User has ["Portal.Admin", "Portal.Tenants"]
// Result: admin permissions + access to Tenants (but Admin already gives all access)
```

### 3. User Information Display

For Azure AD authenticated users, the application displays:

- **Name** - The user's full name from Azure AD (e.g., "Boris Belov (contractor)")
- **Email address** - The user's Microsoft account email
- **Azure Role** - The primary assigned Enterprise Application role
- **Access Level** - The mapped internal role (admin, edit, view)
- **Section Access** - Which sections the user can view
- **Permissions** - A detailed list of what the user can do

### 4. BFS Auth Dialog

When authenticated via Azure AD, the login dialog shows:

- 👤 **Name**: User's full name from Azure AD
- 📧 **Email**: User's Microsoft account
- 🛡️ **Azure Role**: The Portal role assigned in the Enterprise Application
- 📚 **Section Access**: Which sections are accessible (based on roles)
- 🔄 **Refresh Authentication**: Button to refresh the authentication token
- ✅ **Permissions List**: Clear list of what the user can and cannot do

### 5. User Menu

The user menu (top right) displays:

- Azure AD status indicator
- Email address
- Azure role name
- Access level badge
- Sign out button (redirects to Azure logout)

## API Endpoint

The application uses the Azure App Service authentication endpoint:

```
GET /.auth/me
```

### Expected Response Format

```json
[
  {
    "access_token": "eyJ0eXAiOiJKV1QiLCJub25jZSI6...",
    "expires_on": "2025-10-21T15:53:04.6501519Z",
    "id_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiI...",
    "provider_name": "aad",
    "user_claims": [
      {
        "typ": "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress",
        "val": "Boris.Belov@myparadigm.com"
      },
      {
        "typ": "name",
        "val": "Boris Belov (contractor)"
      },
      {
        "typ": "preferred_username",
        "val": "Boris.Belov@myparadigm.com"
      },
      {
        "typ": "roles",
        "val": "Portal.Admin"
      }
    ],
    "user_id": "Boris.Belov@myparadigm.com"
  }
]
```

### Key Claims

The application extracts the following information from `user_claims`:

1. **Email**: Looks for claims with `typ`:
   - `http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress`
   - `preferred_username`
   - `email`
   - `emails`

2. **Name**: Looks for claim with `typ` = `name`

3. **Role**: Looks for claim with `typ` = `roles`
   - Value should be one of: `Portal.Admin`, `Portal.Editor`, `Portal.Reader`

## Logout Process

### Frontend Logout

When the user clicks "Sign Out" in the user menu:

1. The application clears the local user state
2. Removes authentication data from localStorage
3. If Azure AD authenticated, redirects to `/.auth/logout`

### Azure AD Logout Endpoint

```
GET /.auth/logout
```

This endpoint (provided by Azure App Service):
- Terminates the Azure AD session
- Clears authentication cookies
- Optionally redirects to a post-logout URL

### Backend Configuration for Logout

The backend developer should configure the logout behavior in Azure App Service:

1. **Azure Portal** → **App Service** → **Authentication**
2. Under **Azure Active Directory** settings:
   - Set **Logout endpoint**: `/.auth/logout`
   - Configure **Post logout redirect URI** (optional): URL to redirect after logout

3. **Optional**: Add custom logout redirect in app settings:
```json
{
  "authentication": {
    "platform": {
      "enabled": true
    },
    "globalValidation": {
      "requireAuthentication": true,
      "unauthenticatedClientAction": "RedirectToLoginPage"
    },
    "identityProviders": {
      "azureActiveDirectory": {
        "registration": {
          "clientId": "your-client-id",
          "clientSecretSettingName": "MICROSOFT_PROVIDER_AUTHENTICATION_SECRET",
          "openIdIssuer": "https://login.microsoftonline.com/{tenant-id}/v2.0"
        },
        "validation": {
          "allowedAudiences": ["your-client-id"]
        },
        "logout": {
          "postLogoutRedirectUri": "https://your-domain.com"
        }
      }
    }
  }
}
```

### Complete Logout Flow

```
User clicks "Sign Out"
    ↓
Frontend clears state
    ↓
Redirect to /.auth/logout
    ↓
Azure terminates session
    ↓
Clear cookies
    ↓
Redirect to post-logout URL (if configured)
    ↓
User sees login page
```

## Local Development Mode

When running locally (not on `azurewebsites.net` domain), the application falls back to local authentication:

### Test Credentials

- **Admin**: `admin` / `admin123`
- **Editor**: `editor` / `edit123`
- **Viewer**: `viewer` / `view123`

## Configuration

### Backend Setup Required

The Azure AD roles must be configured on the backend side:

1. **Enterprise Application** must have the roles defined:
   - `Portal.Admin`
   - `Portal.Editor`
   - `Portal.Reader`

2. **Role Claims** must be included in the JWT token
3. **App Service Authentication** must be enabled
4. The `/.auth/me` endpoint must be accessible
5. The `/.auth/logout` endpoint must be configured

### Role Assignment

Roles are assigned to users in the Azure AD Enterprise Application:

1. Go to Azure Portal → Enterprise Applications
2. Select your application
3. Go to "Users and groups"
4. Assign users to the appropriate role (Portal.Admin, Portal.Editor, or Portal.Reader)

## Security Features

### Automatic Token Refresh

- The application checks authentication on every page load
- Users can manually refresh their authentication using the "Refresh Authentication" button
- Expired sessions are automatically cleared

### Secure Logout

When an Azure AD user logs out:

1. Local session is cleared
2. User is redirected to `/.auth/logout`
3. Azure AD session is terminated
4. Authentication cookies are cleared

### Permission Enforcement

The application enforces permissions at multiple levels:

- **UI Level**: Buttons and actions are hidden/disabled based on role
- **Component Level**: Features are conditionally rendered
- **Data Level**: API calls should also validate permissions server-side

## Troubleshooting

### Common Issues

1. **"No Azure AD authentication found"**
   - The `/.auth/me` endpoint is not returning data
   - Check that App Service Authentication is enabled
   - Verify the user is logged in to Azure AD

2. **User has wrong permissions**
   - Check the role assigned in the Enterprise Application
   - Verify the `roles` claim is included in the JWT token
   - Try refreshing authentication

3. **Email not showing**
   - The JWT token may not include the email claim
   - Check the Enterprise Application token configuration
   - The app will fall back to using `user_id` or `preferred_username`

4. **Logout not working**
   - Verify `/.auth/logout` endpoint is accessible
   - Check App Service authentication settings
   - Ensure post-logout redirect is configured

### Debugging

To debug authentication issues:

1. Open browser DevTools → Console
2. Check for authentication-related logs
3. Inspect the `/.auth/me` response in the Network tab
4. Verify the parsed user data in localStorage under key `bfs_user`
5. Check the `user_claims` array for the `roles` claim

## Implementation Files

- `/lib/azure-auth.ts` - Azure AD integration utilities
- `/components/AuthContext.tsx` - Authentication context and state management
- `/components/LoginDialog.tsx` - Login UI with Azure AD info display
- `/components/UserMenu.tsx` - User menu with Azure AD details

## Example Usage

```typescript
import { useAuth } from './components/AuthContext';

function MyComponent() {
  const { user, isAuthenticated, refreshAzureAuth, logout } = useAuth();

  if (!isAuthenticated) {
    return <div>Please log in</div>;
  }

  return (
    <div>
      <h1>Welcome {user.name || user.username}!</h1>
      <p>Email: {user.email}</p>
      <p>Role: {user.role}</p>
      {user.isAzureAuth && (
        <>
          <p>Azure Role: {user.azureRole}</p>
          <button onClick={logout}>Sign Out from Azure</button>
        </>
      )}
      
      {user.role === 'admin' && (
        <button>Admin Only Action</button>
      )}
    </div>
  );
}
```

## Backend Implementation Guide for Logout

### For Backend Developers

To properly implement logout functionality:

1. **Ensure Azure App Service Authentication is enabled**
   ```bash
   az webapp auth update --resource-group <resource-group> \
     --name <app-name> \
     --enabled true \
     --action RedirectToLoginPage
   ```

2. **Configure Azure AD provider with logout settings**
   - In Azure Portal, navigate to your App Service
   - Go to Authentication → Azure Active Directory
   - Add `/.auth/logout` as the logout endpoint
   - Optionally configure post-logout redirect URI

3. **Test the logout flow**
   ```bash
   # User should be redirected and session cleared
   curl -X GET https://your-app.azurewebsites.net/.auth/logout
   ```

4. **Verify session is cleared**
   - After logout, calling `/.auth/me` should return empty or unauthenticated response

## Next Steps

- Configure the Enterprise Application roles in Azure Portal
- Assign roles to users
- Test authentication with different role types
- Verify permissions work correctly for each role level
- Configure logout redirect URI (optional)
- Test complete authentication flow including logout