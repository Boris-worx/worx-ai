# 🔄 Switching Between Demo and Live API Modes

## 🎯 Current Status: Demo Mode

Your application is currently running in **Demo Mode** - this is the safest default setting.

## 📊 Mode Comparison

| Feature | Demo Mode | Live API Mode |
|---------|-----------|---------------|
| **Data Source** | In-memory (browser) | Cosmos DB (Azure) |
| **Internet Required** | ❌ No | ✅ Yes |
| **Data Persistence** | ❌ Lost on refresh | ✅ Persisted |
| **CORS Issues** | ❌ None | ⚠️ Possible |
| **Setup Required** | ❌ None | ✅ API must be configured |
| **Best For** | Testing UI/UX | Production use |

## 🚀 How to Switch to Live API Mode

### Step 1: Open Configuration File
```
File: /lib/api.ts
Location: Line 10
```

### Step 2: Change DEMO_MODE
```typescript
// BEFORE:
const DEMO_MODE = true;

// AFTER:
const DEMO_MODE = false;
```

### Step 3: Save and Refresh
- Save the file: `Ctrl+S` or `Cmd+S`
- Refresh browser: `Ctrl+R` or `F5`

### Step 4: Check Status
You should see:
```
Live API Mode: Connected to poc-apis-bfs.azurewebsites.net
```

## ⚠️ Common Issues in Live API Mode

### Issue 1: "Failed to fetch" Error
**Cause**: CORS policy blocking the request
**Symptoms**:
```
❌ Error fetching tenants: TypeError: Failed to fetch
❌ Load error: TypeError: Failed to fetch
```

**Solutions**:
1. **Contact API Administrator**: Ask to add your domain to CORS allowed origins
2. **Check API Server**: Verify `poc-apis-bfs.azurewebsites.net` is online
3. **Test API Directly**: Try accessing in browser or Postman
4. **Switch Back to Demo**: Set `DEMO_MODE = true` temporarily

### Issue 2: Empty Tenant List
**Cause**: No tenants in database yet
**Solution**: Import from Postman Collection

### Issue 3: Authentication Error (401)
**Cause**: Invalid API key
**Solution**: Verify API key in `/lib/api.ts` line 5-6

## 🧪 Testing Live API Connection

### Option 1: Via Application
1. Set `DEMO_MODE = false`
2. Open browser console (F12)
3. Refresh page
4. Look for:
   ```
   🌐 Fetching tenants from: https://...
   📡 Response status: 200 OK
   ✅ Extracted tenants: X
   ```

### Option 2: Via curl
```bash
curl -X GET \
  'https://poc-apis-bfs.azurewebsites.net/1.0/tenants' \
  -H 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
```

### Option 3: Via Postman
1. Import your Postman Collection
2. Run "GET /1.0/tenants" request
3. Check response

## 🔧 API Configuration Reference

Your application is pre-configured with:

```typescript
// /lib/api.ts
const API_BASE_URL = 'https://poc-apis-bfs.azurewebsites.net/1.0';
const AUTH_HEADER_KEY = 'X-BFS-Auth';
const AUTH_HEADER_VALUE = 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855';
```

## 📝 Workflow Recommendations

### For Development/Testing
✅ Use **Demo Mode** (`DEMO_MODE = true`)
- Fast, no network delays
- No CORS issues
- Safe to experiment

### For Production/Real Data
✅ Use **Live API Mode** (`DEMO_MODE = false`)
- Real data from Cosmos DB
- Data persists across sessions
- Full CRUD operations

## 🆘 Troubleshooting Steps

1. **Open Browser Console**: Press `F12`
2. **Look for Errors**: Check Console tab
3. **Check Network Tab**: See actual API requests
4. **Read Error Messages**: They contain helpful details
5. **Try Demo Mode**: Switch back if stuck

## ✅ Success Indicators

### Demo Mode Working:
```
✅ "Demo Mode: Import JSON to add tenants"
✅ Can import Postman Collection
✅ Tenants appear in table
✅ All CRUD operations work
```

### Live API Mode Working:
```
✅ "Live API Mode: Connected to poc-apis-bfs..."
✅ Console shows "200 OK"
✅ "Loaded X tenant(s) from API"
✅ Tenants loaded from Cosmos DB
```

## 🎓 Quick Reference

| Task | Demo Mode | Live API Mode |
|------|-----------|---------------|
| **Add Tenants** | Import JSON | Import JSON OR API Call |
| **View Tenants** | From memory | From Cosmos DB |
| **Edit Tenant** | Updates memory | Updates Cosmos DB |
| **Delete Tenant** | Removes from memory | Deletes from Cosmos DB |
| **Data After Refresh** | ❌ Lost | ✅ Persisted |

## 🔒 Security Note

The API key is embedded in the code (`/lib/api.ts`). This is:
- ✅ **OK for internal tools**
- ✅ **OK for development**
- ⚠️ **NOT recommended for public websites**

For production public apps, use environment variables or backend proxy.

---

**Current Recommendation**: Start with **Demo Mode** to test the UI, then switch to **Live API Mode** when ready to work with real data.

**Need Help?** Check `/API_DEBUGGING_GUIDE.md` for detailed troubleshooting.
