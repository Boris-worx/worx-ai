# 🎨 ModelSchema UX Update - Two-Column Layout

## ✅ Status: COMPLETED (v2 - Header Layout)

Updated the Schema Detail Dialog to use a header-based layout with metadata at the top and two equal columns below for JSON Schema and Properties.

## 📐 New Layout v2

### **Header + Two Equal Columns**

```
┌─────────────────────────────────────────────────────────────────┐
│  Location - v1 (1.0.0)                                          │
│  JSON Schema (Draft 2020-12)                                    │
│                                                                 │
│  ID             Status    Created              Updated         │
│  Location:1     [active]  10/12/2025, 5:31 PM  10/12/2025...   │
├─────────────────────────────────┬───────────────────────────────┤
│ LEFT (50%)                      │ RIGHT (50%)                   │
├─────────────────────────────────┼───────────────────────────────┤
│ JSON Schema:                    │ Properties:      21 fields    │
│                                 │                               │
│ ┌───────────────────────────┐   │ ┌──────────────┬────────┬───┐│
│ │ {                         │   │ │ Field        │ Type   │ R │││
│ │   "$id": "...",           │   │ ├──────────────┼────────┼───┤│
│ │   "$schema": "...",       │   │ │ LocationId   │ string │ Y │││
│ │   "title": "Location",    │   │ │ Name         │ string │ Y │││
│ │   "type": "object",       │   │ │ Phone        │ string │ N │││
│ │   "required": [...],      │   │ │ Fax          │ string │ N │││
│ │   "properties": {         │   │ │ Division     │ string │ N │││
│ │     "LocationId": {...},  │   │ │ Region       │ string │ N │││
│ │     "Name": {...},        │   │ │ Zone         │ string │ N │││
│ │     ...                   │   │ │ Category     │ string │ N │││
│ │   }                       │   │ │ Group        │ string │ N │││
│ │ }                         │   │ │ IsAdminSite  │ boolean│ N │││
│ └───────────────────────────┘   │ │ ...          │ ...    │...│││
│ [scrollable]                    │ └──────────────┴────────┴───┘│
│                                 │ [scrollable]                  │
└─────────────────────────────────┴───────────────────────────────┘
```

## 🎯 Key Features

### **Header Section**
Horizontal metadata row with 4 columns:
1. **ID** - Schema identifier (e.g., "Location:1") - monospace font
2. **Status** - Badge with state (Active/Deprecated/Draft)
3. **Created** - Timestamp with US format (MM/DD/YYYY, HH:MM:SS AM/PM)
4. **Updated** - Timestamp with US format

Border separator between header and content.

### **Left Column (50%)**
1. **JSON Schema** heading (same size as Properties heading)
2. Full JSON Schema code (scrollable)
3. Syntax highlighted with monospace font

### **Right Column (50%)**
1. **Properties** heading (same size as JSON Schema heading)
2. Field count badge (e.g., "21 fields")
3. **Properties Table** with 3 columns:
   - **Field** - Property name (blue text, monospace font)
   - **Type** - Data type (string, boolean, integer, object)
   - **Required** - Badge:
     - 🔴 **"required"** - Red badge (`bg-red-500`)
     - ⚪ **"optional"** - Gray badge (`bg-gray-400`)

## 🎨 Design Details

### **Table Styling**
- Alternating row colors (zebra striping)
- Header row: `bg-muted/50`
- Even rows: `bg-background`
- Odd rows: `bg-muted/30`
- Border: rounded corners with `rounded-lg`

### **Field Column**
- Font: Monospace (`font-mono`)
- Color: Primary blue (`text-primary`)
- Size: Small (`text-sm`)

### **Type Column**
- Color: Muted foreground
- Plain text, no badges

### **Required Column**
- **Required fields**: 
  - Badge: `variant="destructive"`
  - Custom: `bg-red-500 hover:bg-red-600`
  - Text: "required"
- **Optional fields**:
  - Badge: `variant="secondary"`
  - Custom: `bg-gray-400 text-gray-700`
  - Text: "optional"

### **JSON Schema Section**
- ScrollArea height: `h-[calc(90vh-450px)]`
- Background: `bg-muted`
- Padding: `p-3`
- Font: Monospace, extra small (`text-xs font-mono`)
- Line height: Relaxed (`leading-relaxed`)

## 📊 Layout Structure

```tsx
{/* Header with metadata */}
<div className="space-y-4 pb-4 border-b">
  <div>
    <DialogTitle className="text-2xl mb-1">
      {model} - v{version} ({semver})
    </DialogTitle>
    <DialogDescription className="text-xs">
      JSON Schema (Draft 2020-12)
    </DialogDescription>
  </div>

  {/* Metadata Row - 4 columns */}
  <div className="grid grid-cols-4 gap-4 text-sm">
    <div>ID</div>
    <div>Status</div>
    <div>Created</div>
    <div>Updated</div>
  </div>
</div>

{/* Two equal columns - 50/50 */}
<div className="grid grid-cols-2 gap-6 h-[calc(90vh-280px)]">
  {/* Left: JSON Schema */}
  <div className="overflow-y-auto pr-2">
    <h4>JSON Schema:</h4>
    <ScrollArea>...</ScrollArea>
  </div>
  
  {/* Right: Properties Table */}
  <div className="overflow-y-auto pl-2">
    <h4>Properties:</h4>
    <table>...</table>
  </div>
</div>
```

## 🔄 Updated Files

1. **`/components/TenantsView.tsx`**
   - Global ModelSchema dialog
   - Accessed via "ModelSchema" button

2. **`/components/TenantDetail.tsx`**
   - Tenant-specific ModelSchema dialog
   - Accessed via "View" button on tenant → "View Schema"

## 📝 Date Format

```javascript
new Date(schema.CreateTime).toLocaleString('en-US', {
  month: '2-digit',
  day: '2-digit',
  year: 'numeric',
  hour: '2-digit',
  minute: '2-digit',
  second: '2-digit',
  hour12: true
})
// Output: "10/12/2025, 5:31:19 PM"
```

## 🎯 User Experience Improvements

### **v1 Layout** (Old - Vertical Metadata)
- ❌ Metadata in left column took vertical space
- ❌ Unequal columns (40% vs 60%)
- ❌ JSON Schema and Properties different sizes

### **v2 Layout** (New - Header Metadata)
- ✅ Metadata in header (horizontal) - saves space
- ✅ Equal columns (50% vs 50%)
- ✅ JSON Schema and Properties same size
- ✅ Both headings (h4) are same size
- ✅ Better visual balance
- ✅ More space for content
- ✅ Professional appearance

## 🖥️ Dialog Size

```tsx
className="max-w-[90vw] max-h-[90vh] w-[1200px]"
```

- Max width: 90% of viewport
- Max height: 90% of viewport
- Preferred width: 1200px
- Responsive and scrollable

## 🎨 Color Coding

| Element | Color | Purpose |
|---------|-------|---------|
| Field names | Blue (`text-primary`) | Highlight property names |
| Required badge | Red (`bg-red-500`) | Alert for mandatory fields |
| Optional badge | Gray (`bg-gray-400`) | Indicate optional fields |
| Table header | Muted (`bg-muted/50`) | Separate header from data |
| Alt rows | Muted (`bg-muted/30`) | Improve readability |
| JSON code | Muted background | Distinguish code section |

## 📋 Example Output

For **Location Schema v1**:
- **21 properties** total
- **2 required fields**: LocationId, Name
- **19 optional fields**: Phone, Fax, Division, etc.
- **Mix of types**: string, boolean, integer, object

### Table Preview:
```
┌──────────────────────┬─────────┬──────────┐
│ Field                │ Type    │ Required │
├──────────────────────┼─────────┼──────────┤
│ LocationId           │ string  │ required │
│ Name                 │ string  │ required │
│ Phone                │ string  │ optional │
│ Fax                  │ string  │ optional │
│ Division             │ string  │ optional │
│ Region               │ string  │ optional │
│ Zone                 │ string  │ optional │
│ Category             │ string  │ optional │
│ Group                │ string  │ optional │
│ IsAdminSite          │ boolean │ optional │
│ IsDistributionSite   │ boolean │ optional │
│ IsEnterpriseZone     │ boolean │ optional │
│ isManufacturingSite  │ boolean │ optional │
│ IsWholesaleSite      │ boolean │ optional │
│ QuoteDaysValid       │ integer │ optional │
│ QuoteDisclaimer      │ string  │ optional │
│ Market               │ object  │ optional │
│ TaxCode              │ object  │ optional │
│ Address              │ object  │ optional │
│ CreateTime           │ string  │ optional │
│ UpdateTime           │ string  │ optional │
└──────────────────────┴─────────┴──────────┘
```

## ✅ Testing Checklist v2

- [x] Header shows title with version and semver
- [x] Header shows metadata in horizontal 4-column layout
- [x] Metadata labels are small (text-xs)
- [x] Border separator between header and content
- [x] Two columns are equal size (50/50)
- [x] "JSON Schema:" heading is h4
- [x] "Properties:" heading is h4 (same size)
- [x] JSON Schema is scrollable
- [x] Properties table displays all fields
- [x] Required fields have red "required" badge
- [x] Optional fields have gray "optional" badge
- [x] Field names are in monospace font
- [x] Field names are blue colored
- [x] Table has zebra striping
- [x] Dialog is responsive and scrollable
- [x] Date format matches US standard
- [x] Both dialogs updated (TenantsView + TenantDetail)

## 🚀 How to Test

1. **Go to Tenants tab**
2. **Click "ModelSchema" button** (global schemas)
3. **Click any schema card**
4. **Click "View Full Schema"**
5. **Verify two-column layout**
6. **Scroll both columns independently**
7. **Check table formatting**
8. **Verify badge colors**

OR

1. **Go to Tenants tab**
2. **Click "View" on any tenant**
3. **Scroll to "Model Schemas" section**
4. **Click "View Schema"** on any schema card
5. **Verify same two-column layout**

## 🎯 Key Improvements in v2

1. **Horizontal Header**: Metadata moved to header saves vertical space
2. **Equal Columns**: 50/50 split provides visual balance
3. **Same-Sized Headings**: JSON Schema and Properties both use h4
4. **More Content Space**: Header layout frees up ~100px of vertical space
5. **Cleaner Design**: Clear separation between metadata and content

## 📏 Spacing Details

```tsx
Header Section:
- Title: text-2xl (large heading)
- Description: text-xs (small subtitle)
- Metadata labels: text-xs (consistent small size)
- Metadata values: text-sm (readable size)
- Bottom border: pb-4 border-b (clear separation)

Content Section:
- Column gap: gap-6 (good spacing)
- Height: h-[calc(90vh-280px)] (accounts for header)
- ScrollArea height: h-[calc(90vh-340px)] (nested scrolling)
```

---

**Status: Ready for Production! 🎉**

The v2 layout provides a professional, balanced interface with metadata in the header and equal-sized content columns for optimal viewing experience.

Last Updated: Oct 13, 2025
