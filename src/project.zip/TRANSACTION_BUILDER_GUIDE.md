# Transaction Builder - User Guide

## Overview

The Transaction Builder provides a workflow configuration interface for creating and managing ERP transaction flows. It allows you to define how transactions are processed, stored, and routed.

---

## Features

### 1. Tenant Selection
- **ALL**: Process transaction for all tenants
- **Specific Tenant**: Select individual tenant from dropdown
- Quick "ALL" button for convenience

### 2. Transaction Data Input

Multiple ways to provide transaction data:

#### Upload File
- Click "Upload File" button
- Supports: JSON, YAML, YML, TXT formats
- File content automatically loaded into textarea

#### Paste URL
- Click "Paste URL" button
- Paste URL from clipboard
- Optionally fetch content from URL

#### Manual Entry
- Type or paste directly into textarea
- Supports YAML or newOrder JSON format
- Syntax highlighting with monospace font

### 3. Action Configuration

Select one or more actions to perform:

#### STORE (in database)
- Saves transaction to Cosmos DB
- Persistent storage
- Full audit trail

#### PUBLISH (forward)
- Forwards transaction to external systems
- Real-time processing
- Message queue integration

#### RESPOND (Query)
- Generates response based on transaction
- Query processing
- Synchronous response

#### AGENT (MCP)
- AI Agent processing via MCP
- Intelligent routing
- Automated decision making

### 4. Start Builder
- Validates configuration
- Initiates workflow
- Shows confirmation

---

## User Interface

### Visual Layout

```
┌─────────────────────────────────────────────────────────┐
│  TRANSACTION BUILDER                                     │
│  Configure and build transaction workflows               │
├─────────────────────────────────────────────────────────┤
│                                                          │
│  1. TENANT ID                                            │
│  ┌──────────────────────┐  ┌──────┐                    │
│  │ ALL                ▼ │  │ ALL  │                    │
│  └──────────────────────┘  └──────┘                    │
│                                                          │
│  2. NEW TRANSACTION                                      │
│  [Upload File] [Paste URL]    ~ YAML / newOrder JSON    │
│  ┌────────────────────────────────────────────────┐    │
│  │ Enter transaction data or use upload/URL...    │    │
│  │                                                │    │
│  │                                                │    │
│  └────────────────────────────────────────────────┘    │
│                                                          │
│  3. ACTION:                                              │
│     □ STORE (in database)                               │
│     □ PUBLISH (forward)                                 │
│     □ RESPOND (Query)                                   │
│     □ AGENT (MCP)                                       │
│                                                          │
│  [▶ Start Builder]                                      │
│                                                          │
└─────────────────────────────────────────────────────────┘
```

---

## How to Use

### Basic Workflow

1. **Navigate to Builder Tab**
   - Click "Builder" tab in main navigation

2. **Select Tenant**
   - Choose "ALL" for all tenants
   - Or select specific tenant from dropdown

3. **Enter Transaction Data**
   - Upload file, paste URL, or type manually
   - Use YAML or JSON format

4. **Select Actions**
   - Check one or more action checkboxes
   - Multiple actions can be combined

5. **Start Builder**
   - Click "Start Builder" button
   - Review confirmation message

---

## Example Workflows

### Example 1: Store Invoice

**Configuration:**
- Tenant: ALL
- Data: 
  ```json
  {
    "type": "Invoice",
    "customerId": "CUST-001",
    "amount": 1500.00
  }
  ```
- Actions: ☑ STORE

**Result:**
- Invoice saved to database for all tenants

---

### Example 2: Process Order with Response

**Configuration:**
- Tenant: tenant-123
- Data:
  ```yaml
  type: newOrder
  orderId: ORD-2025-001
  items:
    - productId: PROD-001
      quantity: 10
  ```
- Actions: ☑ STORE, ☑ RESPOND

**Result:**
- Order stored in database
- Response generated with order status

---

### Example 3: AI-Powered Processing

**Configuration:**
- Tenant: ALL
- Data: Customer inquiry JSON
- Actions: ☑ AGENT, ☑ RESPOND

**Result:**
- AI agent processes inquiry
- Intelligent response generated

---

### Example 4: Full Workflow

**Configuration:**
- Tenant: tenant-456
- Data: Complex transaction
- Actions: ☑ STORE, ☑ PUBLISH, ☑ RESPOND, ☑ AGENT

**Result:**
- Stored in database
- Published to external systems
- Response generated
- AI agent processes for insights

---

## Data Formats

### JSON Format

```json
{
  "type": "Customer",
  "action": "create",
  "data": {
    "name": "Acme Corp",
    "email": "contact@acme.com"
  }
}
```

### YAML Format

```yaml
type: Customer
action: create
data:
  name: Acme Corp
  email: contact@acme.com
```

### newOrder Format

```json
{
  "type": "newOrder",
  "orderId": "ORD-001",
  "customer": "CUST-123",
  "items": [
    {
      "sku": "PROD-001",
      "quantity": 5,
      "price": 99.99
    }
  ],
  "total": 499.95
}
```

---

## Action Combinations

| Store | Publish | Respond | Agent | Use Case |
|-------|---------|---------|-------|----------|
| ✓ | - | - | - | Simple storage |
| ✓ | ✓ | - | - | Store and forward |
| - | - | ✓ | - | Query only |
| ✓ | - | ✓ | - | Store with response |
| - | - | - | ✓ | AI processing |
| ✓ | ✓ | ✓ | - | Full workflow |
| ✓ | ✓ | ✓ | ✓ | Complete automation |

---

## Validation Rules

### Required Fields
- ✅ Transaction data must not be empty
- ✅ At least one action must be selected

### Optional
- Tenant selection (defaults to ALL)

### Supported File Types
- `.json` - JSON files
- `.yaml`, `.yml` - YAML files
- `.txt` - Plain text files

---

## Tips & Best Practices

### 1. Start Simple
- Begin with STORE action only
- Test with single tenant
- Verify data format

### 2. Use File Upload
- Prepare transaction data in editor
- Validate JSON/YAML syntax
- Upload for consistency

### 3. Test Actions Incrementally
- Test STORE first
- Add RESPOND to verify processing
- Add PUBLISH for integration
- Add AGENT for automation

### 4. Monitor Results
- Check console logs
- Review toast notifications
- Verify database entries

### 5. Use ALL Carefully
- ALL tenant selection affects all tenants
- Test with specific tenant first
- Verify data compatibility

---

## Keyboard Shortcuts

- **Ctrl/Cmd + V**: Paste into textarea (when focused)
- **Tab**: Navigate between fields
- **Space**: Toggle checkboxes (when focused)
- **Enter**: Submit form (when in textarea)

---

## Troubleshooting

### Transaction data not loading from file
- Check file format (JSON, YAML, YML, TXT only)
- Verify file is not empty
- Try copying content manually

### "Please enter transaction data" error
- Ensure textarea is not empty
- Check for whitespace-only content
- Paste sample data to test

### "Please select at least one action" error
- Check at least one action checkbox
- Verify checkbox is actually selected
- Try clicking checkbox again

### Paste URL not working
- Check clipboard permissions
- Ensure URL is copied
- Try manual paste into textarea

---

## API Integration

### Future Enhancement

When connected to real API, the Transaction Builder will:

1. **Validate** transaction data against schema
2. **Submit** to processing pipeline
3. **Execute** selected actions
4. **Return** processing results
5. **Update** transaction status

### Expected Endpoints

```http
POST /builder/process
X-BFS-Auth: api-key
Content-Type: application/json

{
  "tenantId": "ALL",
  "transactionData": { ... },
  "actions": ["store", "publish", "respond"]
}
```

---

## Sample Files

Create these sample files to test:

### sample-invoice.json
```json
{
  "type": "Invoice",
  "invoiceNumber": "INV-2025-001",
  "customerId": "CUST-123",
  "amount": 1500.00,
  "dueDate": "2025-11-01"
}
```

### sample-order.yaml
```yaml
type: newOrder
orderId: ORD-2025-001
customer:
  id: CUST-456
  name: Acme Corp
items:
  - sku: PROD-001
    quantity: 10
    price: 99.99
total: 999.90
```

---

## Security Notes

### Data Privacy
- Transaction data is processed securely
- API calls include X-BFS-Auth header
- Data encrypted in transit

### Tenant Isolation
- Tenant-specific data is isolated
- ALL mode requires appropriate permissions
- Access controlled by authentication

---

## Future Enhancements

### Planned Features
- [ ] Schema validation
- [ ] Real-time preview
- [ ] Transaction templates
- [ ] Batch processing
- [ ] Workflow visualization
- [ ] History tracking
- [ ] Scheduled execution

---

## Support

For questions or issues:
1. Check this guide first
2. Review console logs
3. Test with sample data
4. Contact support team

---

**Transaction Builder makes complex workflows simple!** 🚀
