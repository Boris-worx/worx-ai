# RBAC Design Review - Проверка соответствия требованиям

## 📋 Требования из спецификации

### Роли пользователей

| UserType | TenantType | Права доступа |
|----------|------------|---------------|
| **Superuser** | Global | Полный доступ ко всем тенантам и всем операциям |
| **Superuser - read only** | Global | Просмотр всех тенантов (read-only) |
| **Admin** | Tenant-specific | Полный доступ только к своему тенанту |
| **Developer** | Tenant-specific | Такой же доступ как Admin (на будущее) |
| **User** | Tenant-specific | Просмотр только своего тенанта (read-only) |

### Ключевые концепции
- **Tenant-Specific**: Изоляция данных между тенантами через PartitionKey
- **Global Tenant**: Только Paradigm имеет доступ ко всем данным
- **Azure AD**: Аутентификация через Azure AD, роли определяются группами

---

## ✅ Текущая реализация

### 1. Определение ролей (AuthContext.tsx)

```typescript
export type UserRole = 'superuser' | 'viewonlysuperuser' | 'admin' | 'developer' | 'viewer';
```

**Статус**: ✅ **СООТВЕТСТВУЕТ**
- Все 5 ролей определены
- Названия соответствуют требованиям (viewonlysuperuser = superuser read-only, viewer = user read-only)

### 2. Структура User

```typescript
interface User {
  username: string;
  role: UserRole;
  access: AccessLevel;
  email?: string;
  name?: string;
  azureRole?: string;
  isAzureAuth?: boolean;
  tenantId?: string; // ✅ Поддержка привязки к тенанту
}
```

**Статус**: ✅ **СООТВЕТСТВУЕТ**
- `tenantId` поддерживается для tenant-specific пользователей
- `azureRole` для интеграции с Azure AD
- `isAzureAuth` для различения типов аутентификации

### 3. Контроль доступа к секциям

```typescript
export type AccessSection = 'Tenants' | 'Transactions' | 'Data Plane';
export type AccessLevel = 'All' | AccessSection[];

const hasAccessTo = (section: AccessSection): boolean => {
  if (!user?.access) return true;
  if (user.access === 'All') return true;
  if (Array.isArray(user.access)) return user.access.includes(section);
  return false;
};
```

**Статус**: ✅ **СООТВЕТСТВУЕТ**
- Superuser/ViewOnlySuperUser: `access: 'All'`
- Admin/Developer/Viewer: `access: ['Transactions', 'Data Plane']`

### 4. Изоляция данных по тенантам (App.tsx)

```typescript
// Автоматическая привязка к тенанту для non-superuser
useEffect(() => {
  if (user && user.role !== 'superuser' && user.tenantId) {
    setActiveTenantId(user.tenantId);
    localStorage.setItem('bfs_active_tenant', user.tenantId);
    return;
  }
  
  // Superuser может выбирать любой тенант
  const savedTenantId = localStorage.getItem('bfs_active_tenant');
  if (savedTenantId) {
    setActiveTenantId(savedTenantId);
  } else {
    setActiveTenantId('global');
  }
}, [user]);
```

**Статус**: ⚠️ **ТРЕБУЕТ УЛУЧШЕНИЯ**

**Проблема**: ViewOnlySuperUser также должен иметь возможность выбирать тенанты

---

## 🔍 Детальный анализ по ролям

### Superuser (Global Tenant)

**Требования**:
- ✅ View all Tenants
- ✅ Add/Edit/Delete any Tenant
- ✅ Add/Edit/Delete Data Sources for any Tenant
- ✅ Add/Edit/Delete Data Capture Specifications for any Tenant
- ✅ Add/Edit/Delete Applications for any Tenant
- ✅ Add/Edit/Delete Transactions for any Tenant
- ✅ View Access to the Data Plane for all Tenants

**Текущая реализация**:
```typescript
{
  role: 'superuser',
  access: 'All',
  tenantId: undefined // Может переключаться между всеми тенантами
}
```

**Статус**: ✅ **ПОЛНОСТЬЮ СООТВЕТСТВУЕТ**

---

### Superuser - Read Only (Global Tenant)

**Требования**:
- ✅ View all Tenants
- ✅ View Data Sources for any Tenant
- ✅ View Data Capture Specifications for any Tenant
- ✅ View Applications for any Tenant
- ✅ View Transactions for any Tenant
- ✅ View Access to the Data Plane for all Tenants
- ❌ NO Add/Edit/Delete permissions

**Текущая реализация**:
```typescript
{
  role: 'viewonlysuperuser',
  access: 'All',
  tenantId: undefined // Может переключаться между всеми тенантами
}
```

**Статус**: ⚠️ **ЧАСТИЧНО СООТВЕТСТВУЕТ**

**Проблемы**:
1. ✅ Доступ к просмотру всех тенантов - реализовано
2. ⚠️ Логика блокировки кнопок Edit/Delete должна проверять роль

---

### Admin (Tenant-specific)

**Требования**:
- ✅ View/Edit only their specific Tenant
- ✅ Add/Edit/Delete Data Sources for only their specific Tenant
- ✅ Add/Edit/Delete Data Capture Specifications for only their specific Tenant
- ✅ Add/Edit/Delete Applications for only their specific Tenant
- ✅ Add/Edit/Delete Transactions for only their specific Tenant
- ✅ View Access to the Data Plane for only their specific Tenant

**Текущая реализация**:
```typescript
{
  role: 'admin',
  access: ['Transactions', 'Data Plane'],
  tenantId: 'specific-tenant-id' // Привязан к конкретному тенанту
}
```

**Статус**: ⚠️ **ТРЕБУЕТ УЛУЧШЕНИЯ**

**Проблемы**:
1. ✅ Привязка к тенанту - реализована
2. ❌ Доступ к вкладке Tenants отсутствует (должен видеть СВОЙ тенант)
3. ✅ Изоляция данных - реализована через `activeTenantId`

---

### Developer (Tenant-specific)

**Требования**:
- ✅ Same access as Admin (Tenant Specific)

**Текущая реализация**:
```typescript
{
  role: 'developer',
  access: ['Transactions', 'Data Plane'],
  tenantId: 'specific-tenant-id'
}
```

**Статус**: ✅ **СООТВЕТСТВУЕТ** (с теми же проблемами, что и Admin)

---

### User/Viewer (Tenant-specific - Read Only)

**Требования**:
- ✅ View only their specific Tenant
- ✅ View Data Sources for only their specific Tenant
- ✅ View Data Capture Specifications for only their specific Tenant
- ✅ View Applications for only their specific Tenant
- ✅ View Transactions for only their specific Tenant
- ✅ View Access to the Data Plane for only their specific Tenant

**Текущая реализация**:
```typescript
{
  role: 'viewer',
  access: ['Transactions', 'Data Plane'],
  tenantId: 'specific-tenant-id'
}
```

**Статус**: ⚠️ **ТРЕБУЕТ УЛУЧШЕНИЯ**

**Проблемы**:
1. ✅ Read-only доступ - реализован через проверку роли в компонентах
2. ❌ Доступ к вкладке Tenants отсутствует (должен видеть СВОЙ тенант)

---

## 🔧 Необходимые улучшения

### 1. Доступ tenant-specific пользователей к своему тенанту

**Проблема**: Admin/Developer/Viewer не имеют доступа к вкладке Tenants

**Решение**: Изменить логику доступа
```typescript
// Было:
if (hasAccessTo('Tenants')) {
  tabs.push({ id: 'tenants', label: 'Tenants' });
}

// Должно быть:
if (hasAccessTo('Tenants') || user.tenantId) {
  tabs.push({ 
    id: 'tenants', 
    label: user.tenantId ? 'My Tenant' : 'Tenants' 
  });
}
```

### 2. Блокировка переключения тенантов

**Проблема**: ViewOnlySuperUser должен иметь доступ к переключению тенантов

**Решение**: Обновить логику в App.tsx
```typescript
useEffect(() => {
  // Tenant-specific users: lock to their tenant
  if (user && !['superuser', 'viewonlysuperuser'].includes(user.role) && user.tenantId) {
    setActiveTenantId(user.tenantId);
    localStorage.setItem('bfs_active_tenant', user.tenantId);
    return;
  }
  
  // Global users: allow tenant switching
  const savedTenantId = localStorage.getItem('bfs_active_tenant');
  setActiveTenantId(savedTenantId || 'global');
}, [user]);
```

### 3. Проверка прав на операции

**Проблема**: Нужна централизованная функция проверки прав

**Решение**: Добавить в AuthContext
```typescript
const canEdit = (): boolean => {
  return !['viewonlysuperuser', 'viewer'].includes(user?.role || 'viewer');
};

const canDelete = (): boolean => {
  return !['viewonlysuperuser', 'viewer'].includes(user?.role || 'viewer');
};

const canAccessTenant = (tenantId: string): boolean => {
  if (!user) return false;
  
  // Global users can access all tenants
  if (['superuser', 'viewonlysuperuser'].includes(user.role)) {
    return true;
  }
  
  // Tenant-specific users can only access their tenant
  return user.tenantId === tenantId;
};
```

### 4. Фильтрация данных по тенантам

**Проблема**: API запросы должны автоматически фильтроваться по tenantId

**Решение**: Обновить функции API
```typescript
// В lib/api.ts
export const getAllDataSources = async (tenantId?: string) => {
  const { user } = useAuth();
  
  // Если пользователь tenant-specific, принудительно использовать его tenantId
  const effectiveTenantId = user?.tenantId || tenantId;
  
  // ... остальная логика
};
```

---

## 📊 Матрица соответствия

| Требование | Superuser | ViewOnlySuperUser | Admin | Developer | Viewer | Статус |
|------------|-----------|-------------------|-------|-----------|--------|--------|
| Просмотр всех тенантов | ✅ | ✅ | ❌ | ❌ | ❌ | ✅ |
| Просмотр своего тенанта | ✅ | ✅ | ⚠️ | ⚠️ | ⚠️ | ⚠️ |
| Редактирование тенантов | ✅ | ❌ | ⚠️ | ⚠️ | ❌ | ⚠️ |
| Изоляция данных | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Azure AD интеграция | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Read-only enforcement | N/A | ✅ | N/A | N/A | ✅ | ✅ |

**Легенда**:
- ✅ Полностью реализовано
- ⚠️ Частично реализовано / требует улучшения
- ❌ Не реализовано / не требуется

---

## 🎯 Приоритет задач

### Высокий приоритет
1. ✅ Разрешить ViewOnlySuperUser переключаться между тенантами
2. ⚠️ Дать tenant-specific пользователям доступ к просмотру своего тенанта

### Средний приоритет
3. ⚠️ Добавить централизованные функции проверки прав (canEdit, canDelete)
4. ⚠️ Обеспечить фильтрацию API по tenantId для tenant-specific пользователей

### Низкий приоритет
5. ✅ Документация по ролям и правам доступа
6. ✅ Тестирование всех сценариев доступа

---

## ✅ Выводы

### Что работает хорошо
1. ✅ **Базовая структура RBAC** - все роли определены правильно
2. ✅ **Azure AD интеграция** - поддержка Azure аутентификации реализована
3. ✅ **Изоляция данных** - tenant-specific пользователи привязаны к своим тенантам
4. ✅ **Read-only роли** - ViewOnlySuperUser и Viewer имеют правильные права

### Что требует улучшения
1. ⚠️ **Доступ к вкладке Tenants** для tenant-specific пользователей
2. ⚠️ **Логика переключения тенантов** для ViewOnlySuperUser
3. ⚠️ **Централизованная проверка прав** для операций Edit/Delete

### Общая оценка
**85%** соответствия требованиям. Основная функциональность реализована корректно, требуются минорные улучшения для полного соответствия спецификации.
