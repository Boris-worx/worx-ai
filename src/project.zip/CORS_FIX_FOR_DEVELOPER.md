# 🔧 CORS Configuration Required - For Backend Developer

## 🚨 Issue

Web application **cannot connect** to BFS API due to missing CORS headers.

**Error in Browser:**
```
TypeError: Failed to fetch
CORS policy: No 'Access-Control-Allow-Origin' header is present
```

**Status:**
- ✅ API Key: Working (tested in Postman)
- ✅ API Endpoints: Working (tested in Postman)
- ❌ CORS: **NOT configured** (blocking browser requests)

---

## ✅ Solution: Enable CORS on Azure App Service

### Quick Fix (5 minutes - Azure Portal)

1. **Login to Azure Portal**: https://portal.azure.com

2. **Navigate to App Service**:
   - Search for: `poc-apis-bfs`
   - Click on the App Service

3. **Configure CORS**:
   - Left menu → **API** section → **CORS**
   - Under "Allowed Origins", add: `*`
   - Click **Save**

4. **Restart App Service**:
   - Overview → Click **Restart**
   - Wait 30 seconds

5. **Test**:
   ```bash
   curl -X GET 'https://poc-apis-bfs.azurewebsites.net/1.0/tenants' \
     -H 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
     -H 'Origin: https://make.figma.com' \
     -v
   ```
   
   **Look for:** `Access-Control-Allow-Origin: *` in response headers

---

## 📋 Required CORS Headers

The API must send these headers in **ALL responses**:

```http
Access-Control-Allow-Origin: *
Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS
Access-Control-Allow-Headers: X-BFS-Auth, Content-Type, If-Match
Access-Control-Max-Age: 86400
```

### For OPTIONS Preflight Requests

Browser sends OPTIONS before actual request:

**Browser Request:**
```http
OPTIONS /1.0/tenants HTTP/1.1
Origin: https://make.figma.com
Access-Control-Request-Method: GET
Access-Control-Request-Headers: x-bfs-auth
```

**API Must Respond:**
```http
HTTP/1.1 204 No Content
Access-Control-Allow-Origin: *
Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS
Access-Control-Allow-Headers: X-BFS-Auth, Content-Type, If-Match
```

---

## 🔧 Code Implementation (if needed)

### Option 1: ASP.NET Core

**In `Program.cs` or `Startup.cs`:**

```csharp
public void ConfigureServices(IServiceCollection services)
{
    services.AddCors(options =>
    {
        options.AddPolicy("AllowAll",
            builder =>
            {
                builder.AllowAnyOrigin()
                       .AllowAnyMethod()
                       .AllowAnyHeader()
                       .WithExposedHeaders("ETag", "If-Match");
            });
    });
    
    // ... other services
}

public void Configure(IApplicationBuilder app)
{
    // IMPORTANT: UseCors must be before UseRouting
    app.UseCors("AllowAll");
    
    app.UseRouting();
    app.UseAuthentication();
    app.UseAuthorization();
    app.UseEndpoints(endpoints => { });
}
```

### Option 2: web.config

```xml
<?xml version="1.0" encoding="utf-8"?>
<configuration>
  <system.webServer>
    <httpProtocol>
      <customHeaders>
        <add name="Access-Control-Allow-Origin" value="*" />
        <add name="Access-Control-Allow-Methods" value="GET, POST, PUT, DELETE, OPTIONS" />
        <add name="Access-Control-Allow-Headers" value="X-BFS-Auth, Content-Type, If-Match" />
        <add name="Access-Control-Max-Age" value="86400" />
      </customHeaders>
    </httpProtocol>
  </system.webServer>
</configuration>
```

### Option 3: Node.js/Express

```javascript
const cors = require('cors');

app.use(cors({
  origin: '*',
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['X-BFS-Auth', 'Content-Type', 'If-Match'],
  exposedHeaders: ['ETag']
}));
```

---

## 🧪 Verification Steps

### Step 1: Test OPTIONS Request
```bash
curl -X OPTIONS \
  'https://poc-apis-bfs.azurewebsites.net/1.0/tenants' \
  -H 'Origin: https://make.figma.com' \
  -H 'Access-Control-Request-Method: GET' \
  -H 'Access-Control-Request-Headers: x-bfs-auth' \
  -v
```

**Expected Response:**
```
< HTTP/1.1 204 No Content
< Access-Control-Allow-Origin: *
< Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS
< Access-Control-Allow-Headers: X-BFS-Auth, Content-Type, If-Match
```

### Step 2: Test GET Request
```bash
curl -X GET \
  'https://poc-apis-bfs.azurewebsites.net/1.0/tenants' \
  -H 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
  -H 'Origin: https://make.figma.com' \
  -v
```

**Expected Response:**
```
< HTTP/1.1 200 OK
< Access-Control-Allow-Origin: *
< Content-Type: application/json
```

### Step 3: Test in Browser Console
```javascript
fetch('https://poc-apis-bfs.azurewebsites.net/1.0/tenants', {
  method: 'GET',
  headers: {
    'X-BFS-Auth': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
  }
})
.then(res => console.log('✅ CORS Working!', res.status))
.catch(err => console.error('❌ CORS Blocked:', err));
```

---

## 📊 Affected Endpoints

All these endpoints need CORS:

```
✅ GET    /1.0/tenants
✅ GET    /1.0/tenants/{id}
✅ POST   /1.0/tenants
✅ PUT    /1.0/tenants/{id}
✅ DELETE /1.0/tenants/{id}
```

**Custom Headers Used:**
- `X-BFS-Auth` - API authentication key (required on ALL requests)
- `If-Match` - ETag value (required on PUT/DELETE)
- `Content-Type` - application/json

---

## 🔐 Production Security

For production, instead of `*`, use specific domains:

**Azure Portal CORS:**
```
https://make.figma.com
https://app.yourcompany.com
http://localhost:3000
```

**Or in Code:**
```csharp
var allowedOrigins = new[] {
    "https://make.figma.com",
    "https://app.yourcompany.com",
    "http://localhost:3000"
};

builder.WithOrigins(allowedOrigins)
       .AllowAnyMethod()
       .AllowAnyHeader();
```

---

## ✅ Success Checklist

After configuration, verify:

- [ ] OPTIONS requests return 204 with CORS headers
- [ ] GET requests return data with CORS headers
- [ ] Browser console shows no CORS errors
- [ ] Web app loads tenants successfully
- [ ] All CRUD operations work from browser

---

## 📞 After Configuration

**Notify the frontend team:**
- ✅ CORS is now enabled
- ✅ Allowed origins: `*` (or list specific domains)
- ✅ All endpoints are accessible from browser

---

## 🚀 Priority: **HIGH**

**Impact:** Web application is completely blocked without CORS  
**Effort:** 5-10 minutes  
**User Impact:** Cannot use the application until fixed

---

## 📝 Quick Reference

**Server:** `poc-apis-bfs.azurewebsites.net`  
**API Key:** `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`  
**Frontend Origin:** `https://make.figma.com`

**Required Headers:**
```
Access-Control-Allow-Origin: *
Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS
Access-Control-Allow-Headers: X-BFS-Auth, Content-Type, If-Match
```

---

**Contact:** If you have questions, please reach out to the web application team.
