# Tenant Import - Supported Formats

## 🎯 Overview

The Tenant Import feature now supports **multiple JSON formats** for maximum flexibility.

---

## 📋 Supported Formats

### Format 1: Simple Array (Original)

**Best for:** Creating new tenants from scratch

```json
[
  {
    "TenantName": "Acme Corporation"
  },
  {
    "TenantName": "TechStart Industries"
  },
  {
    "TenantName": "Global Enterprises"
  }
]
```

**Behavior:**
- ✅ System auto-generates TenantId
- ✅ Creates tenants via API
- ✅ Sets CreateTime and UpdateTime
- ✅ Generates ETag

**Use Case:**
- Initial tenant creation
- Adding new tenants from external list
- Quick bulk tenant setup

**Sample File:** `/sample-tenants-import.json`

---

### Format 2: API Response (New!)

**Best for:** Importing/restoring from API export

```json
{
  "status": {
    "code": 200,
    "message": "Successful"
  },
  "data": {
    "tenants": [
      {
        "TenantId": "tenant-1",
        "TenantName": "Acme Corporation",
        "CreateTime": "2025-10-02T22:11:27.902156",
        "UpdateTime": "2025-10-02T22:11:27.902156",
        "_rid": "1tsVAIBajWwBAAAAAAAAAA==",
        "_self": "dbs/1tsVAA==/colls/1tsVAIBajWw=/docs/1tsVAIBajWwBAAAAAAAAAA==/",
        "_etag": "\"5400c5bc-0000-0300-0000-68def8900000\"",
        "_attachments": "attachments/",
        "_ts": 1759443088
      },
      {
        "TenantId": "tenant-2",
        "TenantName": "TechStart Industries",
        "CreateTime": "2025-10-02T22:37:15.580991",
        "UpdateTime": "2025-10-02T22:37:15.580991",
        "_rid": "1tsVAIBajWwCAAAAAAAAAA==",
        "_self": "dbs/1tsVAA==/colls/1tsVAIBajWw=/docs/1tsVAIBajWwCAAAAAAAAAA==/",
        "_etag": "\"550083ec-0000-0300-0000-68defea00000\"",
        "_attachments": "attachments/",
        "_ts": 1759444640
      }
    ]
  }
}
```

**Behavior:**
- ✅ Uses existing TenantId
- ✅ Preserves all Cosmos DB metadata
- ✅ Keeps CreateTime and UpdateTime
- ✅ Maintains ETag
- ✅ Imports directly without API call

**Use Case:**
- Restoring from backup
- Migrating between environments
- Importing from API export
- Data recovery

**Sample File:** `/sample-tenants-api-format.json`

---

### Format 3: API Response with Direct Data Array

**Alternative API format:**

```json
{
  "status": {
    "code": 200,
    "message": "Successful"
  },
  "data": [
    {
      "TenantId": "tenant-1",
      "TenantName": "Acme Corporation",
      ...
    }
  ]
}
```

**Behavior:**
- Same as Format 2
- `data` is array instead of object with `tenants` property

---

## 🔄 Format Detection Logic

```typescript
if (Array.isArray(json)) {
  // Format 1: Direct array
  tenantsArray = json;
} else if (json.data && Array.isArray(json.data.tenants)) {
  // Format 2: API response with data.tenants
  tenantsArray = json.data.tenants;
} else if (json.data && Array.isArray(json.data)) {
  // Format 3: API response with data as array
  tenantsArray = json.data;
}
```

---

## 🎯 Import Behavior

### Simple Array → API Creation

```
User uploads simple array
    ↓
For each tenant:
    ↓
  Call: createTenant(TenantName)
    ↓
  API generates:
    - TenantId
    - CreateTime
    - UpdateTime
    - _etag
    ↓
  Returns complete tenant object
    ↓
Add to application state
```

### API Response → Direct Import

```
User uploads API response
    ↓
Extract tenants from data.tenants
    ↓
For each tenant:
    ↓
  Already has:
    - TenantId ✓
    - TenantName ✓
    - CreateTime ✓
    - UpdateTime ✓
    - _etag ✓
    - All metadata ✓
    ↓
  Use directly (no API call)
    ↓
Add to application state
```

---

## 📊 Comparison

| Feature | Simple Array | API Response |
|---------|-------------|--------------|
| **TenantId** | Auto-generated | Preserved |
| **CreateTime** | New timestamp | Original preserved |
| **UpdateTime** | New timestamp | Original preserved |
| **_etag** | New generated | Original preserved |
| **_rid, _self** | New generated | Original preserved |
| **_ts** | New timestamp | Original preserved |
| **API Calls** | Yes (one per tenant) | No (direct import) |
| **Speed** | Slower | Instant |
| **Use Case** | New tenants | Restore/migrate |

---

## 🧪 Testing

### Test 1: Simple Array Format

**File:** `/sample-tenants-import.json`
```json
[
  { "TenantName": "Acme Corporation" },
  { "TenantName": "TechStart Industries" }
]
```

**Steps:**
1. Click "Import Tenants from JSON"
2. Upload file
3. Click "Import Tenants"

**Expected:**
- ✅ 2 API calls made
- ✅ TenantIds generated (e.g., tenant-xxx)
- ✅ Success: "Successfully imported 2 tenant(s)"
- ✅ 2 tenants in table

---

### Test 2: API Response Format

**File:** `/sample-tenants-api-format.json` (your file)
```json
{
  "status": { ... },
  "data": {
    "tenants": [
      { "TenantId": "tenant-1", "TenantName": "...", ... }
    ]
  }
}
```

**Steps:**
1. Click "Import Tenants from JSON"
2. Upload file
3. Click "Import Tenants"

**Expected:**
- ✅ NO API calls (direct import)
- ✅ TenantIds preserved (tenant-1, tenant-2, etc.)
- ✅ Success: "Successfully imported 5 tenant(s)"
- ✅ 5 tenants in table
- ✅ All metadata preserved

---

### Test 3: Mixed Validation

**File with invalid tenant:**
```json
[
  { "TenantName": "Valid Tenant" },
  { "Name": "Invalid" },  // Missing TenantName
  { "TenantName": "Another Valid" }
]
```

**Expected:**
- ⚠️ Warning: "Found 2 valid tenant(s) out of 3"
- ✅ Imports 2 valid tenants
- ❌ Skips invalid one

---

## 💡 User Experience

### Loading File

**Before (OLD):**
```
Upload → Error: "Invalid JSON: Expected an array of tenants"
(Your API format failed)
```

**After (NEW):**
```
Upload → Success: "JSON loaded successfully - 5 tenant(s) found"
(Both formats work!)
```

### Import Process

**Format 1 (Simple Array):**
```
Click Import
    ↓
Button: "Importing..."
    ↓
API calls visible in Network tab
    ↓
Success toast
    ↓
Tenants appear in table
```

**Format 2 (API Response):**
```
Click Import
    ↓
Button: "Importing..."
    ↓
Instant (no API calls)
    ↓
Success toast
    ↓
Tenants appear in table
```

---

## 🎨 UI Updates

### Format Examples in Dialog

**Now shows both formats:**

```
┌─────────────────────────────────────────────────────────┐
│  Import Tenants from JSON                         [×]   │
├─────────────────────────────────────────────────────────┤
│                                                          │
│  Supported formats:                                      │
│                                                          │
│  Format 1: Simple array                                 │
│  [                                                       │
│    { "TenantName": "Company A" },                       │
│    { "TenantName": "Company B" }                        │
│  ]                                                       │
│                                                          │
│  Format 2: API response                                 │
│  {                                                       │
│    "status": { "code": 200, ... },                      │
│    "data": {                                            │
│      "tenants": [                                       │
│        { "TenantId": "tenant-1", "TenantName": ... }    │
│      ]                                                   │
│    }                                                     │
│  }                                                       │
│                                                          │
│  For simple array: TenantID will be auto-generated.     │
│  For API response: Uses existing TenantId and metadata. │
│                                                          │
└─────────────────────────────────────────────────────────┘
```

---

## 📚 Files Provided

| File | Format | Description |
|------|--------|-------------|
| `/sample-tenants-import.json` | Simple Array | 5 tenants, names only |
| `/sample-tenants-api-format.json` | API Response | 5 tenants, full metadata |

**Both work with the import feature!**

---

## 🔮 Future Enhancements

### Potential Additions

**1. Format Auto-Detection Preview**
```
Upload → Shows: "Detected: API Response Format (5 tenants)"
```

**2. Export to API Format**
```
[Export Tenants] → Downloads in API format
```

**3. Format Conversion**
```
Option: "Convert to simple array before import"
```

**4. Validation Details**
```
Shows which fields will be preserved vs generated
```

---

## ✅ Summary

**Before:**
- ❌ Only simple array format
- ❌ Your API format failed

**After:**
- ✅ Simple array format (creates new)
- ✅ API response format (imports existing)
- ✅ Automatic format detection
- ✅ Preserves metadata
- ✅ Both formats work perfectly

**Your file now works!** 🎉

---

## 🚀 How to Use Your File

1. **Open Application**
2. **Click "Import Tenants from JSON"**
3. **Upload your file** (the one with `status` and `data.tenants`)
4. **Preview shows:** "JSON loaded successfully - 5 tenant(s) found"
5. **Click "Import Tenants"**
6. **Success!** All 5 tenants with full metadata imported
7. **Check table:** See tenant-1, tenant-2, tenant-3, tenant-4, tenant-5

**All Cosmos DB metadata preserved!** ✅