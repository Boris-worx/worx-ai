# Data Capture Specification tenantId Fix

## Problem

При обновлении Data Capture Specification возникала ошибка:

```
❌ Error response: {"status": {"code": 400, "message": "Missing tenantId"}, "data": {}}
Error updating data capture spec: Error: Missing tenantId
Failed to update spec: Error: Missing tenantId
```

## Root Cause

В функции `updateDataCaptureSpec` в `/components/DataSourcesView.tsx` (строки 2798-2813) при вызове API для обновления спецификации не передавались обязательные поля:
- `tenantId` - идентификатор тенанта (обязательное поле)
- `dataSourceId` - идентификатор источника данных (обязательное поле)

Согласно интерфейсу `DataCaptureSpec` в `/lib/api.ts` (строки 84-104), эти поля являются обязательными:
```typescript
export interface DataCaptureSpec {
  dataCaptureSpecId?: string;
  dataCaptureSpecName: string;
  tenantId: string;           // обязательное поле (без ?)
  dataSourceId: string;       // обязательное поле (без ?)
  // ... остальные поля
}
```

## Solution

Добавлены обязательные поля `tenantId` и `dataSourceId` в объект обновления:

### Изменения в `/components/DataSourcesView.tsx`

```typescript
// Добавлена валидация tenantId перед обновлением
const tenantId = realSpec.tenantId || activeTenantId;
if (!tenantId || tenantId === 'global') {
  toast.error('Cannot update spec: Invalid tenant');
  setIsUpdatingSpec(false);
  return;
}

// В вызов updateDataCaptureSpec добавлены обязательные поля
const updatedSpec = await updateDataCaptureSpec(
  selectedSpec.dataCaptureSpecId,
  {
    dataCaptureSpecName: editSpecForm.dataCaptureSpecName,
    tenantId: tenantId,                    // ✅ ДОБАВЛЕНО
    dataSourceId: realSpec.dataSourceId,   // ✅ ДОБАВЛЕНО
    isActive: editSpecForm.isActive,
    version: editSpecForm.version,
    profile: editSpecForm.profile,
    sourcePrimaryKeyField: editSpecForm.sourcePrimaryKeyField,
    partitionKeyField: editSpecForm.partitionKeyField,
    partitionKeyValue: editSpecForm.partitionKeyValue,
    allowedFilters: allowedFilters,
    requiredFields: requiredFields,
    containerSchema: containerSchema
  },
  realSpec._etag
);
```

## Implementation Details

1. **tenantId извлекается из существующей спецификации**: `realSpec.tenantId || activeTenantId`
   - Сначала пытаемся использовать tenantId из загруженной спецификации
   - Если отсутствует, используем активный тенант

2. **Валидация tenantId**:
   - Проверяем, что tenantId существует
   - Запрещаем обновление для глобального тенанта (защита данных)

3. **dataSourceId берется из существующей спецификации**: `realSpec.dataSourceId`
   - Поскольку это обязательное поле, оно должно присутствовать в загруженной спецификации

## Consistency with Create Operation

Эта логика соответствует операции создания спецификации (строки 2404-2414):
```typescript
const tenantId = selectedDataSource.TenantId || activeTenantId;

if (!tenantId || tenantId === 'global') {
  toast.error('Cannot create spec: Invalid tenant');
  return;
}

await createDataCaptureSpec({
  // ...
  tenantId: tenantId,
  dataSourceId: dataSourceId,
  // ...
});
```

## Multi-tenancy Considerations

Это исправление критично для мультитенантной изоляции данных:
- Каждая Data Capture Specification привязана к конкретному тенанту
- При обновлении спецификации tenantId должен сохраняться
- Запрещено изменение спецификаций глобального тенанта через UI

## Testing

После исправления необходимо протестировать:
1. ✅ Создание новой Data Capture Specification
2. ✅ Обновление существующей Data Capture Specification
3. ✅ Валидация изоляции данных между тенантами
4. ✅ Проверка, что глобальный тенант не может обновлять спецификации

## Related Files

- `/components/DataSourcesView.tsx` - основной компонент, исправление на строках 2788-2813
- `/lib/api.ts` - определения интерфейсов и API функций
  - Интерфейс `DataCaptureSpec`: строки 84-104
  - Функция `updateDataCaptureSpec`: строки 1569-1609
  - Функция `createDataCaptureSpec`: строки 1530-1566

## Status

✅ **FIXED** - Все обязательные поля теперь передаются в API для обновления Data Capture Specification
