# ✅ Data Capture Specifications - Table Implementation

## 🎯 Что реализовано

Data Capture Specifications теперь отображаются как **полноценная таблица** в expanded row каждого Data Source, точно как в workflow! Таблица содержит колонки: **Table**, **Version**, **Date**, и **Action** с кнопками View/Edit/Delete.

---

## 🖼️ Как выглядит (по образцу workflow)

```
Data Source: Bidtools (разверну нуто ▼)
┌──────────────────────────────────────────────────────────────────────┐
│ Data Capture Specifications:         [+ Add Data Capture Specification]│
├──────────────────┬──────────┬─────────────┬──────────────────────────┤
│ Table            │ Version  │ Date        │ Action                   │
├──────────────────┼──────────┼─────────────┼──────────────────────────┤
│ Quotes           │ 2.0      │ 10/30/2025  │ [View] [Edit] [Delete]   │
│ QuoteDetails     │ 2.1      │ 10/31/2025  │ [View] [Edit] [Delete]   │
│ QuotePacks       │ 2.1      │ 10/31/2025  │ [View] [Edit] [Delete]   │
└──────────────────┴──────────┴─────────────┴──────────────────────────┘
```

---

## ✨ Функциональность

### 1. Expandable Row с таблицей

**При развороте Data Source:**
```
▶ Data Source свёрнут  → Показывает только main row
▼ Data Source развёрнут → Показывает таблицу specifications
```

### 2. Data Capture Specifications Table

**Колонки:**
```
┌─────────────────┬──────────┬────────────┬────────────┐
│ Table           │ Version  │ Date       │ Action     │
├─────────────────┼──────────┼────────────┼────────────┤
│ Quotes          │ 2.0      │ 10/30/2025 │ View/Edit/Delete │
│ QuoteDetails    │ 2.1      │ 10/31/2025 │ View/Edit/Delete │
│ QuotePacks      │ 2.1      │ 10/31/2025 │ View/Edit/Delete │
└─────────────────┴──────────┴────────────┴────────────┘
```

**Actions:**
```
[View]   - Открывает dialog с JSON schema
[Edit]   - Открывает dialog для редактирования version и schema
[Delete] - Открывает confirmation dialog
```

### 3. Add Data Capture Specification Button

**Расположение:**
```
┌──────────────────────────────────────────────────────────────┐
│ Data Capture Specifications:    [+ Add Data Capture Specification] │
└──────────────────────────────────────────────────────────────┘
```

**Кнопка:**
- Синяя (#1D6BCD)
- Иконка Plus
- Показывается только для canCreate users
- При клике: toast "Add Data Capture Specification - Coming soon!"

---

## 💻 Технические детали

### DataCaptureSpecification Interface

```typescript
interface DataCaptureSpecification {
  id: string;           // Уникальный ID
  table: string;        // Название таблицы (Quotes, QuoteDetails, etc.)
  version: string;      // Версия specification (2.0, 2.1, etc.)
  date: string;         // Дата создания/обновления
  schema: any;          // JSON schema данных
}
```

---

### Mock Data - getMockSpecifications()

**Bidtools Specifications:**
```typescript
[
  { id: 'spec_quotes', table: 'Quotes', version: '2.0', date: '10/30/2025', schema: {...} },
  { id: 'spec_quotedetails', table: 'QuoteDetails', version: '2.1', date: '10/31/2025', schema: {...} },
  { id: 'spec_quotepacks', table: 'QuotePacks', version: '2.1', date: '10/31/2025', schema: {...} }
]
```

**Databricks Specifications:**
```typescript
[
  { id: 'spec_quotes_db', table: 'Quotes', version: '1.5', date: '10/27/2025', schema: {...} },
  { id: 'spec_quotepackorder_db', table: 'QuotePackOrder', version: '1.0', date: '10/27/2025', schema: {...} }
]
```

**Пустой Data Source:**
```typescript
[]  // Показывает empty state
```

---

### Expanded Content - renderExpandedContent()

**Структура:**
```tsx
renderExpandedContent={(row) => {
  const specifications = getMockSpecifications(getDataSourceName(row));
  
  return (
    <div className="space-y-3">
      {/* Header with Add button */}
      <div className="flex items-center justify-between">
        <h4>Data Capture Specifications:</h4>
        <Button>[+ Add Data Capture Specification]</Button>
      </div>
      
      {/* Table or Empty State */}
      {specifications.length === 0 ? (
        <EmptyState />
      ) : (
        <SpecificationsTable specifications={specifications} />
      )}
    </div>
  );
}}
```

---

### Specifications Table

**HTML Table:**
```tsx
<table className="w-full text-sm">
  <thead className="bg-muted/50 border-b">
    <tr>
      <th className="text-left py-2 px-4">Table</th>
      <th className="text-left py-2 px-4">Version</th>
      <th className="text-left py-2 px-4">Date</th>
      <th className="text-right py-2 px-4">Action</th>
    </tr>
  </thead>
  <tbody>
    {specifications.map((spec) => (
      <tr key={spec.id} className="border-b last:border-0 hover:bg-muted/30">
        <td className="py-2 px-4">{spec.table}</td>
        <td className="py-2 px-4">{spec.version}</td>
        <td className="py-2 px-4">{spec.date}</td>
        <td className="py-2 px-4">
          <div className="flex gap-1 justify-end">
            <Button onClick={viewSpec}>View</Button>
            <Button onClick={editSpec}>Edit</Button>
            <Button onClick={deleteSpec}>Delete</Button>
          </div>
        </td>
      </tr>
    ))}
  </tbody>
</table>
```

**Styling:**
```css
- Table: w-full text-sm border rounded-lg
- Header: bg-muted/50 border-b
- Rows: hover:bg-muted/30 border-b last:border-0
- Actions: flex gap-1 justify-end
```

---

### Empty State

**Когда нет specifications:**
```tsx
<div className="text-center py-8 border-2 border-dashed rounded-lg">
  <Database className="h-10 w-10 mx-auto mb-3 text-muted-foreground" />
  <p className="text-sm text-muted-foreground">
    No Data Capture Specifications defined
  </p>
  <Button size="sm" variant="outline" className="mt-3">
    <Plus className="h-4 w-4 mr-1" />
    Add First Specification
  </Button>
</div>
```

**Показывается когда:**
- Data Source новый (только создан)
- Ещё не добавлены specifications
- getMockSpecifications() возвращает []

---

## 🎛️ Dialogs

### 1. View Specification Dialog

**Trigger:** Клик на "View" в Action column

**Content:**
```
┌─────────────────────────────────────────┐
│ Data Capture Specification              │
│ Schema definition for Quotes            │
├─────────────────────────────────────────┤
│ Table:   Quotes                         │
│ Version: 2.0                            │
│ Date:    10/30/2025                     │
├─────────────────────────────────────────┤
│ JSON Schema:                            │
│ ┌─────────────────────────────────────┐ │
│ │ {                                   │ │
│ │   "before": null,                   │ │
│ │   "after": {                        │ │
│ │     "QuoteId": 132821,              │ │
│ │     ...                             │ │
│ │   }                                 │ │
│ │ }                                   │ │
│ └─────────────────────────────────────┘ │
├─────────────────────────────────────────┤
│                            [Close]      │
└─────────────────────────────────────────┘
```

**Features:**
```tsx
- max-w-3xl max-h-[85vh]
- Top info: Table, Version, Date in 3-column grid
- JSON in <pre> with:
  - text-xs font
  - overflow-x-auto (horizontal scroll)
  - max-h-[400px] overflow-y-auto (vertical scroll)
  - bg-muted/30 border rounded
```

---

### 2. Edit Specification Dialog

**Trigger:** Клик на "Edit" в Action column

**Content:**
```
┌─────────────────────────────────────────┐
│ Edit Data Capture Specification         │
│ Update specification for Quotes         │
├─────────────────────────────────────────┤
│ Table:                                  │
│ [Quotes                 ] (disabled)    │
│                                         │
│ Version: *                              │
│ [2.0                    ]               │
│                                         │
│ JSON Schema: *                          │
│ ┌─────────────────────────────────────┐ │
│ │ { "before": null, "after": {...} }  │ │
│ │                                     │ │
│ │ (10 rows)                           │ │
│ └─────────────────────────────────────┘ │
├─────────────────────────────────────────┤
│                  [Cancel] [Save Changes]│
└─────────────────────────────────────────┘
```

**Features:**
```tsx
- max-w-2xl
- Table field disabled (read-only)
- Version input editable
- JSON Schema Textarea:
  - rows={10}
  - font-mono text-xs
  - Pre-filled with current schema (pretty printed)
- Save button: toast.success() + close
```

---

### 3. Delete Specification Dialog

**Trigger:** Клик на "Delete" в Action column

**Content:**
```
┌─────────────────────────────────────────┐
│ Delete Data Capture Specification       │
├─────────────────────────────────────────┤
│ Are you sure you want to delete the     │
│ specification for "Quotes"?             │
│ This action cannot be undone.           │
├─────────────────────────────────────────┤
│                     [Cancel] [Delete]   │
└─────────────────────────────────────────┘
```

**Features:**
```tsx
- AlertDialog (destructive action)
- Shows table name in message
- Delete button: bg-red-600 hover:bg-red-700
- On confirm: toast.success() + close
```

---

## 🎨 Styling

### Table Header

```css
thead: bg-muted/50 border-b
th: text-left py-2 px-4 (last one text-right for Actions)
```

### Table Rows

```css
tr: border-b last:border-0 hover:bg-muted/30
td: py-2 px-4
```

### Action Buttons

```css
Button: variant="ghost" size="sm"
Container: flex gap-1 justify-end
Delete button: text-muted-foreground hover:text-destructive
```

### Add Button (Top)

```css
bg-[#1D6BCD] hover:bg-[#1557A8]
size="sm"
Icon: Plus h-4 w-4 mr-1
```

### Empty State

```css
Container: text-center py-8 border-2 border-dashed rounded-lg
Icon: Database h-10 w-10 text-muted-foreground
Text: text-sm text-muted-foreground
Button: size="sm" variant="outline" mt-3
```

---

## 🔄 Workflow соответствие

### Из изображения:

```
Tenant: Global    Data Source: Bidtools    [+ Add Data Capture Specification]

Data Capture Specifications:

Table          Version    Date         Action
Quotes         2.0        10/30/2025   View/Edit/Delete
QuoteDetails   2.1        10/31/2025   View/Edit/Delete
QuotePacks     2.1        10/31/2025   View/Edit/Delete
```

### Наша реализация:

```
✅ Expandable row для каждого Data Source
✅ Заголовок "Data Capture Specifications:"
✅ Кнопка "+ Add Data Capture Specification" справа
✅ Таблица с колонками: Table, Version, Date, Action
✅ View/Edit/Delete actions для каждой specification
✅ Соответствие данных из изображения (Bidtools: Quotes 2.0, QuoteDetails 2.1, etc.)
```

---

## 🧪 Тестирование

### Шаги:

1. **Открой Data Source Onboarding tab**
   ```
   App → Data Source Onboarding
   ```

2. **Разверни Bidtools Data Source**
   ```
   Клик на chevron (▶) → меняется на (▼)
   ✅ Показывается expanded content
   ```

3. **Проверь заголовок**
   ```
   ✅ "Data Capture Specifications:" слева
   ✅ "+ Add Data Capture Specification" button справа (синий)
   ```

4. **Проверь таблицу Bidtools**
   ```
   ✅ 3 строки:
      - Quotes: Version 2.0, Date 10/30/2025
      - QuoteDetails: Version 2.1, Date 10/31/2025
      - QuotePacks: Version 2.1, Date 10/31/2025
   ✅ Actions: View, Edit, Delete для каждой
   ```

5. **Кликни View для Quotes**
   ```
   ✅ Открывается dialog
   ✅ Показывает Table: Quotes, Version: 2.0, Date: 10/30/2025
   ✅ JSON schema отображается с pretty print
   ✅ Scrolling работает (vertical + horizontal)
   ✅ Close button закрывает dialog
   ```

6. **Кликни Edit для QuoteDetails**
   ```
   ✅ Открывается edit dialog
   ✅ Table field disabled (QuoteDetails)
   ✅ Version field editable (2.1)
   ✅ JSON Schema textarea с 10 rows
   ✅ Schema pre-filled с current data
   ✅ Save Changes: toast "Specification updated successfully!"
   ✅ Cancel закрывает без сохранения
   ```

7. **Кликни Delete для QuotePacks**
   ```
   ✅ Открывается alert dialog
   ✅ Message: "Are you sure you want to delete... QuotePacks?"
   ✅ Delete button красный (bg-red-600)
   ✅ Delete: toast "Specification for QuotePacks deleted successfully!"
   ✅ Cancel закрывает без удаления
   ```

8. **Кликни Add Data Capture Specification**
   ```
   ✅ Toast: "Add Data Capture Specification - Coming soon!"
   ```

9. **Разверни Databricks Data Source**
   ```
   ✅ Показывает 2 specifications:
      - Quotes: Version 1.5, Date 10/27/2025
      - QuotePackOrder: Version 1.0, Date 10/27/2025
   ✅ Actions работают так же
   ```

10. **Сверни Bidtools, разверни снова**
    ```
    ✅ Таблица показывается снова
    ✅ Данные не потеряны
    ```

11. **Проверь Empty State (если добавишь новый Data Source)**
    ```
    ✅ Иконка Database
    ✅ Text: "No Data Capture Specifications defined"
    ✅ Button: "Add First Specification"
    ✅ Button работает (toast)
    ```

12. **Проверь permissions**
    ```
    SuperUser / Admin / Developer:
    ✅ Видят Add button
    ✅ Видят все три action: View/Edit/Delete

    ViewOnlySuperUser / Viewer:
    ✅ НЕ видят Add button
    ✅ Видят только View action
    ```

---

## 📊 Статистика

### Код добавлен:

**DataSourcesView.tsx:**
```
+ DataCaptureSpecification interface (5 lines)
+ getMockSpecifications() function (~50 lines)
+ State для spec dialogs (4 lines)
+ renderExpandedContent с таблицей (~80 lines)
+ 3 новых dialog (View/Edit/Delete) (~150 lines)
```

**Итого:**
```
+ ~290 lines добавлено
- ~70 lines удалено (старый accordion)
= +220 lines net
```

---

### Размер dialogs:

**View Specification:**
```
max-w-3xl (768px)
max-h-[85vh]
JSON max-h-[400px]
```

**Edit Specification:**
```
max-w-2xl (672px)
Textarea: 10 rows
```

**Delete Specification:**
```
AlertDialog (default size ~400px)
```

---

## 🚀 Готово к интеграции с API

### Текущее состояние (Mock):

```typescript
const getMockSpecifications = (dataSourceName: string): DataCaptureSpecification[]
```

### Будущее (Real API):

```typescript
// API endpoint
GET /api/datasources/{dataSourceId}/specifications
POST /api/datasources/{dataSourceId}/specifications
PUT /api/datasources/{dataSourceId}/specifications/{specId}
DELETE /api/datasources/{dataSourceId}/specifications/{specId}

// Реализация
const [specifications, setSpecifications] = useState<DataCaptureSpecification[]>([]);

useEffect(() => {
  if (expandedDataSource) {
    fetchSpecifications(expandedDataSource.id).then(setSpecifications);
  }
}, [expandedDataSource]);

// В renderExpandedContent
const specifications = specificationsState[getDataSourceId(row)] || [];
```

---

## ✅ Что готово

```
✅ DataCaptureSpecification interface
✅ Mock данные для Bidtools (3 specs)
✅ Mock данные для Databricks (2 specs)
✅ getMockSpecifications() helper
✅ Таблица в expanded row с 4 колонками
✅ Header с Add button
✅ Empty state для новых Data Sources
✅ View specification dialog с JSON schema
✅ Edit specification dialog с version и schema
✅ Delete specification confirmation dialog
✅ Permissions check (canCreate, canEdit, canDelete)
✅ Toast notifications для всех actions
✅ Hover effects на table rows
✅ Responsive styling
✅ Соответствие workflow изображению
```

---

## 📝 Чеклист

```
□ Data Source Onboarding tab открыт
□ Data Source можно развернуть (chevron ▶/▼)
□ Показывается "Data Capture Specifications:" заголовок
□ Add button показывается (если canCreate)
□ Таблица с 4 колонками: Table, Version, Date, Action
□ Bidtools показывает 3 specifications:
  □ Quotes: 2.0, 10/30/2025
  □ QuoteDetails: 2.1, 10/31/2025
  □ QuotePacks: 2.1, 10/31/2025
□ Databricks показывает 2 specifications:
  □ Quotes: 1.5, 10/27/2025
  □ QuotePackOrder: 1.0, 10/27/2025
□ View action открывает dialog с JSON schema
□ Edit action открывает dialog с версией и schema
□ Delete action открывает confirmation dialog
□ Add button показывает toast
□ Empty state работает (когда нет specs)
□ Permissions работают корректно:
  □ SuperUser/Admin/Developer: View+Edit+Delete+Add
  □ ViewOnlySuperUser/Viewer: только View
```

---

**Статус:** ✅ Готово  
**Дата:** 3 ноября 2025  
**Соответствует:** Workflow изображению полностью

Data Capture Specifications теперь в таблице! 🎉
