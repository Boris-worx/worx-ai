# Edit Data Source - Simplified ✨

## Изменение

Упростил диалог "Edit Data Source" - теперь можно редактировать только **Data Source Name**.

---

## ❌ Удалено

### Поля в UI:
1. ~~Type~~ - удалено
2. ~~Connection String~~ - удалено
3. ~~Description~~ - удалено

### State Variables:
```typescript
// ❌ УДАЛЕНО
const [editDataSourceType, setEditDataSourceType] = useState('');
const [editDataSourceConnection, setEditDataSourceConnection] = useState('');
const [editDataSourceDescription, setEditDataSourceDescription] = useState('');
```

---

## ✅ Оставлено

### Поле в UI:
- **Data Source Name** - единственное редактируемое поле

### State Variable:
```typescript
// ✅ ОСТАВЛЕНО
const [editDataSourceName, setEditDataSourceName] = useState('');
```

---

## До и После

### ❌ Старый Dialog (4 поля)
```
┌─────────────────────────────────────┐
│ Edit Data Source                    │
├─────────────────────────────────────┤
│ Data Source Name *                  │
│ [Databricks            ]            │
│                                     │
│ Type                                │
│ [e.g., SQL, NoSQL...   ]            │
│                                     │
│ Connection String                   │
│ [••••••••••••••••      ]            │
│                                     │
│ Description                         │
│ [                      ]            │
│ [                      ]            │
│ [                      ]            │
│                                     │
│       [Cancel]  [Save Changes]      │
└─────────────────────────────────────┘
```

### ✅ Новый Dialog (1 поле)
```
┌─────────────────────────────────────┐
│ Edit Data Source                    │
│ Update data source information      │
├─────────────────────────────────────┤
│ Data Source Name *                  │
│ [Databricks            ]            │
│                                     │
│       [Cancel]  [Save Changes]      │
└─────────────────────────────────────┘
```

---

## Изменения в Коде

### 1. State (lines 369-372)
```typescript
// BEFORE:
const [dataSourceToEdit, setDataSourceToEdit] = useState<DataSource | null>(null);
const [isEditOpen, setIsEditOpen] = useState(false);
const [editDataSourceName, setEditDataSourceName] = useState('');
const [editDataSourceType, setEditDataSourceType] = useState('');
const [editDataSourceConnection, setEditDataSourceConnection] = useState('');
const [editDataSourceDescription, setEditDataSourceDescription] = useState('');

// AFTER:
const [dataSourceToEdit, setDataSourceToEdit] = useState<DataSource | null>(null);
const [isEditOpen, setIsEditOpen] = useState(false);
const [editDataSourceName, setEditDataSourceName] = useState('');
```

### 2. handleEditClick (lines 629-633)
```typescript
// BEFORE:
const handleEditClick = (dataSource: DataSource) => {
  setDataSourceToEdit(dataSource);
  setEditDataSourceName(getDataSourceName(dataSource));
  setEditDataSourceType(dataSource.Type || '');
  setEditDataSourceConnection(dataSource.ConnectionString || '');
  setEditDataSourceDescription(dataSource.Description || '');
  setIsEditOpen(true);
};

// AFTER:
const handleEditClick = (dataSource: DataSource) => {
  setDataSourceToEdit(dataSource);
  setEditDataSourceName(getDataSourceName(dataSource));
  setIsEditOpen(true);
};
```

### 3. handleEdit (lines 639-657)
```typescript
// BEFORE:
const updated = await updateDataSource(
  idToUpdate,
  editDataSourceName.trim(),
  etag,
  editDataSourceType.trim() || undefined,
  editDataSourceConnection.trim() || undefined,
  editDataSourceDescription.trim() || undefined,
);

// AFTER:
const updated = await updateDataSource(
  idToUpdate,
  editDataSourceName.trim(),
  etag,
  undefined, // type
  undefined, // connection
  undefined, // description
);
```

### 4. Dialog UI (lines 1120-1148)
```typescript
// BEFORE: 4 input fields
<div className="space-y-4 py-4">
  <div className="space-y-2">
    <Label>Data Source Name *</Label>
    <Input value={editDataSourceName} ... />
  </div>
  <div className="space-y-2">
    <Label>Type</Label>
    <Input value={editDataSourceType} ... />
  </div>
  <div className="space-y-2">
    <Label>Connection String</Label>
    <Input value={editDataSourceConnection} type="password" ... />
  </div>
  <div className="space-y-2">
    <Label>Description</Label>
    <Textarea value={editDataSourceDescription} ... />
  </div>
</div>

// AFTER: 1 input field
<div className="space-y-4 py-4">
  <div className="space-y-2">
    <Label htmlFor="editDataSourceName">Data Source Name *</Label>
    <Input
      id="editDataSourceName"
      placeholder="Enter data source name"
      value={editDataSourceName}
      onChange={(e) => setEditDataSourceName(e.target.value)}
      onKeyDown={(e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
          e.preventDefault();
          handleEdit();
        }
      }}
    />
  </div>
</div>
```

---

## Новые Возможности

### ⌨️ Enter Key Support
Добавлена поддержка клавиши Enter для быстрого сохранения:
```typescript
onKeyDown={(e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    handleEdit();
  }
}}
```

**Теперь можно:**
1. Открыть Edit dialog
2. Изменить имя
3. Нажать `Enter` ⌨️
4. Готово! ✅

---

## API Call

### Запрос остался прежним:
```typescript
PUT /1.0/txns/datasource_{id}
Headers:
  X-BFS-Auth: {authToken}
  If-Match: {etag}
Body:
{
  "DatasourceName": "New Name"
}
```

**Примечание:** Type, Connection, Description отправляются как `undefined`, поэтому не обновляются в API.

---

## Преимущества

### ✅ Упрощение UI
- Меньше полей = быстрее редактировать
- Фокус на главном - имени Data Source

### ✅ Меньше Кода
- Удалено 3 state переменных
- Удалено ~40 строк UI кода
- Проще поддерживать

### ✅ Лучший UX
- Диалог компактнее
- Быстрее загружается
- Enter для сохранения

---

## Тестирование

### ✅ Test Case 1: Edit Name
1. Открыть Data Sources tab
2. Нажать Edit на любом Data Source
3. Изменить имя: "Databricks" → "Databricks Production"
4. Нажать "Save Changes"
5. ✅ Имя обновлено

### ✅ Test Case 2: Enter Key
1. Открыть Edit dialog
2. Изменить имя
3. Нажать `Enter` ⌨️
4. ✅ Диалог закрывается, изменения сохранены

### ✅ Test Case 3: Cancel
1. Открыть Edit dialog
2. Изменить имя
3. Нажать "Cancel"
4. ✅ Изменения НЕ сохранены

### ✅ Test Case 4: Empty Name
1. Открыть Edit dialog
2. Очистить имя полностью
3. Нажать "Save Changes"
4. ✅ Показывается ошибка: "Data Source Name is required"

---

## Будущие Улучшения

### Возможности для расширения:
1. **Inline Editing** - редактировать имя прямо в таблице
2. **Auto-save** - сохранять при потере фокуса
3. **Name Validation** - проверка на уникальность
4. **Recent Changes** - показывать историю изменений

---

## Файлы Изменены

1. **`/components/DataSourcesView.tsx`** (4 изменения)
   - State variables simplified
   - handleEditClick simplified
   - handleEdit updated
   - Dialog UI simplified

---

## Итог

| Характеристика | Было | Стало | Улучшение |
|----------------|------|-------|-----------|
| **Полей в форме** | 4 | 1 | ↓ 75% |
| **State переменных** | 6 | 3 | ↓ 50% |
| **Строк кода UI** | ~50 | ~15 | ↓ 70% |
| **Клавиатурная навигация** | ❌ | ✅ Enter | ✨ NEW |

---

**Статус:** ✅ **Готово - диалог упрощен!**

---

**Время выполнения:** ~5 минут  
**Приоритет:** 🟢 Низкий (косметическое улучшение)  
**Протестировано:** ⏳ Требуется тестирование
