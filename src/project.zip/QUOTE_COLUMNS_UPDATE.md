# Quote Columns Update - Data Plane

## 📋 Изменение

Настроены **специфичные колонки для типа Quote** в Data Plane, которые отображаются по умолчанию при выборе Quote.

---

## ✅ Новые колонки по умолчанию для Quote

### До:
```
Колонки по умолчанию (общие для всех типов):
- ID (TxnId)
- Name
- Status
- Created
```

### После:
```
Колонки по умолчанию для Quote:
- ✅ ID (TxnId) - locked
- ✅ Created (CreateTime)
- ✅ location Address (Txn.location.Address)
- ✅ location Code (Txn.location.Code)
- ✅ location Name (Txn.location.Name)

Доступны через Column Selector:
- Quote ID (Txn.quoteId)
- Account Number (Txn.accountNumber)
- Requested By Date (Txn.customerRequestedByDate)
- Export Notes (Txn.exportNotes)
- ERP User ID (Txn.erpUserId)
- Updated (UpdateTime)
```

---

## 🔧 Технические изменения

### 1. **Функция getDefaultColumns() - теперь принимает txnType**

**Файл:** `/components/TransactionsView.tsx`

**До:**
```typescript
const getDefaultColumns = (): ColumnConfig[] => [
  { key: 'TxnId', label: 'ID', enabled: true, locked: true },
  { key: 'Txn.Name', label: 'Name', enabled: true },
  // ... общие колонки для всех типов
];
```

**После:**
```typescript
const getDefaultColumns = (txnType?: string): ColumnConfig[] => {
  // Quote-specific columns
  if (txnType === 'Quote') {
    return [
      { key: 'TxnId', label: 'ID', enabled: true, locked: true },
      { key: 'CreateTime', label: 'Created', enabled: true },
      { key: 'Txn.location.Address', label: 'location Address', enabled: true },
      { key: 'Txn.location.Code', label: 'location Code', enabled: true },
      { key: 'Txn.location.Name', label: 'location Name', enabled: true },
      // ... другие Quote поля
    ];
  }
  
  // Default columns for other transaction types
  return [
    { key: 'TxnId', label: 'ID', enabled: true, locked: true },
    { key: 'Txn.Name', label: 'Name', enabled: true },
    // ... общие колонки
  ];
};
```

---

### 2. **LocalStorage - отдельные настройки для каждого типа**

**До:**
```typescript
// Одни настройки колонок для всех типов транзакций
localStorage.getItem('transactionsViewColumns')
```

**После:**
```typescript
// Отдельные настройки для каждого типа транзакции
const storageKey = `transactionsViewColumns_${selectedTxnType}`;
localStorage.getItem(storageKey)
// Например: 'transactionsViewColumns_Quote'
//           'transactionsViewColumns_Customer'
//           'transactionsViewColumns_Location'
```

**Преимущества:**
- ✅ У каждого типа транзакций свои настройки колонок
- ✅ При переключении между типами настройки сохраняются
- ✅ Можно настроить колонки для Quote отдельно от Customer

---

### 3. **Автозагрузка колонок при смене типа**

Добавлен `useEffect` для загрузки настроек колонок при смене типа транзакции:

```typescript
useEffect(() => {
  const STORAGE_VERSION = '5';
  const storageKey = `transactionsViewColumns_${selectedTxnType}`;
  const saved = localStorage.getItem(storageKey);
  const savedVersion = localStorage.getItem(`${storageKey}_version`);
  
  if (saved && savedVersion === STORAGE_VERSION) {
    setColumnConfigs(JSON.parse(saved));
  } else {
    // Load default columns for this type
    setColumnConfigs(getDefaultColumns(selectedTxnType));
  }
}, [selectedTxnType]);
```

**Поведение:**
1. Пользователь выбирает "Quote" → загружаются колонки для Quote
2. Пользователь выбирает "Customer" → загружаются колонки для Customer
3. Настройки каждого типа сохраняются независимо

---

### 4. **Поддержка вложенных объектов**

Обновлена функция `availableFields` для извлечения вложенных полей:

```typescript
const availableFields = useMemo(() => {
  const fieldsSet = new Set<string>();
  
  // Helper to recursively extract fields
  const extractFields = (obj: any, prefix: string = '') => {
    Object.keys(obj).forEach(key => {
      const fullKey = prefix ? `${prefix}.${key}` : key;
      const value = obj[key];
      
      if (value && typeof value === 'object' && !Array.isArray(value)) {
        fieldsSet.add(fullKey); // Add parent (e.g., "Txn.location")
        extractFields(value, fullKey); // Add children (e.g., "Txn.location.Address")
      } else {
        fieldsSet.add(fullKey);
      }
    });
  };
  
  transactions.forEach(txn => {
    if (txn.Txn) {
      extractFields(txn.Txn, 'Txn');
    }
  });
  
  return Array.from(fieldsSet).sort();
}, [transactions]);
```

**Результат:**
- ✅ Обнаруживает `Txn.location`
- ✅ Обнаруживает `Txn.location.Address`
- ✅ Обнаруживает `Txn.location.Code`
- ✅ Обнаруживает `Txn.location.Name`

---

### 5. **Функция getNestedValue уже поддерживает вложенность**

Существующая функция правильно работает с многоуровневой вложенностью:

```typescript
const getNestedValue = (obj: any, path: string): any => {
  if (path.includes('.')) {
    const parts = path.split('.'); // ['Txn', 'location', 'Address']
    let value = obj;
    for (const part of parts) {
      value = value?.[part];
      if (value === undefined) return undefined;
    }
    return value;
  }
  return obj[path];
};
```

**Примеры:**
- `getNestedValue(txn, 'Txn.location.Address')` → `"123 Main St"`
- `getNestedValue(txn, 'Txn.location.Code')` → `"LOC001"`
- `getNestedValue(txn, 'Txn.location.Name')` → `"Warehouse A"`

---

## 📊 Структура данных Quote

### Ожидаемая структура:

```json
{
  "TxnId": "Quote:quote-12345",
  "TxnType": "Quote",
  "CreateTime": "2025-10-29T10:30:00Z",
  "UpdateTime": "2025-10-29T14:45:00Z",
  "Txn": {
    "quoteId": "quote-12345",
    "accountNumber": "579237",
    "customerRequestedByDate": "2025-07-25T00:00:00.000Z",
    "exportNotes": "Some notes",
    "erpUserId": "ONLINE",
    "location": {
      "Address": "123 Main Street, Building A",
      "Code": "LOC-001",
      "Name": "Main Warehouse"
    },
    "categories": [
      {
        "categoryId": "35",
        "name": null,
        "description": null
      }
    ]
  },
  "_etag": "...",
  "_ts": 1730233445
}
```

---

## 🎯 Использование

### Для пользователя:

1. **Откройте Data Plane**
2. **Выберите тип "Quote"** из выпадающего списка
3. **Увидите колонки:**
   ```
   ID | Created | location Address | location Code | location Name
   ```

4. **Настройка колонок:**
   - Нажмите кнопку "Columns" (иконка с колонками)
   - Выберите/снимите галочки с нужных полей
   - Настройки сохранятся автоматически для Quote

5. **Переключение на другой тип:**
   - Выберите "Customer" → увидите колонки для Customer
   - Вернитесь на "Quote" → увидите сохраненные настройки Quote

---

## 🔄 Миграция настроек

### Storage Version: 4 → 5

**Что изменилось:**
- Старый формат: `transactionsViewColumns` (единый для всех)
- Новый формат: `transactionsViewColumns_{TxnType}` (отдельный для каждого)

**Поведение при обновлении:**
1. При первом открытии Quote → загружаются дефолтные колонки Quote
2. При первом открытии Customer → загружаются дефолтные колонки Customer
3. Старые настройки игнорируются, но не удаляются

**Очистка старых данных** (опционально):
```javascript
// Удалить старый формат вручную в консоли браузера
localStorage.removeItem('transactionsViewColumns');
localStorage.removeItem('transactionsViewColumnsVersion');
```

---

## ✅ Проверка изменений

### Чеклист:

- [ ] Открыть Data Plane
- [ ] Выбрать тип "Quote"
- [ ] Проверить, что видны 5 колонок по умолчанию:
  - [ ] ID
  - [ ] Created
  - [ ] location Address
  - [ ] location Code
  - [ ] location Name
- [ ] Открыть Column Selector
- [ ] Проверить, что доступны дополнительные поля Quote
- [ ] Изменить настройки колонок
- [ ] Переключиться на "Customer"
- [ ] Вернуться на "Quote"
- [ ] Проверить, что настройки Quote сохранились

---

## 📝 Примечания

### Если location поля отсутствуют:

Если API не возвращает `location` объект в Quote, колонки будут показывать "-".

**Решение:**
1. Проверить структуру данных в API
2. Если поля называются по-другому, обновить `getDefaultColumns()`
3. Возможные варианты:
   - `Txn.Location.Address` (с заглавной L)
   - `Txn.locationAddress` (без вложенности)
   - `Txn.location_address` (snake_case)

### Добавление новых типов:

Чтобы добавить специфичные колонки для других типов:

```typescript
const getDefaultColumns = (txnType?: string): ColumnConfig[] => {
  if (txnType === 'Quote') {
    return [...]; // Quote columns
  }
  
  if (txnType === 'Invoice') {
    return [
      { key: 'TxnId', label: 'ID', enabled: true, locked: true },
      { key: 'Txn.InvoiceNumber', label: 'Invoice #', enabled: true },
      { key: 'Txn.DueDate', label: 'Due Date', enabled: true },
      // ... Invoice-specific columns
    ];
  }
  
  if (txnType === 'Order') {
    return [...]; // Order columns
  }
  
  // Default for all other types
  return [...];
};
```

---

## 📁 Измененные файлы

### `/components/TransactionsView.tsx`

**Изменения:**
1. **Line 61-95:** Функция `getDefaultColumns()` - добавлен параметр `txnType`, специфичные колонки для Quote
2. **Line 97-116:** Инициализация `columnConfigs` - использует `selectedTxnType` в storage key
3. **Line 118-126:** Функция `handleResetColumns` - использует `selectedTxnType`
4. **Line 128-134:** `useEffect` для сохранения - использует `selectedTxnType` в key
5. **Line 136-189:** Функция `availableFields` - добавлена рекурсивная обработка вложенных объектов
6. **Line 287-304:** Новый `useEffect` - загрузка колонок при смене типа транзакции

**Storage Version:** 4 → 5

---

## 🎓 Дополнительная информация

### Связанные документы:
- `/QUOTE_IMPLEMENTATION_SUMMARY.md` - Общая реализация Quote
- `/QUOTE_TESTING_GUIDE.md` - Руководство по тестированию Quote
- `/QUOTE_TEST_RU.md` - Быстрый старт (RU)
- `/DATA_PLANE_PAGINATION.md` - Пагинация в Data Plane

### API эндпоинты:
- `GET /1.0/txns?TxnType=Quote` - получить все Quote
- `GET /1.0/txns/Quote:{quoteId}` - получить один Quote
- `POST /1.0/txns` - создать Quote
- `PUT /1.0/txns/Quote:{quoteId}` - обновить Quote
- `DELETE /1.0/txns/Quote:{quoteId}` - удалить Quote

---

## ✅ Статус

**Дата:** 29 октября 2025  
**Версия:** 1.0  
**Статус:** ✅ Готово к использованию  
**Storage Version:** 5

---

**Автор:** BFS Platform Team  
**Последнее обновление:** 29 октября 2025
