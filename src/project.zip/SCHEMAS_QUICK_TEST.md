# ✅ Data Capture Schemas - Быстрый тест

## 🚀 Как протестировать

### 1. Открой Data Source Onboarding
```
App → Data Source Onboarding tab
```

### 2. Нажми View на любой Data Source
```
Bidtools row → View button
или
Databricks row → View button
```

### 3. Проверь структуру Dialog

```
┌────────────────────────────────────────┐
│ Data Source Details                    │
│ Detailed information about this data   │
│ source                                 │
├────────────────────────────────────────┤
│                                        │
│ Basic Information                      │
│ ├─ Data Source ID                     │
│ ├─ Name                                │
│ ├─ Type                                │
│ └─ ...                                 │
│                                        │
│ ──────────────────────────────────── │
│                                        │
│ Data Capture Schemas                   │
│ Schema definitions for data capture... │
│                                        │
│ ▶ 🔵 Quotes            [52 fields]    │
│ ▶ 🟢 QuotePacks        [32 fields]    │
│ ▶ 🟣 QuoteDetails      [48 fields]    │
│ ▶ 🟠 QuotePackOrder    [13 fields]    │
│                                        │
├────────────────────────────────────────┤
│                             [Close]    │
└────────────────────────────────────────┘
```

### 4. Разверни Quotes
```
Клик на "Quotes" →

▼ 🔵 Quotes                  [52 fields]
  ┌────────────────────────────────────┐
  │ {                                  │
  │   "before": null,                  │
  │   "after": {                       │
  │     "QuoteId": 132821,            │
  │     "CustomerId": 63341,          │
  │     "ServiceRequestId": 49835,    │
  │     ...                            │
  │   },                               │
  │   "source": { ... }                │
  │ }                                  │
  └────────────────────────────────────┘
```

### 5. Разверни остальные схемы
```
✅ QuotePacks - зелёный Database icon, 32 fields
✅ QuoteDetails - фиолетовый icon, 48 fields
✅ QuotePackOrder - оранжевый icon, 13 fields
```

### 6. Проверь поведение Accordion
```
✅ Открывается один item
✅ Другие автоматически закрываются
✅ Можно закрыть все
✅ Smooth анимация
✅ Chevron icon поворачивается
```

### 7. Проверь JSON display
```
✅ Pretty print (indent = 2 spaces)
✅ Светлый фон (bg-muted/30)
✅ Border вокруг
✅ Горизонтальный скролл работает
✅ Моноширинный шрифт
```

### 8. Проверь responsive
```
Desktop:
✅ Dialog width = ~896px
✅ JSON легко читается

Mobile:
✅ Dialog почти на весь экран
✅ Horizontal scroll для длинных строк JSON
✅ Vertical scroll для всего dialog
```

---

## ✅ Чеклист

```
□ Data Source Onboarding tab открыт
□ View button работает
□ Dialog открывается
□ Basic Information отображается
□ Separator видно
□ "Data Capture Schemas" заголовок есть
□ 4 accordion items видны:
  □ 🔵 Quotes (52 fields)
  □ 🟢 QuotePacks (32 fields)
  □ 🟣 QuoteDetails (48 fields)
  □ 🟠 QuotePackOrder (13 fields)
□ Accordion открывается/закрывается
□ JSON отображается корректно
□ Pretty print работает
□ Scrolling работает
□ Close button закрывает dialog
```

---

## 🎨 Что должно быть

### Цвета иконок
```
🔵 Quotes:         синий (text-blue-500)
🟢 QuotePacks:     зелёный (text-green-500)
🟣 QuoteDetails:   фиолетовый (text-purple-500)
🟠 QuotePackOrder: оранжевый (text-orange-500)
```

### Badges
```
Quotes:          52 fields
QuotePacks:      32 fields
QuoteDetails:    48 fields
QuotePackOrder:  13 fields
```

### JSON структура
```json
{
  "before": null,
  "after": {
    // поля схемы
  },
  "source": {
    "version": "3.3.1.Final",
    "connector": "sqlserver",
    "table": "TableName",
    ...
  },
  "op": "r",
  "ts_ms": ...,
  ...
}
```

---

## 🐛 Возможные проблемы

### 1. Accordion не открывается
```
Проблема: Клик не работает
Решение: Проверь что AccordionTrigger импортирован
```

### 2. JSON не отформатирован
```
Проблема: Всё в одну строку
Решение: Проверь JSON.stringify(data, null, 2)
                                        ↑↑↑↑
                                    indent = 2
```

### 3. Иконки не цветные
```
Проблема: Все иконки одного цвета
Решение: Проверь className="text-blue-500" и т.д.
```

### 4. Scrolling не работает
```
Проблема: JSON обрезается
Решение: 
  - Dialog: overflow-y-auto
  - Pre: overflow-x-auto
```

### 5. Dialog слишком маленький
```
Проблема: JSON не помещается
Решение: max-w-4xl (не max-w-2xl)
```

---

## 📊 Ожидаемые данные

### Quotes (52 fields)
```
QuoteId, CustomerId, ServiceRequestId, IsPublished,
LocationCode, LocationName, LocationAddress,
QuoteName, PricingMethodId, ExpirationDate, ...
```

### QuotePacks (32 fields)
```
QuotePackId, QuoteId, QuotePackName, BuildingName,
CreatedBy, CreatedDate, QuotePackIsPublished, ...
```

### QuoteDetails (48 fields)
```
QuoteDetailId, QuoteId, Sku, Quantity, ManualPrice,
ItemTypeId, QuotePackId, MaterialDescription, ...
```

### QuotePackOrder (13 fields)
```
QuotePackOrderId, QuoteId, QuotePackId,
QuotePackOrderErpSystem, ERPQuoteNumber, ...
```

---

## ✅ Готово!

Если все пункты чеклиста отмечены ✅, то Data Capture Schemas работают корректно! 🎉

---

**Статус:** ✅ Готово к тестированию  
**Дата:** 3 ноября 2025
