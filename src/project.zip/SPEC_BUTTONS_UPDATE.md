# ✅ Data Capture Specifications - Buttons Style Update

## 🎯 Что изменено

Кнопки View/Edit/Delete в таблице Data Capture Specifications теперь выглядят **точно так же** как кнопки действий в основной таблице Data Sources - с иконками и стилем `variant="outline"`.

---

## 🔄 До и После

### ❌ До (variant="ghost", без иконок):

```tsx
<Button variant="ghost" size="sm">
  View
</Button>
<Button variant="ghost" size="sm">
  Edit
</Button>
<Button variant="ghost" size="sm">
  Delete
</Button>
```

**Вид:**
```
┌───────┬──────┬────────┐
│ View  │ Edit │ Delete │  ← Простой текст, прозрачный фон
└───────┴──────┴────────┘
```

---

### ✅ После (variant="outline", с иконками):

```tsx
<Button variant="outline" size="sm">
  <Eye className="h-4 w-4 mr-1" />
  View
</Button>
<Button variant="outline" size="sm">
  <Pencil className="h-4 w-4 mr-1" />
  Edit
</Button>
<Button variant="outline" size="sm">
  <Trash2 className="h-4 w-4 mr-1" />
  Delete
</Button>
```

**Вид:**
```
┌─────────────┬──────────────┬───────────────┐
│ 👁️ View    │ ✏️ Edit     │ 🗑️ Delete    │  ← С иконками, с border
└─────────────┴──────────────┴───────────────┘
```

---

## 🎨 Изменения в коде

### Файл: `/components/DataSourcesView.tsx`

**Строки ~919-960:**

```diff
- <div className="flex gap-1 justify-end">
+ <div className="flex gap-2 justify-end">
    <Button
-     variant="ghost"
+     variant="outline"
      size="sm"
      onClick={() => {
        setSelectedSpec(spec);
        setIsSpecViewOpen(true);
      }}
      title="View specification"
    >
+     <Eye className="h-4 w-4 mr-1" />
      View
    </Button>
    {canEdit && (
      <Button
-       variant="ghost"
+       variant="outline"
        size="sm"
        onClick={() => {
          setSelectedSpec(spec);
          setIsSpecEditOpen(true);
        }}
        title="Edit specification"
      >
+       <Pencil className="h-4 w-4 mr-1" />
        Edit
      </Button>
    )}
    {canDelete && (
      <Button
-       variant="ghost"
+       variant="outline"
        size="sm"
        onClick={() => {
          setSpecToDelete(spec);
          setIsSpecDeleteOpen(true);
        }}
-       className="text-muted-foreground hover:text-destructive"
        title="Delete specification"
      >
+       <Trash2 className="h-4 w-4 mr-1" />
        Delete
      </Button>
    )}
  </div>
```

---

## 🎯 Ключевые изменения

### 1. Variant

**Было:** `variant="ghost"` (прозрачная кнопка)  
**Стало:** `variant="outline"` (кнопка с border)

```tsx
<Button variant="outline" size="sm">
```

---

### 2. Иконки

**Добавлены иконки:**
```tsx
<Eye className="h-4 w-4 mr-1" />      // View button
<Pencil className="h-4 w-4 mr-1" />   // Edit button
<Trash2 className="h-4 w-4 mr-1" />   // Delete button
```

**Импорт:**
```tsx
import { Plus, RefreshCw, Trash2, Pencil, Eye, Database, MoreVertical, Filter } from 'lucide-react';
```

---

### 3. Gap между кнопками

**Было:** `gap-1` (4px)  
**Стало:** `gap-2` (8px)

```tsx
<div className="flex gap-2 justify-end">
```

**Причина:** кнопки с border занимают больше места, нужен больший gap

---

### 4. Delete button styling

**Удалено:**
```tsx
className="text-muted-foreground hover:text-destructive"
```

**Причина:** `variant="outline"` уже имеет правильный стиль, дополнительный className не нужен

---

## 🖼️ Визуальное сравнение

### Основная таблица (Data Sources) - Actions:

```
┌───────────────────────────────────────────────────────────┐
│ Actions                                                    │
├───────────────────────────────────────────────────────────┤
│ [👁️ View]  [✏️ Edit]  [🗑️ Delete]  ← variant="outline"  │
└───────────────────────────────────────────────────────────┘
```

### Таблица Specifications (expanded row) - Actions:

```
┌───────────────────────────────────────────────────────────┐
│ Action                                                     │
├───────────────────────────────────────────────────────────┤
│ [👁️ View]  [✏️ Edit]  [🗑️ Delete]  ← variant="outline"  │
└───────────────────────────────────────────────────────────┘
```

**Результат:** Обе таблицы теперь имеют одинаковый стиль кнопок! ✅

---

## 📏 Стили кнопок

### Button Props:

```tsx
variant="outline"    // Border around button
size="sm"           // Small size
title="..."         // Tooltip on hover
```

### Icon Props:

```tsx
className="h-4 w-4 mr-1"
// h-4 w-4: размер иконки 16px × 16px
// mr-1: margin-right 4px (отступ от текста)
```

### Container Props:

```tsx
className="flex gap-2 justify-end"
// flex: flexbox layout
// gap-2: 8px between buttons
// justify-end: align buttons to right
```

---

## 🎨 Shadcn/UI Button Variants

### Все доступные варианты:

```tsx
variant="default"    // Синий фон (#1D6BCD)
variant="outline"    // Border, прозрачный фон ✅ ИСПОЛЬЗУЕМ
variant="ghost"      // Без border, прозрачный фон
variant="destructive" // Красный фон для удаления
variant="secondary"  // Серый фон
variant="link"       // Как ссылка, без фона
```

**Наш выбор:** `variant="outline"` - выглядит профессионально и чётко видно границы кнопок

---

## 🧪 Тестирование

### Шаги для проверки:

1. **Открой Data Source Onboarding tab**
   ```
   App → Data Source Onboarding
   ```

2. **Разверни Bidtools Data Source**
   ```
   Клик на chevron (▶) → (▼)
   ```

3. **Проверь кнопки View/Edit/Delete**
   ```
   ✅ Все кнопки имеют border (outline style)
   ✅ Все кнопки имеют иконки:
      - View: глаз (Eye)
      - Edit: карандаш (Pencil)
      - Delete: корзина (Trash2)
   ✅ Gap между кнопками 8px (gap-2)
   ✅ Кнопки выровнены вправо (justify-end)
   ```

4. **Сравни со стилем кнопок выше (основная таблица)**
   ```
   ✅ Кнопки внизу (specifications) выглядят так же как кнопки вверху (data sources)
   ✅ Одинаковый variant="outline"
   ✅ Одинаковые иконки
   ✅ Одинаковый размер
   ```

5. **Проверь hover эффект**
   ```
   ✅ Hover на View: светлый фон
   ✅ Hover на Edit: светлый фон
   ✅ Hover на Delete: светлый фон
   ```

6. **Проверь разные роли**
   ```
   SuperUser / Admin / Developer:
   ✅ Видят все три кнопки: View, Edit, Delete

   ViewOnlySuperUser / Viewer:
   ✅ Видят только View
   ```

---

## 📊 Сравнение с изображением

### Из изображения (верхние кнопки):

```
┌─────────────────────────────────────────────────┐
│ [👁️ View]  [✏️ Edit]  [🗑️ Delete]             │
└─────────────────────────────────────────────────┘
```

### Наша реализация (нижние кнопки):

```
┌─────────────────────────────────────────────────┐
│ [👁️ View]  [✏️ Edit]  [🗑️ Delete]             │
└─────────────────────────────────────────────────┘
```

**Результат:** ✅ Полное соответствие!

---

## 💡 Преимущества outline variant

### Почему `variant="outline"` лучше чем `variant="ghost"`:

1. **Чёткие границы**
   ```
   outline: [Button]  ← Видно где заканчивается кнопка
   ghost:    Button   ← Не видно границы
   ```

2. **Профессиональный вид**
   ```
   outline: Выглядит как настоящая кнопка
   ghost: Выглядит как текстовая ссылка
   ```

3. **Лучшая кликабельность**
   ```
   outline: Понятно где кликать (есть border)
   ghost: Менее понятно (только hover эффект)
   ```

4. **Согласованность UI**
   ```
   outline: Все кнопки в приложении в одном стиле
   ghost: Разный стиль кнопок
   ```

---

## 🎯 Финальный результат

### Data Capture Specifications Table с новыми кнопками:

```
┌──────────────────────────────────────────────────────────────────────┐
│ Data Capture Specifications:       [+ Add Data Capture Specification]│
├──────────────────┬──────────┬─────────────┬───────────────────────────┤
│ Table            │ Version  │ Date        │ Action                    │
├──────────────────┼──────────┼─────────────┼───────────────────────────┤
│ Quotes           │ 2.0      │ 10/30/2025  │ [👁️ View] [✏️ Edit] [🗑️ Delete] │
│ QuoteDetails     │ 2.1      │ 10/31/2025  │ [👁️ View] [✏️ Edit] [🗑️ Delete] │
│ QuotePacks       │ 2.1      │ 10/31/2025  │ [👁️ View] [✏️ Edit] [🗑️ Delete] │
└──────────────────┴──────────┴─────────────┴───────────────────────────┘
```

**Все кнопки теперь:**
```
✅ С иконками (Eye, Pencil, Trash2)
✅ variant="outline" (с border)
✅ size="sm" (маленький размер)
✅ gap-2 (8px между кнопками)
✅ Выглядят так же как кнопки основной таблицы
```

---

## 📝 Чеклист

```
✅ variant="ghost" заменён на variant="outline"
✅ Добавлена иконка Eye для View button
✅ Добавлена иконка Pencil для Edit button
✅ Добавлена иконка Trash2 для Delete button
✅ gap-1 заменён на gap-2 (больший отступ)
✅ Удалён лишний className для Delete button
✅ Все иконки импортированы из lucide-react
✅ Кнопки выглядят идентично кнопкам основной таблицы
```

---

**Статус:** ✅ Готово  
**Дата:** 3 ноября 2025  
**Файл:** `/components/DataSourcesView.tsx`

Кнопки specifications теперь в едином стиле с основными кнопками! 🎉
