# 🧪 JSON Import Test Formats

## ✅ Working Formats

### Format 1: Simple Array (Recommended)
**File**: `test-simple.json`
```json
[
  { "TenantName": "Company A" },
  { "TenantName": "Company B" }
]
```

### Format 2: Object with tenants
```json
{
  "tenants": [
    { "TenantName": "Company A" },
    { "TenantName": "Company B" }
  ]
}
```

### Format 3: API Response Format
```json
{
  "status": {
    "code": 200,
    "message": "Success"
  },
  "data": {
    "tenants": [
      {
        "TenantId": "tenant-1",
        "TenantName": "Company A",
        "_etag": "\"abc123\""
      }
    ]
  }
}
```

### Format 4: Single Tenant
```json
{
  "TenantName": "Single Company"
}
```

### Format 5: Data Array
```json
{
  "data": [
    { "TenantName": "Company A" }
  ]
}
```

## 🔍 Debugging

If import fails, check browser console (F12) for:
- 📄 Raw JSON preview
- 📦 Parsed structure
- ✅ Detected format
- ⚠️ Invalid items
- ❌ Error details

## 📝 Requirements

Each tenant MUST have:
- `TenantName` field (string)

Optional fields:
- `TenantId` (will be auto-generated if missing)
- `_etag` (for existing tenants)
- Other metadata fields

## 🚨 Common Issues

### Issue 1: Wrong field name
❌ `{ "name": "Company" }`  
✅ `{ "TenantName": "Company" }`

### Issue 2: Empty array
❌ `[]`  
✅ `[{ "TenantName": "Company" }]`

### Issue 3: Missing quotes
❌ `{ TenantName: "Company" }`  
✅ `{ "TenantName": "Company" }`

### Issue 4: Trailing commas
❌ `[{ "TenantName": "A" },]`  
✅ `[{ "TenantName": "A" }]`

## 🧪 Test Files Available

1. `/test-simple.json` - Simple 3-tenant array
2. `/sample-tenants-simple.json` - 5 tenants
3. `/sample-tenants.json` - Complex format
4. `/sample-tenants-api-format.json` - API response format

Download and try importing these test files!
