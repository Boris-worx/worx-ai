# ✅ Исправлена ошибка создания Data Capture Specifications

## Проблема была решена

Ошибка **400 "Missing tenantId"** при создании Data Capture Specifications была устранена.

## Что было исправлено

### Проблема
API endpoint `/1.0/data-capture-specs` ожидает данные в **camelCase** формате, но приложение отправляло их в **PascalCase** формате.

### Решение
Обновлены функции в `/lib/api.ts`:
- ✅ `getDataCaptureSpecs` - фильтры теперь в camelCase (tenantId, dataSourceId)
- ✅ `createDataCaptureSpec` - теперь отправляет данные в camelCase
- ✅ `updateDataCaptureSpec` - теперь обновляет данные в camelCase

## Правильный формат JSON для создания

```json
{
  "dataCaptureSpecName": "Quote",
  "tenantId": "BFS",
  "dataSourceId": "bidtools",
  "isActive": true,
  "version": 1,
  "profile": "data-capture",
  "sourcePrimaryKeyField": "quoteId",
  "partitionKeyField": "partitionKey",
  "partitionKeyValue": "BFS-bidtools",
  "allowedFilters": [
    "quoteId",
    "customerId",
    "quoteStatus"
  ],
  "requiredFields": [
    "quoteId",
    "customerId"
  ],
  "containerSchema": {
    "schemaVersion": 1,
    "type": "object",
    "properties": {
      "quoteId": { "type": "string" },
      "partitionKey": { "type": "string" }
    },
    "required": ["quoteId", "partitionKey"],
    "unevaluatedProperties": true
  }
}
```

## Как проверить

1. Откройте вкладку **Data Source Onboarding**
2. Выберите Data Source (например, **Bidtools**)
3. Нажмите кнопку **"Create Data Capture Specification"**
4. Заполните форму:
   - Specification Name: **Quote**
   - Source Primary Key Field: **quoteId**
   - Partition Key Field: **partitionKey**
   - Partition Key Value: будет автоматически заполнено как `{tenantId}-{dataSourceId}`
5. Нажмите **"Create Specification"**
6. ✅ Спецификация должна создаться успешно без ошибок

## Что изменилось в коде

### До (неправильно)
```javascript
const apiPayload = {
  DataCaptureSpecName: spec.dataCaptureSpecName,  // ❌ PascalCase
  TenantId: spec.tenantId,                        // ❌ PascalCase
  DataSourceId: spec.dataSourceId,                // ❌ PascalCase
  // ...
};
```

### После (правильно)
```javascript
const apiPayload = {
  dataCaptureSpecName: spec.dataCaptureSpecName,  // ✅ camelCase
  tenantId: spec.tenantId,                        // ✅ camelCase
  dataSourceId: spec.dataSourceId,                // ✅ camelCase
  isActive: spec.isActive,
  version: spec.version,
  profile: spec.profile,
  sourcePrimaryKeyField: spec.sourcePrimaryKeyField,
  partitionKeyField: spec.partitionKeyField,
  partitionKeyValue: spec.partitionKeyValue,
  allowedFilters: spec.allowedFilters,
  requiredFields: spec.requiredFields,
  containerSchema: spec.containerSchema
};
```

## Важно

Это исправление относится **только** к Data Capture Specifications endpoint.

Другие endpoints (например, `/datasources`, `/tenants`) могут использовать **PascalCase** и работают корректно.

## Статус
✅ **ГОТОВО** - можно создавать Data Capture Specifications
