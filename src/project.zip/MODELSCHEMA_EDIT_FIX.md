# Model Schema Edit Fix

## Проблема
Операция редактирования Model Schema не работала, хотя операция удаления работала корректно.

## Причина
1. **Поля model и version являются частью первичного ключа** - id формируется как `"ModelSchema:{model}:{version}"` в базе данных
2. **Попытка изменить эти поля приводила к конфликту** - API пытался обновить запись с одним ID, используя другой ID в теле запроса
3. **Неправильная обработка ID** - функция пыталась переконструировать ID из измененных значений model/version, что создавало несоответствие между URL и телом запроса

## Решение

### 1. Сделали поля model и version read-only в диалоге редактирования
**Файл:** `/components/ModelSchemaView.tsx`

```typescript
// До:
<Input
  id="edit-model"
  value={editFormData.model}
  onChange={(e) => setEditFormData({ ...editFormData, model: e.target.value })}
/>

// После:
<Input
  id="edit-model"
  value={editFormData.model}
  disabled
  className="bg-muted"
/>
<p className="text-xs text-muted-foreground">Model name cannot be changed after creation</p>
```

### 2. Исправили логику обработки ID в updateModelSchema
**Файл:** `/lib/api.ts`

**До:**
```typescript
// Пыталась переконструировать ID из новых значений
const constructedId = `${schemaData.model}:${schemaData.version}`;
const txnDataWithId = {
  ...schemaData,
  id: constructedId,
};
```

**После:**
```typescript
// Извлекаем ID без префикса и используем его как есть
let idWithoutPrefix = schemaId;
if (schemaId.startsWith('ModelSchema:')) {
  idWithoutPrefix = schemaId.substring('ModelSchema:'.length);
}

const txnDataWithId = {
  ...schemaData,
  id: idWithoutPrefix, // "Location:1" остается "Location:1"
};
```

## Результат
✅ Операция редактирования теперь работает корректно
✅ ID остается неизменным при редактировании
✅ Пользователь может изменять только: state, semver, и jsonSchema
✅ Улучшены консольные логи для отладки

## Что можно редактировать
- ✅ **state** (active, draft, deprecated)
- ✅ **semver** (семантическая версия, например "1.2.0")
- ✅ **jsonSchema** (JSON Schema определение)

## Что нельзя редактировать
- ❌ **model** (имя модели - часть первичного ключа)
- ❌ **version** (версия - часть первичного ключа)

## Примечание
Если нужно изменить model или version, следует:
1. Создать новую схему с нужными значениями
2. Опционально удалить или установить состояние "deprecated" для старой схемы

## Тестирование
1. Открыть вкладку "Data Plane"
2. Нажать "Edit" на любой схеме
3. Изменить state, semver или jsonSchema
4. Нажать "Update Schema"
5. ✅ Схема должна успешно обновиться

## Логи для отладки
Функция `updateModelSchema` теперь выводит подробные логи:
```
📝 PUT Model Schema Request:
  Original SchemaId: ModelSchema:Location:1
  TxnId for URL: ModelSchema:Location:1
  ID for Txn object: Location:1
  URL: https://...
  ETag: "..."
  Body: { TxnType: "ModelSchema", Txn: {...} }
📥 Response status: 200 OK
✅ Model schema updated successfully
📦 Response body: {...}
```
