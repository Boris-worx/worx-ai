# Data Source Onboarding Display Update

## Issue
Data Source Onboarding tab was showing minimal information - only ID, Name, and Created date by default. Users couldn't see important fields like Type, Status, and Description without manually enabling columns.

## Changes Made

### 1. Updated Default Visible Columns
**Before:**
- ✓ Data Source ID (locked)
- ✓ Name
- ✗ Type (hidden)
- ✗ Status (hidden)
- ✓ Created
- ✗ Updated (hidden)
- ✗ Description (hidden)

**After:**
- ✓ Data Source ID (locked) - styled like Data Plane ID
- ✓ Name
- ✓ Type - shown with badge
- ✓ Status - shown with colored badge
- ✓ Description - with truncation for long text
- ✓ Created - formatted date
- ✗ Updated (available via column selector)
- ✗ Connection String (available via column selector, hidden for security)

### 2. Improved Cell Formatting

#### Data Source ID
```tsx
// Styled with code block like Data Plane
<code className="text-[10px] md:text-[11px] bg-muted px-1 md:px-1.5 py-0.5 rounded truncate block">
  {displayId}
</code>
```

#### Type
```tsx
// Displayed as outline badge
<Badge variant="outline" className="text-xs">{value}</Badge>
```

#### Status
```tsx
// Color-coded badges
- Active: Green badge (bg-green-600)
- Inactive: Gray badge (secondary)
- Other: Outline badge
```

#### Description
```tsx
// Truncated with tooltip on hover
<div className="max-w-[200px] md:max-w-[300px]">
  <span className="text-xs md:text-sm truncate block" title={fullDescription}>
    {description}
  </span>
</div>
```

#### Dates (CreateTime, UpdateTime)
```tsx
// Formatted and localized
<span className="whitespace-nowrap text-xs md:text-sm">
  {new Date(value).toLocaleDateString()}
</span>
```

### 3. API Data Structure

The BFS API returns data sources in this format:
```json
{
  "DatasourceId": "string",
  "DatasourceName": "string",
  "Type": "string",
  "Status": "string",
  "Description": "string",
  "ConnectionString": "string",
  "CreateTime": "2025-10-29T...",
  "UpdateTime": "2025-10-29T...",
  "_etag": "...",
  "_ts": 1234567890
}
```

### 4. Column Configuration Version

Updated storage version from `3` to `4` to ensure all users see the new default columns on next page load.

**File:** `/components/DataSourcesView.tsx`
- Line 81: `const STORAGE_VERSION = '4'`
- Line 102: `const STORAGE_VERSION = '4'`

### 5. Security Considerations

- **ConnectionString** field is available but hidden by default
- When viewing details, ConnectionString is masked as `••••••••`
- Users can enable ConnectionString column if needed via Column Selector

## User Experience Improvements

### Before
- User sees only 3 columns: ID, Name, Created
- No information about data source type or status
- Must manually enable columns to see more details
- Limited context about each data source

### After
- User sees 6 relevant columns immediately
- Type and Status clearly visible with badges
- Description provides context
- Professional appearance matching Data Plane
- All additional fields available via Column Selector

## Visual Consistency

Now Data Source Onboarding matches the visual style of Data Plane:
- ✅ ID field styled identically (code block with gray background)
- ✅ Badges for status/type fields
- ✅ Truncated text with tooltips
- ✅ Responsive text sizes (xs/sm)
- ✅ Consistent date formatting

## Testing Checklist

- [x] Data Source ID displays with code styling
- [x] Type shows as badge
- [x] Status shows with appropriate color
- [x] Description truncates with tooltip
- [x] Dates format correctly
- [x] Column selector still works
- [x] New defaults apply for new users
- [x] Existing column preferences respected
- [x] ConnectionString remains hidden by default
- [x] Mobile responsive layout maintained

## API Response Handling

The system handles multiple API response formats:
```typescript
// Supports these formats:
- Direct array: data[]
- Nested: data.datasources[]
- Standard: data.data[]
- Value: data.value[]
- BFS format: data.data.DataSources[]
```

All formats are automatically detected and processed.

## Files Modified

1. `/components/DataSourcesView.tsx`
   - Updated default columns (line 69-77)
   - Updated storage version (lines 81, 102)
   - Enhanced formatCellValue function (lines 357-410)
   - Added ID styling in columns mapping (lines 209-218)

2. `/lib/api.ts`
   - Enhanced logging in getAllDataSources() to show:
     - All fields in first data source
     - All unique fields across all data sources
     - Field value examples for each unique field
   - Lines 1120-1139: Detailed field analysis logging

## New Files Created

1. `/test-datasources-api.html`
   - Standalone HTML tool to inspect DataSource API
   - Shows response format, field analysis, raw JSON
   - Copy-to-clipboard functionality
   - Visual summary cards and tables

2. `/DATASOURCE_API_INSPECTION.md`
   - Complete guide for inspecting DataSource API
   - Three methods: HTML tester, Browser console, cURL
   - Expected data structure documentation
   - Troubleshooting guide

3. `/ПРОВЕРКА_API_DATASOURCES.md`
   - Russian quick reference guide
   - Fast checklist for API inspection
   - Common issues and solutions

## Related Features

- Column Selector - users can still customize which columns to show
- Pagination - works with all visible columns
- Search - searches across all fields including new visible ones
- Sort - can sort by Type, Status, Description
- Export capability (if implemented) includes all fields

## API Inspection Tools

Now you can easily inspect what data the BFS API actually returns:

### Method 1: HTML Test Tool
- Open `/test-datasources-api.html` in browser
- Click "Fetch DataSources"
- Get complete field analysis

### Method 2: Browser Console
- Open app → DevTools (F12)
- Go to Data Source Onboarding tab
- Check console for detailed logs

### Method 3: cURL Command
```bash
curl -X GET 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/datasources' \
  -H 'X-BFS-Auth: bfs-secret-key-12345'
```

---

**Status:** ✅ Complete  
**Date:** October 29, 2025  
**Impact:** Improved visibility and UX for Data Source management + Added comprehensive API inspection tools
