# Data Sources - Шпаргалка для разработчиков

## Быстрый старт

### Тестирование GLOBAL TENANT

```bash
# 1. Login as Portal.SuperUser
# 2. Navigate to Data Sources tab
# 3. Select GLOBAL TENANT
# 4. Verify you see data sources from ALL tenants
# 5. Select BFS tenant
# 6. Verify you see ONLY BFS data sources
```

### Создание Data Source

```bash
# UI
1. Select tenant (BFS, Meritage, etc.)
2. Click "Add Data Source"
3. Enter name
4. Click "Create"
5. Wait 1 second for refresh

# curl
curl -X POST "https://dp-eastus-poc-txservices-apis.azurewebsites.net/datasources" \
  -H "Content-Type: application/json" \
  -H "X-BFS-Auth: dummytoken123" \
  -d '{"DatasourceName":"test","TenantId":"BFS"}'
```

### Удаление Data Source

```bash
# UI
1. Click trash icon
2. Confirm deletion
3. Wait 1 second for refresh

# curl
curl -X DELETE "https://dp-eastus-poc-txservices-apis.azurewebsites.net/datasources/datasource_xxx" \
  -H "X-BFS-Auth: dummytoken123" \
  -H "If-Match: \"etag-value\""
```

## Архитектура

```
┌─────────────┐
│   App.tsx   │  ← Управление состоянием + загрузка данных
└──────┬──────┘
       │
       │ props: dataSources, activeTenantId, refreshData
       ▼
┌───────────────────────┐
│ DataSourcesView.tsx   │  ← UI + CRUD операции
└───────────────────────┘
       │
       │ calls
       ▼
┌─────────────┐
│   api.ts    │  ← API запросы к BFS API
└─────────────┘
```

## Изоляция тенантов

### GLOBAL TENANT (SuperUser)

```typescript
// Загружает из ВСЕХ тенантов
if (activeTenantId === 'global') {
  const promises = tenants.map(t => getAllDataSources(t.TenantId));
  const results = await Promise.all(promises);
  allDataSources = results.flat();
}
```

**Видит:** Все data sources из всех тенантов

### Конкретный тенант (BFS, Meritage, etc.)

```typescript
// Загружает только для тенанта
allDataSources = await getAllDataSources(activeTenantId);
```

**Видит:** Только data sources своего тенанта

## API Endpoints

```
Base: https://dp-eastus-poc-txservices-apis.azurewebsites.net

GET    /datasources
GET    /datasources?Filters={"TenantId":"BFS"}
POST   /datasources
PUT    /datasources/{id}
DELETE /datasources/{id}
```

### Headers

```
X-BFS-Auth: dummytoken123
Content-Type: application/json
If-Match: "etag"  # Для PUT/DELETE
```

## Типовые команды curl

### Получить все data sources тенанта

```bash
curl -X GET "https://dp-eastus-poc-txservices-apis.azurewebsites.net/datasources?Filters=%7B%22TenantId%22%3A%22BFS%22%7D" \
  -H "X-BFS-Auth: dummytoken123" | jq
```

### Создать data source

```bash
curl -X POST "https://dp-eastus-poc-txservices-apis.azurewebsites.net/datasources" \
  -H "Content-Type: application/json" \
  -H "X-BFS-Auth: dummytoken123" \
  -d '{
    "DatasourceName": "test-ds",
    "TenantId": "BFS"
  }' | jq
```

### Обновить data source

```bash
curl -X PUT "https://dp-eastus-poc-txservices-apis.azurewebsites.net/datasources/datasource_xxx" \
  -H "Content-Type: application/json" \
  -H "X-BFS-Auth: dummytoken123" \
  -H "If-Match: \"etag-value\"" \
  -d '{
    "DatasourceName": "updated-name",
    "TenantId": "BFS"
  }' | jq
```

### Удалить data source

```bash
curl -X DELETE "https://dp-eastus-poc-txservices-apis.azurewebsites.net/datasources/datasource_xxx" \
  -H "X-BFS-Auth: dummytoken123" \
  -H "If-Match: \"etag-value\""
```

## Debugging

### Проверить логи загрузки

```javascript
// Откройте DevTools Console (F12)
// Выберите GLOBAL TENANT
// Ищите:

📡 Fetching data sources for GLOBAL tenant (all tenants)...
✅ Loaded 5 data sources for tenant BFS
✅ Loaded 3 data sources for tenant Meritage
✅ Total data sources from all tenants: 8
```

### Проверить состояние в React DevTools

```javascript
// Найдите компонент App
// Посмотрите state:
dataSources: Array[8]
activeTenantId: "global"
tenants: Array[3]
```

### Проверить network requests

```
1. DevTools → Network tab
2. Переключите тенант
3. Фильтр: XHR
4. Ищите запросы к /datasources
5. Проверьте Query String Parameters
```

## Типовые проблемы

### ❌ GLOBAL не видит все data sources

**Проверить:**
```javascript
// В App.tsx, функция refreshDataSources()
if (activeTenantId === 'global') {
  // Должен делать запросы для КАЖДОГО тенанта
  const promises = tenants.map(t => getAllDataSources(t.TenantId));
}
```

**Симптомы:**
- GLOBAL показывает меньше data sources чем ожидается
- Отсутствуют data sources некоторых тенантов

**Решение:** Проверьте логи - успешны ли все запросы?

### ❌ После create/delete запись не обновляется

**Проверить:**
```typescript
// Должна быть задержка 1 секунда
await createDataSource(data);
await new Promise(resolve => setTimeout(resolve, 1000));
refreshData();
```

**Симптомы:**
- Создали data source → не появился в списке
- Удалили data source → все еще в списке

**Решение:** Добавьте задержку перед refreshData()

### ❌ Ошибка ETag при update/delete

**Проверить:**
```typescript
// Передается ли ETag?
await deleteDataSource(id, dataSource._etag);
```

**Симптомы:**
- `412 Precondition Failed`
- `ETag mismatch`

**Решение:** Обновите data source перед операцией

## Code Snippets

### Добавить новое поле в Data Source

```typescript
// 1. Обновить интерфейс
interface DataSource {
  // ... existing fields
  NewField?: string;
}

// 2. Добавить в column configs
const columns: ColumnConfig[] = [
  // ... existing columns
  { key: 'NewField', label: 'New Field', enabled: false },
];

// 3. Обновить форму создания
<Input
  value={newFieldValue}
  onChange={(e) => setNewFieldValue(e.target.value)}
  placeholder="Enter new field"
/>
```

### Добавить валидацию

```typescript
const validateDataSource = (data: Partial<DataSource>): boolean => {
  if (!data.DatasourceName) {
    toast.error('Name is required');
    return false;
  }
  
  if (!data.TenantId) {
    toast.error('Tenant is required');
    return false;
  }
  
  // Custom validation
  if (data.DatasourceName.length < 3) {
    toast.error('Name must be at least 3 characters');
    return false;
  }
  
  return true;
};

// Use in create
const handleCreate = async () => {
  if (!validateDataSource(formData)) return;
  // ... proceed with create
};
```

### Добавить фильтрацию

```typescript
const [searchTerm, setSearchTerm] = useState('');

const filteredDataSources = useMemo(() => {
  if (!searchTerm) return dataSources;
  
  return dataSources.filter(ds =>
    ds.DatasourceName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    ds.DatasourceId?.toLowerCase().includes(searchTerm.toLowerCase())
  );
}, [dataSources, searchTerm]);
```

## Testing Checklist

### UI Tests
- [ ] GLOBAL TENANT видит все data sources
- [ ] BFS видит только BFS data sources
- [ ] Создание работает
- [ ] Редактирование работает
- [ ] Удаление работает
- [ ] Search работает
- [ ] Column selector работает
- [ ] Expandable rows работают

### API Tests
```bash
# GET - все тенанты
for tenant in BFS Meritage PIM; do
  echo "Testing $tenant..."
  curl -X GET "...?Filters={\"TenantId\":\"$tenant\"}" \
    -H "X-BFS-Auth: dummytoken123"
done

# POST - создание
curl -X POST ".../datasources" \
  -H "Content-Type: application/json" \
  -H "X-BFS-Auth: dummytoken123" \
  -d '{"DatasourceName":"test","TenantId":"BFS"}'

# DELETE - удаление
curl -X DELETE ".../datasources/{id}" \
  -H "X-BFS-Auth: dummytoken123" \
  -H "If-Match: \"etag\""
```

### Performance Tests
- [ ] Загрузка < 2 сек для 1-3 тенантов
- [ ] Загрузка < 5 сек для 4-10 тенантов
- [ ] UI responsive во время загрузки
- [ ] Нет memory leaks

## Документация

### Полная документация
- `/GLOBAL_TENANT_DATASOURCES_FIX_RU.md` - GLOBAL TENANT fix
- `/TENANT_ISOLATION_RU.md` - архитектура изоляции
- `/DATASOURCE_DELETE_FIX_RU.md` - delete fix
- `/DATASOURCE_CURL_TEST_RU.md` - curl тесты
- `/TESTING_GLOBAL_TENANT_RU.md` - тестирование
- `/CHANGELOG_DATASOURCES_RU.md` - полный changelog

### Быстрые ссылки
```bash
# Посмотреть все документы
ls -la /*.md

# Поиск по документам
grep -r "GLOBAL TENANT" /*.md
```

## Контакты

BFS Portal Development Team

## Версия

Актуальна на: 13 ноября 2025
