# ✅ Apicurio PUT Operation - Ready to Use

## 🎯 Task
Change `name` field in `inv.response` artifact from `"inv"` to `"TxServices_inv"`

**Artifact URL:**
```
https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/bfs.online/artifacts/inv.response/
```

---

## ⚡ Quick Start (2 clicks)

### Option 1: Quick Fix Button (Fastest)
1. Open **Data Sources** tab
2. Click **"Quick Fix: inv → TxServices_inv"** button

### Option 2: PUT Test (With detailed logs)
1. Click **Database icon** (🗄️) in top navigation
2. Open **"🧪 PUT Test"** tab
3. Click **"Run PUT Test"**

---

## 📦 What's Included

### 1. PUT API Function
**File:** `/lib/apicurio.ts`
```typescript
updateApicurioArtifact(groupId, artifactId, content, version?)
```

### 2. Quick Fix Button
**File:** `/components/ApicurioQuickPutButton.tsx`
- One-click update
- Shows in Data Sources tab (SuperUser only)
- Auto toast notification

### 3. PUT Test Component
**File:** `/components/ApicurioPutTest.tsx`
- Full test with 4 steps
- Detailed console logs
- Verification included

### 4. Integration
**Updated:** `/components/ApicurioConnectionTest.tsx`
- New "🧪 PUT Test" tab added

**Updated:** `/components/DataSourcesView.tsx`
- Quick Fix button integrated

---

## 🚀 Usage

### Quick Fix Button
```
Data Sources → Quick Fix Button → Done!
```

### PUT Test (Detailed)
```
Database Icon → PUT Test → Run Test → Check Console
```

### Programmatic Usage
```typescript
import { updateApicurioArtifact, getApicurioArtifact } from '../lib/apicurio';

// Get current content
const content = await getApicurioArtifact('bfs.online', 'inv.response');

// Modify
const modified = { ...content, name: 'TxServices_inv' };

// Update
const result = await updateApicurioArtifact('bfs.online', 'inv.response', modified);

if (result.success) {
  console.log('✅ Updated! Version:', result.version);
}
```

---

## 📊 Expected Results

### Success Response
```json
{
  "success": true,
  "message": "Artifact updated successfully",
  "version": "1.0.1"
}
```

### Toast Notification
```
✅ Updated successfully!
inv.response → name: "TxServices_inv" (v1.0.1)
```

### Console Output
```
📦 PUT: Updating artifact: https://apicurio-poc.../inv.response
📦 PUT: Response status: 200
📦 ✅ PUT successful
📦 Apicurio artifacts cache cleared
```

---

## ✅ Verification

### Check in Browser
1. Open console (F12)
2. Look for `✅ PUT successful`
3. Check toast notification

### Check via API
```bash
curl https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/bfs.online/artifacts/inv.response/versions/latest/content | jq '.name'
```

Expected: `"TxServices_inv"`

### Check in Application
1. Data Sources → Add Data Source
2. Create from Apicurio Template
3. Select `inv.response`
4. Verify name field = `TxServices_inv`

---

## 📁 Files Changed

### New Files ✨
- `/components/ApicurioPutTest.tsx` - Test component
- `/components/ApicurioQuickPutButton.tsx` - Quick fix button
- `/APICURIO_PUT_TEST_GUIDE.md` - Detailed guide
- `/QUICK_PUT_INSTRUCTIONS.md` - Step-by-step instructions
- `/PUT_OPERATION_VISUAL_GUIDE.md` - Visual diagrams

### Modified Files ✏️
- `/lib/apicurio.ts` - Added `updateApicurioArtifact()`
- `/components/ApicurioConnectionTest.tsx` - Added PUT Test tab
- `/components/DataSourcesView.tsx` - Added Quick Fix button

---

## 🐛 Troubleshooting

### CORS Error?
Apicurio Registry needs CORS configuration for PUT requests.

### 403 Forbidden?
Check authentication and permissions on Apicurio Registry.

### Button not visible?
Quick Fix button only shows for **Portal.SuperUser** role.

### Changes not reflected?
Cache is auto-cleared. Try refreshing the page or checking version number.

---

## 📖 Documentation

| Document | Description |
|----------|-------------|
| `/APICURIO_PUT_TEST_GUIDE.md` | Complete testing guide with examples |
| `/QUICK_PUT_INSTRUCTIONS.md` | Quick reference for both methods |
| `/PUT_OPERATION_VISUAL_GUIDE.md` | Visual diagrams and flow charts |

---

## 🎉 Ready to Use!

Everything is implemented and ready. Just open the app and choose your preferred method:

- **Fast:** Use Quick Fix button in Data Sources
- **Detailed:** Use PUT Test in API Connection Diagnostics

Both methods will update `inv.response` artifact's name field from `"inv"` to `"TxServices_inv"`.
