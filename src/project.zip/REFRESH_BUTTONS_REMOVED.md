# Удалены кнопки Refresh и обновлён Loading State

## Выполненные изменения

### 1. Удалены кнопки Refresh из всех компонентов

Убраны кнопки Refresh из:
- **TenantsView** - desktop и mobile версии
- **TransactionsView** - desktop и mobile версии  
- **DataSourcesView** - desktop и mobile версии
- **ApplicationsView** - desktop и mobile версии
- **ModelSchemaView** - desktop и mobile версии
- **TransactionBuilder** - удалена отдельная кнопка Refresh

### 2. Заменён Spinner на Skeleton Loading

Вместо анимированного spinner с текстом "Loading..." теперь используется **skeleton loading** (chips подгрузка):

**Было:**
```tsx
{isLoading ? (
  <div className="text-center py-12">
    <RefreshCw className="h-8 w-8 animate-spin mx-auto mb-4 text-muted-foreground" />
    <p className="text-muted-foreground">Loading...</p>
  </div>
) : ...}
```

**Стало:**
```tsx
{isLoading ? (
  <div className="space-y-3">
    <Skeleton className="h-12 w-full" />
    <Skeleton className="h-12 w-full" />
    <Skeleton className="h-12 w-full" />
    <Skeleton className="h-12 w-full" />
    <Skeleton className="h-12 w-full" />
  </div>
) : ...}
```

### 3. Обновлён TransactionsView

Добавлен skeleton loading для состояния `isLoadingType` - когда переключаются типы транзакций:

```tsx
{/* Loading State */}
{isLoadingType && (
  <div className="space-y-3">
    <Skeleton className="h-12 w-full" />
    <Skeleton className="h-12 w-full" />
    <Skeleton className="h-12 w-full" />
    <Skeleton className="h-12 w-full" />
    <Skeleton className="h-12 w-full" />
  </div>
)}
```

### 4. Сохранена функциональность refreshData

**ВАЖНО:** Функция `refreshData()` **НЕ** удалена из компонентов! Она продолжает использоваться для:

- Автоматического обновления после создания/редактирования/удаления
- Обновления данных из App.tsx при первой загрузке
- Синхронизации данных между компонентами

Удалены только **UI кнопки** Refresh, так как данные обновляются автоматически.

### 5. Обновлённые импорты

Убраны неиспользуемые импорты:
- `RefreshIcon` из `./icons/RefreshIcon` (где не нужен)
- `RefreshCw` из `lucide-react` (где не нужен)

Добавлен импорт:
- `Skeleton` из `./ui/skeleton`

## Компоненты с изменениями

1. ✅ **TenantsView.tsx**
2. ✅ **TransactionsView.tsx** 
3. ✅ **DataSourcesView.tsx**
4. ✅ **ApplicationsView.tsx**
5. ✅ **ModelSchemaView.tsx**
6. ✅ **TransactionBuilder.tsx**

## UX улучшения

- **Более современный вид** - skeleton loading выглядит современнее чем spinner
- **Меньше кликов** - нет необходимости вручную обновлять данные
- **Автоматическое обновление** - данные автоматически обновляются после операций
- **Чище интерфейс** - убрана лишняя кнопка из панели инструментов

## Что НЕ изменилось

- Функции `refreshData()`, `refreshTenants()`, `refreshDataSources()` остались
- Автоматическое обновление после CRUD операций работает
- Логика загрузки данных не изменилась
- API вызовы остались прежними
