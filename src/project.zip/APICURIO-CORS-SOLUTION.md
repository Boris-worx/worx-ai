# Apicurio Registry - CORS Solution

## Problem

When accessing Apicurio Registry from the browser, you may encounter CORS (Cross-Origin Resource Sharing) errors:

```
Error fetching Apicurio artifacts: TypeError: Failed to fetch
Error fetching JSON schemas for BFS.online: TypeError: Failed to fetch
```

This occurs because:
1. **Browser Security**: Modern browsers block requests from `https://your-app.com` to `http://apicurio.52.158.160.62.nip.io` unless CORS headers are configured
2. **HTTP vs HTTPS**: Mixed content (HTTPS app calling HTTP API) may be blocked
3. **Missing CORS Headers**: Apicurio server needs to return `Access-Control-Allow-Origin` headers

## Current Solution: Mock Data Mode (CORS Avoidance)

The application is configured to **use mock data directly** without attempting real Apicurio API calls. This completely eliminates CORS errors.

### Feature Flag

In `/lib/api.ts`, there is a feature flag:

```typescript
const USE_MOCK_APICURIO = true;  // Set to false to try real Apicurio API
```

When `USE_MOCK_APICURIO = true`:
- ✅ **No CORS errors** - Never makes real API calls
- ✅ **Instant loading** - No network delay
- ✅ **Fully functional** - All features work with mock data
- ✅ **Clean console** - Only success messages, no errors

### What Works Now

✅ **Mock Data Mode**: Uses mock data directly, avoiding CORS completely
✅ **16 Mock Artifacts**: All artifacts from `paradigm.mybldr.bidtools` are available
✅ **QuoteDetails Schema**: Full JSON schema for `bfs.QuoteDetails.json` is included
✅ **Zero CORS Errors**: No failed fetch attempts, clean console
✅ **Discovery Dialog**: Shows all 16 artifacts instantly

### Mock Data Included

**Groups:**
- `bfs.online`
- `paradigm.mybldr.bidtools` (16 artifacts)
- `paradigm.txservices.quotes`

**Artifacts in paradigm.mybldr.bidtools:**

1. 📄 **bfs.QuoteDetails.json** (JSON) - Full schema available
2. 🔷 **bidtools.LineTypes-key** (AVRO Key)
3. 🔷 **bidtools.QuoteDetails-key** (AVRO Key)
4. 🔷 **bidtools.QuotePackOrder-key** (AVRO Key)
5. 🔷 **bidtools.QuotePacks-key** (AVRO Key)
6. 🔷 **bidtools.Quotes-key** (AVRO Key)
7. 🔷 **bidtools.ReasonCodes-key** (AVRO Key)
8. 🔷 **bidtools.ServiceRequests-key** (AVRO Key)
9. 🔷 **bfs.ServiceRequests** (AVRO Value)
10. 🔷 **bfs.QuoteDetails** (AVRO Value)
11. 🔷 **bfs.WorkflowCustomers** (AVRO Value)
12. 🔷 **bfs.LineTypes** (AVRO Value)
13. 🔷 **bfs.QuotePackOrder** (AVRO Value)
14. 🔷 **bfs.QuotePacks** (AVRO Value)
15. 🔷 **bfs.Quotes** (AVRO Value)
16. 🔷 **bfs.ReasonCodes** (AVRO Value)

### How It Works

1. **Check Feature Flag**: `USE_MOCK_APICURIO = true` in `/lib/api.ts`
2. **Skip Real API**: Never attempts to fetch from Apicurio Registry
3. **Return Mock Data**: Immediately returns mock data
4. **Log Success**: Console shows: `📋 Using mock Apicurio groups (CORS avoidance mode enabled)`
5. **Zero Errors**: No CORS errors, no warnings, clean operation

### Testing Mock Mode

Check browser console (F12) for these messages:

```
🔍 Loading Apicurio schemas for data source: BFS.online
📋 Using mock Apicurio groups (CORS avoidance mode enabled)
📋 Using mock artifacts for group: paradigm.mybldr.bidtools (CORS avoidance mode)
✅ Loaded 1 schema(s) from Apicurio
📋 Using mock schema for: bfs.QuoteDetails.json (CORS avoidance mode)
```

**Note:** You will see NO error messages, NO warnings, just clean success messages!

## Switching to Real Apicurio

To connect to the real Apicurio Registry instead of using mock data:

1. **Change the feature flag** in `/lib/api.ts`:
   ```typescript
   const USE_MOCK_APICURIO = false;  // Try real Apicurio API
   ```

2. **Implement one of the CORS solutions below** (otherwise you'll get CORS errors)

## Production Solutions

For production deployment with real Apicurio, you need one of these solutions:

### Option 1: Configure CORS on Apicurio Server (Recommended)

Configure Apicurio to allow requests from your app domain:

```yaml
# Apicurio configuration
cors:
  enabled: true
  allowed-origins:
    - "https://your-app-domain.com"
    - "http://localhost:5173"  # For development
  allowed-methods:
    - GET
    - POST
    - PUT
    - DELETE
  allowed-headers:
    - Content-Type
    - Accept
```

### Option 2: Backend Proxy

Create a backend API endpoint that proxies requests to Apicurio:

```typescript
// Your backend API
app.get('/api/apicurio/groups', async (req, res) => {
  const response = await fetch('http://apicurio.52.158.160.62.nip.io/apis/registry/v2/groups');
  const data = await response.json();
  res.json(data);
});
```

Then update frontend to call your API:
```typescript
const APICURIO_REGISTRY_URL = '/api/apicurio';  // Use your backend
```

### Option 3: HTTPS Upgrade

If Apicurio is on HTTP and your app is on HTTPS:

1. **Add SSL/TLS** to Apicurio server
2. **Use reverse proxy** (nginx, Apache) with SSL in front of Apicurio
3. **Update URL** to use `https://` instead of `http://`

Example nginx configuration:
```nginx
server {
    listen 443 ssl;
    server_name apicurio.yourdomain.com;
    
    ssl_certificate /path/to/cert.pem;
    ssl_certificate_key /path/to/key.pem;
    
    location / {
        proxy_pass http://apicurio.52.158.160.62.nip.io;
        proxy_set_header Host $host;
        
        # CORS headers
        add_header 'Access-Control-Allow-Origin' '*';
        add_header 'Access-Control-Allow-Methods' 'GET, POST, PUT, DELETE, OPTIONS';
    }
}
```

### Option 4: Browser Extension (Development Only)

For **development only**, use a browser extension to disable CORS:

- **Chrome**: "CORS Unblock" extension
- **Firefox**: "CORS Everywhere" extension

⚠️ **Warning**: Never use this in production!

### Option 5: Use Mock Data Permanently

If Apicurio integration is not critical:

1. Keep the current fallback mock data
2. Add more mock schemas as needed
3. Update `/lib/api.ts` to add more artifacts

```typescript
// Add more mock artifacts
if (groupId === 'bfs.online') {
  return {
    count: 5,
    artifacts: [
      { id: 'bfs.Customers.json', type: 'JSON', ... },
      { id: 'bfs.Orders.json', type: 'JSON', ... },
      // etc.
    ]
  };
}
```

## Verifying Real Apicurio Connection

To test if Apicurio is accessible:

### 1. Direct API Test

Open in browser:
```
http://apicurio.52.158.160.62.nip.io/apis/registry/v2/groups
```

**Expected Result**: JSON response with groups
**If CORS Error**: You'll see the data but browser console shows CORS error

### 2. cURL Test (No CORS issues)

```bash
curl -H "Accept: application/json" \
  http://apicurio.52.158.160.62.nip.io/apis/registry/v2/groups
```

**Expected Result**: JSON data without CORS restrictions

### 3. Health Check

```bash
curl http://apicurio.52.158.160.62.nip.io/health/live
```

**Expected Result**: `{"status": "UP"}`

## Current Status

✅ **Application Works**: With or without real Apicurio connection
✅ **Mock Data Available**: 16 artifacts ready to use
✅ **No User Impact**: CORS errors are handled gracefully
✅ **Development Ready**: Can continue building features

⚠️ **Production Consideration**: Implement one of the production solutions before deployment

## Next Steps

1. **Short term**: Continue using mock data for development
2. **Medium term**: Contact Apicurio admin to configure CORS
3. **Long term**: Set up backend proxy or upgrade to HTTPS

## Questions?

- **Q: Can I still create specifications?**
  - ✅ Yes! Mock data provides `bfs.QuoteDetails.json` schema

- **Q: Will Discovery Dialog work?**
  - ✅ Yes! Shows all 16 mock artifacts

- **Q: Are the mock schemas realistic?**
  - ✅ Yes! Based on your documented artifacts

- **Q: Can I add more mock schemas?**
  - ✅ Yes! Edit `/lib/api.ts` fallback sections

- **Q: When will real Apicurio work?**
  - After implementing one of the production solutions above
