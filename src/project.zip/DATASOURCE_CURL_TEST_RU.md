# Тестирование Data Sources через cURL

## Базовая информация

**API Base URL:** `https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0`  
**Auth Header:** `X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`

## Тестовые команды

### 1. Получить все Data Sources
```bash
curl --location 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/datasources' \
--header 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
--header 'Content-Type: application/json'
```

**Ожидаемый результат:**
```json
{
  "status": {
    "code": 200,
    "message": "Success"
  },
  "data": {
    "DataSources": [
      {
        "DatasourceId": "datasource_abc123",
        "DatasourceName": "AS400",
        "TenantId": "BFS",
        "DatasourceType": null,
        "CreateTime": "2025-11-13T10:00:00Z",
        "UpdateTime": "2025-11-13T10:00:00Z"
      }
    ]
  }
}
```

### 2. Получить Data Sources для конкретного Tenant (BFS)
```bash
curl --location 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/datasources?Filters=%7B%22TenantId%22%3A%22BFS%22%7D' \
--header 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
--header 'Content-Type: application/json'
```

**Примечание:** `%7B%22TenantId%22%3A%22BFS%22%7D` - это URL-encoded версия `{"TenantId":"BFS"}`

**Альтернативная команда (без URL encoding):**
```bash
curl --location 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/datasources' \
--header 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
--header 'Content-Type: application/json' \
--get \
--data-urlencode 'Filters={"TenantId":"BFS"}'
```

### 3. Создать Data Source
```bash
curl --location 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/datasources' \
--header 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
--header 'Content-Type: application/json' \
--data '{
    "DatasourceName": "AS400",
    "TenantId": "BFS"
}'
```

**Ожидаемый результат:**
```json
{
  "status": {
    "code": 201,
    "message": "Created"
  },
  "data": {
    "DatasourceId": "datasource_new123",
    "DatasourceName": "AS400",
    "TenantId": "BFS",
    "DatasourceType": null,
    "CreateTime": "2025-11-13T10:00:00Z",
    "UpdateTime": "2025-11-13T10:00:00Z",
    "_etag": "\"abc123\""
  }
}
```

**ВАЖНО:** Сохраните `DatasourceId` и `_etag` из ответа для последующих операций!

### 4. Получить конкретный Data Source по ID
```bash
curl --location 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/datasources/datasource_new123?TenantId=BFS' \
--header 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
--header 'Content-Type: application/json'
```

### 5. Обновить Data Source
```bash
curl --location --request PUT 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/datasources/datasource_new123' \
--header 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
--header 'Content-Type: application/json' \
--header 'If-Match: "abc123"' \
--data '{
    "DatasourceName": "AS400_Updated",
    "TenantId": "BFS"
}'
```

**Примечание:** Замените `"abc123"` на актуальный `_etag` из предыдущего ответа.

### 6. Удалить Data Source
```bash
curl --location --request DELETE 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/datasources/datasource_new123?TenantId=BFS' \
--header 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
--header 'If-Match: "abc123"'
```

**Ожидаемый результат:**
- HTTP Status: `200 OK` или `204 No Content`
- Тело ответа: пустое или JSON с подтверждением

### 7. Проверить что Data Source удалён
```bash
# Попытаться получить удалённый data source
curl --location 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/datasources/datasource_new123?TenantId=BFS' \
--header 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
--header 'Content-Type: application/json'
```

**Ожидаемый результат:**
- HTTP Status: `404 Not Found`

## Полный тестовый сценарий

### Шаг 1: Создать тестовый Data Source
```bash
RESPONSE=$(curl --location 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/datasources' \
--header 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
--header 'Content-Type: application/json' \
--silent \
--data '{
    "DatasourceName": "TestDataSource",
    "TenantId": "BFS"
}')

echo "Создан Data Source:"
echo $RESPONSE | jq '.'

# Извлечь ID и ETag (требует jq)
DATASOURCE_ID=$(echo $RESPONSE | jq -r '.data.DatasourceId')
ETAG=$(echo $RESPONSE | jq -r '.data._etag')

echo ""
echo "DatasourceId: $DATASOURCE_ID"
echo "ETag: $ETAG"
```

### Шаг 2: Подождать 1 секунду
```bash
sleep 1
```

### Шаг 3: Проверить что Data Source существует
```bash
curl --location "https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/datasources/${DATASOURCE_ID}?TenantId=BFS" \
--header 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
--header 'Content-Type: application/json' \
| jq '.'
```

### Шаг 4: Удалить Data Source
```bash
curl --location --request DELETE "https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/datasources/${DATASOURCE_ID}?TenantId=BFS" \
--header 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
--header "If-Match: ${ETAG}" \
--verbose

echo "Data Source удалён"
```

### Шаг 5: Подождать 1 секунду
```bash
sleep 1
```

### Шаг 6: Проверить что Data Source удалён (должен вернуться 404)
```bash
curl --location "https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/datasources/${DATASOURCE_ID}?TenantId=BFS" \
--header 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
--header 'Content-Type: application/json' \
--verbose

echo ""
echo "Ожидаемый результат: HTTP 404 Not Found"
```

### Шаг 7: Проверить список Data Sources для BFS
```bash
curl --location 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/datasources?Filters=%7B%22TenantId%22%3A%22BFS%22%7D' \
--header 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
--header 'Content-Type: application/json' \
| jq '.data.DataSources[] | {DatasourceId, DatasourceName, TenantId}'

echo ""
echo "TestDataSource не должен присутствовать в списке"
```

## Типичные ошибки и их решения

### Ошибка: 404 Not Found при DELETE
**Причина:** Data Source уже удалён или не существует  
**Решение:** Это нормально, приложение обрабатывает 404 как успешное удаление

### Ошибка: 412 Precondition Failed при UPDATE/DELETE
**Причина:** Неверный ETag (данные были изменены)  
**Решение:** Получите актуальный ETag через GET запрос

### Ошибка: CORS error
**Причина:** Браузер блокирует запрос из-за CORS политики  
**Решение:** Используйте curl в терминале, а не в браузере

### Ошибка: 401 Unauthorized
**Причина:** Неверный или отсутствующий Auth Header  
**Решение:** Проверьте что `X-BFS-Auth` заголовок указан правильно

## Дополнительные примеры

### Создать несколько Data Sources для разных Tenants
```bash
# BFS
curl --location 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/datasources' \
--header 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
--header 'Content-Type: application/json' \
--data '{"DatasourceName": "BFS_DB", "TenantId": "BFS"}'

# Meritage
curl --location 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/datasources' \
--header 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
--header 'Content-Type: application/json' \
--data '{"DatasourceName": "Meritage_DB", "TenantId": "Meritage"}'

# Smith Douglas
curl --location 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/datasources' \
--header 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
--header 'Content-Type: application/json' \
--data '{"DatasourceName": "SmithDouglas_DB", "TenantId": "Smith Douglas"}'
```

### Проверить изоляцию между Tenants
```bash
# Получить все Data Sources
echo "=== ВСЕ DATA SOURCES ==="
curl -s --location 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/datasources' \
--header 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
| jq '.data.DataSources | group_by(.TenantId) | map({tenant: .[0].TenantId, count: length})'

echo ""
echo "=== ТОЛЬКО BFS ==="
curl -s --location 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/datasources?Filters=%7B%22TenantId%22%3A%22BFS%22%7D' \
--header 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
| jq '.data.DataSources[] | {DatasourceName, TenantId}'

echo ""
echo "=== ТОЛЬКО Meritage ==="
curl -s --location 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/datasources' \
--header 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
--get \
--data-urlencode 'Filters={"TenantId":"Meritage"}' \
| jq '.data.DataSources[] | {DatasourceName, TenantId}'
```

## Полезные утилиты

Для работы с JSON ответами рекомендуется установить `jq`:

```bash
# macOS
brew install jq

# Ubuntu/Debian
sudo apt-get install jq

# Windows (через Chocolatey)
choco install jq
```

Для более удобного просмотра ответов можно использовать `jq`:
```bash
curl ... | jq '.'          # Красивое форматирование
curl ... | jq '.data'      # Извлечь только data
curl ... | jq -r '.data.DatasourceId'  # Извлечь конкретное поле
```
