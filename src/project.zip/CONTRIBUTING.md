# Contributing to BFS Tenant Management

Thank you for your interest in contributing to the BFS Tenant Management Platform! 🎉

## 🤝 How to Contribute

### Reporting Bugs

If you find a bug, please create an issue with:
- Clear description of the problem
- Steps to reproduce
- Expected vs actual behavior
- Screenshots (if applicable)
- Browser/environment details

### Suggesting Features

Feature requests are welcome! Please include:
- Clear description of the feature
- Use case and benefits
- Proposed implementation (optional)

### Code Contributions

1. **Fork the repository**
2. **Create a feature branch**
   ```bash
   git checkout -b feature/your-feature-name
   ```

3. **Make your changes**
   - Follow existing code style
   - Add comments for complex logic
   - Update documentation if needed

4. **Test your changes**
   - Test with demo mode
   - Test with real API (if possible)
   - Verify responsive design

5. **Commit with clear messages**
   ```bash
   git commit -m "Add feature: clear description"
   ```

6. **Push and create Pull Request**
   ```bash
   git push origin feature/your-feature-name
   ```

## 📝 Code Style Guidelines

### TypeScript
- Use TypeScript for all new files
- Define interfaces for props and data structures
- Avoid `any` type when possible

### React Components
- Use functional components with hooks
- Keep components focused and single-purpose
- Extract reusable logic into custom hooks

### Styling
- Use Tailwind CSS utility classes
- Follow existing spacing/sizing patterns
- Ensure responsive design (mobile-first)

### File Organization
```
components/
  ├── ui/           # shadcn/ui components
  └── FeatureName.tsx # Feature components
```

## ✅ Checklist Before Submitting

- [ ] Code follows project style
- [ ] All TypeScript errors resolved
- [ ] Component is responsive
- [ ] Tested in demo mode
- [ ] Documentation updated
- [ ] No console errors
- [ ] Commit messages are clear

## 🐛 Bug Fix Process

1. Identify the bug
2. Create issue (if doesn't exist)
3. Create branch: `bugfix/issue-name`
4. Fix and test
5. Submit PR referencing issue

## ✨ Feature Development Process

1. Discuss feature in issue first
2. Get approval from maintainers
3. Create branch: `feature/feature-name`
4. Develop and test
5. Update documentation
6. Submit PR

## 🔍 Code Review Process

- All PRs require review
- Address reviewer feedback
- Keep PRs focused and small
- Be patient and respectful

## 📚 Resources

- [React Documentation](https://react.dev)
- [TypeScript Handbook](https://www.typescriptlang.org/docs/)
- [Tailwind CSS](https://tailwindcss.com/docs)
- [shadcn/ui](https://ui.shadcn.com)

## 💬 Questions?

- Open a discussion issue
- Ask in PR comments
- Check existing documentation

Thank you for contributing! 🙌
