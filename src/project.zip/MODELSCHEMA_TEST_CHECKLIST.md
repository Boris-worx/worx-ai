# ✅ Model Schema Testing Checklist

## 🎯 Testing Guide

После исправления "ModelSchema id mismatch or missing" ошибки, необходимо протестировать все CRUD операции.

## 📋 Checklist

### **✅ 1. CREATE (Создание схемы)**

**Steps**:
1. Открыть Model Schema tab
2. Нажать кнопку "Create Model Schema"
3. Заполнить форму:
   - Model: `TestSchema`
   - Version: `1`
   - State: `active`
   - Semver: `1.0.0`
   - JSON Schema: (default или custom)
4. Нажать "Create"

**Expected Result**:
- ✅ Success toast: "Model schema "TestSchema" created successfully"
- ✅ Новая схема появилась в таблице
- ✅ Таблица отсортирована (новая схема сверху)

**Console Check**:
```
📤 POST Model Schema Request:
  URL: https://api.../txns
  Body: {
    "TxnType": "ModelSchema",
    "Txn": {
      "model": "TestSchema",
      "version": 1,
      "state": "active",
      "semver": "1.0.0",
      "jsonSchema": {...}
    }
  }

📥 Response status: 200 OK
✅ Success response: {...}
```

---

### **✅ 2. READ (Чтение списка схем)**

**Steps**:
1. Открыть Model Schema tab
2. Дождаться загрузки

**Expected Result**:
- ✅ Список схем загрузился
- ✅ Все схемы отображаются корректно
- ✅ Deleted схемы скрыты
- ✅ Нет ошибок в console

**Console Check**:
```
📡 Fetching Model Schemas...
  URL: https://api.../txns?TxnType=ModelSchema

📥 Response: [
  {
    "TxnId": "ModelSchema:Location:1",
    "Txn": {
      "id": "Location:1",
      "model": "Location",
      ...
    }
  },
  ...
]

✅ Loaded X schemas
```

---

### **✅ 3. UPDATE (Редактирование схемы)**

**Steps**:
1. Открыть Model Schema tab
2. Найти любую схему (например, TestSchema:1)
3. Нажать кнопку "Edit" (карандаш)
4. Изменить поле (например, state на "deprecated")
5. Нажать "Update"

**Expected Result**:
- ✅ Success toast: "Model schema "TestSchema" updated successfully"
- ✅ Изменения отобразились в таблице
- ✅ Badge обновился (если меняли state)

**Console Check** (КРИТИЧНО!):
```
📝 PUT Model Schema Request:
  SchemaId: TestSchema:1
  TxnId: ModelSchema:TestSchema:1
  Constructed ID: TestSchema:1 (from model="TestSchema" and version=1)  ← ✅ VERIFY THIS!
  URL: https://api.../txns/ModelSchema:TestSchema:1
  ETag: "abc123..."
  Body: {
    "TxnType": "ModelSchema",
    "Txn": {
      "id": "TestSchema:1",  ← ✅ MUST MATCH model:version!
      "model": "TestSchema",
      "version": 1,
      "state": "deprecated",
      "semver": "1.0.0",
      "jsonSchema": {...}
    }
  }

📥 Response status: 200 OK
✅ Model schema updated successfully
```

**❌ Errors to Watch For**:
```
❌ Error 1: {"status":{"code":400,"message":"ModelSchema id mismatch or missing"},"data":{}}
→ id format is wrong (has "ModelSchema:" prefix)

❌ Error 2: {"status":{"code":400,"message":"Invalid ModelSchema data: Value error, id must be 'X:Y'"},"data":{}}
→ id doesn't match model:version (using old value)
```

---

### **✅ 3b. UPDATE - Change Model Name (Critical Test!)**

**Steps**:
1. Открыть Model Schema tab
2. Найти любую схему (например, TestSchema:1)
3. Нажать кнопку "Edit" (карандаш)
4. **Изменить Model Name** (например, "TestSchema" → "TestSchemaV2")
5. Нажать "Update"

**Expected Result**:
- ✅ Success toast: "Model schema "TestSchemaV2" updated successfully"
- ✅ Изменения отобразились в таблице
- ✅ NO validation errors

**Console Check** (КРИТИЧНО!):
```
📝 PUT Model Schema Request:
  SchemaId: TestSchema:1
  TxnId: ModelSchema:TestSchema:1
  Constructed ID: TestSchemaV2:1 (from model="TestSchemaV2" and version=1)  ← ✅ NEW ID!
  URL: https://api.../txns/ModelSchema:TestSchema:1  ← OLD TxnId in URL
  Body: {
    "TxnType": "ModelSchema",
    "Txn": {
      "id": "TestSchemaV2:1",  ← ✅ NEW ID matches NEW model!
      "model": "TestSchemaV2",  ← ✅ NEW model name
      "version": 1,
      ...
    }
  }

📥 Response status: 200 OK
✅ Model schema updated successfully
```

**❌ If You See This Error**:
```
❌ Error: {"status":{"code":400,"message":"Invalid ModelSchema data: Value error, id must be 'TestSchemaV2:1'"},"data":{}}
```
→ Code is using OLD id instead of constructing from model:version!

---

### **✅ 4. DELETE (Soft Delete)**

**Steps**:
1. Открыть Model Schema tab
2. Найти схему для удаления (например, TestSchema:1)
3. Нажать кнопку "Delete" (корзина)
4. Подтвердить удаление в диалоге

**Expected Result**:
- ✅ Success toast: "Model schema "TestSchema" deleted successfully"
- ✅ Схема исчезла из таблицы
- ✅ Таблица автоматически обновилась

**Console Check** (КРИТИЧНО!):
```
🗑️ DELETE Model Schema Request:
  SchemaId: TestSchema:1
  TxnId: ModelSchema:TestSchema:1
  URL: https://api.../txns/ModelSchema:TestSchema:1
  ETag: "abc123..."

📥 Response status: 400 Bad Request
❌ Error response: {"status":{"code":400,"message":"Unsupported TxnType"},"data":{}}

ℹ️ Hard delete not supported, trying soft delete (state: "deleted")
📝 Soft delete: updating state to "deleted"
  Constructed ID: TestSchema:1 (from model="TestSchema" and version=1)  ← ✅ VERIFY THIS!

📥 Response status: 200 OK
✅ Model schema soft deleted (state: "deleted")
```

**Verify in API**:
```bash
# GET request to see the deleted schema
GET /txns/ModelSchema:TestSchema:1

# Response should have state: "deleted"
{
  "TxnId": "ModelSchema:TestSchema:1",
  "Txn": {
    "id": "TestSchema:1",
    "model": "TestSchema",
    "version": 1,
    "state": "deleted",  ← ✅ Marked as deleted
    ...
  }
}
```

---

## 🔍 Common Issues & Solutions

### **Issue 1: "ModelSchema id mismatch or missing"**

**Symptom**:
```
❌ Error response: {"status":{"code":400,"message":"ModelSchema id mismatch or missing"},"data":{}}
```

**Cause**: `id` в body содержит префикс "ModelSchema:"

**Solution**: Проверьте console log, должно быть:
```
Constructed ID: TestSchema:1 (from model="TestSchema" and version=1)  ← БЕЗ "ModelSchema:"
```

Если видите:
```
Constructed ID: ModelSchema:TestSchema:1  ← НЕПРАВИЛЬНО!
```

Значит код в `/lib/api.ts` не применился. Проверьте строку:
```typescript
const constructedId = `${schemaData.model}:${schemaData.version}`;
```

---

### **Issue 2: "Invalid ModelSchema data: Value error, id must be 'X:Y'"**

**Symptom**:
```
❌ Error: {"status":{"code":400,"message":"Invalid ModelSchema data: Value error, id must be 'NewModel:1'"},"data":{}}
```

**Cause**: `id` не соответствует текущим `model:version` (используется старое значение)

**Solution**: Проверьте console log:
```
Constructed ID: NewModel:1 (from model="NewModel" and version=1)  ← Должно совпадать!
```

Если в Body видите старое `id`:
```json
{
  "id": "OldModel:1",  ← НЕПРАВИЛЬНО!
  "model": "NewModel",
  "version": 1
}
```

Проверьте код в `/lib/api.ts`:
```typescript
// ❌ WRONG
const txnDataWithId = {
  ...schemaData,
  id: oldId, // Using old value
};

// ✅ CORRECT
const constructedId = `${schemaData.model}:${schemaData.version}`;
const txnDataWithId = {
  ...schemaData,
  id: constructedId, // Construct from current data
};
```

---

### **Issue 3: Delete не работает**

**Symptom**:
```
❌ Error: Unsupported TxnType
```
Но НЕТ сообщения "Hard delete not supported, trying soft delete"

**Cause**: Soft delete fallback не сработал

**Solution**: Проверьте код в `/lib/api.ts` в блоке обработки ошибок:
```typescript
if (errorData.status?.message === 'Unsupported TxnType' || 
    errorData.status?.message === 'Unsupported txn_type') {
  console.log('ℹ️ Hard delete not supported, trying soft delete');
  // ... soft delete code
}
```

---

### **Issue 4: Deleted схемы видны в списке**

**Symptom**: После удаления схема все еще отображается

**Cause**: Фильтр deleted схем не применяется

**Solution**: Проверьте `/components/ModelSchemaView.tsx`:
```typescript
const activeSchemas = schemas.filter(s => s.state !== 'deleted');
```

---

## 📊 Quick Verification Matrix

| Operation | Expected Console Message | Expected UI Behavior |
|-----------|-------------------------|---------------------|
| **CREATE** | `✅ Success response:` | Schema appears in table |
| **READ** | `✅ Loaded X schemas` | Table populated |
| **UPDATE** | `Constructed ID: {id} (from model=...` | Changes visible |
| **DELETE** | `✅ Model schema soft deleted` | Schema disappears |

---

## 🎯 Final Check

После всех тестов убедитесь:

1. ✅ **No errors in console**
2. ✅ **All toasts are success messages**
3. ✅ **Table updates automatically after each operation**
4. ✅ **Deleted schemas are hidden**
5. ✅ **Console logs show "Constructed ID: {model}:{version}" for UPDATE/DELETE**
6. ✅ **Can change model name without errors**
7. ✅ **Can change version without errors**

---

## 📝 Notes

- **CREATE** не требует `id` в body - API создаст его автоматически
- **UPDATE/DELETE** требуют `id` БЕЗ префикса "ModelSchema:" и соответствующий `{model}:{version}`
- **ID Construction**: `id` всегда конструируется из текущих `model` и `version`
- **URL** всегда использует полный `TxnId` с префиксом
- **Soft Delete** - это правильное поведение для схем данных
- **Model/Version Changes**: При изменении model или version, `id` автоматически обновляется

---

**Если все пункты ✅ - ModelSchema CRUD полностью функционален! 🎉**

Last Updated: Oct 29, 2025
