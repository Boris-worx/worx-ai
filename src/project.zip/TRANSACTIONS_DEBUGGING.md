# Transactions Debugging Guide

## Проблема: "Нет транзакций Customer"

### ✅ Что проверить:

#### 1. **База данных пустая**
API может возвращать пустой массив `[]` если в Cosmos DB нет данных для этого типа транзакции.

**Это нормально!** Нужно создать первую транзакцию через UI:
```
1. Откройте вкладку Transactions
2. Выберите тип: Customer
3. Нажмите "Create Transaction"
4. Заполните JSON данными
5. Нажмите "Create"
```

#### 2. **X-BFS-Auth заголовок**
Проверяется автоматически! Откройте Console (F12) и увидите:

```
🌐 GET Transactions Request:
  URL: https://...net/1.0/txns?TxnType=Customer
  Headers: {
    X-BFS-Auth: "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
    Content-Type: "application/json"
  }
```

#### 3. **API Response**
В консоли будет показан полный ответ:

**Успешный пустой ответ (база пустая):**
```json
{
  "status": {
    "code": 200,
    "message": "OK"
  },
  "data": []
}
```

**Успешный ответ с данными:**
```json
{
  "status": {
    "code": 200,
    "message": "OK"
  },
  "data": [
    {
      "TxnId": "abc123",
      "TxnType": "Customer",
      "Txn": {
        "CustomerId": "CUST12345",
        "CustomerName": "Acme Corp"
      }
    }
  ]
}
```

**Ошибка (неправильный Auth):**
```json
{
  "status": {
    "code": 401,
    "message": "Unauthorized"
  }
}
```

---

## 🔍 Как проверить в Console:

### Шаг 1: Откройте Developer Tools
```
Chrome/Edge: F12 или Ctrl+Shift+I
Firefox: F12
```

### Шаг 2: Перейдите в Console
Увидите логи:
```
🌐 GET Transactions Request:
  URL: https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/txns?TxnType=Customer
  Headers: {X-BFS-Auth: "e3b0c44...", Content-Type: "application/json"}
  TxnType: Customer

📡 Response received:
  Status: 200 OK
  Headers: {content-type: "application/json", ...}

📦 Response body (raw): {"status":{"code":200,"message":"OK"},"data":[]}

✅ Loaded 0 transaction(s) for type: Customer
```

### Шаг 3: Проверьте Network Tab
1. Откройте вкладку "Network"
2. Выберите тип транзакции в UI
3. Найдите запрос `txns?TxnType=Customer`
4. Проверьте:
   - **Request Headers** → должен быть `X-BFS-Auth`
   - **Response** → проверьте тело ответа

---

## ✅ Создание первой транзакции:

### Через UI:
1. **Transactions** → **Create Transaction**
2. **Type:** Customer
3. **JSON:**
```json
{
  "CustomerId": "CUST12345",
  "CustomerName": "Acme Corp",
  "Email": "contact@acme.com",
  "Phone": "+1-555-1234",
  "Address": "123 Main St, Springfield",
  "Status": "Active"
}
```
4. **Create** → проверьте консоль

### Что увидите в Console:
```
🌐 POST Transaction Request:
  URL: https://.../txns
  Headers: {
    X-BFS-Auth: "e3b0c44...",
    Content-Type: "application/json"
  }
  Body: {
    "TxnType": "Customer",
    "Txn": {
      "CustomerId": "CUST12345",
      ...
    }
  }

📡 Response received:
  Status: 201 Created

✅ Created transaction: {...}
```

---

## ❓ FAQ:

### Q: Почему нет транзакций?
**A:** База данных Cosmos DB пустая для этого типа. Создайте первую транзакцию.

### Q: X-BFS-Auth отправляется?
**A:** Да! Проверьте Console → увидите в логах Headers с X-BFS-Auth.

### Q: JSON из примера автоматически создаётся?
**A:** Нет! Примеры в коде - это templates. Нужно вручную нажать "Create Transaction".

### Q: Как проверить что API работает?
**A:** Откройте Console (F12) и выберите тип транзакции. Увидите полный лог запроса и ответа.

---

## 🎯 Итог:

1. ✅ **X-BFS-Auth** автоматически добавляется ко всем запросам
2. ✅ **Console logging** показывает все детали (headers, body, response)
3. ✅ **Пустой результат** - нормально если база пустая
4. ✅ **Создайте транзакцию** через UI для проверки

**Если в консоли видно `Status: 200 OK` и `data: []` - значит API работает, просто база пустая!**
