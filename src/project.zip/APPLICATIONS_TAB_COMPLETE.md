# Applications Tab - Готово ✅

## Что сделано

Создана новая вкладка **Applications** точно в стиле Data Source Onboarding (1 в 1 копия).

## Структура

### 1. Основная таблица - Applications

**Колонки (по умолчанию включены):**
- ✅ Application ID - locked, всегда показывается
- ✅ Name - название приложения
- ✅ Version - версия (Badge)
- ✅ Status - статус (Active/Inactive с цветными badge)
- ✅ Description - описание с truncation
- ✅ Created - дата создания
- ❌ Updated - дата обновления (выключена по умолчанию)

### 2. Expandable раздел - Transaction Specifications

Показывается при раскрытии строки приложения. Содержит таблицу:

**Колонки:**
- Table - название таблицы
- Version - версия
- Date - дата
- Action - кнопки View/Edit/Delete

### 3. Mock данные

**Applications:**
- **Bidtools** v2.0 (Active) - с 3 specifications: Quotes, QuoteDetails, QuotePacks
- **Databricks** v1.5 (Active) - с 2 specifications: Quotes, QuotePackOrder

## Функциональность

### ✅ Полностью работает (как в Data Source Onboarding)

1. **Column Selector** - выбор колонок с сохранением в localStorage
2. **Tenant Selector** - переключение тенантов
3. **Refresh** - кнопка обновления данных
4. **Create Application** - диалог создания с полями:
   - Application Name* (required)
   - Version
   - Description
5. **View Application** - просмотр деталей в Dialog
6. **Edit Application** - редактирование названия
7. **Delete Application** - удаление с подтверждением
8. **Expandable Rows** - раскрытие для просмотра Transaction Specifications
9. **Responsive Design** - адаптив для мобильных с Dropdown Menu
10. **Empty States** - красивые placeholder когда нет данных
11. **Loading States** - анимация загрузки

### 🔜 Coming Soon (как в Data Source Onboarding)

- Add Transaction Specification
- Edit Transaction Specification  
- Delete Transaction Specification
- View Transaction Specification (показывает toast "Coming soon!")

## Стиль - точно как Data Source Onboarding

### CardHeader
```
Title: "Applications" (20px, bold, padding: 0 0 5px 0)
Description: "Manage applications and their transaction specifications"
```

### Кнопки
- Desktop: все кнопки видны (TenantSelector, ColumnSelector, Refresh, Add)
- Mobile: TenantSelector + DropdownMenu с остальными кнопками

### Таблица
- Expandable rows с Transaction Specifications
- Actions: View/Edit/Delete (desktop) или Icons (mobile compact)
- Badge для Version и Status
- Truncated Description с tooltip

### Empty State
```
Icon: AppWindow (h-12 w-12)
Title: "No Applications"
Message: "Get started by creating your first application"
Button: "Add Application"
```

## Права доступа (RBAC)

### Доступ к вкладке:
- ✅ Portal.SuperUser
- ✅ Admin
- ✅ Developer
- ✅ ViewOnlySuperUser (read-only)
- ✅ Viewer (read-only)

### Create/Edit/Delete:
- ✅ Portal.SuperUser
- ✅ Admin
- ✅ Developer
- ❌ ViewOnlySuperUser
- ❌ Viewer

## Файлы

### Созданные
- `/components/ApplicationsView.tsx` - основной компонент (точная копия стиля DataSourcesView)

### Обновленные
- `/App.tsx` - добавлена вкладка Applications
- `/components/MobileMenu.tsx` - добавлена вкладка в мобильное меню

## Навигация

**Desktop:**
```
Tenants | Transaction Onboarding | Data Source Onboarding | Applications | Data Plane
```

**Mobile:**
```
☰ Menu
  └─ Applications (с иконкой AppWindow)
```

**Позиция:** после "Data Source Onboarding", перед "Data Plane"

## Column Selector

Работает точно как в Data Source Onboarding:

1. Сохраняет настройки в localStorage (`applicationsViewColumns`)
2. Показывает все доступные поля из данных
3. Автоматически скрывает пустые колонки
4. Application ID - locked, нельзя выключить
5. Version 1 в localStorage для контроля обновлений

## LocalStorage

```javascript
// Column settings
localStorage.setItem('applicationsViewColumns', JSON.stringify(configs))
localStorage.setItem('applicationsViewColumnsVersion', '1')
```

## Следующие шаги

### Для полной функциональности:

1. Добавить реальные API вызовы (пока mock данные)
2. Реализовать CRUD для Transaction Specifications
3. Добавить фильтрацию по tenant
4. Добавить валидацию для Version поля
5. Добавить поддержку Schema для спецификаций

## Проверка

### Чтобы проверить:

1. Запустить приложение
2. Войти как SuperUser/Admin/Developer
3. Открыть вкладку "Applications"
4. Проверить:
   - ✅ 2 приложения в списке (Bidtools, Databricks)
   - ✅ Можно раскрыть строку и увидеть Transaction Specifications
   - ✅ Column Selector работает
   - ✅ Кнопки Create/Edit/Delete работают
   - ✅ Responsive на мобильных
   - ✅ Empty state показывается при пустых данных

## Статус

✅ **ГОТОВО** - Вкладка Applications полностью создана 1 в 1 как Data Source Onboarding

---

**Дата:** 05.11.2025  
**Время:** ~30 минут  
**Автор:** AI Assistant
