# Apicurio Registry Quick Start Guide

## What is Apicurio Registry?

Apicurio Registry is a schema registry that stores and manages data schemas (JSON, AVRO, Protobuf) for your data sources. In this application, it provides a centralized way to manage Data Capture Specifications.

## How It Works in This Application

When you create a **Data Capture Specification**, you need to define a JSON schema that describes the structure of your data. Instead of manually writing this schema, Apicurio Registry allows you to:

1. **Browse available schemas** from centralized registry
2. **Load schemas automatically** into your specification
3. **Discover all schemas** across all data sources

## Step-by-Step: Creating a Specification with Apicurio

### Example: Creating QuoteDetails Specification for BFS.online

#### Step 1: Navigate to Data Source Onboarding
- Click on the **"Data Source Onboarding"** tab in the main navigation

#### Step 2: Find Your Data Source
- Locate the **"BFS.online"** data source in the table
- Click the expand button (▼) to see details

#### Step 3: Add Specification
- Click the **"Add Specification"** button
- Wait for schemas to load from Apicurio (you'll see a loading indicator)

#### Step 4: Load Schema from Apicurio
At the top of the dialog, you'll see: **"Load Schema from Apicurio Registry"**

If schemas are available:
```
┌─────────────────────────────────────┐
│ Load Schema from Apicurio Registry  │
│                                     │
│ ┌─────────────────────────────────┐ │
│ │ bfs.QuoteDetails.json    [bfs...│ │ <- Click here
│ └─────────────────────────────────┘ │
│ 1 JSON schema(s) available          │
└─────────────────────────────────────┘
```

If no schemas are found:
```
┌─────────────────────────────────────┐
│ Load Schema from Apicurio Registry  │
│                                     │
│  No JSON schemas found in Apicurio  │
│  Registry for this data source.     │
│  You can still manually enter       │
│  a schema below.                    │
└─────────────────────────────────────┘
```

#### Step 5: Select a Schema
- Click on the dropdown
- Select **"bfs.QuoteDetails.json"**
- The schema will automatically load into the **Container Schema JSON** field
- The **Specification Name** will be auto-filled as "QuoteDetails"

#### Step 6: Complete Other Fields
Fill in the remaining required fields:

- **Version:** 1 (default)
- **Active:** ✓ (checked)
- **Profile:** data-capture
- **Primary Key Field:** `quoteId`
- **Partition Key Field:** `partitionKey`
- **Partition Key Value:** `{tenantId}-bidtools`
- **Allowed Filters:** Select from dropdown:
  - quoteId
  - customerId
  - quoteStatus
  - (etc.)

#### Step 7: Review Schema
The right panel shows the loaded JSON schema:

```json
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "type": "object",
  "properties": {
    "quoteId": {
      "type": "string"
    },
    "customerId": {
      "type": "string"
    },
    // ... more fields
  },
  "required": ["quoteId", "partitionKey"]
}
```

#### Step 8: Create Specification
- Click **"Create Specification"** button
- Success! ✅

## Discovering All Available Schemas

Want to see what schemas are available across ALL data sources?

### Method 1: Discovery Dialog

1. Go to **Data Source Onboarding** tab
2. Click the **menu button (⋮)** in the header
3. Select **"Discover Specifications"**
4. Browse all schemas organized by group:

```
paradigm.mybldr.bidtools  |  16 artifacts
├── 📄 bfs.QuoteDetails.json        [JSON] [View]
├── 🔷 bidtools.Quotes-key          [AVRO] [Key] [View]
├── 🔷 bfs.Quotes                   [AVRO] [View]
├── 🔷 bidtools.QuoteDetails-key    [AVRO] [Key] [View]
├── 🔷 bfs.QuoteDetails             [AVRO] [View]
└── ... (11 more)

bfs.online  |  X artifacts
└── ...
```

5. Click **"View"** on any schema to copy it to clipboard

### Method 2: Direct Apicurio UI

Open the Apicurio Registry UI directly:
- URL: http://apicurio.52.158.160.62.nip.io/ui
- Browse groups and artifacts
- View schema versions
- Download schemas

## Understanding Schema Types

### JSON Schemas (📄)
- Used directly in Data Capture Specifications
- Human-readable format
- Example: `bfs.QuoteDetails.json`

### AVRO Schemas (🔷)
- Binary format used by Kafka/Debezium
- More efficient for streaming
- Need conversion for use in this application
- Example: `bfs.QuoteDetails` (AVRO)

### Key Schemas (🔷 Key)
- Debezium CDC (Change Data Capture) schemas
- Identify records uniquely
- Example: `bidtools.QuoteDetails-key`

## Group Naming Convention

Apicurio uses a hierarchical naming convention:

```
{organization}.{domain}.{application}
```

Examples:
- `paradigm.mybldr.bidtools` - Bidtools app in mybldr domain
- `paradigm.txservices.quotes` - Quotes service in txservices domain
- `bfs.online` - BFS online platform

## Troubleshooting

### No schemas appear when creating specification

**Problem:** Dropdown shows "No JSON schemas found"

**Solutions:**
1. Check that your data source name matches a group in Apicurio
2. Verify Apicurio Registry is accessible
3. Open browser console (F12) and look for errors
4. Try "Discover Specifications" to see all available schemas
5. Check that JSON schemas exist for your group (not just AVRO)

### Schema fails to load

**Problem:** Error when selecting a schema from dropdown

**Solutions:**
1. Check browser console for API errors
2. Verify the artifact exists in Apicurio UI
3. Ensure you have network access to Apicurio
4. Try refreshing the page and opening the dialog again

### Wrong data source name

**Problem:** Your data source is "BFS.online" but app looks for "BFS"

**Solution:** The app already supports multiple name variations:
- `BFS` → `bfs.online`
- `BFS.online` → `bfs.online`
- `bfs.online` → `bfs.online`
- `Bidtools` → `paradigm.mybldr.bidtools`
- `BIDTOOLS` → `paradigm.mybldr.bidtools`

If your data source has a different name, it will try to find a matching group automatically.

## Currently Available Schemas

Based on discovery from `paradigm.mybldr.bidtools` group:

### JSON Schemas (Ready to Use)
1. ✅ **bfs.QuoteDetails.json** - QuoteDetails entity

### AVRO Schemas (View Only)
Currently 15 AVRO schemas available. Future update will support AVRO to JSON conversion.

## Next Steps

After creating your first specification:
1. View it in the expanded data source row
2. Edit specification if needed
3. Create more specifications for other entities
4. Use "Discover Specifications" to explore all available schemas

## API Integration

For developers, the application provides these API functions:

```typescript
// Get all groups
const groups = await getApicurioGroups();

// Get artifacts from a specific group
const artifacts = await getApicurioArtifacts('paradigm.mybldr.bidtools');

// Get schema content
const schema = await getApicurioArtifactContent('paradigm.mybldr.bidtools', 'bfs.QuoteDetails.json');

// Get JSON schemas for a data source (by name)
const jsonSchemas = await getJsonSchemasForDataSource('BFS.online');

// Discover all specifications across all groups
const allSpecs = await getAllDataSourceSpecifications();
```

## Resources

- **Apicurio Registry UI:** http://apicurio.52.158.160.62.nip.io/ui
- **Apicurio API Docs:** http://apicurio.52.158.160.62.nip.io/apis/registry/v2
- **Health Check:** http://apicurio.52.158.160.62.nip.io/health/live
- **Integration Docs:** See `/APICURIO-INTEGRATION.md`
- **Discovered Specs:** See `/APICURIO-DISCOVERED-SPECS.md`
- **Test Script:** Run `node test-apicurio.js`
