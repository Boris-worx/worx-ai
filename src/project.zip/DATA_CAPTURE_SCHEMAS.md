# ✅ Data Capture Schemas в Data Source Onboarding

## 📋 Обзор

Добавлена функциональность **Data Capture Schemas** внутри каждого Data Source. При нажатии на **View** для Bidtools или Databricks открывается диалог с деталями и accordion, содержащий 4 схемы данных.

---

## 🎯 Функциональность

### View Data Source → Data Capture Schemas

Теперь в Detail Dialog есть **две секции**:

1. **Basic Information** - основная информация о Data Source
2. **Data Capture Schemas** - accordion с 4 схемами

---

## 📊 4 Data Capture Schemas

### 1. **Quotes** 🔵

```json
{
  "before": null,
  "after": {
    "QuoteId": 132821,
    "CustomerId": 63341,
    "ServiceRequestId": 49835,
    "IsPublished": true,
    "PublishedByUserId": 38798,
    "DatePublished": "2025-10-20T14:45:28.6771648Z",
    "CostCodeRequired": false,
    "PricingMethodId": 2,
    "PricingAsOfDate": "2025-10-02T00:00:00Z",
    "ExpirationDate": "2025-10-31T00:00:00Z",
    "LocationCode": "1209",
    "LocationName": "North Hollywood",
    "LocationAddress": "BFS GROUP LLC., 7151 Lankershim Blvd, North Hollywood, CA, 91605",
    "QuoteName": "WIN11",
    ...
  },
  "source": {
    "version": "3.3.1.Final",
    "connector": "sqlserver",
    "name": "cdc",
    "table": "Quotes",
    ...
  },
  "op": "r"
}
```

**Описание:**
- Основная информация о Quote (расчёт/предложение)
- Содержит Customer, Service Request, Location данные
- Pricing информацию и даты

---

### 2. **QuotePacks** 🟢

```json
{
  "before": null,
  "after": {
    "QuotePackId": 52763,
    "QuoteId": 132794,
    "QuotePackName": "TEST",
    "QuotePackSortOrder": 1,
    "CreatedBy": 38762,
    "CreatedDate": "2025-10-15T14:19:02.8562334Z",
    "BuildingName": "Project Quote",
    "QuotePackIsPublished": true,
    ...
  },
  "source": {
    "table": "QuotePacks",
    ...
  }
}
```

**Описание:**
- Пакеты внутри Quote
- Группировка материалов по зданиям/проектам
- Информация о публикации и сортировке

---

### 3. **QuoteDetails** 🟣

```json
{
  "before": null,
  "after": {
    "QuoteDetailId": 6166417,
    "QuoteId": 132820,
    "Sku": "3",
    "ManualPrice": "FCgo",
    "Quantity": 3,
    "IsTaxable": false,
    "MaterialDescription": "",
    "ItemTypeId": 2,
    "QuotePackId": 52823,
    "MinorCategory": "1070",
    ...
  },
  "source": {
    "table": "QuoteDetails",
    ...
  }
}
```

**Описание:**
- Детали каждого элемента в Quote
- SKU, количество, цены
- Категории и описания материалов

---

### 4. **QuotePackOrder** 🟠

```json
{
  "before": null,
  "after": {
    "QuotePackOrderId": 977,
    "QuoteId": 132769,
    "QuotePackId": 52742,
    "OnlineOrderNumber": null,
    "QuotePackOrderErpSystem": "trend",
    "ERPQuoteNumber": "51435778-00",
    "IsAddedFromMyBldr": true,
    "ErpOrderStatus": 0
  },
  "source": {
    "table": "QuotePackOrder",
    ...
  }
}
```

**Описание:**
- Информация о заказах QuotePack
- Связь с ERP системами
- Статус обработки заказа

---

## 🖼️ UI Структура

### Detail Dialog

```
┌─────────────────────────────────────────────┐
│ Data Source Details                         │
│ Detailed information about this data source │
├─────────────────────────────────────────────┤
│                                             │
│ Basic Information                           │
│ ├─ Data Source ID: datasource_f1rsb08...   │
│ ├─ Name: Bidtools                           │
│ ├─ Type: SQL Database                       │
│ ├─ Status: Active                           │
│ └─ ...                                      │
│                                             │
│ ───────────────────────────────────────    │
│                                             │
│ Data Capture Schemas                        │
│ Schema definitions for data capture ops     │
│                                             │
│ ▼ 🔵 Quotes                 [52 fields]    │
│   └─ { JSON content }                       │
│                                             │
│ ▶ 🟢 QuotePacks             [32 fields]    │
│                                             │
│ ▶ 🟣 QuoteDetails           [48 fields]    │
│                                             │
│ ▶ 🟠 QuotePackOrder         [13 fields]    │
│                                             │
├─────────────────────────────────────────────┤
│                                  [Close]    │
└─────────────────────────────────────────────┘
```

---

## 💻 Код

### Импорты

```tsx
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from './ui/accordion';
import { Separator } from './ui/separator';
```

---

### Mock Data

```tsx
const mockDataCaptureSchemas = {
  Quotes: { ... },
  QuotePacks: { ... },
  QuoteDetails: { ... },
  QuotePackOrder: { ... }
};
```

**Примечание:** 
- Пока используются mock данные
- В будущем будут загружаться через API

---

### Accordion Implementation

```tsx
<Accordion type="single" collapsible className="w-full">
  <AccordionItem value="quotes">
    <AccordionTrigger className="text-sm hover:no-underline">
      <div className="flex items-center gap-2">
        <Database className="h-4 w-4 text-blue-500" />
        <span>Quotes</span>
        <Badge variant="outline" className="ml-2 text-xs">
          {Object.keys(mockDataCaptureSchemas.Quotes.after).length} fields
        </Badge>
      </div>
    </AccordionTrigger>
    <AccordionContent>
      <div className="rounded-md border bg-muted/30 p-3 mt-2">
        <pre className="text-xs overflow-x-auto">
          {JSON.stringify(mockDataCaptureSchemas.Quotes, null, 2)}
        </pre>
      </div>
    </AccordionContent>
  </AccordionItem>
  
  {/* QuotePacks, QuoteDetails, QuotePackOrder ... */}
</Accordion>
```

---

## 🎨 Дизайн

### Цвета иконок

```
Quotes:          🔵 text-blue-500
QuotePacks:      🟢 text-green-500
QuoteDetails:    🟣 text-purple-500
QuotePackOrder:  🟠 text-orange-500
```

---

### Badge с количеством полей

```tsx
<Badge variant="outline" className="ml-2 text-xs">
  {Object.keys(schema.after).length} fields
</Badge>
```

**Примеры:**
```
Quotes:          52 fields
QuotePacks:      32 fields
QuoteDetails:    48 fields
QuotePackOrder:  13 fields
```

---

### JSON Display

```tsx
<div className="rounded-md border bg-muted/30 p-3 mt-2">
  <pre className="text-xs overflow-x-auto">
    {JSON.stringify(schema, null, 2)}
  </pre>
</div>
```

**Стиль:**
- `bg-muted/30` - слегка затемнённый фон
- `text-xs` - маленький шрифт для JSON
- `overflow-x-auto` - горизонтальный скролл при необходимости
- `border` - граница вокруг
- Pretty print с отступами (indent = 2)

---

## 📱 Responsive

### Dialog Size

```tsx
<DialogContent className="max-w-4xl max-h-[85vh] overflow-y-auto">
```

**Параметры:**
- `max-w-4xl` - ширина до 896px (больше чем раньше, чтобы JSON помещался)
- `max-h-[85vh]` - высота до 85% экрана
- `overflow-y-auto` - вертикальный скролл при необходимости

---

### Mobile

```
Desktop:
- Ширина: 896px
- Высота: 85vh
- JSON в одну строку

Mobile:
- Ширина: ~100% экрана с отступами
- Высота: 85vh
- JSON с горизонтальным скроллом
```

---

## 🔄 Будущие улучшения

### 1. API Integration

**Сейчас:**
```tsx
const mockDataCaptureSchemas = { ... }; // Hardcoded
```

**Будет:**
```tsx
const [schemas, setSchemas] = useState([]);

useEffect(() => {
  fetchDataCaptureSchemas(dataSourceId).then(setSchemas);
}, [dataSourceId]);
```

---

### 2. Dynamic Schemas

```tsx
// Вместо 4 фиксированных схем:
{schemas.map(schema => (
  <AccordionItem key={schema.name} value={schema.name}>
    <AccordionTrigger>
      {schema.name}
      <Badge>{schema.fieldCount} fields</Badge>
    </AccordionTrigger>
    <AccordionContent>
      <pre>{JSON.stringify(schema.data, null, 2)}</pre>
    </AccordionContent>
  </AccordionItem>
))}
```

---

### 3. Schema Filtering

```tsx
// Поиск по полям
<Input 
  placeholder="Search fields..." 
  onChange={(e) => filterSchemaFields(e.target.value)}
/>
```

---

### 4. Field Details

**Сейчас:** Только JSON view

**Будет:** Таблица с деталями каждого поля

```
┌────────────────┬─────────┬──────────┬──────────────┐
│ Field Name     │ Type    │ Nullable │ Description  │
├────────────────┼─────────┼──────────┼──────────────┤
│ QuoteId        │ int     │ No       │ Primary key  │
│ CustomerId     │ int     │ No       │ Customer ref │
│ IsPublished    │ boolean │ No       │ Publish flag │
│ ...            │ ...     │ ...      │ ...          │
└────────────────┴─────────┴──────────┴──────────────┘
```

---

### 5. Export Schema

```tsx
<Button 
  variant="outline" 
  size="sm"
  onClick={() => exportSchemaAsJSON(schema)}
>
  <Download className="h-4 w-4 mr-2" />
  Export Schema
</Button>
```

---

## 🧪 Тестирование

### Шаги

1. **Открыть Data Source Onboarding**
   ```
   App → Data Source Onboarding tab
   ```

2. **Нажать View на Bidtools**
   ```
   Bidtools row → View button
   ```

3. **Проверить Basic Information**
   ```
   ✅ Data Source ID видно
   ✅ Name = Bidtools
   ✅ Type = SQL Database
   ✅ Status = Active
   ```

4. **Проверить Data Capture Schemas секцию**
   ```
   ✅ Заголовок "Data Capture Schemas"
   ✅ Описание "Schema definitions..."
   ✅ 4 accordion items
   ```

5. **Развернуть Quotes**
   ```
   ✅ Database icon (синий)
   ✅ Badge "52 fields"
   ✅ JSON отображается
   ✅ Форматирование (pretty print)
   ```

6. **Развернуть QuotePacks**
   ```
   ✅ Database icon (зелёный)
   ✅ Badge "32 fields"
   ✅ JSON отображается
   ```

7. **Развернуть QuoteDetails**
   ```
   ✅ Database icon (фиолетовый)
   ✅ Badge "48 fields"
   ✅ JSON отображается
   ```

8. **Развернуть QuotePackOrder**
   ```
   ✅ Database icon (оранжевый)
   ✅ Badge "13 fields"
   ✅ JSON отображается
   ```

9. **Проверить accordion поведение**
   ```
   ✅ Только один item открыт одновременно
   ✅ Можно закрыть все
   ✅ Smooth анимация
   ```

10. **Проверить responsive**
    ```
    ✅ Desktop: Dialog 896px width
    ✅ Mobile: Dialog занимает почти весь экран
    ✅ JSON имеет горизонтальный скролл
    ✅ Vertical scroll работает
    ```

---

## ✅ Что сделано

### Изменения в `/components/DataSourcesView.tsx`

1. **Добавлены импорты:**
   ```tsx
   import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from './ui/accordion';
   import { Separator } from './ui/separator';
   ```

2. **Добавлены mock данные:**
   ```tsx
   const mockDataCaptureSchemas = {
     Quotes: { ... },
     QuotePacks: { ... },
     QuoteDetails: { ... },
     QuotePackOrder: { ... }
   };
   ```

3. **Обновлён Detail Dialog:**
   - Увеличена ширина: `max-w-4xl` (было `max-w-2xl`)
   - Увеличена высота: `max-h-[85vh]` (было `max-h-[80vh]`)
   - Добавлена секция "Basic Information"
   - Добавлен Separator
   - Добавлена секция "Data Capture Schemas" с Accordion

4. **Добавлен Accordion с 4 схемами:**
   - Quotes (blue)
   - QuotePacks (green)
   - QuoteDetails (purple)
   - QuotePackOrder (orange)

5. **Каждая схема имеет:**
   - Database icon с цветом
   - Название схемы
   - Badge с количеством полей
   - JSON content в `<pre>` с pretty print

---

## 📊 Статистика

### Размеры схем

```
Quotes:          52 fields
QuotePacks:      32 fields  
QuoteDetails:    48 fields
QuotePackOrder:  13 fields

Total:           145 fields
```

---

### Структура данных

```
Each schema:
  ├─ before: null
  ├─ after: { ... fields ... }
  ├─ source: { connector, table, version, ... }
  ├─ transaction: null
  ├─ op: "r" (read operation)
  └─ timestamps: { ts_ms, ts_us, ts_ns }
```

---

## 🎯 Итого

**Добавлено:**
```
✅ Data Capture Schemas секция в Detail Dialog
✅ Accordion с 4 схемами
✅ Mock данные для всех 4 схем
✅ Красивое отображение JSON
✅ Badge с количеством полей
✅ Цветные иконки для каждой схемы
✅ Responsive dialog (max-w-4xl)
✅ Separator между секциями
```

**Функциональность:**
```
✅ View Data Source → See schemas
✅ Expand/collapse any schema
✅ Only one schema open at a time
✅ Pretty-printed JSON
✅ Horizontal scroll for long lines
✅ Field count badges
```

**Готово к:**
```
✅ Тестированию пользователем
✅ API интеграции (в будущем)
✅ Добавлению новых схем
✅ Расширению функциональности
```

---

**Статус:** ✅ Готово  
**Дата:** 3 ноября 2025  
**Файл:** `/components/DataSourcesView.tsx`

Data Capture Schemas теперь доступны в Data Source Onboarding! 🎉
