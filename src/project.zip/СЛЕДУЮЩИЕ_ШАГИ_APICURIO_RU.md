# Следующие шаги - Интеграция Apicurio с Data Plane

## 🎯 Текущее состояние

✅ **Завершено:**
- Очистка `getApicurioArtifactContent()` от mock данных
- Все Apicurio функции работают с реальным v3 API
- Data Source Onboarding может загружать схемы из Apicurio
- Data Capture Specifications могут создаваться с предзаполнением из Apicurio схем

⏳ **В ожидании:**
- Интеграция Data Capture Specs → Transaction Types в Data Plane
- Валидация транзакций по схемам из Apicurio
- CORS конфигурация на Apicurio Registry

---

## 📋 План дальнейшей разработки

### Phase 1: Тестирование текущей интеграции (1-2 дня)

#### 1.1 Проверка CORS конфигурации

**Задача:** Убедиться что Apicurio Registry доступен из браузера

**Действия:**
```bash
# Тест 1: Проверить CORS headers
curl -I https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/search/artifacts

# Должны быть headers:
# Access-Control-Allow-Origin: *
# или
# Access-Control-Allow-Origin: https://your-app-domain.com

# Тест 2: Проверить из браузера Console
fetch('https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/search/artifacts?name=Value')
  .then(r => r.json())
  .then(d => console.log('✅ Success:', d.count, 'artifacts'))
  .catch(e => console.error('❌ CORS Error:', e));
```

**Если CORS ошибка:**
- См. `/APICURIO-CORS-SOLUTION.md` для решений
- Временно можно использовать browser extension (только dev!)
- Production: настроить CORS на Apicurio или использовать backend proxy

#### 1.2 Тестирование Data Capture Spec Creation

**Сценарий:**
1. Открыть Data Source Onboarding
2. Найти data source (например BFS.online)
3. Нажать "Add Specification"
4. Дождаться загрузки схем из Apicurio
5. Выбрать схему из dropdown
6. Проверить auto-fill полей формы
7. Создать спецификацию
8. Проверить что сохранилось в БД

**Ожидаемый результат:**
- ✅ Схемы загружаются из Apicurio (не mock)
- ✅ Форма заполняется автоматически
- ✅ Data Capture Spec сохраняется с containerSchema
- ✅ Видны в таблице Data Capture Specifications

**Проверить в консоли:**
```
📡 Fetching schemas for data source: BFS.online (v3 API)...
  URL: https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/search/artifacts?name=BFS.online
✅ Found X schemas (JSON + AVRO) for BFS.online
📡 Fetching Apicurio artifact content (v3 API): {artifactId}
✅ Fetched schema for {artifactId}
```

#### 1.3 Документирование результатов

**Создать отчет:**
- Какие артефакты успешно загружаются
- Какие схемы работают для auto-fill
- Какие проблемы обнаружены
- Screenshots для User Story 2 verification

---

### Phase 2: Data Plane Integration (3-5 дней)

#### 2.1 Архитектура синхронизации

**Концепция:**
```
Data Source Onboarding (создание)
        ↓
Data Capture Specification
    - dataCaptureSpecId
    - dataCaptureSpecName
    - containerSchema (из Apicurio)
    - dataSourceId
    - tenantId
        ↓
Автоматическая синхронизация
        ↓
Data Plane (Transaction Type)
    - TxnType = dataCaptureSpecName
    - JsonSchema = containerSchema
    - Metadata ссылается на Data Capture Spec
```

**Варианты реализации:**

**Вариант A: Transaction Types как представление**
```typescript
// В Data Plane показываем Data Capture Specs как Transaction Types
interface TransactionTypeFromDataCapture {
  TxnType: string; // dataCaptureSpecName
  source: 'DataCaptureSpec';
  dataCaptureSpecId: string;
  jsonSchema: any; // containerSchema из spec
  tenantId: string;
  dataSourceId: string;
}

// Объединяем с реальными ModelSchemas
const allTransactionTypes = [
  ...modelSchemas.map(toTransactionType),
  ...dataCaptureSpecs.map(toTransactionTypeFromDataCapture)
];
```

**Вариант B: Создание ModelSchema при создании Data Capture Spec**
```typescript
// При создании Data Capture Spec автоматически создаем ModelSchema
async function createDataCaptureSpec(spec: DataCaptureSpec) {
  // 1. Сохранить Data Capture Spec
  const savedSpec = await saveToCosmosDB(spec);
  
  // 2. Автоматически создать ModelSchema
  const modelSchema: ModelSchema = {
    id: `${spec.dataCaptureSpecName}:1`,
    model: spec.dataCaptureSpecName,
    version: 1,
    state: 'active',
    semver: '1.0.0',
    jsonSchema: spec.containerSchema, // Схема из Apicurio
    profile: 'data-capture',
    // metadata
    dataCaptureSpecId: savedSpec.dataCaptureSpecId,
    tenantId: spec.tenantId,
    dataSourceId: spec.dataSourceId
  };
  
  // 3. Сохранить как Transaction с TxnType=ModelSchema
  await createTransaction({
    TxnType: 'ModelSchema',
    Txn: modelSchema
  });
  
  return savedSpec;
}
```

**Рекомендация:** Начать с **Варианта B** - более чистая архитектура и консистентность данных.

#### 2.2 Изменения в API

**Файл:** `/lib/api.ts`

**Добавить:**
```typescript
// Create ModelSchema from Data Capture Spec
export async function createModelSchemaFromDataCaptureSpec(
  spec: DataCaptureSpec
): Promise<ModelSchema> {
  const modelSchema: ModelSchema = {
    id: `${spec.dataCaptureSpecName}:1`,
    model: spec.dataCaptureSpecName,
    version: 1,
    state: 'active',
    semver: '1.0.0',
    jsonSchema: spec.containerSchema,
    profile: 'data-capture',
    CreateTime: new Date().toISOString(),
    UpdateTime: new Date().toISOString()
  };
  
  // Save as Transaction with TxnType=ModelSchema
  await createTransaction({
    TxnType: 'ModelSchema',
    Txn: modelSchema
  });
  
  return modelSchema;
}

// Update createDataCaptureSpec to auto-create ModelSchema
export async function createDataCaptureSpec(
  spec: DataCaptureSpec
): Promise<DataCaptureSpec> {
  // 1. Create Data Capture Spec (existing code)
  const response = await fetch(...);
  const savedSpec = await response.json();
  
  // 2. Auto-create ModelSchema
  try {
    await createModelSchemaFromDataCaptureSpec(savedSpec);
    console.log('✅ Auto-created ModelSchema for', savedSpec.dataCaptureSpecName);
  } catch (error) {
    console.warn('⚠️ Failed to create ModelSchema:', error);
    // Don't fail the entire operation
  }
  
  return savedSpec;
}
```

#### 2.3 UI изменения

**Файл:** `/components/ModelSchemaView.tsx` (Data Plane)

**Добавить badge для schemas из Data Capture:**
```tsx
<Badge variant={schema.profile === 'data-capture' ? 'secondary' : 'default'}>
  {schema.profile === 'data-capture' ? '📊 Data Capture' : 'Manual'}
</Badge>
```

**Показать metadata:**
```tsx
{schema.profile === 'data-capture' && (
  <div className="text-sm text-gray-500">
    <div>Source: Data Capture Spec</div>
    <div>Data Source ID: {schema.dataSourceId}</div>
    <div>Spec ID: {schema.dataCaptureSpecId}</div>
  </div>
)}
```

**Защита от редактирования:**
```tsx
const canEdit = schema.profile !== 'data-capture';
const canDelete = schema.profile !== 'data-capture';

// Disable edit/delete buttons for data-capture schemas
<Button disabled={!canEdit}>Edit</Button>
<Button disabled={!canDelete}>Delete</Button>
```

#### 2.4 Тестирование

**Сценарий:**
1. Создать Data Capture Spec из Apicurio схемы
2. Проверить что ModelSchema создался автоматически
3. Перейти в Data Plane → Model Schema
4. Увидеть новый Transaction Type с badge "📊 Data Capture"
5. Попытаться отредактировать - кнопка должна быть disabled
6. Проверить что схема валидная (можно создавать транзакции)

**Проверить:**
- ✅ Data Capture Spec → ModelSchema синхронизация работает
- ✅ Badge отображается корректно
- ✅ Защита от редактирования работает
- ✅ JSON Schema валидная и готова для валидации транзакций

---

### Phase 3: Валидация транзакций (2-3 дня)

#### 3.1 Добавить JSON Schema Validator

**Установить библиотеку:**
```typescript
import Ajv from "ajv"; // JSON Schema validator
```

**Добавить в `/lib/api.ts`:**
```typescript
import Ajv from 'ajv';

// Validate transaction data against schema
export function validateTransactionAgainstSchema(
  txnData: any,
  jsonSchema: any
): { valid: boolean; errors: any[] } {
  const ajv = new Ajv({ allErrors: true });
  const validate = ajv.compile(jsonSchema);
  const valid = validate(txnData);
  
  return {
    valid,
    errors: validate.errors || []
  };
}
```

#### 3.2 Интегрировать валидацию в Transaction Create

**Файл:** `/components/TransactionCreateDialog.tsx`

**Добавить валидацию перед сохранением:**
```typescript
const handleCreate = async () => {
  // 1. Get schema for selected TxnType
  const modelSchema = modelSchemas.find(s => s.model === selectedTxnType);
  
  if (modelSchema?.jsonSchema) {
    // 2. Validate transaction data
    const validation = validateTransactionAgainstSchema(
      transactionData,
      modelSchema.jsonSchema
    );
    
    if (!validation.valid) {
      // 3. Show validation errors
      toast.error('Transaction validation failed');
      console.error('Validation errors:', validation.errors);
      setValidationErrors(validation.errors);
      return; // Don't save invalid transaction
    }
  }
  
  // 4. Save transaction (existing code)
  await createTransaction({
    TxnType: selectedTxnType,
    Txn: transactionData
  });
  
  toast.success('Transaction created successfully');
};
```

#### 3.3 UI для отображения ошибок валидации

**Добавить в форму:**
```tsx
{validationErrors.length > 0 && (
  <Alert variant="destructive">
    <AlertTitle>Validation Errors</AlertTitle>
    <AlertDescription>
      <ul className="list-disc pl-4">
        {validationErrors.map((err, idx) => (
          <li key={idx}>
            <span className="font-medium">{err.instancePath}</span>: {err.message}
          </li>
        ))}
      </ul>
    </AlertDescription>
  </Alert>
)}
```

#### 3.4 Тестирование валидации

**Сценарий позитивный:**
1. Создать Data Capture Spec с QuoteDetails схемой
2. Перейти в Data Plane
3. Создать новую транзакцию типа "QuoteDetails"
4. Заполнить все required поля корректно
5. Сохранить
6. ✅ Транзакция создается успешно

**Сценарий негативный:**
1. Создать транзакцию типа "QuoteDetails"
2. Пропустить required поле (например, `quoteId`)
3. Попытаться сохранить
4. ❌ Валидация должна остановить сохранение
5. ✅ Показать ошибку: "quoteId: must have required property 'quoteId'"
6. Исправить ошибку
7. ✅ Сохранение успешно

---

### Phase 4: Расширенные функции (опционально, 3-5 дней)

#### 4.1 Bulk Import из Apicurio

**Функция:**
- Импортировать несколько схем из Apicurio одновременно
- Создать Data Capture Specs для всех
- Автоматически создать ModelSchemas

**UI:**
```tsx
<Dialog>
  <DialogTitle>Bulk Import from Apicurio</DialogTitle>
  <DialogContent>
    {/* Показать все доступные артефакты */}
    {apicurioArtifacts.map(artifact => (
      <Checkbox key={artifact.artifactId}>
        {artifact.name || artifact.artifactId}
      </Checkbox>
    ))}
    
    <Button onClick={handleBulkImport}>
      Import Selected ({selectedCount})
    </Button>
  </DialogContent>
</Dialog>
```

#### 4.2 Schema Version Management

**Функция:**
- Поддержка нескольких версий одной схемы
- Миграция между версиями
- Backward compatibility

**Структура:**
```typescript
interface DataCaptureSpec {
  // ... existing fields
  version: number; // Schema version (1, 2, 3...)
  previousVersionId?: string; // Link to previous version
  schemaVersionHistory: {
    version: number;
    createdAt: string;
    changes: string;
    apicurioArtifactId: string;
  }[];
}
```

#### 4.3 Schema Registry UI

**Функция:**
- Отдельная вкладка "Schema Registry"
- Просмотр всех схем из Apicurio
- Сравнение версий
- Управление lifecycle (draft, active, deprecated)

**UI Mock:**
```
+--------------------------------------------------+
| Schema Registry                                   |
+--------------------------------------------------+
| Search: [_________]  Group: [All▼]  Type: [All▼] |
+--------------------------------------------------+
| Name            | Version | Type | Status | Used  |
|-----------------|---------|------|--------|-------|
| QuoteDetails    | 1.2.0   | JSON | Active | 15    |
| CustomerProfile | 2.0.0   | AVRO | Active | 8     |
| Invoice         | 1.0.0   | JSON | Draft  | 0     |
+--------------------------------------------------+
```

#### 4.4 Real-time Sync с Apicurio

**Функция:**
- Webhook от Apicurio при обновлении схемы
- Автоматическое обновление Data Capture Specs
- Уведомления о breaking changes

**Flow:**
```
Apicurio Schema Updated
        ↓
Webhook → Backend
        ↓
Update Data Capture Spec
        ↓
Check for breaking changes
        ↓
If breaking: Notify users
If compatible: Auto-update
```

---

## 🎯 Prioritized Roadmap

### Week 1: Foundation
- [x] ✅ Очистка mock данных
- [ ] ⏳ CORS конфигурация и тестирование
- [ ] ⏳ Полное тестирование Data Capture Spec creation

### Week 2: Core Integration
- [ ] 🎯 Автоматическое создание ModelSchema из Data Capture Spec
- [ ] 🎯 UI обновления в Data Plane
- [ ] 🎯 Тестирование синхронизации

### Week 3: Validation
- [ ] 🎯 Интеграция JSON Schema validator
- [ ] 🎯 UI для отображения ошибок валидации
- [ ] 🎯 End-to-end тестирование

### Week 4: Polish & Testing
- [ ] 🔧 Bug fixes
- [ ] 🔧 Performance optimization
- [ ] 🔧 Documentation updates
- [ ] 🔧 User acceptance testing

### Future (Optional)
- [ ] 💡 Bulk Import
- [ ] 💡 Version Management
- [ ] 💡 Schema Registry UI
- [ ] 💡 Real-time Sync

---

## ✅ Success Criteria

### Минимальные требования (MVP):
- ✅ Data Capture Specs создаются из Apicurio схем
- ✅ Автоматически становятся Transaction Types в Data Plane
- ✅ Можно создавать транзакции с этими типами
- ✅ Базовая валидация работает

### Расширенные требования:
- ✅ Версионирование схем
- ✅ Bulk operations
- ✅ Advanced validation с детальными ошибками
- ✅ Real-time sync с Apicurio

### Production Ready:
- ✅ CORS настроен
- ✅ Error handling complete
- ✅ Comprehensive testing
- ✅ Documentation complete
- ✅ Performance acceptable
- ✅ Security audit passed

---

## 📞 Что делать при блокерах

### Блокер: CORS не работает

**Временное решение:**
- Browser extension для dev (CORS Unblock)
- Backend proxy endpoint

**Долгосрочное решение:**
- Настроить CORS на Apicurio Registry
- Или всегда использовать backend proxy

### Блокер: Apicurio недоступен

**Решение:**
- Добавить health check для Apicurio
- Graceful degradation в UI (показать ручной ввод)
- Кэширование схем в localStorage

### Блокер: Схемы в неправильном формате

**Решение:**
- Добавить schema transformation layer
- Документировать требования к формату
- Валидация при импорте

---

## 📝 Вопросы для принятия решений

### 1. Автоматическое создание ModelSchema - когда?

**Вариант A:** При создании Data Capture Spec  
**Вариант B:** Отложенно (по требованию)  
**Вариант C:** Ручная синхронизация (кнопка "Sync to Data Plane")

**Рекомендация:** Вариант A - проще для пользователя

### 2. Что делать при обновлении схемы в Apicurio?

**Вариант A:** Ручное обновление через UI  
**Вариант B:** Автоматическая проверка и уведомление  
**Вариант C:** Webhook real-time sync

**Рекомендация:** Начать с A, потом добавить B

### 3. Можно ли редактировать Data Capture Specs?

**Вариант A:** Да, с версионированием  
**Вариант B:** Нет, только создание новой версии  
**Вариант C:** Да, с проверкой breaking changes

**Рекомендация:** Вариант C - баланс между гибкостью и безопасностью

### 4. Что делать со старыми Transaction Types не из Apicurio?

**Вариант A:** Оставить как есть (backward compatibility)  
**Вариант B:** Миграция на схемы из Apicurio  
**Вариант C:** Dual mode - поддержка обоих вариантов

**Рекомендация:** Вариант C - не ломать существующие транзакции

---

## 🎉 Финальная цель

**Complete Flow:**
```
1. Admin создает схему в Apicurio Registry
        ↓
2. Developer импортирует в Data Source Onboarding
        ↓
3. Создается Data Capture Specification
        ↓
4. Автоматически появляется Transaction Type в Data Plane
        ↓
5. Users могут создавать транзакции с валидацией по схеме
        ↓
6. Данные сохраняются в Cosmos DB с правильной структурой
        ↓
7. Transaction Types изолированы по тенантам
        ↓
8. Global tenant видит все, остальные - только свои
```

**User Experience:**
- ✅ Простое создание новых типов транзакций
- ✅ Автоматическая валидация данных
- ✅ Централизованное управление схемами
- ✅ Версионирование и миграция
- ✅ Полная изоляция между тенантами

---

**Следующее действие:** Начать с Phase 1 - CORS тестирование и валидация текущей интеграции.

**ETA до MVP:** 2-3 недели при полной занятости на проекте.

**Дата создания:** 27 ноября 2025
