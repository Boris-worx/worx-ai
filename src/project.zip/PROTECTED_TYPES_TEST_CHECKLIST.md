# Protected Types - Test Checklist

## 🧪 Тестовый Чеклист

### Pre-Test Setup
- [ ] Приложение запущено (`npm run dev`)
- [ ] Пользователь залогинен
- [ ] Открыта вкладка "Global Transaction Spec"
- [ ] В списке есть Customer и Location
- [ ] В списке есть хотя бы один другой тип (например, Invoice, Product)

---

## ✅ Desktop Tests

### Test 1: Visual Indicators - Customer
- [ ] Открыть вкладку "Global Transaction Spec"
- [ ] Найти запись с типом "Customer"
- [ ] ✅ Рядом с "Customer" отображается иконка замка 🔒
- [ ] ✅ Иконка замка серого цвета (muted-foreground)
- [ ] ✅ Иконка правильно выровнена с текстом

**Expected Result:** Lock icon видна рядом с Customer

---

### Test 2: Visual Indicators - Location
- [ ] Найти запись с типом "Location"
- [ ] ✅ Рядом с "Location" отображается иконка замка 🔒
- [ ] ✅ Иконка замка серого цвета (muted-foreground)
- [ ] ✅ Иконка правильно выровнена с текстом

**Expected Result:** Lock icon видна рядом с Location

---

### Test 3: Visual Indicators - Other Types
- [ ] Найти запись с другим типом (Invoice, Product, etc.)
- [ ] ✅ Иконка замка НЕ отображается
- [ ] ✅ Только название типа без дополнительных индикаторов

**Expected Result:** Lock icon НЕ видна для обычных типов

---

### Test 4: Lock Icon Tooltip - Customer
- [ ] Навести курсор на Lock icon рядом с Customer
- [ ] ✅ Tooltip появляется сразу (delay 0ms)
- [ ] ✅ Текст: "Protected system type - cannot be edited or deleted"
- [ ] ✅ Tooltip темного цвета (primary background)
- [ ] ✅ Tooltip позиционируется корректно

**Expected Result:** Tooltip показывается с правильным текстом

---

### Test 5: Lock Icon Tooltip - Location
- [ ] Навести курсор на Lock icon рядом с Location
- [ ] ✅ Tooltip появляется
- [ ] ✅ Текст такой же как для Customer

**Expected Result:** Tooltip показывается одинаково

---

### Test 6: Edit Button - Customer
- [ ] Найти кнопку "Edit" для Customer
- [ ] ✅ Кнопка отображается в disabled состоянии
- [ ] ✅ Кнопка серого цвета
- [ ] ✅ Курсор меняется на "not-allowed" при hover
- [ ] ✅ Кнопка НЕ кликается

**Expected Result:** Edit button disabled для Customer

---

### Test 7: Edit Button Tooltip - Customer
- [ ] Навести курсор на disabled Edit кнопку для Customer
- [ ] ✅ Tooltip появляется
- [ ] ✅ Текст: "Protected system type - cannot be edited"
- [ ] ✅ Tooltip позиционируется корректно

**Expected Result:** Tooltip объясняет почему Edit disabled

---

### Test 8: Delete Button - Customer
- [ ] Найти кнопку "Delete" для Customer
- [ ] ✅ Кнопка отображается в disabled состоянии
- [ ] ✅ Кнопка серого цвета
- [ ] ✅ Курсор меняется на "not-allowed" при hover
- [ ] ✅ Кнопка НЕ кликается

**Expected Result:** Delete button disabled для Customer

---

### Test 9: Delete Button Tooltip - Customer
- [ ] Навести курсор на disabled Delete кнопку для Customer
- [ ] ✅ Tooltip появляется
- [ ] ✅ Текст: "Protected system type - cannot be deleted"
- [ ] ✅ Tooltip позиционируется корректно

**Expected Result:** Tooltip объясняет почему Delete disabled

---

### Test 10: View Button - Customer
- [ ] Найти кнопку "View" для Customer
- [ ] ✅ Кнопка активна (НЕ disabled)
- [ ] ✅ Кнопка кликается
- [ ] Нажать на "View"
- [ ] ✅ Открывается диалог с деталями Customer schema

**Expected Result:** View работает нормально для Customer

---

### Test 11: All Buttons - Location
- [ ] Повторить Tests 6-10 для Location
- [ ] ✅ Edit disabled с tooltip
- [ ] ✅ Delete disabled с tooltip
- [ ] ✅ View работает

**Expected Result:** Location ведет себя так же как Customer

---

### Test 12: All Buttons - Other Types
- [ ] Найти запись с другим типом (Invoice, etc.)
- [ ] ✅ Edit кнопка АКТИВНА
- [ ] ✅ Delete кнопка АКТИВНА
- [ ] ✅ View кнопка АКТИВНА
- [ ] ✅ Все кнопки кликаются
- [ ] ✅ НЕТ disabled tooltips

**Expected Result:** Обычные типы полностью функциональны

---

## 📱 Mobile/Tablet Tests

### Test 13: Mobile View - Visual Check
- [ ] Уменьшить ширину окна до mobile (<768px)
- [ ] ✅ Lock icon отображается для Customer
- [ ] ✅ Lock icon отображается для Location
- [ ] ✅ Lock icon НЕ отображается для других типов
- [ ] ✅ Иконки правильно масштабируются

**Expected Result:** Lock icons видны на mobile

---

### Test 14: Mobile View - Compact Buttons
- [ ] На mobile view кнопки отображаются как icons
- [ ] ✅ View icon активен для Customer
- [ ] ✅ Edit icon disabled для Customer
- [ ] ✅ Delete icon disabled для Customer
- [ ] ✅ Disabled icons имеют правильный стиль (h-8 w-8)

**Expected Result:** Compact buttons работают правильно

---

### Test 15: Mobile View - Tooltips
- [ ] Попробовать нажать/hover на Lock icon
- [ ] ✅ Tooltip показывается (если поддерживается на mobile)
- [ ] Попробовать нажать на disabled Edit icon
- [ ] ✅ Tooltip показывается (если поддерживается)

**Expected Result:** Tooltips доступны на mobile

---

## 🎭 Role-Based Tests

### Test 16: SuperUser Role
- [ ] Залогиниться как SuperUser
- [ ] ✅ Customer/Location показывают Lock icon
- [ ] ✅ Edit/Delete disabled для Customer/Location
- [ ] ✅ Edit/Delete активны для других типов

**Expected Result:** Защита работает для всех ролей

---

### Test 17: Admin Role
- [ ] Залогиниться как Admin
- [ ] ✅ Результат такой же как для SuperUser

**Expected Result:** Admin видит такую же защиту

---

### Test 18: Developer Role
- [ ] Залогиниться как Developer
- [ ] ✅ Результат такой же как для SuperUser

**Expected Result:** Developer видит такую же защиту

---

### Test 19: Viewer Role
- [ ] Залогиниться как Viewer
- [ ] ✅ Edit/Delete скрыты для ВСЕХ типов (permission-based)
- [ ] ✅ View работает для всех типов
- [ ] ✅ Lock icon все равно отображается для Customer/Location

**Expected Result:** Viewer не видит Edit/Delete вообще

---

## 🔍 Edge Cases

### Test 20: Empty State
- [ ] Удалить все схемы (если возможно в тестовом окружении)
- [ ] ✅ Empty state отображается правильно
- [ ] Добавить только Customer
- [ ] ✅ Lock icon появляется
- [ ] ✅ Edit/Delete disabled

**Expected Result:** Защита работает с одной записью

---

### Test 21: Case Sensitivity
- [ ] Создать схему с именем "customer" (lowercase)
- [ ] ✅ Lock icon НЕ отображается (проверка case-sensitive)
- [ ] ✅ Edit/Delete активны
- [ ] Переименовать в "Customer" (если возможно)
- [ ] ✅ Lock icon появляется

**Expected Result:** Проверка чувствительна к регистру

---

### Test 22: Multiple Versions
- [ ] Если есть Customer v1 и Customer v2
- [ ] ✅ Lock icon показывается для обеих версий
- [ ] ✅ Edit/Delete disabled для обеих версий

**Expected Result:** Защита работает для всех версий типа

---

### Test 23: Refresh Behavior
- [ ] Нажать кнопку "Refresh"
- [ ] ✅ После перезагрузки Lock icons остаются
- [ ] ✅ Disabled состояния сохраняются

**Expected Result:** Состояние не сбрасывается при refresh

---

### Test 24: Column Selector
- [ ] Открыть Column Selector
- [ ] Отключить колонку "Model"
- [ ] ✅ Lock icon пропадает (колонка скрыта)
- [ ] Включить колонку "Model" обратно
- [ ] ✅ Lock icon появляется снова

**Expected Result:** Lock icon привязан к колонке Model

---

## 🐛 Bug Scenarios

### Test 25: Rapid Clicking
- [ ] Быстро кликать на disabled Edit кнопку
- [ ] ✅ Ничего не происходит
- [ ] ✅ Нет ошибок в консоли
- [ ] ✅ Tooltip ведет себя нормально

**Expected Result:** Нет багов при rapid clicking

---

### Test 26: Browser DevTools
- [ ] Открыть DevTools
- [ ] Попробовать forcefully enable кнопку через HTML
- [ ] Попробовать кликнуть
- [ ] ⚠️ Кнопка может сработать (только UI защита)
- [ ] ✅ Но логика в handler-ах должна блокировать

**Note:** UI защита не должна быть единственной (нужна backend защита)

---

### Test 27: Accessibility - Keyboard Navigation
- [ ] Использовать Tab для навигации
- [ ] ✅ Disabled кнопки получают focus
- [ ] ✅ Tooltip показывается при focus
- [ ] ✅ Enter/Space не активируют disabled кнопки

**Expected Result:** Keyboard navigation работает корректно

---

### Test 28: Accessibility - Screen Reader
- [ ] Использовать screen reader (если доступен)
- [ ] ✅ Disabled состояние объявляется
- [ ] ✅ Tooltip текст читается
- [ ] ✅ Lock icon имеет смысловое значение

**Expected Result:** Доступно для screen readers

---

## 📊 Summary Checks

### Visual Consistency
- [ ] ✅ Lock icon одинаковый размер везде
- [ ] ✅ Tooltips одинаковые по стилю
- [ ] ✅ Disabled кнопки визуально отличаются от активных
- [ ] ✅ Цвета соответствуют дизайн-системе

### Functional Consistency
- [ ] ✅ Все защищенные типы ведут себя одинаково
- [ ] ✅ Desktop и mobile имеют одинаковую логику
- [ ] ✅ Все роли видят одинаковую защиту
- [ ] ✅ Tooltips появляются везде где нужно

### Performance
- [ ] ✅ Нет задержек при рендеринге
- [ ] ✅ Tooltips отзывчивые
- [ ] ✅ useMemo оптимизирует перерисовки
- [ ] ✅ Нет memory leaks

---

## ✅ Final Approval

### Functionality
- [ ] ✅ Customer защищен
- [ ] ✅ Location защищен
- [ ] ✅ Другие типы не защищены
- [ ] ✅ View работает для всех
- [ ] ✅ Edit/Delete blocked для защищенных

### UX
- [ ] ✅ Lock icon понятен
- [ ] ✅ Tooltips информативны
- [ ] ✅ Disabled кнопки очевидны
- [ ] ✅ Нет confusion для пользователей

### Code Quality
- [ ] ✅ Код чистый и читаемый
- [ ] ✅ Нет дублирования
- [ ] ✅ Хорошая структура
- [ ] ✅ Комментарии там где нужно

### Documentation
- [ ] ✅ MODELSCHEMA_PROTECTED_TYPES.md создан
- [ ] ✅ PROTECTED_TYPES_QUICK_RU.md создан
- [ ] ✅ MODELSCHEMA_PROTECTION_SUMMARY.md создан
- [ ] ✅ Этот checklist создан

---

## 🚀 Ready for Production?

### Checklist
- [ ] All tests passed
- [ ] No bugs found
- [ ] Performance is good
- [ ] Accessibility verified
- [ ] Documentation complete
- [ ] Code reviewed
- [ ] Ready to merge

### Sign-Off
- **Tested by:** ________________
- **Date:** ________________
- **Status:** ☐ Approved ☐ Needs work
- **Notes:** ________________

---

**Total Tests:** 28  
**Critical Tests:** 12  
**Nice-to-Have Tests:** 16

**Estimated Testing Time:** 30-45 minutes for full checklist
