# DataSource API with Tenant Filtering

## Summary

Обновил API для работы с DataSources с поддержкой фильтрации по TenantId.

## Changes Made

### 1. Updated DataSource Interface (`/lib/api.ts`)

Добавлены новые поля:
- `DatasourceType?: string | null` - тип data source
- `TenantId?: string` - идентификатор тенанта

```typescript
export interface DataSource {
  DataSourceId?: string;
  DatasourceId?: string;
  DataSourceName?: string;
  DatasourceName?: string;
  DatasourceType?: string | null;
  Type?: string;
  TenantId?: string;  // NEW
  ConnectionString?: string;
  Description?: string;
  Status?: string;
  CreateTime?: string;
  UpdateTime?: string;
  _rid?: string;
  _self?: string;
  _etag?: string;
  _attachments?: string;
  _ts?: number;
}
```

### 2. Updated `getAllDataSources()` Function

Добавлена поддержка фильтрации по TenantId:

```typescript
export async function getAllDataSources(tenantId?: string): Promise<DataSource[]>
```

**Usage Examples:**

```typescript
// Get all data sources (no filter)
const allDataSources = await getAllDataSources();

// Get data sources for specific tenant
const bfsDataSources = await getAllDataSources('BFS');
```

**API Call Format:**
```
GET /1.0/datasources?Filters={"TenantId":"BFS"}
```

### 3. Updated `createDataSource()` Function

Добавлена поддержка TenantId при создании:

```typescript
export async function createDataSource(
  dataSourceName: string,
  tenantId?: string
): Promise<DataSource>
```

**Usage Examples:**

```typescript
// Create data source for specific tenant
const newDataSource = await createDataSource('Informix', 'BFS');

// Create data source without tenant (will be assigned default)
const newDataSource = await createDataSource('AS400');
```

**API Call Format:**
```json
POST /1.0/datasources
{
  "DatasourceName": "AS400",
  "TenantId": "BFS"
}
```

### 4. Updated App.tsx

Добавлена автоматическая перезагрузка DataSources при смене активного тенанта:

```typescript
// Reload data sources when active tenant changes
useEffect(() => {
  if (activeTenantId) {
    refreshDataSources();
  }
}, [activeTenantId]);
```

Обновлена функция `refreshDataSources()`:
- Фильтрует по activeTenantId, если это не 'global'
- Для global tenant загружает все DataSources

## API Examples from Real BFS API

### Get DataSources for Tenant 'BFS'

```bash
curl --location --globoff 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/datasources?Filters={%22TenantId%22%3A%22BFS%22}' \
--header 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
```

**Response:**
```json
{
  "status": {
    "code": 200,
    "message": "Successful"
  },
  "data": {
    "DataSources": [
      {
        "DatasourceId": "datasource_2e24953d-ec54-4e0b-b82e-85c7030d2f5a",
        "DatasourceName": "AS400",
        "DatasourceType": null,
        "TenantId": "BFS",
        "CreateTime": "2025-11-09T01:28:53.779058",
        "UpdateTime": "2025-11-09T01:28:53.779459"
      },
      {
        "DatasourceId": "datasource_6fbfdb6a-ee56-474b-b313-45929186188d",
        "DatasourceName": "Informix",
        "DatasourceType": null,
        "TenantId": "BFS",
        "CreateTime": "2025-11-09T01:23:47.224634",
        "UpdateTime": "2025-11-09T01:23:47.224884"
      }
    ]
  }
}
```

### Create Tenant

```bash
curl --location 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/tenants' \
--header 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
--header 'Content-Type: application/json' \
--data '{
    "TenantId":"BFS",
    "TenantName": "BFS"
}'
```

### Create DataSource

```bash
curl --location 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/datasources' \
--header 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
--header 'Content-Type: application/json' \
--data '{
    "DatasourceName": "AS400",
    "TenantId": "BFS"
}'
```

## Tenant Isolation

### How it Works

1. **Global Tenant ('global')**
   - Загружает все DataSources без фильтра
   - Видит DataSources всех тенантов
   - Доступно только для Portal.SuperUser

2. **Specific Tenant (e.g., 'BFS', 'tenant-100')**
   - Загружает только DataSources с matching TenantId
   - Фильтрация происходит на уровне API
   - Полная изоляция данных между тенантами

### Code Flow

```
User selects tenant → activeTenantId changes → useEffect triggers
                                                      ↓
                                         refreshDataSources() called
                                                      ↓
                                   getAllDataSources(tenantId?) called
                                                      ↓
                         API: GET /datasources?Filters={"TenantId":"BFS"}
                                                      ↓
                                    DataSources filtered by tenant
                                                      ↓
                                         UI shows only tenant data
```

## Future Enhancements

Планируется добавить в API response информацию о Tenant, чтобы не делать дополнительные запросы:

```json
{
  "status": {...},
  "data": {
    "DataSources": [...],
    "Tenants": {
      "BFS": {
        "TenantId": "BFS",
        "TenantName": "BFS"
      }
    }
  }
}
```

## Testing

1. **Test Global Tenant**
   ```typescript
   // Should load all DataSources
   setActiveTenantId('global');
   ```

2. **Test Specific Tenant**
   ```typescript
   // Should load only BFS DataSources
   setActiveTenantId('BFS');
   ```

3. **Test Tenant Switching**
   ```typescript
   // Should reload DataSources each time
   setActiveTenantId('BFS');
   setActiveTenantId('tenant-100');
   setActiveTenantId('global');
   ```

## Related Files

- `/lib/api.ts` - API functions
- `/App.tsx` - DataSource loading logic
- `/components/DataSourcesView.tsx` - DataSource UI

## API Reference

### Three Main APIs

1. **Tenants API**
   - `GET /1.0/tenants` - Get all tenants
   - `POST /1.0/tenants` - Create tenant

2. **DataSources API**  
   - `GET /1.0/datasources` - Get all data sources
   - `GET /1.0/datasources?Filters={"TenantId":"BFS"}` - Get filtered
   - `POST /1.0/datasources` - Create data source
   - `DELETE /1.0/datasources/{id}` - Delete data source

3. **Transactions API**
   - `GET /1.0/txns?TxnType=ModelSchema` - Get transactions by type
   - `POST /1.0/txns` - Create transaction
   - `DELETE /1.0/txns/{id}` - Delete transaction
