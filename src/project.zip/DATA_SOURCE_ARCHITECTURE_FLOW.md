# Data Source Architecture & Flow Diagrams

## 🏗️ Архитектура Data Source Onboarding

```
┌─────────────────────────────────────────────────────────────────────┐
│                     MANAGEMENT PORTAL (React UI)                     │
│                                                                      │
│  ┌─────────────┐  ┌──────────────┐  ┌─────────────┐  ┌───────────┐ │
│  │   Tenants   │  │ Transactions │  │Data Sources │  │Data Plane │ │
│  │             │  │              │  │             │  │           │ │
│  └─────────────┘  └──────────────┘  └─────────────┘  └───────────┘ │
│                                           │                          │
│                                           ▼                          │
│                          ┌─────────────────────────────┐            │
│                          │  Data Capture Specifications│            │
│                          │  (Multiple per Data Source) │            │
│                          └─────────────────────────────┘            │
└────────────────────────────────┬─────────────────────────────────────┘
                                 │
                                 │ X-BFS-Auth
                                 ▼
┌─────────────────────────────────────────────────────────────────────┐
│                         TxServices API                               │
│                 (BFS Transaction Hub Backend)                        │
│                                                                      │
│  GET    /datasources?Filters={"TenantId":"BFS"}                     │
│  POST   /datasources                                                │
│  PUT    /datasources/{id}  (with If-Match: ETag)                   │
│  DELETE /datasources/{id}  (with If-Match: ETag)                   │
│                                                                      │
│  GET    /datacapturespecs?TenantId=BFS&DataSourceId=online         │
│  POST   /datacapturespecs                                           │
│  PUT    /datacapturespecs/{id}                                      │
│  DELETE /datacapturespecs/{id}                                      │
└────────────────────────────────┬─────────────────────────────────────┘
                                 │
                                 ▼
┌─────────────────────────────────────────────────────────────────────┐
│                          Cosmos DB                                   │
│                     (Transaction Hub Storage)                        │
│                                                                      │
│  Container: DataSources                                             │
│  ┌────────────────────────────────────────────────────────────┐    │
│  │ {                                                           │    │
│  │   "DatasourceId": "datasource_abc123",                     │    │
│  │   "DatasourceName": "Online",                              │    │
│  │   "TenantId": "BFS",          ◄─── Partition Key           │    │
│  │   "DatasourceType": "Informix",                            │    │
│  │   "Status": "Active"                                       │    │
│  │ }                                                           │    │
│  └────────────────────────────────────────────────────────────┘    │
│                                                                      │
│  Container: DataCaptureSpecs                                        │
│  ┌────────────────────────────────────────────────────────────┐    │
│  │ {                                                           │    │
│  │   "dataCaptureSpecId": "spec_xyz789",                      │    │
│  │   "dataCaptureSpecName": "Quote",                          │    │
│  │   "tenantId": "BFS",          ◄─── Partition Key           │    │
│  │   "dataSourceId": "datasource_abc123",                     │    │
│  │   "sourcePrimaryKeyField": "quoteId",                      │    │
│  │   "partitionKeyField": "customerId",                       │    │
│  │   "containerSchema": { ... }  ◄─── JSON Schema             │    │
│  │ }                                                           │    │
│  └────────────────────────────────────────────────────────────┘    │
└────────────────────────────────┬─────────────────────────────────────┘
                                 │
                                 │
      ┌──────────────────────────┴──────────────────────────┐
      │                                                      │
      ▼                                                      ▼
┌──────────────────┐                              ┌───────────────────┐
│  ACE (IBM App    │                              │  Apicurio Registry│
│  Connect         │                              │                   │
│  Enterprise)     │                              │  ┌──────────────┐ │
│                  │                              │  │bfs.online    │ │
│  ┌────────────┐  │  Change Data Capture (CDC)  │  │  - Quote     │ │
│  │    CDC     │  │◄─────────────────────────────│  │  - Customer  │ │
│  │  Connector │  │                              │  │  - Invoice   │ │
│  └─────┬──────┘  │                              │  └──────────────┘ │
│        │         │                              │                   │
└────────┼─────────┘                              │  ┌──────────────┐ │
         │                                        │  │paradigm...   │ │
         │                                        │  │bidtools      │ │
         ▼                                        │  │  - Quote     │ │
┌──────────────────┐                              │  │  - Material  │ │
│  Source Systems  │                              │  └──────────────┘ │
│                  │                              └───────────────────┘
│  • Online (Informix)                                     │
│  • Trend (SQL Server)                                    │
│  • SAP (HANA)                                            │
│  • Bidtools (SQL)   ◄────────────────────────────────────┘
│  • Databricks                JSON/AVRO Schemas
│                                                           
└──────────────────┘
```

---

## 🔄 Data Flow для разных тенантов

### Global Tenant (Paradigm)

```
User: Superuser (Global)
activeTenantId: 'global'

┌─────────────────────────────────────────────────────────────┐
│  Step 1: Load Data Sources                                  │
└─────────────────────────────────────────────────────────────┘
                          │
                          ▼
    ┌────────────────────────────────────────────┐
    │  For EACH tenant in tenants:               │
    │  ┌──────────────────────────────────────┐  │
    │  │ GET /datasources?Filters={"TenantId":"BFS"}         │
    │  │ GET /datasources?Filters={"TenantId":"SmithDouglas"}│
    │  │ GET /datasources?Filters={"TenantId":"Meritage"}    │
    │  └──────────────────────────────────────┘  │
    └────────────────────────────────────────────┘
                          │
                          ▼
    ┌────────────────────────────────────────────┐
    │  Combine all results:                      │
    │  allDataSources = [                        │
    │    ...bfsSources,                          │
    │    ...smithDouglasSources,                 │
    │    ...meritageSources                      │
    │  ]                                         │
    └────────────────────────────────────────────┘
                          │
                          ▼
    ┌────────────────────────────────────────────┐
    │  Display in UI:                            │
    │                                            │
    │  Data Sources (All Tenants)                │
    │  ┌──────────────────────────────────────┐  │
    │  │ Online         │ BFS      │ Informix │  │
    │  │ Trend          │ BFS      │ SQL      │  │
    │  │ SAP            │ BFS      │ HANA     │  │
    │  │ Bidtools       │ Global   │ SQL      │  │
    │  │ Databricks     │ Global   │ Cloud    │  │
    │  │ BuilderLink    │ Smith D. │ API      │  │
    │  └──────────────────────────────────────┘  │
    └────────────────────────────────────────────┘
```

### Specific Tenant (BFS)

```
User: Admin (BFS tenant)
activeTenantId: 'BFS' (locked)

┌─────────────────────────────────────────────────────────────┐
│  Step 1: Load Data Sources                                  │
└─────────────────────────────────────────────────────────────┘
                          │
                          ▼
    ┌────────────────────────────────────────────┐
    │  Single API call:                          │
    │  GET /datasources?Filters={"TenantId":"BFS"}│
    └────────────────────────────────────────────┘
                          │
                          ▼
    ┌────────────────────────────────────────────┐
    │  Filter: only BFS data sources             │
    │  allDataSources = bfsSources               │
    └────────────────────────────────────────────┘
                          │
                          ▼
    ┌────────────────────────────────────────────┐
    │  Display in UI:                            │
    │                                            │
    │  Data Sources (BFS Tenant Only)            │
    │  ┌──────────────────────────────────────┐  │
    │  │ Online         │ BFS      │ Informix │  │
    │  │ Trend          │ BFS      │ SQL      │  │
    │  │ SAP            │ BFS      │ HANA     │  │
    │  └──────────────────────────────────────┘  │
    │                                            │
    │  ❌ Cannot see Bidtools (Global)           │
    │  ❌ Cannot see BuilderLink (Smith Douglas) │
    └────────────────────────────────────────────┘
```

---

## 📊 CRUD Operations Flow

### Create Data Source

```
┌─────────────────────────────────────────────────────────────┐
│  User Action: Click "Create Data Source"                    │
└─────────────────────────────────────────────────────────────┘
                          │
                          ▼
    ┌────────────────────────────────────────────┐
    │  Open Dialog:                              │
    │  ┌──────────────────────────────────────┐  │
    │  │ Name: [Online____________]           │  │
    │  │ Tenant: [BFS ▼] ◄─ Auto-selected     │  │
    │  │         if not global user           │  │
    │  │ Type: [Database_________]            │  │
    │  │                                      │  │
    │  │  [Cancel]  [Create]                  │  │
    │  └──────────────────────────────────────┘  │
    └────────────────────────────────────────────┘
                          │
                          ▼
    ┌────────────────────────────────────────────┐
    │  Validation:                               │
    │  ✓ Name not empty                          │
    │  ✓ TenantId selected                       │
    │  ✓ User has permission (not viewer)        │
    │  ✓ If tenant-specific user:                │
    │    tenantId === user.tenantId              │
    └────────────────────────────────────────────┘
                          │
                          ▼
    ┌────────────────────────────────────────────┐
    │  API Call:                                 │
    │  POST /datasources                         │
    │  Headers: {                                │
    │    "X-BFS-Auth": "...",                    │
    │    "Content-Type": "application/json"      │
    │  }                                         │
    │  Body: {                                   │
    │    "DatasourceName": "Online",             │
    │    "TenantId": "BFS",                      │
    │    "DatasourceType": "Database",           │
    │    "Status": "Active"                      │
    │  }                                         │
    └────────────────────────────────────────────┘
                          │
                          ▼
    ┌────────────────────────────────────────────┐
    │  Cosmos DB:                                │
    │  INSERT INTO DataSources                   │
    │  {                                         │
    │    "DatasourceId": "datasource_abc123",    │
    │    "DatasourceName": "Online",             │
    │    "TenantId": "BFS",                      │
    │    "CreateTime": "2025-11-14T10:00:00Z"    │
    │  }                                         │
    └────────────────────────────────────────────┘
                          │
                          ▼
    ┌────────────────────────────────────────────┐
    │  UI Update:                                │
    │  ✅ Add to local state                     │
    │  ✅ Show success toast                     │
    │  ✅ Refresh data from API                  │
    └────────────────────────────────────────────┘
```

### Update Data Source (with ETag)

```
┌─────────────────────────────────────────────────────────────┐
│  User Action: Click "Edit" on a Data Source                 │
└─────────────────────────────────────────────────────────────┘
                          │
                          ▼
    ┌────────────────────────────────────────────┐
    │  Step 1: GET to retrieve current _etag     │
    │  GET /datasources/datasource_abc123        │
    │                                            │
    │  Response:                                 │
    │  {                                         │
    │    "DatasourceId": "datasource_abc123",    │
    │    "DatasourceName": "Online",             │
    │    "TenantId": "BFS",                      │
    │    "_etag": "\"abc-123-xyz\""  ◄─ ВАЖНО!  │
    │  }                                         │
    └────────────────────────────────────────────┘
                          │
                          ▼
    ┌────────────────────────────────────────────┐
    │  User modifies in dialog:                  │
    │  Name: "Online (Primary)" ◄─ Changed       │
    └────────────────────────────────────────────┘
                          │
                          ▼
    ┌────────────────────────────────────────────┐
    │  Step 2: PUT with If-Match header          │
    │  PUT /datasources/datasource_abc123        │
    │  Headers: {                                │
    │    "X-BFS-Auth": "...",                    │
    │    "If-Match": "\"abc-123-xyz\"",  ◄─ ETag│
    │    "Content-Type": "application/json"      │
    │  }                                         │
    │  Body: {                                   │
    │    "DatasourceName": "Online (Primary)",   │
    │    "TenantId": "BFS",                      │
    │    "UpdateTime": "2025-11-14T11:00:00Z"    │
    │  }                                         │
    └────────────────────────────────────────────┘
                          │
                          ▼
    ┌────────────────────────────────────────────┐
    │  Cosmos DB Optimistic Concurrency:         │
    │  IF _etag matches "abc-123-xyz"            │
    │    ✅ UPDATE document                      │
    │    ✅ Generate new _etag                   │
    │  ELSE                                      │
    │    ❌ Return 412 Precondition Failed       │
    │       (someone else modified it)           │
    └────────────────────────────────────────────┘
```

### Delete Data Source (with ETag)

```
┌─────────────────────────────────────────────────────────────┐
│  User Action: Click "Delete" → Confirm                      │
└─────────────────────────────────────────────────────────────┘
                          │
                          ▼
    ┌────────────────────────────────────────────┐
    │  Step 1: GET to retrieve _etag             │
    │  (same as Update)                          │
    └────────────────────────────────────────────┘
                          │
                          ▼
    ┌────────────────────────────────────────────┐
    │  Step 2: DELETE with If-Match              │
    │  DELETE /datasources/datasource_abc123     │
    │  Headers: {                                │
    │    "X-BFS-Auth": "...",                    │
    │    "If-Match": "\"abc-123-xyz\""           │
    │  }                                         │
    └────────────────────────────────────────────┘
                          │
                          ▼
    ┌────────────────────────────────────────────┐
    │  Cosmos DB:                                │
    │  IF _etag matches                          │
    │    ✅ DELETE document                      │
    │  ELSE                                      │
    │    ❌ 412 Precondition Failed              │
    └────────────────────────────────────────────┘
```

---

## 🔗 Data Capture Specification Flow

### Relationship: Data Source → Multiple Specs

```
Data Source: "Online" (Informix)
TenantId: BFS
┃
┣━━ Data Capture Spec #1
┃   ├─ Name: "Quote"
┃   ├─ Table: quotes
┃   ├─ Primary Key: quoteId
┃   ├─ Partition Key: customerId
┃   └─ Container Schema: { ... }
┃
┣━━ Data Capture Spec #2
┃   ├─ Name: "Customer"
┃   ├─ Table: customers
┃   ├─ Primary Key: customerId
┃   ├─ Partition Key: region
┃   └─ Container Schema: { ... }
┃
┗━━ Data Capture Spec #3
    ├─ Name: "Invoice"
    ├─ Table: invoices
    ├─ Primary Key: invoiceId
    ├─ Partition Key: customerId
    └─ Container Schema: { ... }
```

### Creating Data Capture Spec with Apicurio

```
┌─────────────────────────────────────────────────────────────┐
│  User: Select Data Source "Online"                          │
│  → Click "Add Specification"                                │
└─────────────────────────────────────────────────────────────┘
                          │
                          ▼
    ┌────────────────────────────────────────────┐
    │  Load Apicurio Schemas:                    │
    │  GET apicurio.../groups/bfs.online/artifacts│
    │                                            │
    │  Available Schemas:                        │
    │  ┌──────────────────────────────────────┐  │
    │  │ [x] Quote (v1.2.0) - JSON Schema     │  │
    │  │ [ ] Customer (v1.0.0) - JSON Schema  │  │
    │  │ [ ] Invoice (v1.1.0) - JSON Schema   │  │
    │  └──────────────────────────────────────┘  │
    └────────────────────────────────────────────┘
                          │
                          ▼
    ┌────────────────────────────────────────────┐
    │  User selects "Quote" schema               │
    │  → Auto-fill form:                         │
    │    Name: Quote                             │
    │    Primary Key: quoteId                    │
    │    Partition Key: customerId               │
    │  → Import Container Schema from Apicurio   │
    └────────────────────────────────────────────┘
                          │
                          ▼
    ┌────────────────────────────────────────────┐
    │  POST /datacapturespecs                    │
    │  {                                         │
    │    "dataCaptureSpecName": "Quote",         │
    │    "tenantId": "BFS",                      │
    │    "dataSourceId": "datasource_abc123",    │
    │    "sourcePrimaryKeyField": "quoteId",     │
    │    "partitionKeyField": "customerId",      │
    │    "containerSchema": { /* from Apicurio */ }│
    │  }                                         │
    └────────────────────────────────────────────┘
                          │
                          ▼
    ┌────────────────────────────────────────────┐
    │  ACE Configuration (Backend):              │
    │  ┌──────────────────────────────────────┐  │
    │  │ CDC Connector Setup:                 │  │
    │  │ - Source: Online.quotes table        │  │
    │  │ - Target: Cosmos DB (Transaction Hub)│  │
    │  │ - Schema: Use containerSchema        │  │
    │  │ - Partition: customerId              │  │
    │  └──────────────────────────────────────┘  │
    │                                            │
    │  ✅ Start CDC monitoring                   │
    └────────────────────────────────────────────┘
```

---

## 🎯 Permission Matrix per Operation

| Operation | Superuser | ViewOnlySU | Admin | Developer | Viewer |
|-----------|-----------|------------|-------|-----------|--------|
| **View Data Sources** |
| View all tenants | ✅ | ✅ | ❌ | ❌ | ❌ |
| View own tenant | ✅ | ✅ | ✅ | ✅ | ✅ |
| Switch tenants | ✅ | ✅ | ❌ | ❌ | ❌ |
| **Create Data Source** |
| For any tenant | ✅ | ❌ | ❌ | ❌ | ❌ |
| For own tenant | ✅ | ❌ | ✅ | ✅ | ❌ |
| **Edit Data Source** |
| Any tenant's DS | ✅ | ❌ | ❌ | ❌ | ❌ |
| Own tenant's DS | ✅ | ❌ | ✅ | ✅ | ❌ |
| **Delete Data Source** |
| Any tenant's DS | ✅ | ❌ | ❌ | ❌ | ❌ |
| Own tenant's DS | ✅ | ❌ | ✅ | ✅ | ❌ |
| **Data Capture Specs** |
| View specs | ✅ | ✅ | ✅ | ✅ | ✅ |
| Create spec | ✅ | ❌ | ✅ | ✅ | ❌ |
| Edit spec | ✅ | ❌ | ✅ | ✅ | ❌ |
| Delete spec | ✅ | ❌ | ✅ | ✅ | ❌ |

---

## 🚀 End-to-End Example: BFS Onboarding "Online" Data Source

```
┌──────────────────────────────────────────────────────────────────┐
│ STEP 1: BFS Admin creates Data Source                            │
└──────────────────────────────────────────────────────────────────┘
  User: admin@bfs.com (Admin role, BFS tenant)
  
  1. Login → Auto-locked to BFS tenant
  2. Navigate to "My Tenant" → "Data Sources"
  3. Click "Create Data Source"
     - Name: "Online"
     - Tenant: BFS (auto-selected, cannot change)
     - Type: "Informix"
  4. Submit → POST /datasources
  5. ✅ Created: datasource_12345


┌──────────────────────────────────────────────────────────────────┐
│ STEP 2: BFS Developer adds Data Capture Specifications           │
└──────────────────────────────────────────────────────────────────┘
  User: developer@bfs.com (Developer role, BFS tenant)
  
  1. Open "Online" data source details
  2. Click "Add Specification" → "Quote table"
     a. Apicurio loads schemas from group: bfs.online
     b. Select "Quote" (v1.2.0) JSON Schema
     c. Auto-fill:
        - Primary Key: quoteId
        - Partition Key: customerId
        - Container Schema: imported from Apicurio
  3. Submit → POST /datacapturespecs
  4. ✅ Created: spec_quote_001
  
  5. Click "Add Specification" → "Customer table"
     Similar process...
  6. ✅ Created: spec_customer_001
  
  7. Click "Add Specification" → "Invoice table"
  8. ✅ Created: spec_invoice_001


┌──────────────────────────────────────────────────────────────────┐
│ STEP 3: ACE Backend automatically configures CDC                 │
└──────────────────────────────────────────────────────────────────┘
  Backend Process (Automated):
  
  For each Data Capture Spec:
    1. Read spec from Cosmos DB
    2. Configure CDC connector:
       - Source: BFS Online Informix DB → quotes table
       - Target: Cosmos DB Transaction Hub
       - Schema: Use containerSchema from spec
       - Primary Key: quoteId
       - Partition: customerId
    3. Start monitoring changes
    4. On INSERT/UPDATE/DELETE in source:
       → Transform using containerSchema
       → Write to Cosmos DB with correct partition
  
  ✅ CDC active for: Quote, Customer, Invoice


┌──────────────────────────────────────────────────────────────────┐
│ STEP 4: Data flows from source to Transaction Hub                │
└──────────────────────────────────────────────────────────────────┘
  
  Source: BFS Online (Informix)
  ┌───────────────────────────────────────┐
  │ quotes table                          │
  │ ┌───────────────────────────────────┐ │
  │ │ INSERT INTO quotes VALUES (       │ │
  │ │   quoteId: 'Q-12345',             │ │
  │ │   customerId: 'C-001',            │ │
  │ │   amount: 5000.00                 │ │
  │ │ )                                 │ │
  │ └───────────────────────────────────┘ │
  └───────────────────────────────────────┘
              │
              │ CDC detects change
              ▼
  ┌───────────────────────────────────────┐
  │ ACE Transformation                    │
  │ - Apply containerSchema               │
  │ - Add metadata                        │
  │ - Set partition key                   │
  └───────────────────────────────────────┘
              │
              ▼
  Target: Cosmos DB (Transaction Hub)
  ┌───────────────────────────────────────┐
  │ {                                     │
  │   "id": "Q-12345",                    │
  │   "partitionKey": "C-001",            │
  │   "quoteId": "Q-12345",               │
  │   "customerId": "C-001",              │
  │   "amount": 5000.00,                  │
  │   "metaData": {                       │
  │     "sources": [{                     │
  │       "dataSourceId": "datasource_12345",│
  │       "tenantId": "BFS",              │
  │       "captureTime": "2025-11-14..."  │
  │     }]                                │
  │   }                                   │
  │ }                                     │
  └───────────────────────────────────────┘


┌──────────────────────────────────────────────────────────────────┐
│ STEP 5: BFS users view data in Data Plane                        │
└──────────────────────────────────────────────────────────────────┘
  User: viewer@bfs.com (Viewer role, BFS tenant)
  
  1. Navigate to "Data Plane" tab
  2. Filter: TenantId = BFS (auto-applied)
  3. View transformed data:
     ┌──────────────────────────────────────────┐
     │ Quote Q-12345                            │
     │ Customer: C-001                          │
     │ Amount: $5,000.00                        │
     │ Source: Online (Informix)                │
     │ Captured: 2025-11-14 10:23:45            │
     └──────────────────────────────────────────┘
  
  ✅ Data isolated: Cannot see Smith Douglas or Meritage data
```

---

## ✅ Summary

### Key Architecture Features

1. **Multi-Tenant Isolation**: Strict PartitionKey separation
2. **Real-time CDC**: Changes flow automatically from source to hub
3. **Schema Registry**: Apicurio provides centralized schema management
4. **RBAC Integration**: Role-based access at every layer
5. **ETag Concurrency**: Prevents conflicting updates
6. **Scalable**: Global tenant can aggregate all data sources

### Technology Stack

- **Frontend**: React + TypeScript + shadcn/ui
- **API**: TxServices (Azure hosted)
- **Database**: Cosmos DB (with PartitionKey isolation)
- **Integration**: ACE (IBM App Connect Enterprise)
- **CDC**: Change Data Capture for real-time sync
- **Schema Registry**: Apicurio (JSON/AVRO schemas)

### Production Readiness: ✅ 100%
