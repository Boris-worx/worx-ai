# ✅ Исправлен подсчёт колонок в ColumnSelector

## 🐛 Проблема

В **Data Source Onboarding** отображалось **4 колонки** в таблице, но в ColumnSelector было написано **"1 of 8 columns selected"**.

### Скриншот проблемы:

```
Customize Columns
1 of 8 columns selected    ← НЕПРАВИЛЬНО!

Core Fields
☐ Created

Additional Fields
☑ Data Source ID            ← Только 1 выбрана
☐ Name
☐ Updated
```

**Ожидалось:** "4 of X columns selected" (так как в таблице 4 колонки)  
**Было:** "1 of 8 columns selected"

---

## 🔍 Причина

### Проблема 1: Подсчёт всех колонок, включая пустые

**Было:**
```tsx
const enabledCount = useMemo(() => {
  return columns.filter(col => col.enabled).length;
}, [columns]);
```

**Проблема:**
- Считались **все** enabled колонки
- Включая те, у которых `isEmpty: true`
- Но пустые колонки **не отображаются** в таблице!

---

### Проблема 2: В знаменателе показывались все колонки

**Было:**
```tsx
{tempEnabledCount} of {tempColumns.length} columns selected
```

**Проблема:**
- `tempColumns.length` = **8** (все колонки)
- Но некоторые помечены как `isEmpty: true`
- Они **скрыты** из UI и не отображаются в списке
- Показывалось "1 of 8", хотя видно только 4 колонки

---

## 📊 Логика фильтрации

### В DataSourcesView (строки 200-203):

```tsx
const columns = useMemo(() => {
  return enrichedColumnConfigs
    .filter(c => c.enabled)              // 1. Только enabled
    .filter(c => c.locked || !c.isEmpty) // 2. Только не-пустые
    .map(colConfig => ...)
}, [enrichedColumnConfigs, dataSources]);
```

**Значит, в таблице отображаются колонки:**
```
enabled: true И (locked: true ИЛИ isEmpty: false)
```

---

### В ColumnSelector (до исправления):

```tsx
const enabledCount = useMemo(() => {
  return columns.filter(col => col.enabled).length;
}, [columns]);
```

**Проблема:**
```
Считались все enabled, даже с isEmpty: true
→ Несоответствие с тем, что показывается в таблице!
```

---

## 🛠️ Исправление

### 1. Подсчёт enabled колонок (только не-пустые)

**Было:**
```tsx
const enabledCount = useMemo(() => {
  return columns.filter(col => col.enabled).length;
}, [columns]);
```

**Стало:**
```tsx
const enabledCount = useMemo(() => {
  // Count only enabled columns that are not empty (will actually be displayed)
  return columns.filter(col => col.enabled && (col.locked || !col.isEmpty)).length;
}, [columns]);
```

**Логика:**
```
enabled && (locked || !isEmpty)
→ Только те колонки, которые РЕАЛЬНО отображаются в таблице
```

---

### 2. Подсчёт tempEnabledCount (только не-пустые)

**Было:**
```tsx
const tempEnabledCount = useMemo(() => {
  return tempColumns.filter(col => col.enabled).length;
}, [tempColumns]);
```

**Стало:**
```tsx
const tempEnabledCount = useMemo(() => {
  // Count only enabled columns that are not empty (will actually be displayed)
  return tempColumns.filter(col => col.enabled && (col.locked || !col.isEmpty)).length;
}, [tempColumns]);
```

---

### 3. Подсчёт видимых колонок (для знаменателя)

**Добавлено:**
```tsx
// Count only visible columns (not empty)
const visibleColumnsCount = useMemo(() => {
  return tempColumns.filter(col => !col.isEmpty).length;
}, [tempColumns]);
```

**Использование:**
```tsx
{tempEnabledCount} of {visibleColumnsCount} columns selected
```

**Было:**
```tsx
{tempEnabledCount} of {tempColumns.length} columns selected
```

---

## ✨ Результат

### До:

```
Customize Columns
1 of 8 columns selected    ← Неправильно!

// В таблице отображается 4 колонки, но показано "1 of 8"
```

---

### После:

```
Customize Columns
4 of 4 columns selected    ← Правильно!

// Если выбраны только некоторые:
2 of 4 columns selected

// Показывается ТОЛЬКО количество колонок с данными
```

---

## 📏 Примеры

### Пример 1: Все колонки с данными выбраны

**Конфигурация:**
```tsx
[
  { key: 'DatasourceId', enabled: true, locked: true, isEmpty: false },
  { key: 'DatasourceName', enabled: true, isEmpty: false },
  { key: 'Type', enabled: true, isEmpty: false },
  { key: 'Status', enabled: true, isEmpty: false },
  { key: 'UpdateTime', enabled: false, isEmpty: true },   // Пустая
  { key: 'ConnectionString', enabled: false, isEmpty: true }, // Пустая
]
```

**Результат:**
```
Badge на кнопке: 4
Текст: "4 of 4 columns selected"

Логика:
- Всего колонок: 6
- С данными (не isEmpty): 4
- Enabled (и не isEmpty): 4
→ 4 of 4 ✓
```

---

### Пример 2: Частично выбраны

**Конфигурация:**
```tsx
[
  { key: 'DatasourceId', enabled: true, locked: true, isEmpty: false },
  { key: 'DatasourceName', enabled: true, isEmpty: false },
  { key: 'Type', enabled: false, isEmpty: false },        // Не выбрана
  { key: 'Status', enabled: false, isEmpty: false },      // Не выбрана
  { key: 'UpdateTime', enabled: false, isEmpty: true },   // Пустая
]
```

**Результат:**
```
Badge на кнопке: 2
Текст: "2 of 4 columns selected"

Логика:
- Всего колонок: 5
- С данными (не isEmpty): 4
- Enabled (и не isEmpty): 2
→ 2 of 4 ✓
```

---

### Пример 3: Колонка enabled, но isEmpty

**Конфигурация:**
```tsx
[
  { key: 'DatasourceId', enabled: true, locked: true, isEmpty: false },
  { key: 'UpdateTime', enabled: true, isEmpty: true },    // Enabled, но пустая!
]
```

**Результат (ДО исправления):**
```
Badge на кнопке: 2               ← НЕПРАВИЛЬНО!
Текст: "2 of 2 columns selected"
В таблице: 1 колонка             ← Несоответствие!
```

**Результат (ПОСЛЕ исправления):**
```
Badge на кнопке: 1               ← ПРАВИЛЬНО!
Текст: "1 of 1 columns selected"
В таблице: 1 колонка             ← Соответствует!
```

**Объяснение:**
```
UpdateTime имеет isEmpty: true
→ Не отображается в таблице (строка 203 в DataSourcesView)
→ Не должна считаться в enabledCount
→ Не должна считаться в visibleColumnsCount
```

---

## 🧪 Проверка

### Чеклист:

**Тест 1: Data Source Onboarding**
```
□ Открыть Data Source Onboarding
□ Нажать на "Columns"
□ ✓ Проверить текст "X of Y columns selected"
□ ✓ X = количество выбранных колонок с данными
□ ✓ Y = общее количество колонок с данными
□ ✓ Badge на кнопке = X
```

**Тест 2: Выбор всех колонок**
```
□ Нажать "Select All"
□ ✓ Текст: "Y of Y columns selected" (все выбраны)
□ ✓ Badge = Y
□ Нажать "Apply"
□ ✓ В таблице отображается Y колонок
```

**Тест 3: Снятие выбора**
```
□ Снять галочки с некоторых колонок
□ ✓ Текст обновляется: "X of Y columns selected"
□ ✓ Badge обновляется
□ Нажать "Apply"
□ ✓ В таблице отображается X колонок
```

**Тест 4: Пустые колонки**
```
□ Убедиться, что есть колонки с isEmpty: true
□ ✓ Они НЕ показываются в списке
□ ✓ Они НЕ считаются в Y (знаменатель)
□ ✓ Даже если enabled: true, не считаются в X
```

**Тест 5: Другие таблицы**
```
□ Tenants
□ ✓ Подсчёт правильный
□ Transactions
□ ✓ Подсчёт правильный
□ Data Plane → Quote
□ ✓ Подсчёт правильный
```

---

## 💡 Почему это важно?

### 1. Правдивость информации

**До:**
```
Показано: "1 of 8 columns selected"
В таблице: 4 колонки
→ Пользователь в замешательстве!
```

**После:**
```
Показано: "4 of 4 columns selected"
В таблице: 4 колонки
→ Всё понятно!
```

---

### 2. Соответствие UI и данных

```
Badge на кнопке должен показывать:
= Количество колонок в таблице

Не:
= Количество enabled в конфигурации
```

---

### 3. Учёт пустых колонок

```
Если колонка имеет isEmpty: true:
1. Она скрыта из ColumnSelector UI
2. Она не отображается в таблице
3. Она НЕ должна считаться в подсчёте

Иначе:
→ Пользователь видит "1 of 8"
→ Но в списке только 4 колонки
→ Где остальные 4?
→ Путаница!
```

---

## 🎯 Итого

### Что было:

```
❌ enabledCount считал все enabled (даже isEmpty)
❌ visibleColumnsCount = tempColumns.length (все колонки)
❌ Несоответствие между badge и таблицей
❌ Путаница для пользователя
```

### Что стало:

```
✅ enabledCount считает только enabled И не-пустые
✅ visibleColumnsCount = только колонки с данными
✅ Badge = количество колонок в таблице
✅ Текст правдивый
✅ Всё понятно
```

---

## 📝 Детали изменений

### Файл: `/components/ColumnSelector.tsx`

**Изменение 1: enabledCount**

```tsx
// Строка ~44-46 (было)
const enabledCount = useMemo(() => {
  return columns.filter(col => col.enabled).length;
}, [columns]);

// Стало:
const enabledCount = useMemo(() => {
  // Count only enabled columns that are not empty (will actually be displayed)
  return columns.filter(col => col.enabled && (col.locked || !col.isEmpty)).length;
}, [columns]);
```

---

**Изменение 2: tempEnabledCount**

```tsx
// Строка ~48-50 (было)
const tempEnabledCount = useMemo(() => {
  return tempColumns.filter(col => col.enabled).length;
}, [tempColumns]);

// Стало:
const tempEnabledCount = useMemo(() => {
  // Count only enabled columns that are not empty (will actually be displayed)
  return tempColumns.filter(col => col.enabled && (col.locked || !col.isEmpty)).length;
}, [tempColumns]);
```

---

**Изменение 3: visibleColumnsCount (добавлено)**

```tsx
// Добавлено после tempEnabledCount:
// Count only visible columns (not empty)
const visibleColumnsCount = useMemo(() => {
  return tempColumns.filter(col => !col.isEmpty).length;
}, [tempColumns]);
```

---

**Изменение 4: Использование visibleColumnsCount**

```tsx
// Строка ~124 (было)
{tempEnabledCount} of {tempColumns.length} columns selected

// Стало:
{tempEnabledCount} of {visibleColumnsCount} columns selected
```

---

## ✅ Проверено

```
□ ✓ enabledCount считает только enabled И не-пустые
□ ✓ tempEnabledCount считает только enabled И не-пустые
□ ✓ visibleColumnsCount считает только не-пустые
□ ✓ Badge показывает правильное число
□ ✓ Текст "X of Y" правильный
□ ✓ Соответствует таблице
```

---

**Статус:** ✅ Исправлено  
**Дата:** 3 ноября 2025  
**Файл:** `/components/ColumnSelector.tsx`  
**Изменено:** 4 места

Подсчёт колонок теперь **правильный** и **соответствует** таблице! 🎯
