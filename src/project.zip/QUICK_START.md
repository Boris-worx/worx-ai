# Quick Start Guide - BFS Platform Management

## Getting Started

### Demo Mode (Default)
The application runs in demo mode with mock data by default. No configuration needed!

### Connect to Real API
1. Open `/lib/api.ts`
2. Change `API_BASE_URL` from `https://api.example.com/1.0` to your actual API URL
3. Update `AUTH_HEADER_VALUE` with your X-BFS-Auth key from Postman collection
4. The app will automatically detect real API and disable demo mode

## Features Overview

### Tenants Tab (User Stories 1-3)

**View Tenants** ✓
- Automatic load on page open
- Shows TenantID and TenantName
- Search, Sort, and Filter built-in

**Add Tenant** ✓
- Click "Add New Tenant"
- Enter TenantName only
- System generates TenantID

**Delete Tenant** ✓
- Click "Delete" button
- Confirm in dialog
- Uses _etag for concurrency control

**Edit Tenant** ✓
- Click "Edit" button
- Update TenantName
- Uses _etag for concurrency control

**View Tenant Details** ✓
- Click on TenantID (blue link)
- See all Cosmos DB metadata
- View raw JSON

### Transactions Tab (User Stories 4-6)

**View Transactions** ✓
- Shows list of 16 ERP transaction types
- Click any row to view details
- Search and Sort enabled

**View Details** ✓
- Click transaction name
- See Request JSON in one tab
- See Response JSON in another tab

**Add Transaction** ✓
- Click "Add New Transaction"
- Enter transaction name
- Upload Request JSON file
- Upload Response JSON file
- Click Create

### Data Plane Tab (New!)

**Quote Transactions** 🆕
- Full CRUD support for Quote type
- Pre-filled templates for easy creation
- Test using `/test-quote-api.html` or in-app
- See [QUOTE_TEST_RU.md](/QUOTE_TEST_RU.md) for testing guide

**Supported Types:**
- Customer
- Location
- Quote (NEW!)
- ReasonCode (NEW!)
- ModelSchema

## Sample Files

Use these files to test the application:

- `/sample-tenants.json` - Example tenant data with proper structure
- `/sample-transactions.json` - Example transaction data
- `/sample-request.json` - Example request JSON for new transaction
- `/sample-response.json` - Example response JSON for new transaction

## API Requirements

### Headers
All API calls include:
- `X-BFS-Auth`: Your API key (required)
- `Content-Type`: application/json
- `If-Match`: _etag value (for updates/deletes)

### Response Format
All APIs must return this structure:
```json
{
  "status": {
    "code": 200,
    "message": "Success message"
  },
  "data": {
    // Your data here
  }
}
```

### Error Handling
If API returns error:
- App displays `status.message` in toast notification
- User-friendly error messages
- No crashes or blank screens

## Common Tasks

### Testing User Story 1 (View Tenants)
1. Open app
2. Click "Tenants" tab (default)
3. See list of tenants
4. Try searching by name or ID
5. Click column headers to sort

### Testing User Story 2 (Create Tenant)
1. Click "Add New Tenant"
2. Type "Test Company" in name field
3. Click "Create Tenant"
4. See new tenant in list with auto-generated ID

### Testing User Story 3 (Delete Tenant)
1. Find any tenant in list
2. Click "Delete" button
3. Confirm deletion
4. Tenant removed from list

### Testing Edit Tenant
1. Find any tenant in list
2. Click "Edit" button
3. Change the tenant name
4. Click "Update Tenant"
5. See updated name in list

### Testing Tenant Details View
1. Click on any TenantID (blue link)
2. Dialog opens with complete information
3. View all Cosmos DB metadata fields
4. Check Raw JSON at bottom

### Testing User Story 4 (View Transactions)
1. Click "Transactions" tab
2. See 16 transaction types
3. Use search to filter
4. Click headers to sort

### Testing User Story 5 (View Details)
1. On Transactions tab
2. Click any transaction name row
3. Dialog opens with Request and Response JSON
4. Switch between tabs to view both

### Testing User Story 6 (Add Transaction)
1. Click "Add New Transaction"
2. Enter name: "Test Transaction"
3. Click "Upload Request JSON" → select `/sample-request.json`
4. Click "Upload Response JSON" → select `/sample-response.json`
5. Click "Create Transaction"
6. See new transaction in list

## Troubleshooting

**"Demo Mode" banner showing?**
- Expected! You're using demo data
- To connect real API, see "Connect to Real API" above

**Table not sorting?**
- Click column header directly
- Arrow icons show sort direction

**Upload not working?**
- Ensure JSON file is valid (use JSON validator)
- Check file extension is `.json`

**API errors?**
- Check API_BASE_URL is correct
- Verify AUTH_HEADER_VALUE is set
- Check network tab for actual error response

## Architecture

### Components
- `/components/TenantsView.tsx` - User Stories 1-3
- `/components/TransactionsView.tsx` - User Stories 4-6
- `/components/DataTable.tsx` - Reusable table with sort/search/filter
- `/components/TransactionDetail.tsx` - User Story 5 detail view
- `/components/TransactionForm.tsx` - User Story 6 creation form

### API Module
- `/lib/api.ts` - All API functions and interfaces
- Handles demo mode automatically
- Includes error handling
- Manages headers and etags

### User Stories Documentation
See `/USER_STORIES.md` for detailed requirements and acceptance criteria.
