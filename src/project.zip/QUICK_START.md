# 🚀 Quick Start: Apicurio Dynamic Integration

**TL;DR:** Полностью динамическая система. Новые группы и версии подхватываются автоматически.

---

## ⚡ 30-секунд обзор

```typescript
// 1. Получить все группы динамически
const groups = await getApicurioGroups();
// → ['paradigm.bidtools2', 'bfs.online', ...]

// 2. Получить артефакты группы
const artifacts = await getGroupArtifacts('paradigm.bidtools2');
// → [{ artifactId: 'QuoteDetails', ... }, ...]

// 3. Получить версии артефакта
const versions = await getArtifactVersions('bfs.online', 'inv.response');
// → [{ version: '1.0.0', ... }, { version: '2.0.0', ... }]

// 4. Выбрать последнюю версию
const latest = getLatestVersion(versions);
// → '2.0.0'

// 5. Получить контент (версия определится автоматически)
const schema = await getApicurioArtifact('bfs.online', 'inv.response');
// → { $schema: '...', properties: {...} }
```

---

## 🎯 Основные функции

### `getApicurioGroups()`
```typescript
const groups = await getApicurioGroups();
```
**Что делает:** Получает ВСЕ группы из `/groups/`  
**Возвращает:** `ApicurioGroup[]`  
**Fallback:** Дефолтные группы при 403

---

### `getGroupArtifacts(groupId)`
```typescript
const artifacts = await getGroupArtifacts('paradigm.bidtools2');
```
**Что делает:** Получает артефакты группы  
**Возвращает:** `ApicurioArtifact[]`  
**Fallback:** `[]` при ошибке

---

### `getArtifactVersions(groupId, artifactId)`
```typescript
const versions = await getArtifactVersions('bfs.online', 'inv.response');
```
**Что делает:** Получает все версии артефакта  
**Возвращает:** `ApicurioVersion[]`  
**Используется для:** Автоопределения актуальной версии

---

### `getLatestVersion(versions)`
```typescript
const latest = getLatestVersion(versions);
```
**Что делает:** Выбирает последнюю версию (по `createdOn`)  
**Возвращает:** `string | null`

---

### `getApicurioArtifact(groupId, artifactId, version?)`
```typescript
// Версия определится автоматически
const schema = await getApicurioArtifact('bfs.online', 'inv.response');

// Или указать версию явно
const schemaV1 = await getApicurioArtifact('bfs.online', 'inv.response', '1.0.0');
```
**Что делает:**
1. Если версия не указана → получает через `getArtifactVersions()`
2. Выбирает последнюю через `getLatestVersion()`
3. Загружает контент с этой версией

---

### `getGroupDisplayName(groupId)`
```typescript
const name = getGroupDisplayName('paradigm.bidtools2');
// → 'Bid Tools Templates'
```
**Что делает:** Преобразует `groupId` в красивое имя для UI

---

## 📊 API Flow

```
┌─────────────────────────────────────────────────────────┐
│ 1. GET /groups/                                         │
│    └─> ['paradigm.bidtools2', 'bfs.online']            │
└─────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────┐
│ 2. GET /groups/{groupId}/artifacts/                     │
│    └─> [{ artifactId: 'QuoteDetails', ... }]           │
└─────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────┐
│ 3. GET /groups/{groupId}/artifacts/{id}/versions        │
│    └─> [{ version: '1.0.0' }, { version: '2.0.0' }]    │
└─────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────┐
│ 4. GET /versions/{latestVersion}/content                │
│    └─> { $schema: '...', properties: {...} }           │
└─────────────────────────────────────────────────────────┘
```

---

## 🎨 UI Integration

```tsx
import { getGroupDisplayName } from '../lib/apicurio';

// Вместо хардкода:
<CommandGroup heading="Bid Tools Templates">

// Используем:
<CommandGroup heading={getGroupDisplayName(groupId)}>
```

---

## ✅ Преимущества

| Задача | До | После |
|--------|-----|-------|
| Добавить группу | ❌ Изменить код | ✅ Просто создать в Registry |
| Обновить версию | ❌ Изменить хардкод | ✅ Просто загрузить в Registry |
| Узнать актуальную версию | ❌ Смотреть в коде | ✅ Автоматически определится |

---

## 🧪 Quick Test

```bash
# 1. Проверить группы
curl "https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/"

# 2. Проверить артефакты
curl "https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/bfs.online/artifacts/"

# 3. Проверить версии
curl "https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/bfs.online/artifacts/inv.response/versions"

# 4. Получить контент
curl "https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/bfs.online/artifacts/inv.response/versions/1.0.0/content"
```

---

## 🔍 Логи

Динамические операции легко узнать по эмодзи **🎯**:

```
📦 🎯 DYNAMIC: Fetching groups and artifacts...
📦 🎯 Found 2 groups: paradigm.bidtools2, bfs.online
📦 🎯 DYNAMIC: Fetching versions for QuoteDetails...
📦 ✅ Using latest version: 1.0.0
```

---

## 💡 Примеры использования

### Пример 1: Клиент добавил новую группу

**Действия клиента:**
```bash
# Создать группу "paradigm.widgets" в Apicurio Registry
# Загрузить артефакты в эту группу
```

**Приложение:**
```typescript
// Автоматически получит новую группу
const groups = await getApicurioGroups();
// → ['paradigm.bidtools2', 'bfs.online', 'paradigm.widgets']

// UI автоматически покажет новую группу
```

**Изменения в коде:** `0` строк 🎯

---

### Пример 2: Клиент обновил версию

**Действия клиента:**
```bash
# Загрузить версию 2.0.0 для inv.response в Registry
```

**Приложение:**
```typescript
// Автоматически получит новую версию
const versions = await getArtifactVersions('bfs.online', 'inv.response');
// → [{ version: '1.0.0' }, { version: '2.0.0' }]

const latest = getLatestVersion(versions);
// → '2.0.0' (автоматически выбрана последняя)

// Загрузит контент версии 2.0.0
const schema = await getApicurioArtifact('bfs.online', 'inv.response');
```

**Изменения в коде:** `0` строк 🎯

---

## 📚 Документация

| Нужна помощь? | Документ |
|--------------|----------|
| Полная документация | `/APICURIO_DYNAMIC_INTEGRATION.md` |
| Краткая сводка | `/DYNAMIC_SUMMARY.txt` |
| Общий статус | `/ГОТОВО.txt` |
| Quick start | `/QUICK_START.md` ⬅️ вы здесь |

---

## ⚡ Быстрые команды

```typescript
// Получить все группы
const groups = await getApicurioGroups();

// Получить артефакты группы
const artifacts = await getGroupArtifacts(groupId);

// Получить версии
const versions = await getArtifactVersions(groupId, artifactId);

// Последняя версия
const latest = getLatestVersion(versions);

// Получить контент (версия auto)
const schema = await getApicurioArtifact(groupId, artifactId);

// Красивое имя группы
const name = getGroupDisplayName(groupId);
```

---

**Дата:** 27 ноября 2025  
**Статус:** ✅ Готово к использованию
