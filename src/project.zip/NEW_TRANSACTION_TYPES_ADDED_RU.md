# ✅ Добавлены новые типы транзакций в Data Plane

## Что добавлено

Добавлено **11 новых типов транзакций** в список Transaction Types на вкладке Data Plane для работы с BFS Online данными.

## Новые типы транзакций

### BFS Online типы (Informix)
1. **Keyi** - Key Items
2. **Inv** - Inventory (основная таблица инвентаря)
3. **Inv1** - Inventory variant 1
4. **Inv2** - Inventory variant 2
5. **Inv3** - Inventory variant 3
6. **Invap** - Inventory AP
7. **Invdes** - Inventory Descriptions
8. **Invloc** - Inventory Locations
9. **Loc** - Locations
10. **Loc1** - Locations variant 1
11. **Stocode** - Store Codes

## Обновленная структура типов

### До изменений
```typescript
Transaction Types (29 типов):
- Customer, Location, Quote, QuoteDetail, QuotePack
- ReasonCode, LineType, ServiceRequest, WorkflowCustomer
- Invoice, Sales Order, Item Pricing, etc.
```

### После изменений
```typescript
Transaction Types (40 типов):
- Customer, Location, Quote, QuoteDetail, QuotePack
- Keyi, Inv, Inv1, Inv2, Inv3, Invap, Invdes, Invloc
- Loc, Loc1, Stocode
- ReasonCode, LineType, ServiceRequest, WorkflowCustomer
- Invoice, Sales Order, Item Pricing, etc.
```

## Порядок отображения (алфавитный)

В UI типы отображаются в алфавитном порядке:
```
Customer (26)
Inv (0)
Inv1 (0)
Inv2 (0)
Inv3 (0)
Invap (0)
Invdes (0)
Invloc (0)
Keyi (0)
LineType (22)
Loc (0)
Loc1 (0)
Location (34)
Quote (6964)
QuoteDetail (248474)
QuotePack (15332)
ReasonCode (14)
ServiceRequest (3459)
Stocode (0)
WorkflowCustomer (52279)
```

## Изменения в файлах

### 1. `/lib/api.ts`
#### Обновлен список `TRANSACTION_TYPES`
```typescript
export const TRANSACTION_TYPES = [
  'Customer',
  'Customer Aging',
  'Inv',
  'Inv1',
  'Inv2',
  'Inv3',
  'Invap',
  'Invdes',
  'Invloc',
  'Keyi',
  'LineType',
  'LineTypes',
  'Loc',
  'Loc1',
  'Location',
  // ... остальные типы
  'Stocode',
  'WorkflowCustomer',
  // ...
] as const;
```

#### Упрощена функция `formatTransactionType`
```typescript
// До
export const formatTransactionType = (type: string): string => {
  const typeMap: Record<string, string> = {
    'keyi': 'keyis Items',
    'invloc': 'invlocs Items',
    // ...
  };
  return typeMap[type] || type;
};

// После
export const formatTransactionType = (type: string): string => {
  // Keep original names for display (no plural 's' suffix)
  return type;
};
```

### 2. `/components/TransactionsView.tsx`
#### Обновлен список `fallbackTypes`
```typescript
const fallbackTypes = [
  'Customer',
  'Customer Aging',
  'Inv',
  'Inv1',
  'Inv2',
  'Inv3',
  'Invap',
  'Invdes',
  'Invloc',
  'Keyi',
  'LineType',
  'LineTypes',
  'Loc',
  'Loc1',
  'Location',
  // ...
  'Stocode',
  'WorkflowCustomer',
  // ...
];
```

## Функциональность

### 1. Отображение в Transaction Types Card
```tsx
<Card>
  <CardHeader>
    <CardTitle>Transaction Types (40)</CardTitle>
  </CardHeader>
  <CardContent>
    <Button variant="ghost">Keyi (0)</Button>
    <Button variant="ghost">Inv (0)</Button>
    <Button variant="ghost">Inv1 (0)</Button>
    <!-- ... остальные типы ... -->
  </CardContent>
</Card>
```

### 2. Поиск по типам
```typescript
// Поиск работает для всех новых типов
searchTerm: "inv"
Results: Inv, Inv1, Inv2, Inv3, Invap, Invdes, Invloc, Invoice, Invoice PDF
```

### 3. Фильтрация по тенантам
```typescript
// Каждый тип поддерживает мультитенантность
GET /api/tenants/{tenantId}/transactions/{txntype}/data
```

### 4. Сортировка
- **По имени (A-Z)**: Алфавитный порядок
- **По имени (Z-A)**: Обратный порядок
- **По количеству (Low-High)**: От меньшего к большему
- **По количеству (High-Low)**: От большего к меньшему

## Интеграция с Data Capture Specs

### Автоматическое создание типов
Когда создается Data Capture Specification с `containerName: "Invs"`:
1. ✅ Тип **"Inv"** автоматически появляется в Transaction Types
2. ✅ При клике на **"Inv"** загружаются транзакции из container **"Invs"**
3. ✅ Схема определяется через `containerSchema` в Data Capture Spec

### Пример создания Inv типа
```json
{
  "dataCaptureSpecName": "Inv",
  "containerName": "Invs",
  "tenantId": "1018-tenant",
  "sourcePrimaryKeyField": "invid",
  "allowedFilters": ["invid", "invdes", "ivstat", ...],
  "containerSchema": { ... }
}
```

После создания спецификации:
```
Transaction Types:
- Inv (0) ← новый тип появился автоматически
```

## Связь с Apicurio Templates

### BFS Online Templates → Transaction Types
| Template | Container | Transaction Type |
|----------|-----------|------------------|
| inv | Invs | Inv |
| inv1 | Inv1s | Inv1 |
| inv2 | Inv2s | Inv2 |
| inv3 | Inv3s | Inv3 |
| invap | Invaps | Invap |
| invdes | Invdess | Invdes |
| invloc | Invlocs | Invloc |
| loc | Locs | Loc |
| loc1 | Loc1s | Loc1 |
| stcode | Stocodes | Stocode |
| keyi | Keyis | Keyi |

## API запросы

### Получить транзакции по типу
```http
GET https://dp-eastus-poc-txservices-apis.azurewebsites.net/api/tenants/{tenantId}/transactions/Inv/data
Headers:
  X-BFS-Auth: your-auth-token
  Content-Type: application/json
```

### Создать транзакцию
```http
POST https://dp-eastus-poc-txservices-apis.azurewebsites.net/api/tenants/{tenantId}/transactions/Inv/data
Headers:
  X-BFS-Auth: your-auth-token
  Content-Type: application/json
Body:
{
  "invid": "INV-001",
  "invdes": "Test Item",
  "ivstat": "A",
  ...
}
```

### Получить количество транзакций
```http
GET https://dp-eastus-poc-txservices-apis.azurewebsites.net/api/tenants/{tenantId}/transactions/Inv/data?$count=true&pageSize=0
```

## Тестирование

### 1. Проверка отображения типов
```javascript
// Открыть Data Plane
// Должны отображаться все 11 новых типов:
// Keyi, Inv, Inv1, Inv2, Inv3, Invap, Invdes, Invloc, Loc, Loc1, Stocode
```

### 2. Проверка поиска
```javascript
// В поле поиска ввести "inv"
// Должны найтись: Inv, Inv1, Inv2, Inv3, Invap, Invdes, Invloc, Invoice, Invoice PDF
```

### 3. Проверка сортировки
```javascript
// Нажать кнопку сортировки
// Выбрать "Sort by Name (A-Z)"
// Типы должны отображаться в алфавитном порядке
```

### 4. Проверка интеграции с Data Capture Specs
```javascript
// 1. Создать Data Capture Spec с containerName: "Invs"
// 2. Перейти в Data Plane
// 3. Должен появиться тип "Inv" с количеством транзакций
// 4. При клике на "Inv" должны загружаться транзакции
```

## Совместимость

✅ **Мультитенантность** - каждый тип поддерживает изоляцию данных по тенантам  
✅ **Поиск** - работает для всех новых типов  
✅ **Сортировка** - поддерживается 4 режима сортировки  
✅ **Pagination** - continuation token для больших объемов данных  
✅ **Data Capture Specs** - автоматическое создание типов из спецификаций  
✅ **Apicurio Templates** - интеграция с BFS Online шаблонами  

## Будущие расширения

### Планируется добавить
- **invven** - Inventory Vendors
- **invpri** - Inventory Pricing
- **invqty** - Inventory Quantities
- **custadr** - Customer Addresses
- **custcon** - Customer Contacts

### Автоматическое добавление
При создании новой Data Capture Specification тип автоматически появится в списке Transaction Types.

## Статус
🟢 **Готово** - 11 новых типов транзакций добавлены и готовы к использованию

## См. также
- `/BFS_ONLINE_INV_TEMPLATE_ADDED_RU.md` - Документация по шаблону Inv
- `/APICURIO_403_HANDLING_RU.md` - Обработка ошибок Apicurio
- `/SOURCEPRIMARYKEYFIELD_CONST_EXTRACTION_RU.md` - Извлечение primary key
