# Apicurio Registry - Documentation Index (NO MOCK DATA)

## 📚 Overview

This directory contains documentation for the Apicurio Registry integration after removing all mock data.

**Last Updated**: November 28, 2024  
**Status**: ✅ Complete - No Mock Data

---

## 🎯 Quick Start

**Read these first** (in order):

1. 📄 [APICURIO_MOCK_REMOVED_SUMMARY.txt](./APICURIO_MOCK_REMOVED_SUMMARY.txt)  
   **Quick summary** of what changed (2-minute read)

2. 📄 [APICURIO_REAL_DATA_ONLY.md](./APICURIO_REAL_DATA_ONLY.md)  
   **Quick reference** for developers (5-minute read)

3. 📄 [APICURIO_NO_MOCK_DATA_RU.md](./APICURIO_NO_MOCK_DATA_RU.md)  
   **Detailed explanation** in Russian (10-minute read)

4. ✅ [APICURIO_NO_MOCK_CHECKLIST.md](./APICURIO_NO_MOCK_CHECKLIST.md)  
   **Testing checklist** before deployment

---

## 📖 Documents by Purpose

### For Developers

| Document | Purpose | Time |
|----------|---------|------|
| [APICURIO_REAL_DATA_ONLY.md](./APICURIO_REAL_DATA_ONLY.md) | API reference, functions, behavior | 5 min |
| [APICURIO_NO_MOCK_DATA_RU.md](./APICURIO_NO_MOCK_DATA_RU.md) | Complete implementation details | 10 min |

### For QA

| Document | Purpose | Time |
|----------|---------|------|
| [APICURIO_NO_MOCK_CHECKLIST.md](./APICURIO_NO_MOCK_CHECKLIST.md) | Complete testing checklist | 30 min |
| [APICURIO_MOCK_REMOVED_SUMMARY.txt](./APICURIO_MOCK_REMOVED_SUMMARY.txt) | What changed summary | 2 min |

### For Product Owners

| Document | Purpose | Time |
|----------|---------|------|
| [APICURIO_MOCK_REMOVED_SUMMARY.txt](./APICURIO_MOCK_REMOVED_SUMMARY.txt) | Executive summary | 2 min |
| [APICURIO_REAL_DATA_ONLY.md](./APICURIO_REAL_DATA_ONLY.md) | User impact, behavior changes | 5 min |

---

## 🔑 Key Points

### ✅ What's Done
- **NO MOCK DATA** - Completely removed
- **Two groups only**: `paradigm.bidtools2` and `bfs.online`
- **Real API calls** to Apicurio Registry
- **Smart caching** (30 minutes, localStorage)
- **Graceful degradation** (uses cache on errors)

### ⚠️ Important Changes
- **Error handling**: Shows real errors to users (no silent fallback)
- **Cache required**: First load needs API access
- **Empty state**: If API fails and no cache, shows empty list

### 📊 Statistics
- **Code removed**: ~1,105 lines
- **Mock artifacts removed**: 18 items
- **Mock schemas removed**: 11 types
- **File size**: Reduced from ~1,900 to ~795 lines

---

## 🔍 Quick Reference

### Two Groups (Hardcoded)
```typescript
const KNOWN_GROUPS = [
  { id: 'paradigm.bidtools2', description: 'Bid Tools Templates' },
  { id: 'bfs.online', description: 'BFS Online Templates' },
];
```

### API Endpoints Used
```
GET /groups
GET /groups/paradigm.bidtools2/artifacts
GET /groups/bfs.online/artifacts
GET /groups/{groupId}/artifacts/{artifactId}/versions
GET /groups/{groupId}/artifacts/{artifactId}/versions/{version}/content
```

### Cache Configuration
```typescript
Cache duration: 30 minutes
Storage: localStorage + in-memory
Key: 'apicurio_artifacts_cache'
Clear: clearArtifactsCache()
```

---

## 🧪 Testing

### Smoke Test (1 minute)
1. Open Data Source Onboarding
2. Click "Create from Template"
3. Verify templates load from API
4. Select any template
5. Verify schema loads

### Full Test (30 minutes)
Follow the complete checklist in:  
📄 [APICURIO_NO_MOCK_CHECKLIST.md](./APICURIO_NO_MOCK_CHECKLIST.md)

### Console Test Script
```javascript
// Check for removed mock functions
import('./lib/apicurio').then(module => {
  console.log('getMock functions:', {
    getMockApicurioArtifacts: typeof module.getMockApicurioArtifacts, // undefined ✅
    getMockArtifactSchema: typeof module.getMockArtifactSchema // undefined ✅
  });
});

// Load real data
import('./lib/apicurio').then(async m => {
  const result = await m.searchApicurioArtifacts();
  console.log(`✅ Loaded ${result.count} real artifacts`);
  console.log('Groups:', [...new Set(result.artifacts.map(a => a.groupId))]);
});
```

---

## 📁 Files Changed

### Core Files
1. `/lib/apicurio.ts`
   - Complete rewrite
   - Removed `getMockApicurioArtifacts()`
   - Removed `getMockArtifactSchema()`
   - All fallbacks removed
   - Size: ~1,900 → ~795 lines

2. `/components/DataCaptureSpecCreateDialog.tsx`
   - Updated comments
   - Added error toast

### Documentation Files (NEW)
1. `/APICURIO_NO_MOCK_DATA_RU.md` - Detailed explanation (RU)
2. `/APICURIO_REAL_DATA_ONLY.md` - Quick reference (EN)
3. `/APICURIO_MOCK_REMOVED_SUMMARY.txt` - Summary (RU)
4. `/APICURIO_NO_MOCK_CHECKLIST.md` - Testing checklist
5. `/APICURIO_DOCS_NO_MOCK.md` - This index

---

## 🎓 Learning Path

### New to the Project?
1. Read [APICURIO_MOCK_REMOVED_SUMMARY.txt](./APICURIO_MOCK_REMOVED_SUMMARY.txt)
2. Run the smoke test
3. Read [APICURIO_REAL_DATA_ONLY.md](./APICURIO_REAL_DATA_ONLY.md)

### Need to Test?
1. Read [APICURIO_NO_MOCK_CHECKLIST.md](./APICURIO_NO_MOCK_CHECKLIST.md)
2. Follow all checkboxes
3. Report results

### Need Details?
1. Read [APICURIO_NO_MOCK_DATA_RU.md](./APICURIO_NO_MOCK_DATA_RU.md)
2. Check `/lib/apicurio.ts` source code
3. Review console messages

---

## 🔗 Related Documentation

### Previous Apicurio Docs
- [APICURIO-INTEGRATION.md](./APICURIO-INTEGRATION.md) - Original integration (outdated)
- [APICURIO_DYNAMIC_INTEGRATION.md](./APICURIO_DYNAMIC_INTEGRATION.md) - Dynamic loading (outdated)
- [APICURIO-MOCK-DATA-FIX.md](./APICURIO-MOCK-DATA-FIX.md) - Previous mock data handling (outdated)

**Note**: These documents describe the old implementation with mock data.

### Current Apicurio Docs (✅ Up to date)
- This index: `APICURIO_DOCS_NO_MOCK.md`
- Summary: `APICURIO_MOCK_REMOVED_SUMMARY.txt`
- Reference: `APICURIO_REAL_DATA_ONLY.md`
- Details: `APICURIO_NO_MOCK_DATA_RU.md`
- Checklist: `APICURIO_NO_MOCK_CHECKLIST.md`

---

## 💡 Common Questions

### Q: What if Apicurio is down?
**A**: First load will fail. Subsequent loads use cache (30 min). After cache expires, shows empty list or error.

### Q: Can I add mock data back?
**A**: No. The requirement is **NO MOCK DATA**. Only real Apicurio Registry data.

### Q: What if I need to test offline?
**A**: Load templates once while online (creates cache). Then work offline using cache for 30 minutes.

### Q: How do I clear the cache?
**A**: 
```javascript
import('./lib/apicurio').then(m => m.clearArtifactsCache())
```
Or: `localStorage.removeItem('apicurio_artifacts_cache')`

### Q: Can I add more groups?
**A**: Edit `KNOWN_GROUPS` in `/lib/apicurio.ts`. Currently only two groups are supported.

### Q: Where are the templates coming from?
**A**: 
- `https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/paradigm.bidtools2/artifacts/`
- `https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/bfs.online/artifacts/`

---

## ✅ Verification

Before considering this complete, verify:

- [ ] No references to `getMockApicurioArtifacts` in codebase
- [ ] No references to `getMockArtifactSchema` in codebase
- [ ] All tests in checklist pass
- [ ] Console shows real API calls
- [ ] Only two groups appear in templates
- [ ] Cache works correctly
- [ ] Error handling works

---

## 📞 Support

If you encounter issues:

1. **Check console** - Look for error messages
2. **Check cache** - `localStorage.getItem('apicurio_artifacts_cache')`
3. **Clear cache** - `clearArtifactsCache()`
4. **Verify API** - Test endpoints directly with curl/Postman
5. **Read docs** - This index → specific document
6. **Check network** - DevTools → Network tab → Filter: apicurio

---

**Date**: November 28, 2024  
**Version**: 1.0 (No Mock Data)  
**Status**: ✅ Production Ready

**Maintainer**: Development Team  
**Last Review**: November 28, 2024
