# ✅ Data Capture Schemas теперь в таблице (Expandable Rows)

## 🎯 Что изменено

Data Capture Schemas теперь отображаются **прямо в таблице** с помощью expandable rows, а не в popup-диалоге. Просто кликни на chevron чтобы развернуть Data Source и увидеть 4 схемы.

---

## 🖼️ Как выглядит

```
┌────────────────────────────────────────────────────────────────┐
│ Search...                                         [Clear]      │
├────────────────────────────────────────────────────────────────┤
│  ▽  │ ID              │ Name      │ Created   │ Updated │ ...│
├─────┼─────────────────┼───────────┼───────────┼─────────┼────┤
│  ▼  │ datasource_...  │ Bidtools  │10/31/2025 │11/1/2025│... │
├─────┴─────────────────────────────────────────────────────────┤
│     📘 Quotes                                    [54 fields] ▶│
│     📗 QuotePacks                                [30 fields] ▶│
│     📙 QuoteDetails                              [53 fields] ▶│
│     📕 QuotePackOrder                            [12 fields] ▶│
├────────────────────────────────────────────────────────────────┤
│  ▶  │ datasource_...  │Databricks │10/27/2025 │10/27/2025│...│
└────────────────────────────────────────────────────────────────┘
```

---

## ✨ Функциональность

### 1. Expandable Row

**Клик на Chevron:**
```
▶ Свернуто  → Показывает только основную строку
▼ Развернуто → Показывает Data Capture Schemas под строкой
```

**Chevron Icons:**
```
▶ ChevronRight - строка свернута
▼ ChevronDown  - строка развернута
```

---

### 2. Data Capture Schemas Accordion

**При разворе строки показываются 4 схемы:**

```
📘 Quotes           [54 fields] ▶
📗 QuotePacks       [30 fields] ▶
📙 QuoteDetails     [53 fields] ▶
📕 QuotePackOrder   [12 fields] ▶
```

**При клике на схему:**
```
📘 Quotes           [54 fields] ▼
┌──────────────────────────────────┐
│ {                                │
│   "before": null,                │
│   "after": {                     │
│     "QuoteId": 132821,          │
│     "CustomerId": 63341,        │
│     ...                          │
│   }                              │
│ }                                │
└──────────────────────────────────┘
```

---

### 3. JSON Display

**Особенности:**
```
✅ Pretty print (indent = 2)
✅ Horizontal scroll (overflow-x-auto)
✅ Vertical scroll max-h-[300px]
✅ Border вокруг
✅ Белый фон (bg-background)
✅ Маленький шрифт (text-xs)
```

---

## 💻 Технические детали

### DataTable.tsx - Добавлена expandable функциональность

**Новые props:**
```typescript
interface DataTableProps<T> {
  // ... existing props
  expandable?: boolean;
  renderExpandedContent?: (item: T) => React.ReactNode;
  getRowId?: (item: T) => string;
}
```

**State для expandable rows:**
```typescript
const [expandedRows, setExpandedRows] = useState<Set<string>>(new Set());

const toggleRow = (rowId: string) => {
  const newExpanded = new Set(expandedRows);
  if (newExpanded.has(rowId)) {
    newExpanded.delete(rowId);
  } else {
    newExpanded.add(rowId);
  }
  setExpandedRows(newExpanded);
};
```

**Rendering:**
```tsx
<Fragment key={rowId}>
  {/* Main Row */}
  <TableRow>
    {expandable && (
      <TableCell>
        <Button onClick={() => toggleRow(rowId)}>
          {isExpanded ? <ChevronDown /> : <ChevronRight />}
        </Button>
      </TableCell>
    )}
    {/* ... columns ... */}
  </TableRow>
  
  {/* Expanded Content Row */}
  {expandable && isExpanded && renderExpandedContent && (
    <TableRow>
      <TableCell colSpan={colSpan} className="p-0 bg-muted/30">
        <div className="p-4">
          {renderExpandedContent(item)}
        </div>
      </TableCell>
    </TableRow>
  )}
</Fragment>
```

---

### DataSourcesView.tsx - Использование expandable

**DataTable с expandable:**
```tsx
<DataTable
  data={dataSources}
  columns={columns}
  expandable={true}
  getRowId={(row) => getDataSourceId(row)}
  renderExpandedContent={(row) => (
    <div className="space-y-3">
      <Accordion type="single" collapsible>
        {/* 4 schemas */}
      </Accordion>
    </div>
  )}
  actions={(row) => (/* ... */)}
/>
```

**Expanded Content - Accordion с 4 схемами:**
```tsx
<Accordion type="single" collapsible className="w-full">
  <AccordionItem value="quotes">
    <AccordionTrigger className="text-sm hover:no-underline py-2">
      <div className="flex items-center gap-2">
        <Database className="h-4 w-4 text-blue-500" />
        <span>Quotes</span>
        <Badge variant="outline" className="ml-2 text-xs">
          {Object.keys(mockDataCaptureSchemas.Quotes.after).length} fields
        </Badge>
      </div>
    </AccordionTrigger>
    <AccordionContent>
      <div className="rounded-md border bg-background p-3 mt-2">
        <pre className="text-xs overflow-x-auto max-h-[300px] overflow-y-auto">
          {JSON.stringify(mockDataCaptureSchemas.Quotes, null, 2)}
        </pre>
      </div>
    </AccordionContent>
  </AccordionItem>
  {/* QuotePacks, QuoteDetails, QuotePackOrder */}
</Accordion>
```

---

### Detail Dialog - Упрощён

**Убрано:**
```
❌ Data Capture Schemas секция
❌ Separator
❌ Accordion с схемами
```

**Осталось:**
```
✅ Basic Information (все поля Data Source)
✅ Connection String замаскирован (••••••••)
✅ Close button
```

**Размер вернулся:**
```
max-w-2xl     (было max-w-4xl)
max-h-[80vh]  (было max-h-[85vh])
```

---

## 🎨 Дизайн

### Expandable Row Background

```css
bg-muted/30  /* Светло-серый фон для expanded content */
```

### Chevron Button

```tsx
<Button
  variant="ghost"
  size="sm"
  className="h-6 w-6 p-0"
>
  {isExpanded ? <ChevronDown /> : <ChevronRight />}
</Button>
```

### Accordion Styling

```tsx
<AccordionTrigger className="text-sm hover:no-underline py-2">
  {/* Уменьшенный padding для компактности */}
</AccordionTrigger>
```

### JSON Container

```tsx
<pre className="text-xs overflow-x-auto max-h-[300px] overflow-y-auto">
  {/* 
    - text-xs: маленький шрифт
    - overflow-x-auto: горизонтальный скролл
    - max-h-[300px]: максимальная высота
    - overflow-y-auto: вертикальный скролл
  */}
</pre>
```

---

## 🔄 Поведение

### 1. Expand/Collapse Row

**Клик на Chevron:**
```
Клик → Разворачивает строку
      → Показывает 4 схемы
      → Chevron меняется ▶ → ▼

Клик снова → Сворачивает строку
            → Скрывает схемы
            → Chevron меняется ▼ → ▶
```

### 2. Multiple Rows

```
✅ Можно развернуть несколько строк одновременно
✅ Каждая строка независима
✅ State хранится в Set<string>
```

### 3. Accordion в Expanded Content

```
✅ type="single" - только один schema открыт
✅ collapsible - можно закрыть все
✅ Smooth анимация
```

### 4. Pagination

```
✅ Expanded state сохраняется при pagination
✅ Каждая страница показывает свои expanded rows
✅ При изменении page size - expanded rows сохраняются
```

---

## 🧪 Тестирование

### Шаги:

1. **Открой Data Source Onboarding**
   ```
   App → Data Source Onboarding tab
   ```

2. **Проверь Chevron column**
   ```
   ✅ Новая колонка слева с chevron icons
   ✅ Все rows имеют ▶ icon
   ```

3. **Разверни Bidtools**
   ```
   Клик на ▶ для Bidtools
   ✅ Icon меняется на ▼
   ✅ Показывается expanded content
   ✅ 4 схемы видны
   ```

4. **Проверь схемы**
   ```
   ✅ 📘 Quotes [54 fields]
   ✅ 📗 QuotePacks [30 fields]
   ✅ 📙 QuoteDetails [53 fields]
   ✅ 📕 QuotePackOrder [12 fields]
   ```

5. **Разверни Quotes schema**
   ```
   Клик на "Quotes"
   ✅ JSON отображается
   ✅ Pretty print работает
   ✅ Scrolling работает
   ```

6. **Разверни Databricks row**
   ```
   Клик на ▶ для Databricks
   ✅ Bidtools остаётся развернутым
   ✅ Databricks развернулся
   ✅ Оба показывают schemas
   ```

7. **Сверни Bidtools**
   ```
   Клик на ▼ для Bidtools
   ✅ Icon меняется на ▶
   ✅ Schemas скрываются
   ✅ Databricks остаётся развернутым
   ```

8. **Проверь View button**
   ```
   Клик на View для Bidtools
   ✅ Dialog открывается
   ✅ Показывает только Basic Information
   ✅ НЕТ Data Capture Schemas секции
   ✅ НЕТ Separator
   ```

9. **Проверь responsive**
   ```
   ✅ Mobile: Chevron работает
   ✅ Expanded content занимает всю ширину
   ✅ JSON с horizontal scroll
   ```

10. **Проверь pagination**
    ```
    ✅ Разверни row на странице 1
    ✅ Перейди на страницу 2
    ✅ Вернись на страницу 1
    ✅ Row всё ещё развёрнут
    ```

---

## ✅ Преимущества нового подхода

### Было (Popup):

```
❌ Нужно кликнуть View
❌ Открывается большой Dialog
❌ Нужно скроллить вниз до schemas
❌ Нужно закрыть dialog
❌ Потеря контекста таблицы
```

### Стало (Expandable Rows):

```
✅ Один клик на chevron
✅ Schemas прямо в таблице
✅ Видна вся таблица
✅ Контекст сохраняется
✅ Быстрый доступ
✅ Можно сравнивать schemas между разными data sources
```

---

## 📊 Статистика

### Код изменён:

**DataTable.tsx:**
```
+ 30 lines   - Expandable functionality
+ Fragment   - Для rendering expanded rows
+ ChevronDown/Right icons
```

**DataSourcesView.tsx:**
```
+ expandable={true}
+ getRowId prop
+ renderExpandedContent with 4 schemas
- Data Capture Schemas из Dialog
- Separator
```

**Итого:**
```
+ ~80 lines добавлено
- ~120 lines удалено (из Dialog)
= Чище и компактнее!
```

---

### Размер компонентов:

**Detail Dialog:**
```
Было: max-w-4xl (896px)
Стало: max-w-2xl (672px)
Уменьшилось на: 224px (25%)
```

**Expandable Content:**
```
Width: 100% таблицы (адаптивно)
Height: Auto (зависит от accordion)
Max JSON height: 300px с scroll
```

---

## 🚀 Дальнейшие улучшения

### 1. Schema Counts (будущее)

**Сейчас:**
```tsx
{Object.keys(mockDataCaptureSchemas.Quotes.after).length} fields
```

**Будет (real data):**
```tsx
{schema.fieldCount} fields
```

---

### 2. Schema Search

```tsx
<Input 
  placeholder="Search in schema..." 
  onChange={(e) => filterSchemaFields(e.target.value)}
/>
```

---

### 3. Copy JSON

```tsx
<Button 
  size="sm" 
  variant="outline"
  onClick={() => copyToClipboard(JSON.stringify(schema))}
>
  <Copy className="h-4 w-4 mr-1" />
  Copy JSON
</Button>
```

---

### 4. Expand All / Collapse All

```tsx
<div className="flex gap-2 mb-2">
  <Button size="sm" onClick={expandAllRows}>
    Expand All
  </Button>
  <Button size="sm" onClick={collapseAllRows}>
    Collapse All
  </Button>
</div>
```

---

### 5. API Integration

**Сейчас:**
```tsx
const mockDataCaptureSchemas = { ... };
```

**Будет:**
```tsx
const [schemas, setSchemas] = useState<SchemaType[]>([]);

useEffect(() => {
  fetchDataCaptureSchemas(dataSourceId).then(setSchemas);
}, [dataSourceId]);
```

---

## ✅ Что готово

```
✅ DataTable поддерживает expandable rows
✅ Chevron icons для expand/collapse
✅ Data Capture Schemas в таблице
✅ Accordion с 4 схемами
✅ JSON pretty print с scroll
✅ Цветные иконки для schemas
✅ Badges с количеством полей
✅ Detail Dialog упрощён
✅ Multiple rows можно разворачивать
✅ State сохраняется при pagination
✅ Responsive design
```

---

## 📝 Чеклист

```
□ Data Source Onboarding tab открыт
□ Chevron column видна
□ Клик на chevron работает
□ Row разворачивается/сворачивается
□ 4 schemas показываются:
  □ 📘 Quotes
  □ 📗 QuotePacks
  □ 📙 QuoteDetails
  □ 📕 QuotePackOrder
□ Accordion работает
□ JSON отображается корректно
□ Scrolling работает (horizontal + vertical)
□ Multiple rows можно развернуть
□ View button открывает упрощённый dialog
□ НЕТ schemas в detail dialog
□ Responsive на mobile работает
```

---

**Статус:** ✅ Готово  
**Дата:** 3 ноября 2025  
**Файлы изменены:**
- `/components/DataTable.tsx` - добавлена expandable функциональность
- `/components/DataSourcesView.tsx` - schemas в таблице вместо dialog

Data Capture Schemas теперь доступны прямо в таблице! 🎉
