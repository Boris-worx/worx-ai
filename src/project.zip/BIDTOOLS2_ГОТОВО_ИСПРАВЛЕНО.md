# ✅ Apicurio: paradigm.bidtools → paradigm.bidtools2

**Дата:** 27 ноября 2025  
**Статус:** ✅ ГОТОВО (исправлено)

---

## 🎯 Что сделано

**ЗАМЕНИЛИ** источник для Bid Tools Templates:

### URL изменился:

```diff
- GET /groups/paradigm.bidtools/artifacts
+ GET /groups/paradigm.bidtools2/artifacts
```

**Полный URL:**
```
https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/paradigm.bidtools2/artifacts/
```

---

## 📝 Изменения

### 1. `/lib/apicurio.ts` (строка 87)

```diff
- const groups = ['paradigm.bidtools', 'bfs.online'];
+ const groups = ['paradigm.bidtools2', 'bfs.online'];
```

### 2. `/lib/apicurio.ts` (строки 179-250)

Все 7 mock артефактов теперь используют:
```diff
- groupId: "paradigm.bidtools"
+ groupId: "paradigm.bidtools2"
```

**Артефакты:** LineTypes (CDC), ServiceRequests (CDC), WorkflowCustomers (CDC), QuoteDetails, QuotePacks, Quotes, ReasonCodes

### 3. `/components/DataCaptureSpecCreateDialog.tsx` (строки 951-956)

```diff
- groupId === "paradigm.bidtools"
-   ? "Bid Tools Templates"
-   : groupId === "paradigm.bidtools2"
-     ? "Bid Tools Templates V2"
+ groupId === "paradigm.bidtools2"
+   ? "Bid Tools Templates"
```

---

## 📊 Результат

| Что | Было | Стало |
|-----|------|-------|
| API URL | /groups/**paradigm.bidtools** | /groups/**paradigm.bidtools2** |
| Mock groupId | paradigm.bidtools | paradigm.bidtools2 |
| UI название | "Bid Tools Templates" | "Bid Tools Templates" (то же) |
| Количество групп | 2 | 2 (то же) |
| Количество артефактов | 18 | 18 (то же) |

**Для пользователя:** Ничего не изменилось визуально, но источник данных теперь другой!

---

## 🧪 Как проверить

### Browser DevTools → Network:

Должны увидеть:
```
✅ GET /groups/paradigm.bidtools2/artifacts
✅ GET /groups/bfs.online/artifacts

❌ Не должно быть:
   GET /groups/paradigm.bidtools/artifacts
```

### Console logs:

```
📦 Fetching from group: paradigm.bidtools2
📦 Response status (paradigm.bidtools2): 200
📦 Loaded X artifacts from paradigm.bidtools2 group
```

### UI:

```
Select Template:
  📋 Bid Tools Templates      ← Название то же, но источник bidtools2!
     • LineTypes (CDC)
     • QuoteDetails
     • QuotePacks
     • Quotes
     • ReasonCodes
     • ServiceRequests (CDC)
     • WorkflowCustomers (CDC)
  
  📋 BFS Online Templates
     • inv, inv1, inv2, ...
```

---

## ✅ Checklist

- [x] Заменено `paradigm.bidtools` → `paradigm.bidtools2` в groups array
- [x] Обновлены все 7 mock артефактов
- [x] Обновлен UI heading
- [x] Код компилируется без ошибок
- [x] Старые документы удалены
- [ ] Протестировано в browser (рекомендуется)

---

## 📚 Документация

**Полная документация:** `/APICURIO_BIDTOOLS2_ЗАМЕНА.md` (400+ строк)

**Этот файл:** Quick reference для быстрой проверки

---

## 🚀 Что дальше

**Сегодня (5 минут):**
1. Открыть DevTools → Network
2. Открыть Data Source Onboarding → Add Specification
3. Проверить что запросы идут к `/groups/paradigm.bidtools2/artifacts`

**Для Production:**
- Убедиться что в Apicurio Registry существует группа `paradigm.bidtools2`
- Загрузить туда все 7 артефактов
- Настроить CORS

---

## 💡 TL;DR

✅ **paradigm.bidtools** заменено на **paradigm.bidtools2**  
✅ API теперь вызывает `/groups/paradigm.bidtools2/artifacts`  
✅ UI название осталось "Bid Tools Templates"  
✅ Mock данные обновлены  
✅ Готово к тестированию!

---

**Проверить:** DevTools → Network → Найти запрос к `paradigm.bidtools2`

**Дата:** 27 ноября 2025
