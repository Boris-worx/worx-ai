# Инструкция по тестированию GLOBAL TENANT

## Быстрый тест

### Шаг 1: Проверка изоляции для конкретного тенанта

1. Откройте приложение BFS Portal
2. Войдите как **Portal.SuperUser**
3. Перейдите на вкладку **Data Sources**
4. Выберите тенант **BFS** в селекторе тенантов (правый верхний угол)
5. **Ожидаемый результат:** Видите только data sources с `TenantId = BFS`

### Шаг 2: Создание нового data source

1. Находясь на тенанте **BFS**, нажмите **Add Data Source**
2. Введите имя: `test-global-isolation`
3. Нажмите **Create**
4. **Ожидаемый результат:** Data source создан с `TenantId = BFS`

### Шаг 3: Проверка GLOBAL TENANT

1. В селекторе тенантов выберите **GLOBAL TENANT**
2. **Ожидаемый результат:** Видите ВСЕ data sources из ВСЕХ тенантов:
   - Data sources из BFS (включая `test-global-isolation`)
   - Data sources из Meritage
   - Data sources из PIM
   - Data sources из других тенантов

### Шаг 4: Проверка обратного переключения

1. Переключитесь обратно на тенант **BFS**
2. **Ожидаемый результат:** Видите только data sources BFS
3. Data sources из других тенантов НЕ видны

### Шаг 5: Проверка в консоли браузера

Откройте DevTools (F12) → Console и найдите логи:

```
📡 Fetching data sources for GLOBAL tenant (all tenants)...
✅ Loaded 5 data sources for tenant BFS
✅ Loaded 3 data sources for tenant Meritage
✅ Loaded 2 data sources for tenant PIM
✅ Total data sources from all tenants: 10
```

При переключении на BFS:

```
✅ Loaded 5 data sources for tenant BFS
```

## Детальный тест

### Тест 1: GLOBAL TENANT видит все

**Шаги:**
1. Login: Portal.SuperUser
2. Tab: Data Sources
3. Tenant: GLOBAL TENANT

**Проверить:**
- [ ] Видны data sources из BFS
- [ ] Видны data sources из Meritage
- [ ] Видны data sources из PIM
- [ ] Видны data sources из всех других тенантов
- [ ] Колонка "Tenant ID" показывает разные значения

**Как проверить количество:**
```javascript
// В консоли браузера
console.log('Total data sources:', document.querySelectorAll('table tbody tr').length);
```

### Тест 2: Конкретный тенант видит только свои

**Шаги:**
1. Login: Portal.SuperUser
2. Tab: Data Sources
3. Tenant: BFS

**Проверить:**
- [ ] Видны ТОЛЬКО data sources с TenantId = "BFS"
- [ ] НЕ видны data sources из Meritage
- [ ] НЕ видны data sources из PIM
- [ ] Колонка "Tenant ID" показывает только "BFS"

### Тест 3: Создание и видимость

**Шаги:**
1. Tenant: BFS
2. Create data source "test-bfs-1"
3. Убедиться что виден в списке BFS
4. Switch to GLOBAL TENANT
5. Найти "test-bfs-1" в списке
6. Проверить что TenantId = "BFS"

**Проверить:**
- [ ] Data source создан для правильного тенанта
- [ ] Виден в режиме конкретного тенанта
- [ ] Виден в режиме GLOBAL TENANT
- [ ] Колонка TenantId корректна

### Тест 4: Удаление и изоляция

**Шаги:**
1. Tenant: BFS
2. Create data source "test-delete-bfs"
3. Switch to Meritage
4. Убедиться что "test-delete-bfs" НЕ виден
5. Switch to GLOBAL TENANT
6. Найти "test-delete-bfs"
7. Delete "test-delete-bfs"
8. Switch to BFS
9. Убедиться что "test-delete-bfs" удален

**Проверить:**
- [ ] Data source виден только своему тенанту
- [ ] Data source виден в GLOBAL
- [ ] Удаление работает
- [ ] После удаления не виден нигде

### Тест 5: Multiple tenants

**Шаги:**
1. Create "test-bfs" для BFS
2. Create "test-meritage" для Meritage
3. Create "test-pim" для PIM
4. Switch to GLOBAL TENANT

**Проверить:**
- [ ] Все три data sources видны в GLOBAL
- [ ] test-bfs имеет TenantId = "BFS"
- [ ] test-meritage имеет TenantId = "Meritage"
- [ ] test-pim имеет TenantId = "PIM"

**Переключиться на каждый тенант:**
- [ ] BFS видит только test-bfs
- [ ] Meritage видит только test-meritage
- [ ] PIM видит только test-pim

## Проверка через API (curl)

### GLOBAL: все data sources

```bash
# BFS
curl -X GET "https://dp-eastus-poc-txservices-apis.azurewebsites.net/datasources?Filters=%7B%22TenantId%22%3A%22BFS%22%7D" \
  -H "X-BFS-Auth: dummytoken123" | jq '.data.DataSources | length'

# Meritage
curl -X GET "https://dp-eastus-poc-txservices-apis.azurewebsites.net/datasources?Filters=%7B%22TenantId%22%3A%22Meritage%22%7D" \
  -H "X-BFS-Auth: dummytoken123" | jq '.data.DataSources | length'

# PIM
curl -X GET "https://dp-eastus-poc-txservices-apis.azurewebsites.net/datasources?Filters=%7B%22TenantId%22%3A%22PIM%22%7D" \
  -H "X-BFS-Auth: dummytoken123" | jq '.data.DataSources | length'
```

**Сумма должна соответствовать количеству в GLOBAL TENANT**

### Конкретный тенант

```bash
# BFS data sources
curl -X GET "https://dp-eastus-poc-txservices-apis.azurewebsites.net/datasources?Filters=%7B%22TenantId%22%3A%22BFS%22%7D" \
  -H "X-BFS-Auth: dummytoken123" | jq '.data.DataSources[] | {name: .DatasourceName, tenant: .TenantId}'
```

**Все TenantId должны быть "BFS"**

## Проверка производительности

### Время загрузки GLOBAL TENANT

```javascript
// В консоли браузера перед переключением на GLOBAL
console.time('global-load');

// После полной загрузки
console.timeEnd('global-load');
```

**Ожидаемое время:**
- 1-3 тенанта: < 2 секунд
- 4-10 тенантов: 2-5 секунд
- 10+ тенантов: < 10 секунд

### Оптимизация

Если время загрузки > 10 секунд:
1. Проверьте количество data sources в каждом тенанте
2. Рассмотрите пагинацию на уровне API
3. Рассмотрите кэширование

## Известные ограничения

### 1. Параллельные запросы

GLOBAL TENANT делает **параллельные запросы** для каждого тенанта:

```typescript
const promises = tenants.map(tenant => getAllDataSources(tenant.TenantId));
const results = await Promise.all(promises);
```

**Лимиты:**
- Браузер может ограничивать количество параллельных запросов (обычно 6)
- При большом количестве тенантов (>20) может потребоваться батчинг

### 2. Ошибки отдельных тенантов

Если один тенант недоступен, остальные все равно загрузятся:

```typescript
const promises = tenants.map(async (tenant) => {
  try {
    return await getAllDataSources(tenant.TenantId);
  } catch (error) {
    console.error(`Failed for ${tenant.TenantId}:`, error);
    return []; // Вернуть пустой массив
  }
});
```

### 3. Размер данных

При большом количестве data sources (>1000) рассмотрите:
- Пагинацию на уровне API
- Virtual scrolling в UI
- Ленивую загрузку

## Чеклист перед релизом

- [ ] GLOBAL TENANT видит все data sources
- [ ] Конкретный тенант видит только свои data sources
- [ ] Создание data source корректно устанавливает TenantId
- [ ] Удаление работает корректно
- [ ] Время загрузки GLOBAL приемлемое (< 10 сек)
- [ ] Логи в консоли информативные
- [ ] Нет ошибок в консоли
- [ ] UI responsive во время загрузки
- [ ] Toast notifications корректные
- [ ] Фильтрация и сортировка работают
- [ ] Column selector работает
- [ ] Search работает
- [ ] Expandable rows работают
- [ ] Data Capture Specs корректны

## Troubleshooting

### Проблема: GLOBAL не видит все data sources

**Проверить:**
1. Логи в консоли - какие запросы делаются?
2. Network tab - все ли запросы успешны?
3. Есть ли ошибки для конкретных тенантов?

**Решение:**
- Проверьте `/App.tsx` функцию `refreshDataSources()`
- Убедитесь что `tenants.length > 0` перед загрузкой

### Проблема: Дублирование data sources

**Причина:** Возможно один data source принадлежит нескольким тенантам

**Проверить:**
```javascript
// В консоли
const datasources = /* массив из API */;
const ids = datasources.map(ds => ds.DatasourceId);
const duplicates = ids.filter((id, index) => ids.indexOf(id) !== index);
console.log('Duplicates:', duplicates);
```

### Проблема: Медленная загрузка

**Проверить:**
1. Network tab - какие запросы медленные?
2. Количество тенантов
3. Количество data sources в каждом тенанте

**Решение:**
- Уменьшить размер ответа API (pagination)
- Кэшировать результаты
- Показывать прогресс загрузки

## Дополнительные ресурсы

- `/GLOBAL_TENANT_DATASOURCES_FIX_RU.md` - детали исправления
- `/TENANT_ISOLATION_RU.md` - архитектура изоляции
- `/DATASOURCE_CURL_TEST_RU.md` - тестирование через curl

## Контакты

При возникновении проблем обращайтесь к BFS Portal Development Team
