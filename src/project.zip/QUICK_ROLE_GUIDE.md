# Quick Role Guide

## 🚀 TL;DR

New role system with 5 roles:
- **SuperUser** → Manages everything including tenants ⭐
- **ViewOnlySuperUser** → Reads everything, changes nothing 👀
- **Admin** → Full control of transactions/data (no tenants) 🔧
- **Developer** → Full control of transactions/data (no tenants) 💻
- **Viewer** → Reads transactions/data only (no tenants) 📊

## 🎯 Quick Test (Local Dev)

Login with these credentials:

```
SuperUser:           superuser / super123
ViewOnlySuperUser:   viewonlysuperuser / viewsuper123
Admin:               admin / admin123
Developer:           developer / dev123
Viewer:              viewer / view123
```

## 🔑 Role Testing Dialog

1. Click **user icon** (top-right)
2. Select **"Change Role & Access"**
3. Pick a role to test
4. Click **"Apply Changes"**
5. See permissions change instantly!

## 📊 What Each Role Can Do

### SuperUser (God Mode)
✅ View/Create/Edit/Delete Tenants  
✅ View/Create/Edit/Delete Transactions  
✅ View/Create/Edit/Delete Data Sources  
✅ View/Create/Edit/Delete Model Schemas  

### ViewOnlySuperUser (Read Everything)
✅ View Tenants  
✅ View Transactions  
✅ View Data Sources  
✅ View Model Schemas  
❌ No Create/Edit/Delete anywhere

### Admin (Tenant Admin)
❌ Cannot access Tenants section  
✅ View/Create/Edit/Delete Transactions  
✅ View/Create/Edit/Delete Data Sources  
✅ View/Create/Edit/Delete Model Schemas  

### Developer (Same as Admin)
❌ Cannot access Tenants section  
✅ View/Create/Edit/Delete Transactions  
✅ View/Create/Edit/Delete Data Sources  
✅ View/Create/Edit/Delete Model Schemas  

### Viewer (Read Tenant Data)
❌ Cannot access Tenants section  
✅ View Transactions (read-only)  
✅ View Data Sources (read-only)  
✅ View Model Schemas (read-only)  
❌ No Create/Edit/Delete

## 🔐 Azure AD Setup (5 min)

1. Go to **Azure Portal** → **App Registrations** → Your App
2. Click **App roles** → **Create app role**
3. Add these 5 roles:

```
Display Name: SuperUser
Value: Portal.SuperUser
Description: Full access including tenant management

Display Name: View-Only SuperUser  
Value: Portal.ViewOnlySuperUser
Description: Read-only access to everything

Display Name: Admin
Value: Portal.Admin
Description: Read/write for transactions + data plane

Display Name: Developer
Value: Portal.Developer
Description: Read/write for transactions + data plane

Display Name: Viewer
Value: Portal.Viewer
Description: Read-only for transactions + data plane
```

4. Go to **Enterprise Applications** → Your App → **Users and groups**
5. Assign users to roles

Done! 🎉

## 🎨 Visual Guide

```
┌─────────────────────────────────────────────┐
│  SECTION ACCESS BY ROLE                     │
├─────────────────────────────────────────────┤
│                                             │
│  Tenants Tab:                               │
│    ✅ SuperUser (CRUD)                       │
│    ✅ ViewOnlySuperUser (Read)               │
│    ❌ Admin, Developer, Viewer               │
│                                             │
│  Transaction Onboarding Tab:                │
│    ✅ SuperUser (CRUD)                       │
│    ✅ Admin (CRUD)                           │
│    ✅ Developer (CRUD)                       │
│    ✅ ViewOnlySuperUser (Read)               │
│    ✅ Viewer (Read)                          │
│                                             │
│  Data Source Onboarding Tab:                │
│    ✅ SuperUser (CRUD)                       │
│    ✅ Admin (CRUD)                           │
│    ✅ Developer (CRUD)                       │
│    ✅ ViewOnlySuperUser (Read)               │
│    ✅ Viewer (Read)                          │
│                                             │
│  Data Plane Tab:                            │
│    ✅ SuperUser (CRUD)                       │
│    ✅ Admin (CRUD)                           │
│    ✅ Developer (CRUD)                       │
│    ✅ ViewOnlySuperUser (Read)               │
│    ✅ Viewer (Read)                          │
│                                             │
└─────────────────────────────────────────────┘
```

## ❓ Common Questions

**Q: What's the difference between Admin and Developer?**  
A: Functionally the same. Use "Admin" for business users, "Developer" for technical users.

**Q: Can Viewer see Tenants?**  
A: No. Only SuperUser and ViewOnlySuperUser can access the Tenants section.

**Q: Can Admin create new tenants?**  
A: No. Only SuperUser can create/edit/delete tenants.

**Q: How do I test roles without logging out?**  
A: Use the Role Testing Dialog (click user icon → "Change Role & Access")

**Q: Will role testing affect other users?**  
A: No. Role testing is local to your browser session only.

## 🔗 More Details

- Full documentation: `/ROLE_HIERARCHY.md`
- Migration guide: `/ROLE_MIGRATION_COMPLETE.md`
- Azure RBAC: `/AZURE_RBAC_GUIDE.md`
