# 🚀 Apicurio Cheatsheet

**Quick reference для работы с Apicurio Templates**

---

## 📋 Что изменилось (TL;DR)

```diff
- GET /groups/paradigm.bidtools/artifacts
+ GET /groups/paradigm.bidtools2/artifacts
```

**3 файла изменены, 6 мест в коде**

---

## 🎯 Ожидаемые артефакты (18 total)

### paradigm.bidtools2 (7):

```
CDC (AVRO):
  • CDC_SQLServer_LineTypes
  • CDC_SQLServer_ServiceRequests
  • CDC_SQLServer_WorkflowCustomers

TxServices (JSON):
  • TxServices_SQLServer_QuoteDetails.response
  • TxServices_SQLServer_QuotePacks.response
  • TxServices_SQLServer_Quotes.response
  • TxServices_SQLServer_ReasonCodes.response
```

### bfs.online (11):

```
Informix (JSON):
  • TxServices_Informix_loc1.response
  • TxServices_Informix_loc.response
  • TxServices_Informix_stcode.response
  • TxServices_Informix_inv.response
  • TxServices_Informix_inv1.response
  • TxServices_Informix_inv2.response
  • TxServices_Informix_inv3.response
  • TxServices_Informix_invap.response
  • TxServices_Informix_invdes.response
  • TxServices_Informix_invloc.response
  • TxServices_Informix_keyi.response
```

---

## 🧪 Quick Test (curl)

### Проверить группу paradigm.bidtools2:

```bash
curl "https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/paradigm.bidtools2/artifacts?limit=100"

# Ожидаемый результат: 7 артефактов
```

### Проверить группу bfs.online:

```bash
curl "https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/bfs.online/artifacts?limit=100"

# Ожидаемый результат: 11 артефактов
```

### Получить конкретную схему:

```bash
# QuoteDetails (JSON)
curl "https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/paradigm.bidtools2/artifacts/TxServices_SQLServer_QuoteDetails.response/versions/branch=latest/content"

# LineTypes CDC (AVRO)
curl "https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/paradigm.bidtools2/artifacts/CDC_SQLServer_LineTypes/versions/1.0.0/content"
```

---

## 🌐 Quick Test (Browser)

```
1. Open DevTools → Network
2. Open Data Source Onboarding
3. Click "Add Specification"
4. Check requests:
   ✅ GET /groups/paradigm.bidtools2/artifacts
   ✅ GET /groups/bfs.online/artifacts
   ❌ Should NOT see: /groups/paradigm.bidtools/artifacts
```

---

## 📊 URL Patterns

```
List artifacts:
  /groups/{groupId}/artifacts?limit=100

Get artifact (paradigm.bidtools2):
  /groups/paradigm.bidtools2/artifacts/{artifactId}/versions/1/content
  
Get artifact (bfs.online):
  /groups/bfs.online/artifacts/{artifactId}/versions/1.0.0/content
```

## 🔑 Version Logic

```
paradigm.bidtools2 → version: "1"
bfs.online         → version: "1.0.0"
```

---

## 🔍 Troubleshooting

### 403 Forbidden
```
✅ Normal! App uses mock data automatically
```

### Группа не отображается
```
1. Clear cache: clearArtifactsCache()
2. Hard reload: Ctrl + Shift + R
3. Check console logs
```

### Запросы идут к старой группе
```
1. Clear browser cache
2. Verify code updated
3. Hard reload
```

---

## 📚 Documentation

| Need | File | Time |
|------|------|------|
| Quick start | `/ГОТОВО.txt` | 30 sec |
| Summary | `/BIDTOOLS2_ГОТОВО_ИСПРАВЛЕНО.md` | 5 min |
| Full list | `/APICURIO_ARTIFACTS_TABLE.md` | 2 min |
| Full guide | `/APICURIO_BIDTOOLS2_ЗАМЕНА.md` | 15 min |
| All docs | `/APICURIO_DOCS_INDEX.md` | - |

---

## ✅ Checklist

**Code:**
- [x] groups array updated
- [x] mock data updated (7 artifacts)
- [x] UI heading updated
- [x] ApicurioConnectionTest updated

**Testing:**
- [ ] Browser test (5 min)
- [ ] curl test (5 min)
- [ ] UI check (2 min)

**Production:**
- [ ] Apicurio groups created
- [ ] Artifacts uploaded (18 total)
- [ ] CORS configured

---

## 🎯 Key Facts

```
Файлов изменено:     3
Мест в коде:         6
Всего групп:         2
Всего артефактов:    18 (7 + 11)
Форматов:            AVRO (3) + JSON (15)
```

---

## 🚀 Next Steps

```
1. Test in browser (5 min)
2. Verify curl requests (5 min)
3. Check UI display (2 min)
4. Setup Apicurio (if needed)
```

---

**Created:** 27.11.2025  
**Status:** ✅ Ready
