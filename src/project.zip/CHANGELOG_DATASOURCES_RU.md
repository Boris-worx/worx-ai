# Changelog - Data Sources Improvements

## 2025-11-13 - GLOBAL TENANT Isolation Fix

### Проблема
При фильтрации по GLOBAL TENANT не отображались data sources из других тенантов. Например, data source "check-delete" (BFS) был виден при фильтре BFS, но не был виден при фильтре GLOBAL TENANT.

### Решение
Изменена логика загрузки data sources в `/App.tsx`:

**Было:**
```typescript
const tenantIdFilter = activeTenantId !== 'global' ? activeTenantId : undefined;
const dataSourcesData = await getAllDataSources(tenantIdFilter);
```

**Стало:**
```typescript
if (activeTenantId === 'global') {
  // Загружаем из ВСЕХ тенантов параллельно
  const promises = tenants.map(tenant => getAllDataSources(tenant.TenantId));
  const results = await Promise.all(promises);
  allDataSources = results.flat();
} else {
  // Загружаем только для конкретного тенанта
  allDataSources = await getAllDataSources(activeTenantId);
}
```

### Затронутые файлы
- `/App.tsx` - функция `refreshDataSources()` и useEffect хуки
- Создана документация `/GLOBAL_TENANT_DATASOURCES_FIX_RU.md`
- Создана документация `/TENANT_ISOLATION_RU.md`
- Создана документация `/TESTING_GLOBAL_TENANT_RU.md`

### Результат
- ✅ GLOBAL TENANT теперь видит data sources из ВСЕХ тенантов
- ✅ Конкретный тенант видит только свои data sources
- ✅ Параллельные запросы для оптимизации производительности
- ✅ Детальное логирование для диагностики

### Testing
```bash
# Проверка через UI
1. Select GLOBAL TENANT -> видите все data sources
2. Select BFS -> видите только BFS data sources
3. Create data source в BFS -> виден в BFS и GLOBAL
4. Switch to Meritage -> созданный data source НЕ виден
```

---

## 2025-11-12 - Data Source Delete Fix

### Проблема
После удаления data source запись исчезала из UI, но при обновлении страницы появлялась снова. API успешно удалял запись, но UI не обновлялся.

### Решение
Добавлена задержка 1 секунда перед `refreshData()` после удаления:

```typescript
const handleDelete = async (dataSource: DataSource) => {
  try {
    await deleteDataSource(dataSourceId, dataSource._etag);
    toast.success('Data source deleted successfully');
    
    // Wait 1 second before refreshing to allow backend to process
    await new Promise(resolve => setTimeout(resolve, 1000));
    refreshData();
  } catch (error) {
    // error handling
  }
};
```

### Затронутые файлы
- `/components/DataSourcesView.tsx` - добавлена задержка
- `/lib/api.ts` - улучшено логирование в `deleteDataSource()`
- Создана документация `/DATASOURCE_DELETE_FIX_RU.md`
- Создана документация `/DATASOURCE_CURL_TEST_RU.md`

### Результат
- ✅ Удаление работает стабильно
- ✅ UI корректно обновляется после удаления
- ✅ Детальное логирование DELETE операций

---

## 2025-11-09 - Data Source Create Fix

### Проблема
Аналогично удалению - после создания data source не появлялся в списке до обновления страницы.

### Решение
Добавлена задержка 1 секунда перед `refreshData()` после создания.

### Результат
- ✅ Создание работает стабильно
- ✅ UI корректно обновляется после создания

---

## Архитектура Data Sources

### Компоненты

```
/App.tsx
  ├── Управление состоянием dataSources
  ├── Функция refreshDataSources() - загрузка с учетом тенанта
  └── Передача props в DataSourcesView

/components/DataSourcesView.tsx
  ├── UI компонент для отображения data sources
  ├── CRUD операции (Create, Read, Update, Delete)
  ├── Data Capture Specifications management
  ├── Column selector
  ├── Search и filtering
  └── Expandable rows с Data Capture Specs

/lib/api.ts
  ├── getAllDataSources(tenantId?) - GET /datasources
  ├── createDataSource(data) - POST /datasources
  ├── updateDataSource(id, data, etag) - PUT /datasources/{id}
  └── deleteDataSource(id, etag) - DELETE /datasources/{id}

/components/TenantSelector.tsx
  └── UI для переключения между тенантами
```

### Изоляция данных

#### Уровни изоляции

1. **API Level**
   - Фильтр `?Filters={"TenantId":"BFS"}`
   - ETag для оптимистичной блокировки
   - X-BFS-Auth для аутентификации

2. **App Level** (`/App.tsx`)
   - Загрузка с фильтрацией по `activeTenantId`
   - GLOBAL TENANT → загрузка из всех тенантов
   - Конкретный тенант → фильтрация запроса

3. **Component Level** (`/components/DataSourcesView.tsx`)
   - Отображение данных из props
   - Валидация tenantId при создании
   - Запрет изменения чужих data sources

4. **UI Level** (`/components/TenantSelector.tsx`)
   - Показ только для SuperUser
   - Lock для обычных пользователей

### Роли и права

| Роль | Тенант | Права |
|------|---------|-------|
| Portal.SuperUser | GLOBAL | View All, Create All, Edit All, Delete All |
| Portal.SuperUser | BFS | View BFS, Create BFS, Edit BFS, Delete BFS |
| Admin | BFS (locked) | View BFS, Create BFS, Edit BFS, Delete BFS |
| Developer | BFS (locked) | View BFS, Create BFS, Edit BFS |
| Viewer | BFS (locked) | View BFS (read-only) |

### API Endpoints

```
Base URL: https://dp-eastus-poc-txservices-apis.azurewebsites.net

GET    /datasources                          # Все data sources
GET    /datasources?Filters={"TenantId":"BFS"}  # Data sources тенанта BFS
POST   /datasources                          # Создать data source
PUT    /datasources/{id}                     # Обновить data source (требует ETag)
DELETE /datasources/{id}                     # Удалить data source (требует ETag)

Headers:
  X-BFS-Auth: dummytoken123
  Content-Type: application/json
  If-Match: {etag}  # Для PUT/DELETE
```

### Форматы данных

#### Data Source Object

```typescript
interface DataSource {
  DatasourceId?: string;        // UUID
  DataSourceId?: string;        // Legacy field
  DatasourceName?: string;      // Имя
  DataSourceName?: string;      // Legacy field
  TenantId?: string;            // Тенант (BFS, Meritage, PIM)
  DatasourceType?: string;      // sql-db, cosmos-db, etc.
  CreateTime?: string | null;   // ISO timestamp
  UpdateTime?: string | null;   // ISO timestamp
  _etag?: string;               // ETag для оптимистичной блокировки
  // ... другие поля
}
```

#### API Response

```json
{
  "status": {
    "succeeded": true,
    "message": "Success"
  },
  "data": {
    "DataSources": [
      {
        "DatasourceId": "datasource_b9bb957b-b3e3-4...",
        "DatasourceName": "check-delete",
        "TenantId": "BFS",
        "CreateTime": "2025-11-13T10:30:00Z",
        "_etag": "..."
      }
    ]
  }
}
```

### Логирование

#### Создание
```
🔧 Creating data source...
📤 POST URL: https://...
📦 Request body: {...}
✅ Data source created successfully
⏱️ Waiting 1 second before refresh...
```

#### Удаление
```
🗑️ Deleting data source...
📤 DELETE URL: https://...
📋 Using ETag: "..."
✅ Deleted successfully
⏱️ Waiting 1 second before refresh...
```

#### GLOBAL TENANT загрузка
```
📡 Fetching data sources for GLOBAL tenant (all tenants)...
✅ Loaded 5 data sources for tenant BFS
✅ Loaded 3 data sources for tenant Meritage
✅ Loaded 2 data sources for tenant PIM
✅ Total data sources from all tenants: 10
```

#### Конкретный тенант загрузка
```
✅ Loaded 5 data sources for tenant BFS
```

## Документация

### Основная документация
- `/GLOBAL_TENANT_DATASOURCES_FIX_RU.md` - исправление GLOBAL TENANT
- `/TENANT_ISOLATION_RU.md` - архитектура изоляции тенантов
- `/DATASOURCE_DELETE_FIX_RU.md` - исправление удаления
- `/DATASOURCE_CURL_TEST_RU.md` - тестирование через curl

### Руководства по тестированию
- `/TESTING_GLOBAL_TENANT_RU.md` - тестирование GLOBAL TENANT
- Включают сценарии тестирования, curl команды, чеклисты

## Best Practices

### 1. Всегда используйте ETag

```typescript
// ❌ НЕ правильно
await deleteDataSource(id);

// ✅ Правильно
await deleteDataSource(id, dataSource._etag);
```

### 2. Добавляйте задержку после операций

```typescript
// ❌ НЕ правильно
await createDataSource(data);
refreshData(); // Может загрузиться до завершения операции на сервере

// ✅ Правильно
await createDataSource(data);
await new Promise(resolve => setTimeout(resolve, 1000));
refreshData();
```

### 3. Логируйте все операции

```typescript
console.log('🔧 Creating data source...');
console.log('📤 URL:', url);
console.log('📦 Body:', body);
```

### 4. Обрабатывайте ошибки gracefully

```typescript
try {
  const dataSources = await getAllDataSources(tenantId);
} catch (error) {
  console.error('❌ Failed:', error);
  return []; // Вернуть пустой массив вместо падения
}
```

### 5. Валидируйте tenantId

```typescript
// При создании
if (!newDataSourceTenantId) {
  toast.error('Please select a tenant');
  return;
}
```

## Known Issues

### 1. Задержка в 1 секунду

**Проблема:** После create/delete есть задержка 1 секунда

**Причина:** API требует время на обработку

**Решение:** Оптимистичное обновление UI (будущее улучшение)

### 2. Параллельные запросы для GLOBAL

**Проблема:** При большом количестве тенантов (>20) может быть медленно

**Решение:** Батчинг запросов или пагинация (будущее улучшение)

### 3. Браузерные лимиты

**Проблема:** Браузер ограничивает параллельные запросы (обычно 6)

**Решение:** Уже реализовано через `Promise.all()` - браузер сам управляет очередью

## Future Improvements

### Высокий приоритет
- [ ] Оптимистичное обновление UI (убрать 1 сек задержку)
- [ ] Pagination для больших списков
- [ ] Batch API для GLOBAL TENANT

### Средний приоритет
- [ ] Virtual scrolling для >1000 записей
- [ ] Кэширование результатов
- [ ] Offline mode

### Низкий приоритет
- [ ] Export to CSV/JSON
- [ ] Bulk operations
- [ ] Advanced filtering

## Контакты

BFS Portal Development Team

## License

Proprietary - BFS Internal Use Only
