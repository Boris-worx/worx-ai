# ✅ Добавлен новый Apicurio Template "inv1"

## Обзор
Добавлен новый шаблон **inv1** в группу **🗄️ BFS Online Templates** с упрощенной структурой (4 поля вместо 27 как в inv).

## Изменения

### 1. Добавлен артефакт в `/lib/apicurio.ts`

```typescript
{
  artifactId: "TxServices_Informix_inv1.response",
  groupId: "bfs.online",
  artifactType: "JSON",
  name: "inv1",
  description: "Response schema for Informix TxServices inv1 (Inventory variant 1)",
  createdOn: "2025-11-25T12:00:00Z",
  modifiedOn: "2025-11-25T12:00:00Z",
  version: "1.0.0"
}
```

### 2. Обновлен count шаблонов
- **До:** `count: 11`
- **После:** `count: 12`

### 3. Добавлена JSON схема для inv1

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "type": "object",
  "properties": {
    "TxnType": {
      "type": "string"
    },
    "Txn": {
      "type": "object",
      "properties": {
        "invid": { "type": ["string", "null"] },
        "entby": { "type": ["string", "null"] },
        "entdte": { "type": ["integer", "null"] },
        "enttime": { "type": ["string", "null"] },
        "metaData": {
          "type": "object",
          "properties": {
            "sources": {
              "type": "array",
              "items": {
                "type": "object",
                "properties": {
                  "sourceDatabase": { "type": "string" },
                  "sourceTable": { "type": "string" },
                  "sourceCreateTime": { "type": ["string", "null"], "format": "date-time" },
                  "sourceUpdateTime": { "type": ["string", "null"], "format": "date-time" },
                  "sourceEtag": { "type": ["string", "null"] },
                  "eventType": { "type": "string" },
                  "correlationId": { "type": "string" },
                  "sourcePrimaryKeyField": { "type": "string", "const": "invid" }
                }
              }
            }
          }
        },
        "createTime": {
          "anyOf": [
            { "type": "string", "format": "date-time" },
            { "type": "null" }
          ]
        },
        "updateTime": {
          "anyOf": [
            { "type": "string", "format": "date-time" },
            { "type": "null" }
          ]
        }
      }
    }
  }
}
```

## Структура данных

### Поля (4 основных + метаданные)

| Поле | Тип | Описание |
|------|-----|----------|
| `invid` | string \| null | Inventory ID (Primary Key) |
| `entby` | string \| null | Entered By |
| `entdte` | integer \| null | Entry Date |
| `enttime` | string \| null | Entry Time |

### Метаданные

| Поле | Тип | Описание |
|------|-----|----------|
| `metaData.sources[].sourcePrimaryKeyField` | string | Всегда `"invid"` (const) |
| `metaData.sources[].sourceDatabase` | string | Имя базы данных источника |
| `metaData.sources[].sourceTable` | string | Имя таблицы источника |
| `metaData.sources[].sourceCreateTime` | string \| null | Время создания в источнике |
| `metaData.sources[].sourceUpdateTime` | string \| null | Время обновления в источнике |
| `metaData.sources[].sourceEtag` | string \| null | ETag источника |
| `metaData.sources[].eventType` | string | Тип события |
| `metaData.sources[].correlationId` | string | Correlation ID |

### Системные поля

| Поле | Тип | Описание |
|------|-----|----------|
| `createTime` | string \| null | Дата/время создания (ISO 8601) |
| `updateTime` | string \| null | Дата/время обновления (ISO 8601) |

## Использование в Data Source Onboarding

### 1. Открыть форму создания спецификации
```
Data Source Onboarding → Select Data Source → Create Spec
```

### 2. Выбрать шаблон
В dropdown "Select Apicurio Template":
```
🗄️ BFS Online Templates
  └── inv1 (TxServices_Informix_inv1.response)
```

### 3. Автозаполнение формы
После выбора шаблона форма заполняется автоматически:

```
Spec Name: Inv1
Container Name: Inv1s
Source Primary Key Field: invid
Allowed Filters:
  - invid
  - entby
  - entdte
  - enttime
  - metaData.sources[].sourceDatabase
  - metaData.sources[].sourceTable
  - createTime
  - updateTime
```

## Сравнение inv vs inv1

| Параметр | inv | inv1 |
|----------|-----|------|
| **Основных полей** | 27 | 4 |
| **Primary Key** | invid | invid |
| **Размер схемы** | ~200 строк | ~60 строк |
| **Использование** | Полная инвентаризация | Упрощенная инвентаризация |

### Поля inv (27 полей)
```
invid, invdes, ivstat, clsscd1, clsscd2, clsscd3, clsscd4, clsscd5,
prclsscd, unms, factor, stdpkg, disqty, bomtype, buyerid, apnum,
loccd, invwt, unprc, nunprc, estdt, lactdt, upccode1, upccode2,
gltabid, cstunms, prcunms
```

### Поля inv1 (4 поля)
```
invid, entby, entdte, enttime
```

## Интеграция с Data Plane

### Transaction Type: inv1
- **API Endpoint:** `/1.0/txns?TxnType=inv1`
- **API Version:** v1.0 (BFS Online)
- **Primary Key Field:** `invid`
- **Отображается в списке:** ✅ Да (lowercase)

### Пример API запроса
```bash
curl --location 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/txns?TxnType=inv1' \
  --header 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
```

### Пример ответа
```json
{
  "status": {
    "code": 200,
    "message": "Success"
  },
  "data": {
    "TxnType": "inv1",
    "TxnTotalCount": 456,
    "Txns": [
      {
        "id": "inv1-12345",
        "invid": "INV1-001",
        "entby": "user123",
        "entdte": 20251125,
        "enttime": "14:30:00",
        "metaData": {
          "sources": [{
            "sourceDatabase": "informix_db",
            "sourceTable": "inv1_table",
            "sourcePrimaryKeyField": "invid",
            "sourceCreateTime": "2025-11-25T14:30:00Z",
            "sourceUpdateTime": "2025-11-25T14:35:00Z",
            "sourceEtag": "v1",
            "eventType": "INSERT",
            "correlationId": "corr-123"
          }]
        },
        "createTime": "2025-11-25T14:30:00Z",
        "updateTime": "2025-11-25T14:35:00Z",
        "_etag": "\"0000d402-0000-0800-0000-67446b290000\"",
        "_rid": "rid12345",
        "_ts": 1732540201
      }
    ]
  }
}
```

## Приоритет схем

### Проверка порядка в getMockArtifactSchema()
```typescript
// Порядок проверки важен!
if (artifactId.includes('inv1')) {
  // Возвращает упрощенную схему с 4 полями
}
else if (artifactId.includes('inv')) {
  // Возвращает полную схему с 27 полями
}
```

**Важно:** Проверка на `inv1` должна быть **перед** проверкой на `inv`, иначе `inv1` будет сопоставлена с полной схемой `inv`.

## Извлечение Primary Key

### Логика в extractSourcePrimaryKeyField()
```typescript
// Для inv1 схемы
if (schema.properties?.Txn?.properties?.metaData?.properties?.sources?.items?.properties?.sourcePrimaryKeyField) {
  const pkField = schema.properties.Txn.properties.metaData.properties.sources.items.properties.sourcePrimaryKeyField;
  
  // Проверяем const значение
  if (pkField.const) {
    return pkField.const; // Возвращает "invid"
  }
}
```

## Тестирование

### 1. Data Source Onboarding
```javascript
// 1. Открыть Data Source Onboarding
// 2. Выбрать Data Source
// 3. Нажать "Create Spec"
// 4. В dropdown должно быть 12 шаблонов (было 11)
// 5. Выбрать "inv1" из группы "🗄️ BFS Online Templates"
// 6. Проверить автозаполнение:
//    - Spec Name: Inv1
//    - Container Name: Inv1s
//    - Source Primary Key Field: invid
//    - Allowed Filters: 4 основных поля + метаданные
```

### 2. Консольные логи
```javascript
// При выборе шаблона inv1:
📦 Using local schema template: inv1
📦 Schema extracted from TxServices schema
📦 Fields found: invid, entby, entdte, enttime
📦 Primary key field: invid
```

### 3. Data Plane
```javascript
// 1. Открыть Data Plane
// 2. Должен отображаться тип "inv1" (с количеством транзакций)
// 3. Нажать на "inv1"
// 4. Должны загрузиться транзакции из /1.0/txns?TxnType=inv1
// 5. В таблице должны отображаться поля:
//    - invid
//    - entby
//    - entdte
//    - enttime
```

## Файлы

### Измененные файлы
1. **`/lib/apicurio.ts`**
   - Добавлен артефакт `TxServices_Informix_inv1.response`
   - Добавлена JSON схема для inv1
   - Обновлен count: `11` → `12`
   - Проверка на `inv1` добавлена **перед** проверкой на `inv`

## Статус

🟢 **Готово** - Шаблон inv1 полностью интегрирован

### Доступные шаблоны (12)

#### 📊 Bid Tools Templates (7)
1. LineTypes (CDC)
2. ServiceRequests (CDC)
3. WorkflowCustomers (CDC)
4. QuoteDetails
5. QuotePacks
6. Quotes
7. ReasonCodes

#### 🗄️ BFS Online Templates (5)
8. **inv** - Inventory (27 полей)
9. **inv1** - Inventory variant 1 (4 поля) ← **Новый**
10. loc - Locations (8 полей)
11. loc1 - Locations variant 1 (9 полей)
12. stcode - Store Codes (2 поля)

## Следующие шаги

### Возможные расширения
1. Добавить остальные варианты Inventory:
   - inv2 (Inventory variant 2)
   - inv3 (Inventory variant 3)
   - invap (Inventory AP)
   - invdes (Inventory Descriptions)
   - invloc (Inventory Locations)

2. Добавить validation rules для полей:
   - `entdte` - должна быть валидной датой в формате YYYYMMDD
   - `enttime` - должна быть в формате HH:MM:SS

3. Добавить примеры данных в документацию

## Совместимость

✅ **Обратная совместимость** - Существующий шаблон `inv` работает без изменений  
✅ **API v1.0** - Использует BFS Online endpoint  
✅ **Мультитенантность** - Поддерживает фильтрацию по TenantId  
✅ **Primary Key** - Автоматическое извлечение из `const: "invid"`  
✅ **Data Capture Specs** - Полная интеграция с существующим модулем  

## См. также
- `/BFS_ONLINE_INV_TEMPLATE_ADDED_RU.md` - Шаблон inv (27 полей)
- `/NEW_TRANSACTION_TYPES_ADDED_RU.md` - Все новые типы транзакций
- `/BFS_ONLINE_V10_API_FIX_RU.md` - Интеграция с v1.0 API
- `/FINAL_BFS_ONLINE_SUMMARY_RU.md` - Общая сводка
