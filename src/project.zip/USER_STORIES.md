# BFS Platform Management - User Stories

This application implements the following user stories for managing tenants and ERP transactions on the BFS platform.

## Configuration

Before using with real API:
1. Open `/lib/api.ts`
2. Update `API_BASE_URL` with your actual endpoint (e.g., `https://your-api.com/1.0`)
3. Update `AUTH_HEADER_VALUE` with your X-BFS-Auth key from Postman collection

The app will automatically detect real API configuration and disable demo mode.

## User Story 1: View List of Existing Tenants

**As a Developer, I want to view a list of existing tenants on the platform.**

### Implementation:
- Navigate to the "Tenants" tab
- The app automatically loads tenants from Mahesh's API on page load
- Display shows: TenantID and TenantName columns
- Framework includes Sort, Search, and Filter capabilities:
  - **Search**: Use search bar to filter tenants by ID or Name
  - **Sort**: Click column headers to sort ascending/descending
  - **Filter**: Search automatically filters the visible data

### API Endpoint:
- **Method**: GET
- **Endpoint**: `/tenants`
- **Response Structure**:
```json
{
  "status": {
    "code": 200,
    "message": "Successful"
  },
  "data": {
    "tenants": [...]
  }
}
```

---

## User Story 2: Set Up New Tenant ID

**As a Developer, I want to set up a new tenant ID for a new Supplier onboarding to the BFS platform.**

### Implementation:
- Click "Add New Tenant" button
- Enter TenantName in the dialog
- System generates unique TenantID automatically
- New tenant appears in the table after successful creation

### API Endpoint:
- **Method**: POST
- **Endpoint**: `/tenants`
- **Request Body**: `{ "TenantName": "string" }`
- **Response**: System-generated TenantID and full tenant object

---

## User Story 3: Delete Existing Tenant

**As a Developer, I want to delete an existing tenant from the BFS platform.**

### Implementation:
- Locate tenant in the table
- Click "Delete" button for that tenant
- Confirm deletion in the dialog
- Tenant is removed from Cosmos and table updates

### API Endpoint:
- **Method**: DELETE
- **Endpoint**: `/tenants/{tenantId}`
- **Headers**: Includes If-Match header with _etag value
- **Response**: 200 OK

---

## Additional Tenant Features

### View Tenant Details

**Click on any Tenant ID to view complete tenant information.**

#### Implementation:
- Click on TenantID (shown as clickable link)
- Dialog opens with detailed information:
  - Primary Information (TenantId, TenantName)
  - Timestamps (CreateTime, UpdateTime, _ts)
  - Cosmos DB Metadata (_rid, _etag, _self, _attachments)
  - Raw JSON view

#### API Endpoint:
- **Method**: GET
- **Endpoint**: `/tenants/{tenantId}`
- **Response**: Complete tenant object with all Cosmos DB fields

---

### Edit Tenant

**Update tenant information (TenantName).**

#### Implementation:
- Click "Edit" button for any tenant
- Update TenantName in dialog
- Click "Update Tenant"
- Table refreshes with updated information

#### API Endpoint:
- **Method**: PUT
- **Endpoint**: `/tenants/{tenantId}`
- **Headers**: Includes If-Match header with _etag value
- **Request Body**: `{ "TenantName": "string" }`
- **Response**: Updated tenant object with new _etag

**Note:** TenantID cannot be changed in most database systems. If ID change is required, delete and recreate the tenant.

---

## User Story 4: Retrieve List of 16 ERP Transactions

**As a Developer, I want to retrieve the list of 16 ERP transactions stored in Cosmos.**

### Implementation:
- Navigate to the "Transactions" tab
- View list displays TransactionName in single column
- Same Sort, Search, Filter framework applies:
  - Search by transaction name
  - Sort alphabetically
  - Filter results dynamically

### API Endpoint:
- **Method**: GET
- **Endpoint**: `/transactions`
- **Response**: List of 16 transaction types

### Example Transactions:
1. Customer
2. Customer Aging
3. Invoice
4. Payment
5. Purchase Order
6. Sales Order
7. Vendor
8. Item Master
9. Journal Entry
10. GL Account
11. Budget
12. Cash Receipt
13. AP Voucher
14. Credit Memo
15. Inventory Transfer
16. Fixed Asset

---

## User Story 5: View Transaction Details

**As a Developer, I want to view details of a transaction.**

### Implementation:
- Click on any TransactionName in the list
- Dialog opens showing:
  - **Request JSON Tab**: API Request structure
  - **Response JSON Tab**: Transaction response structure
- JSON is displayed in formatted, readable view
- Metadata shows creation date and etag

### API Endpoint:
- **Method**: GET
- **Endpoint**: `/transactions/{transactionId}`
- **Response**: Transaction object with RequestJSON and ResponseJSON fields

---

## User Story 6: Add New Transaction

**As a Developer, I want to add a new transaction.**

### Implementation:
- Click "Add New Transaction" button
- Fill in form:
  1. **Transaction Name**: Enter name for new transaction type
  2. **Request JSON**: Upload JSON file with API request structure
  3. **Response JSON**: Upload JSON file with transaction response structure
- Click "Create Transaction"
- New transaction appears in the list with 200 OK response

### Sample Files:
- `/sample-request.json` - Example request structure
- `/sample-response.json` - Example response structure

### API Endpoint:
- **Method**: POST
- **Endpoint**: `/transactions`
- **Request Body**:
```json
{
  "TransactionName": "string",
  "RequestJSON": { ... },
  "ResponseJSON": { ... }
}
```
- **Response**: 200 OK with created transaction object

---

## Common Features

### Sort, Search, Filter Framework (User Story 1)
The DataTable component provides reusable functionality for all tables:

- **Search**: Real-time filtering as you type
- **Sort**: Click column headers to toggle asc/desc/unsorted
- **Filter**: Automatic filtering based on search criteria
- **Results Count**: Shows filtered vs total items

This framework is used consistently across:
- Tenants table (User Story 1)
- Transactions table (User Story 4)

### Demo Mode
When using placeholder API URLs, the app runs in demo mode with mock data:
- All CRUD operations work with in-memory data
- Simulated API delays for realistic testing
- No real API calls required for development

### Error Handling
- Toast notifications for all operations
- Detailed error messages from API status.message field
- Validation before API calls
- Loading states during operations

---

## Technical Details

### API Headers
All requests include:
- `X-BFS-Auth`: API key/secret for authentication
- `Content-Type`: application/json
- `If-Match`: _etag value (for PUT/DELETE operations)

### Response Format
All API responses follow this structure:
```json
{
  "status": {
    "code": 200,
    "message": "Success message"
  },
  "data": {
    // Response data here
  }
}
```

### ETag Handling
- All objects include `_etag` field
- PUT and DELETE operations require If-Match header with etag
- Ensures optimistic concurrency control
