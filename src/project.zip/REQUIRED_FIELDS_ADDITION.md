# Добавить Required Fields UI в DataSourcesView.tsx

## Место вставки
После строки 2353 (после `</div>` для Allowed Filters section) и перед строкой 2355 (`<Separator />`)

## Код для вставки

```tsx
{/* Required Fields - Multiselect Checkboxes */}
<div className="space-y-4">
  <div>
    <Label>Required Fields *</Label>
    <p className="text-xs text-muted-foreground mt-1">
      Select fields that must be present in all captured data
    </p>
  </div>
  <ScrollArea className="h-[200px] rounded-md border p-4 bg-white">
    <div className="space-y-2">
      {availableFilters.map((field) => (
        <div key={field} className="flex items-center space-x-2">
          <Checkbox
            id={`required-${field}`}
            checked={createSpecForm.requiredFields.includes(field)}
            onCheckedChange={(checked) => {
              if (checked) {
                setCreateSpecForm({
                  ...createSpecForm,
                  requiredFields: [...createSpecForm.requiredFields, field]
                });
              } else {
                setCreateSpecForm({
                  ...createSpecForm,
                  requiredFields: createSpecForm.requiredFields.filter(f => f !== field)
                });
              }
            }}
            className="border-white data-[state=checked]:bg-primary data-[state=checked]:border-primary"
          />
          <Label htmlFor={`required-${field}`} className="text-sm cursor-pointer font-mono">
            {field}
          </Label>
        </div>
      ))}
    </div>
  </ScrollArea>
  <div className="text-xs text-muted-foreground">
    Selected: {createSpecForm.requiredFields.length} required fields
  </div>
</div>
```

## Также не забудьте добавить в reset form (строка ~2129)

Заменить:
```tsx
allowedFilters: [],
containerSchemaText: ''
```

На:
```tsx
allowedFilters: [],
requiredFields: [],  // ✅ Add this
containerSchemaText: ''
```
