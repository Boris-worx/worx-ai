# Apicurio Registry - Удалены все MOCK данные

## ✅ Что сделано

Полностью удалены все MOCK данные из интеграции с Apicurio Registry. Теперь система работает **ТОЛЬКО** с реальными данными из API.

## 🎯 Основные изменения

### 1. Удалены функции с mock данными
- ❌ `getMockApicurioArtifacts()` - удалена полностью (было ~190 строк mock данных)
- ❌ `getMockArtifactSchema()` - удалена полностью (было ~915 строк mock схем)

### 2. Жёстко заданы только две группы
```typescript
const KNOWN_GROUPS = [
  { id: 'paradigm.bidtools2', description: 'Bid Tools Templates' },
  { id: 'bfs.online', description: 'BFS Online Templates' },
];
```

### 3. Изменено поведение при ошибках API

#### Раньше (с mock данными):
```typescript
// При любой ошибке - возвращали mock данные
if (allArtifacts.length === 0) {
  console.log('📦 🔄 No artifacts loaded, using local Apicurio templates');
  const mockData = getMockApicurioArtifacts();
  return mockData;
}
```

#### Сейчас (без mock данных):
```typescript
// При отсутствии артефактов - выбрасываем ошибку
if (allArtifacts.length === 0) {
  throw new Error('No artifacts available from Apicurio Registry. Please check API access.');
}

// Если есть кеш - используем его даже если expired
if (artifactsCache) {
  console.log('📦 Using expired cache data due to API error');
  return artifactsCache;
}

// Нет кеша - возвращаем пустой результат
return {
  artifacts: [],
  count: 0
};
```

### 4. Функция `getApicurioArtifact` теперь выбрасывает ошибки

#### Раньше:
```typescript
if (response.status === 403) {
  return getMockArtifactSchema(artifactId);
}
if (response.status === 404) {
  return getMockArtifactSchema(artifactId);
}
```

#### Сейчас:
```typescript
if (!response.ok) {
  const errorText = await response.text();
  throw new Error(`Failed to fetch artifact ${artifactId}: ${response.status} - ${errorText}`);
}
```

### 5. Обновлены комментарии в компонентах
В `DataCaptureSpecCreateDialog.tsx`:
```typescript
// Раньше:
// Error is logged but user gets mock data automatically - no need to show error
// The fallback logic in getApicurioArtifact will handle 403 and return mock schemas

// Сейчас:
// Error will be shown to user - no fallback to mock data
toast.error(`Failed to load template: ${error.message}`);
```

## 📋 Что осталось без изменений

### ✅ Хорошие fallback механизмы (не mock данные)
1. **Список групп при 403** - возвращает `KNOWN_GROUPS` (это реальные группы, не mock)
2. **Фильтрация групп** - даже если API вернёт больше групп, используем только наши две
3. **Default версии** - если API не вернул версии, используем дефолтные (`1` для paradigm.bidtools2, `1.0.0` для bfs.online)
4. **Кеширование** - использует localStorage для кеша, при ошибке API использует expired cache

### ✅ Все динамические функции работают
- `getApicurioGroups()` - получает группы из API
- `getGroupArtifacts(groupId)` - получает артефакты из группы
- `getArtifactVersions(groupId, artifactId)` - получает версии артефакта
- `getApicurioArtifact(groupId, artifactId, version?)` - получает схему артефакта

## 🔍 Теперь отображаются только реальные шаблоны

### Группа `paradigm.bidtools2`
Только артефакты, которые реально есть в:
```
https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/paradigm.bidtools2/artifacts/
```

### Группа `bfs.online`
Только артефакты, которые реально есть в:
```
https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/bfs.online/artifacts/
```

## ⚠️ Важные последствия

### 1. Если Apicurio Registry недоступен
- **Первая загрузка**: Покажет пустой список шаблонов или ошибку
- **Повторная загрузка**: Использует кеш из localStorage (если есть)
- **Срок жизни кеша**: 30 минут

### 2. Если артефакт не найден (404)
- Раньше: Показывал mock схему
- Сейчас: Выбрасывает ошибку с сообщением

### 3. Если доступ запрещён (403)
- Раньше: Показывал mock схему
- Сейчас: Выбрасывает ошибку с сообщением

## 🎨 Что видит пользователь

### Успешный сценарий
1. Открывает "Create from Template"
2. Видит реальные шаблоны из двух групп
3. Выбирает шаблон
4. Схема загружается из Apicurio Registry

### Сценарий с ошибкой
1. Открывает "Create from Template"
2. API недоступен
3. Если есть кеш: Видит шаблоны из кеша
4. Если нет кеша: Видит пустой список или ошибку
5. При выборе шаблона: Получает toast с ошибкой

## 📊 Статистика изменений

- **Удалено строк кода**: ~1,105 строк (mock данные + fallback логика)
- **Уменьшение размера файла**: с ~1,900 строк до ~795 строк
- **Удалено mock артефактов**: 18 шт
- **Удалено mock схем**: 11 различных типов схем

## 🔧 Технические детали

### Файлы изменены
1. `/lib/apicurio.ts` - полная переработка, удалены все mock данные
2. `/components/DataCaptureSpecCreateDialog.tsx` - обновлены комментарии

### Сигнатуры функций остались без изменений
Все экспортируемые функции имеют те же сигнатуры, что и раньше:
- `searchApicurioArtifacts(namePattern?: string): Promise<ApicurioSearchResponse>`
- `getApicurioArtifact(groupId: string, artifactId: string, version?: string): Promise<any>`
- `getApicurioGroups(): Promise<ApicurioGroup[]>`
- `getGroupArtifacts(groupId: string): Promise<ApicurioArtifact[]>`
- `getArtifactVersions(groupId: string, artifactId: string): Promise<ApicurioVersion[]>`
- и все остальные utility функции

## ✅ Тестирование

### Что нужно проверить
1. ✅ Открыть Data Source Onboarding → Create from Template
2. ✅ Убедиться, что видны только реальные шаблоны из Apicurio
3. ✅ Выбрать шаблон из группы `paradigm.bidtools2`
4. ✅ Выбрать шаблон из группы `bfs.online`
5. ✅ Проверить, что схемы загружаются из Apicurio Registry
6. ✅ Проверить кеш - закрыть и открыть диалог снова (должен использовать кеш)

### Проверка обработки ошибок
1. ⚠️ Отключить интернет
2. ⚠️ Открыть диалог - должен использовать кеш
3. ⚠️ Очистить кеш в localStorage
4. ⚠️ Открыть диалог - должен показать ошибку или пустой список

## 📝 Итог

✅ **Все MOCK данные удалены**  
✅ **Работает только с реальным Apicurio Registry API**  
✅ **Отображаются только две группы: paradigm.bidtools2 и bfs.online**  
✅ **Graceful degradation через кеширование**  
✅ **Понятные сообщения об ошибках для пользователя**

---

**Дата**: 28 ноября 2024  
**Статус**: ✅ Завершено
