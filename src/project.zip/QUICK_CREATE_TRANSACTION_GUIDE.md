# Quick Guide: Create Transaction with JSON Input

## 🚀 Quick Start (3 Steps)

### 1️⃣ Click "Create Transaction"
- Go to **Data Plane** tab
- Select the transaction type you want (Customer, Invoice, Payment, etc.)
- Click **"Create Transaction"** button

### 2️⃣ Edit the JSON Template
A pre-filled template appears. Just change the values:

**Before:**
```json
{
  "CustomerId": "CUST-1730123456",
  "Name": "John Doe",
  "Email": "john.doe@example.com"
}
```

**After (your data):**
```json
{
  "CustomerId": "CUST-2025-001",
  "Name": "Alice Johnson", 
  "Email": "alice@company.com"
}
```

### 3️⃣ Click "Create Transaction"
- The transaction is created
- It appears in the table
- Done! ✅

---

## 📋 Templates for Each Type

### Customer
```json
{
  "CustomerId": "CUST-001",
  "Name": "Customer Name",
  "Email": "email@example.com",
  "Status": "Active"
}
```

### Invoice
```json
{
  "InvoiceId": "INV-001",
  "CustomerId": "CUST-001",
  "InvoiceDate": "2025-10-28",
  "TotalAmount": 1500.00,
  "Status": "Draft"
}
```

### Payment
```json
{
  "PaymentId": "PAY-001",
  "InvoiceId": "INV-001",
  "Amount": 1500.00,
  "PaymentMethod": "CreditCard",
  "Status": "Completed"
}
```

---

## ⚠️ Common Errors

### Error: "Invalid JSON"
**Problem:** Syntax error in your JSON

**Fix:** Check these common mistakes:
- ✅ Use double quotes `"` not single quotes `'`
- ✅ No comma after the last field
- ✅ All brackets `{}` must match
- ✅ Strings need quotes, numbers don't

**Example:**
```json
// ❌ WRONG
{
  'Name': 'John',  // Wrong: single quotes
  "Email": "john@example.com",  // Wrong: extra comma
}

// ✅ CORRECT  
{
  "Name": "John",
  "Email": "john@example.com"
}
```

### Error: "Required field missing"
**Problem:** The API needs certain fields

**Fix:** Make sure you have these fields:
- Customer: `CustomerId`, `Name`, `Status`
- Invoice: `InvoiceId`, `CustomerId`, `TotalAmount`
- Payment: `PaymentId`, `Amount`, `PaymentMethod`

---

## 💡 Pro Tips

### Copy & Paste
1. Copy JSON from documentation
2. Paste into the dialog
3. Edit as needed
4. Submit ✨

### Use Templates
1. Open the dialog
2. Template is already there
3. Just change the values
4. Submit ✨

### Quick Edits
1. View an existing transaction
2. Copy the JSON
3. Paste into create dialog
4. Change the ID and other values
5. Submit to create a similar transaction ✨

---

## 🎯 What Changed?

### Old Way (File Upload)
1. Create JSON file on your computer
2. Upload the file
3. Transaction created immediately
4. ❌ Can't edit before creating
5. ❌ Have to manage files

### New Way (JSON Input)
1. Click create button
2. Template appears
3. Edit JSON in the dialog
4. Click create
5. ✅ See and edit before creating
6. ✅ No files to manage

---

## 🆘 Need Help?

### Validate Your JSON
If you're not sure if your JSON is correct:
1. Copy your JSON
2. Go to [jsonlint.com](https://jsonlint.com)
3. Paste and click "Validate JSON"
4. Fix any errors shown
5. Copy the corrected JSON back

### Ask for Help
- Check the full guide: `TRANSACTION_CREATE_JSON_GUIDE.md`
- Contact your administrator
- Check browser console (F12) for error details

---

## ✅ Checklist

Before clicking "Create Transaction":
- [ ] Transaction type is correct
- [ ] JSON has no red errors
- [ ] All required fields are filled
- [ ] IDs are unique (not duplicates)
- [ ] Amounts and dates look correct

Click "Create Transaction" and you're done! 🎉
