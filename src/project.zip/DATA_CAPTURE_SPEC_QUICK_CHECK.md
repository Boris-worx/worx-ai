# Data Capture Specifications - Quick Check ⚡

## User Story Requirements

**A Data Capture Specification must include:**

1. ✅ Tenant ID
2. ✅ Version ID  
3. ✅ Data Source ID
4. ✅ Specification Name (used with Tenant name for Cosmos container)
5. ✅ List of required fields
6. ✅ JSON structure of data payload

---

## Compliance Check

| # | Requirement | Status | Details |
|---|-------------|--------|---------|
| 1 | Tenant ID | ❌ **MISSING** | No TenantId field |
| 2 | Version ID | ✅ **EXCELLENT** | version + semver (dual tracking) |
| 3 | Data Source ID | ❌ **MISSING** | No DataSourceId field |
| 4 | Spec Name | ✅ **PERFECT** | `model` field |
| 5 | Required Fields | ✅ **COMPLETE** | `jsonSchema.required` array |
| 6 | JSON Structure | ✅ **COMPLETE** | Full JSON Schema draft-2020-12 |

**Score:** 🟡 **4/6 (67%)**

---

## Current Implementation

```typescript
export interface ModelSchema {
  id: string;
  model: string;             // ✅ #4 - Spec Name
  version: number;           // ✅ #2 - Version (integer)
  semver: string;            // ✅ #2 - Version (semver)
  state: string;             // ✅ Bonus - active/draft/archived
  jsonSchema: any;           // ✅ #6 - JSON structure
  // jsonSchema.required     // ✅ #5 - Required fields list
  CreateTime: string;
  UpdateTime: string;
  _etag?: string;
  // ❌ TenantId?: string;    // #1 - MISSING
  // ❌ DataSourceId?: string; // #3 - MISSING
}
```

---

## What's Working ✅

### #2: Version ID - Excellent! ⭐⭐⭐⭐⭐
```typescript
version: 1           // Simple integer counting
semver: "1.0.0"     // Semantic versioning
```
**Better than required** - dual tracking for flexibility

### #4: Specification Name - Perfect! ⭐⭐⭐⭐⭐
```typescript
model: "Customer"    // Table name = Spec name
```
**Used for Cosmos container:** `${TenantId}-${model}` → "BFS-Customer"

### #5: Required Fields - Standard! ⭐⭐⭐⭐⭐
```typescript
jsonSchema: {
  "required": ["CustomerId", "Name"]
}
```
**Displayed in UI** with badges

### #6: JSON Structure - Complete! ⭐⭐⭐⭐⭐
```typescript
jsonSchema: {
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "properties": { /* full schema */ }
}
```
**Full JSON Schema support** with validation, nested objects, arrays

---

## What's Missing ❌

### #1: Tenant ID - CRITICAL! 🔴
```typescript
// ❌ No TenantId field
```

**Impact:**
- Can't filter specs by tenant
- Can't distinguish Global vs BFS specs
- Cosmos container naming incomplete

**Fix:**
```typescript
TenantId?: string;  // Add to ModelSchema

// Usage:
const containerName = `${TenantId}-${model}`;
// "BFS-Customer", "Global-Quotes"
```

**Effort:** 2 hours

---

### #3: Data Source ID - CRITICAL! 🔴
```typescript
// ❌ No DataSourceId field
```

**Impact:**
- Can't link spec to Data Source
- Can't show hierarchical view (DS → Specs)
- Shows mock data instead of real specs

**Fix:**
```typescript
DataSourceId?: string;  // Add to ModelSchema

// Usage:
const specs = await getAllModelSchemas(tenantId, dataSourceId);
// Filter specs by Data Source
```

**Effort:** 3 hours

---

## Example: Before vs After

### Before (Current - 67%):
```json
{
  "id": "ModelSchema-Customer-1",
  "model": "Customer",
  "version": 1,
  "semver": "1.0.0",
  "state": "active",
  "jsonSchema": {
    "required": ["CustomerId", "Name"],
    "properties": { /* ... */ }
  }
  // ❌ No TenantId
  // ❌ No DataSourceId
}
```

### After (100%):
```json
{
  "id": "ModelSchema-Customer-1",
  "model": "Customer",
  "version": 1,
  "semver": "1.0.0",
  "state": "active",
  "TenantId": "BFS",                  // ✅ Added
  "DataSourceId": "Online-Informix",  // ✅ Added
  "jsonSchema": {
    "required": ["CustomerId", "Name"],
    "properties": { /* ... */ }
  }
}

// Cosmos Container: "BFS-Customer"
```

---

## Visual Impact

### Current UI:
```
Transaction Onboarding Tab
┌────────────────────────────────┐
│ Model    | Ver | State        │
├────────────────────────────────┤
│ Customer | 1   | active       │  ❌ No tenant info
│ Quotes   | 1   | active       │  ❌ No DS info
└────────────────────────────────┘

Data Source Tab
└── Bidtools
    └── Mock specs ❌
```

### After Fixes:
```
🏢 BFS Tenant
┌──────────────────────────────────────────┐
│ Model    | DS     | Tenant | Ver | State│
├──────────────────────────────────────────┤
│ Customer | Online | BFS    | 1   | act. │ ✅
│ Order    | Online | BFS    | 1   | act. │ ✅
└──────────────────────────────────────────┘

🏢 Global Tenant
┌──────────────────────────────────────────┐
│ Model    | DS       | Tenant | Ver |State│
├──────────────────────────────────────────┤
│ Quotes   | Bidtools | Global | 1   | act.│ ✅
└──────────────────────────────────────────┘

Data Source Tab
└── Bidtools [Global]
    ├── Quotes (v1.0.0) ✅ Real from API
    ├── QuoteDetails (v1.0.0) ✅ Real
    └── QuotePacks (v1.0.0) ✅ Real
```

---

## Action Plan

### Phase 1: Add TenantId (2 hours) 🔴
- Update ModelSchema interface
- Add Tenant column to UI
- Filter by active tenant
- Display tenant badge

### Phase 2: Add DataSourceId (3 hours) 🔴
- Update ModelSchema interface
- Link specs to Data Sources
- Load real specs in DataSourcesView
- Add DataSource column to ModelSchemaView

### Phase 3: Testing (2 hours) ✅
- Test tenant filtering
- Test DS linking
- Test real specs display
- Test Cosmos container naming

**Total Effort:** 7 hours  
**Result:** 100% compliance ✅

---

## Bottom Line

**Current:** 67% compliant (4/6 requirements met)  
**Quality of implemented features:** Excellent (100%)  
**Missing:** TenantId + DataSourceId  
**Effort to fix:** 7 hours  
**Priority:** High (needed for multi-tenant deployment)

**Verdict:** 🟡 **Good foundation, needs 2 fields added**

---

## Files Created

1. **[DATA_CAPTURE_SPEC_QUICK_CHECK.md](./DATA_CAPTURE_SPEC_QUICK_CHECK.md)** - This file
2. **[DATA_CAPTURE_SPEC_REQUIREMENTS_CHECK.md](./DATA_CAPTURE_SPEC_REQUIREMENTS_CHECK.md)** - Full analysis (EN)
3. **[DATA_CAPTURE_SPEC_ПРОВЕРКА_ТРЕБОВАНИЙ.md](./DATA_CAPTURE_SPEC_ПРОВЕРКА_ТРЕБОВАНИЙ.md)** - Full review (RU)

---

**Status:** 🟡 Foundation excellent, 2 critical fields needed for 100% compliance
