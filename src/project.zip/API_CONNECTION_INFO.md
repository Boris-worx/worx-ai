# 🌐 BFS API Connection Information

## ✅ Current Configuration

### API Endpoint
```
https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0
```

### Authentication
```
Header: X-BFS-Auth
Value: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
```

### CORS Status
✅ **CORS is configured and working!**

---

## 🚀 Features

### Auto-Load on Start
- ✅ Application automatically loads tenants when opened
- ✅ Shows loading indicator during fetch
- ✅ Displays success message when data loads

### Manual Refresh
- ✅ "Load from API" button to refresh data
- ✅ Real-time sync with Cosmos DB
- ✅ Loading spinner during refresh

---

## 📊 Available Endpoints

All endpoints are accessible via the configured API:

### Tenants
```
✅ GET    /1.0/tenants           - List all tenants
✅ GET    /1.0/tenants/{id}      - Get single tenant
✅ POST   /1.0/tenants           - Create tenant
✅ PUT    /1.0/tenants/{id}      - Update tenant
✅ DELETE /1.0/tenants/{id}      - Delete tenant
```

### Headers Required
- **All requests**: `X-BFS-Auth` (authentication)
- **PUT/DELETE**: `If-Match` (ETag for concurrency control)

---

## ✅ Expected Behavior

### On Application Start
1. Shows loading indicator
2. Fetches tenants from API
3. Displays count: "5 tenant(s) ✓"
4. Shows tenants in table

### Empty Database
1. Connects successfully
2. Shows: "Database is empty - create your first tenant!"
3. User can create tenant via "Add New Tenant"

### API Error
1. Shows error message
2. Suggests checking API accessibility
3. User can still use "Import JSON"

---

## 🔧 Configuration Files

### `/lib/api.ts`
```typescript
const API_BASE_URL = "https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0";
const AUTH_HEADER_KEY = "X-BFS-Auth";
const AUTH_HEADER_VALUE = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855";
const DEMO_MODE = false; // Using live API
```

### `/App.tsx`
```typescript
// Auto-load on mount
useEffect(() => {
  refreshData();
}, []);
```

---

## 🧪 Testing Connection

### Browser Console (F12)
After opening the application, you should see:
```
🌐 Attempting to connect to BFS API...
✅ Connected! Response status: 200
✅ Loaded 5 tenant(s) from API
```

### Using curl
```bash
curl -X GET \
  'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/tenants' \
  -H 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
  -v
```

**Expected Response:**
```
< HTTP/1.1 200 OK
< Access-Control-Allow-Origin: *
< Content-Type: application/json
```

---

## 📝 Operations

### View Tenants
- ✅ Automatically loaded on start
- ✅ Click "Load from API" to refresh
- ✅ Real-time data from Cosmos DB

### Create Tenant
1. Click "Add New Tenant"
2. Enter tenant name
3. System generates TenantId
4. Saves to Cosmos DB via POST /1.0/tenants

### Edit Tenant
1. Click "Edit" on any tenant
2. Modify tenant name
3. System sends PUT with If-Match (ETag)
4. Updates in Cosmos DB

### Delete Tenant
1. Click "Delete" on any tenant
2. Confirm deletion
3. System sends DELETE with X-BFS-Auth
4. Removes from Cosmos DB

### Import JSON
1. Click "Import JSON"
2. Upload Postman Collection or tenant array
3. System creates tenants via POST requests
4. All saved to Cosmos DB

---

## 🎯 Status Indicators

### In Banner
```
BFS API: dp-eastus-poc-txservices-apis.azurewebsites.net
• Loading...           (during fetch)
• 5 tenant(s) ✓        (after successful load)
```

### Toast Messages
```
✅ Loaded 5 tenant(s) from BFS API
ℹ️  Connected to API. Database is empty - create your first tenant!
❌ Could not load tenants: Network error
```

---

## 🔐 Security

### API Authentication
- Every request includes `X-BFS-Auth` header
- API validates key before processing
- Invalid key returns 401 Unauthorized

### ETag Concurrency Control
- PUT/DELETE require `If-Match` header
- Prevents concurrent update conflicts
- Ensures data consistency

---

## ✅ Success Checklist

After deployment, verify:

- [ ] Application loads without errors
- [ ] Banner shows correct API hostname
- [ ] "Load from API" button works
- [ ] Tenants load automatically on start
- [ ] Can create new tenant
- [ ] Can edit existing tenant
- [ ] Can delete tenant
- [ ] Can import from Postman Collection
- [ ] No CORS errors in console

---

## 📞 Support

**API Endpoint:** `dp-eastus-poc-txservices-apis.azurewebsites.net`  
**CORS Status:** ✅ Configured  
**Authentication:** ✅ Working  
**Auto-Load:** ✅ Enabled  

**Everything is ready to use!** 🚀