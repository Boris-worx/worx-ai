# Azure AD Role-Based Access Control (RBAC) Guide

## Overview

This application uses **Microsoft Entra ID (Azure AD) Roles** to control both user permissions and section access. This approach follows Microsoft's standard RBAC pattern and is fully compatible with Microsoft Entra ID schema.

## ✅ Why Role-Based Access?

The client correctly identified that Microsoft Entra ID **does not support custom claims like "access"** in the standard schema. Instead, we use the built-in **roles** feature, which is the recommended approach for authorization in Azure AD applications.

## Supported Azure AD Roles

### Permission Roles (Control CRUD Operations)

These roles control what operations users can perform:

| Azure AD Role | App Permission | Can View | Can Create | Can Edit | Can Delete |
|--------------|----------------|----------|------------|----------|------------|
| `Portal.Admin` | Admin | ✅ | ✅ | ✅ | ✅ |
| `Portal.Editor` | Editor | ✅ | ❌ | ✅ | ✅ |
| `Portal.Reader` | Viewer | ✅ | ❌ | ❌ | ❌ |

### Section Access Roles (Control Visible Sections)

These roles control which sections of the application users can access:

| Azure AD Role | Accessible Sections |
|--------------|-------------------|
| `Portal.Admin` | All (Tenants, Transactions, Data Plane) |
| `Portal.Editor` | All (Tenants, Transactions, Data Plane) |
| `Portal.Reader` | All (Tenants, Transactions, Data Plane) |
| `Portal.Tenants` | Tenants only |
| `Portal.Transactions` | Transactions only |
| `Portal.DataPlane` | Data Plane only |

### Combining Roles for Granular Access

Users can be assigned **multiple roles** to create custom access patterns:

| Role Combination | Result |
|-----------------|--------|
| `["Portal.Tenants", "Portal.Transactions"]` | Access to Tenants and Transactions only |
| `["Portal.Reader", "Portal.Tenants"]` | Read-only access to Tenants section |
| `["Portal.Editor", "Portal.DataPlane"]` | Edit permissions on Data Plane only |
| `["Portal.Admin"]` | Full access to everything |

## How It Works

### 1. Role Parsing

When a user authenticates, the application:

```typescript
// Extract all roles from Azure AD claims
const roleClaims = claims.filter((c) => 
  c.typ === 'roles' || 
  c.typ === 'http://schemas.microsoft.com/ws/2008/06/identity/claims/role'
);

// Parse roles to determine permission level
function parseAzureRole(azureRoles: string[]): UserRole {
  if (azureRoles.includes('Portal.Admin')) return 'admin';
  if (azureRoles.includes('Portal.Editor')) return 'edit';
  return 'view'; // Default: Portal.Reader
}

// Parse roles to determine section access
function parseAzureAccess(azureRoles: string[]): AccessLevel {
  // Admin/Editor/Reader → Full access
  if (azureRoles.includes('Portal.Admin') || 
      azureRoles.includes('Portal.Editor') || 
      azureRoles.includes('Portal.Reader')) {
    return 'All';
  }
  
  // Build access based on section-specific roles
  const sections = [];
  if (azureRoles.includes('Portal.Tenants')) sections.push('Tenants');
  if (azureRoles.includes('Portal.Transactions')) sections.push('Transactions');
  if (azureRoles.includes('Portal.DataPlane')) sections.push('Data Plane');
  
  return sections.length > 0 ? sections : [];
}
```

### 2. Access Control in UI

The application checks permissions before rendering UI elements:

```typescript
// Check section access
{hasAccessTo('Tenants') && (
  <TabsTrigger value="tenants">Tenants</TabsTrigger>
)}

// Check permission level
{user?.role === 'admin' && (
  <Button onClick={createTenant}>Create Tenant</Button>
)}
```

## Setting Up Roles in Azure AD

### Step 1: Register Application Roles in Azure Portal

1. Go to **Azure Portal** → **App registrations**
2. Select your application
3. Go to **App roles**
4. Create the following roles:

#### Admin Role
```json
{
  "allowedMemberTypes": ["User"],
  "description": "Full access to all sections and operations",
  "displayName": "Portal Admin",
  "id": "<generate-unique-guid>",
  "isEnabled": true,
  "value": "Portal.Admin"
}
```

#### Editor Role
```json
{
  "allowedMemberTypes": ["User"],
  "description": "Can view, edit, and delete (but not create)",
  "displayName": "Portal Editor",
  "id": "<generate-unique-guid>",
  "isEnabled": true,
  "value": "Portal.Editor"
}
```

#### Reader Role
```json
{
  "allowedMemberTypes": ["User"],
  "description": "Read-only access to all sections",
  "displayName": "Portal Reader",
  "id": "<generate-unique-guid>",
  "isEnabled": true,
  "value": "Portal.Reader"
}
```

#### Section-Specific Roles
```json
{
  "allowedMemberTypes": ["User"],
  "description": "Access to Tenants section only",
  "displayName": "Tenants Access",
  "id": "<generate-unique-guid>",
  "isEnabled": true,
  "value": "Portal.Tenants"
}
```

Repeat for `Portal.Transactions` and `Portal.DataPlane`.

### Step 2: Assign Roles to Users

1. Go to **Azure Portal** → **Enterprise applications**
2. Select your application
3. Go to **Users and groups**
4. Click **Add user/group**
5. Select user and assign role(s)

### Step 3: Configure Token to Include Roles

1. Go to **App registrations** → Your app → **Token configuration**
2. Click **Add optional claim**
3. Select **ID** token type
4. Add **roles** claim
5. Save changes

## Example Scenarios

### Scenario 1: Finance Team Member
**Requirements:** View-only access to Transactions

**Azure AD Roles:**
```json
["Portal.Reader", "Portal.Transactions"]
```

**Result:**
- Can view Transactions section
- Cannot create, edit, or delete
- Cannot access Tenants or Data Plane

### Scenario 2: Tenant Manager
**Requirements:** Full control over Tenants

**Azure AD Roles:**
```json
["Portal.Admin", "Portal.Tenants"]
```

**Result:**
- Full CRUD access to Tenants
- Cannot access Transactions or Data Plane

### Scenario 3: System Administrator
**Requirements:** Full access to everything

**Azure AD Roles:**
```json
["Portal.Admin"]
```

**Result:**
- Full CRUD access
- Access to all sections (Tenants, Transactions, Data Plane)

### Scenario 4: Multi-Section Editor
**Requirements:** Edit Tenants and Transactions, but not Data Plane

**Azure AD Roles:**
```json
["Portal.Editor", "Portal.Tenants", "Portal.Transactions"]
```

**Result:**
- Can view, edit, delete (but not create)
- Access to Tenants and Transactions only
- Cannot access Data Plane

## Testing Role-Based Access

### Development/Testing Mode

For testing purposes, the application includes a **Role Test Dialog** that allows you to simulate different Azure AD roles:

1. Click on your user avatar in the top-right
2. Select **Change Role & Access**
3. Choose a role and section access
4. Click **Apply Changes**

This is useful for:
- Testing UI behavior with different permissions
- Validating section visibility
- Ensuring proper access control

**Note:** Test mode is only for development. In production, roles come from Azure AD.

## Security Best Practices

### ✅ DO
- Assign minimum required roles (principle of least privilege)
- Use multiple roles for granular control
- Regularly audit role assignments
- Remove roles when employees change positions
- Test role configurations before deploying to production

### ❌ DON'T
- Assign `Portal.Admin` unless absolutely necessary
- Mix permission roles with section roles unnecessarily
- Rely on client-side checks alone (always validate on backend)
- Share admin credentials

## Troubleshooting

### Roles Not Appearing in Token

**Solution:**
1. Verify roles are defined in **App registrations → App roles**
2. Check **Token configuration** includes `roles` claim
3. Ensure roles are assigned in **Enterprise applications → Users and groups**
4. Sign out and sign back in to get new token

### User Has Wrong Permissions

**Solution:**
1. Check assigned roles in Azure Portal
2. Verify role parsing logic in `lib/azure-auth.ts`
3. Clear browser cache and localStorage
4. Check console logs for role parsing output

### Section Not Visible

**Solution:**
1. Verify user has correct section role (e.g., `Portal.Tenants`)
2. Check `hasAccessTo()` function in `AuthContext.tsx`
3. Ensure role is correctly parsed in `parseAzureAccess()`

## Migration from Custom Claims

If you previously used custom claims like `access`, here's how to migrate:

### Before (Custom Claim - Not Supported)
```typescript
// ❌ This doesn't work with Microsoft Entra ID
const accessClaim = claims.find((c) => c.typ === 'access');
access: parseAzureAccess(accessClaim?.val || 'All')
```

### After (Role-Based - Fully Supported)
```typescript
// ✅ This works with Microsoft Entra ID
const roleClaims = claims.filter((c) => c.typ === 'roles');
access: parseAzureAccess(roleClaims.map(c => c.val).flat())
```

## Summary

✅ **Uses Microsoft Entra ID standard schema (roles)**  
✅ **No custom claims required**  
✅ **Fully compatible with Azure AD RBAC**  
✅ **Supports multiple roles per user**  
✅ **Granular permission and section control**  
✅ **Easy to configure in Azure Portal**  

This implementation follows Microsoft's recommended practices for authorization and is production-ready for Azure App Service deployment.
