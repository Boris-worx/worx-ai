# 📚 BFS Portal - Индекс документации

## Обзор

Этот файл содержит ссылки на всю документацию BFS Portal, организованную по темам.

---

## 🗂️ Data Sources

### Основная документация

| Документ | Описание | Для кого |
|----------|----------|----------|
| [DATASOURCES_README_RU.md](DATASOURCES_README_RU.md) | 📋 Главный README с оглавлением | Все |
| [DATASOURCES_SUMMARY_RU.md](DATASOURCES_SUMMARY_RU.md) | 📝 Краткая сводка изменений | Менеджеры, Тестировщики |
| [DATASOURCES_CHEATSHEET_RU.md](DATASOURCES_CHEATSHEET_RU.md) | 🚀 Шпаргалка для разработчиков | Разработчики |

### Технические руководства

| Документ | Описание | Для кого |
|----------|----------|----------|
| [TENANT_ISOLATION_RU.md](TENANT_ISOLATION_RU.md) | 🔐 Архитектура изоляции тенантов | Архитекторы, Разработчики |
| [GLOBAL_TENANT_DATASOURCES_FIX_RU.md](GLOBAL_TENANT_DATASOURCES_FIX_RU.md) | 🔧 Исправление GLOBAL TENANT | Разработчики |
| [DATASOURCE_DELETE_FIX_RU.md](DATASOURCE_DELETE_FIX_RU.md) | 🗑️ Исправление удаления | Разработчики |
| [DATASOURCE_DELETE_GUIDE_RU.md](DATASOURCE_DELETE_GUIDE_RU.md) | 🗑️ Руководство по удалению | Разработчики, Тестировщики |
| [CHANGELOG_DATASOURCES_RU.md](CHANGELOG_DATASOURCES_RU.md) | 📜 Полный changelog | Все |

### Руководства по тестированию

| Документ | Описание | Для кого |
|----------|----------|----------|
| [TESTING_GLOBAL_TENANT_RU.md](TESTING_GLOBAL_TENANT_RU.md) | 🧪 Тестирование GLOBAL TENANT | Тестировщики, QA |
| [DATASOURCE_CURL_TEST_RU.md](DATASOURCE_CURL_TEST_RU.md) | 🔌 curl команды для API | Разработчики, Тестировщики |
| [DATASOURCE_DELETE_CHECKLIST.md](DATASOURCE_DELETE_CHECKLIST.md) | ✅ Чеклист удаления | Тестировщики, QA |

### Quick Start руководства

| Документ | Описание | Для кого |
|----------|----------|----------|
| [DATASOURCE_DELETE_QUICK_START.md](DATASOURCE_DELETE_QUICK_START.md) | 🚀 Быстрый старт удаления | Все |
| [DATASOURCE_DELETE_SUMMARY.md](DATASOURCE_DELETE_SUMMARY.md) | 📋 Сводка по удалению | Менеджеры, Разработчики |

---

## 📖 Быстрая навигация

### Я новый разработчик
1. Начните с [DATASOURCES_SUMMARY_RU.md](DATASOURCES_SUMMARY_RU.md) - краткий обзор
2. Прочитайте [DATASOURCES_CHEATSHEET_RU.md](DATASOURCES_CHEATSHEET_RU.md) - шпаргалка
3. Изучите [TENANT_ISOLATION_RU.md](TENANT_ISOLATION_RU.md) - архитектура

### Мне нужно протестировать
1. [TESTING_GLOBAL_TENANT_RU.md](TESTING_GLOBAL_TENANT_RU.md) - UI тесты
2. [DATASOURCE_CURL_TEST_RU.md](DATASOURCE_CURL_TEST_RU.md) - API тесты

### У меня проблема
1. Проверьте [DATASOURCES_SUMMARY_RU.md](DATASOURCES_SUMMARY_RU.md) - типовые проблемы
2. Прочитайте соответствующий Fix документ
3. Посмотрите [DATASOURCES_CHEATSHEET_RU.md](DATASOURCES_CHEATSHEET_RU.md) - debugging

### Я архитектор/тим лид
1. [TENANT_ISOLATION_RU.md](TENANT_ISOLATION_RU.md) - архитектура
2. [CHANGELOG_DATASOURCES_RU.md](CHANGELOG_DATASOURCES_RU.md) - история изменений
3. [DATASOURCES_README_RU.md](DATASOURCES_README_RU.md) - полный обзор

---

## 🎯 По проблемам

| Проблема | Решение | Документ |
|----------|---------|----------|
| GLOBAL TENANT не показывает все data sources | Параллельные запросы ко всем тенантам | [GLOBAL_TENANT_DATASOURCES_FIX_RU.md](GLOBAL_TENANT_DATASOURCES_FIX_RU.md) |
| После удаления data source появляется снова | Задержка 1 сек перед refresh | [DATASOURCE_DELETE_FIX_RU.md](DATASOURCE_DELETE_FIX_RU.md) |
| После создания data source не появляется | Задержка 1 сек перед refresh | [DATASOURCE_DELETE_FIX_RU.md](DATASOURCE_DELETE_FIX_RU.md) |
| Не вижу кнопку Delete | Недостаточно прав (нужен SuperUser/Admin/Developer) | [DATASOURCE_DELETE_GUIDE_RU.md](DATASOURCE_DELETE_GUIDE_RU.md) |
| Как удалить Data Source? | 5-шаговая инструкция | [DATASOURCE_DELETE_QUICK_START.md](DATASOURCE_DELETE_QUICK_START.md) |
| Не понимаю как работает изоляция | Архитектура мультитенантности | [TENANT_ISOLATION_RU.md](TENANT_ISOLATION_RU.md) |
| Нужны curl команды | Примеры всех операций | [DATASOURCE_CURL_TEST_RU.md](DATASOURCE_CURL_TEST_RU.md) |
| Как протестировать GLOBAL? | Пошаговая инструкция | [TESTING_GLOBAL_TENANT_RU.md](TESTING_GLOBAL_TENANT_RU.md) |

---

## 📋 Чеклисты

### Чеклист перед деплоем

```
Data Sources:
  ✅ GLOBAL TENANT видит все data sources
  ✅ Конкретный тенант видит только свои data sources
  ✅ Создание работает
  ✅ Удаление работает
  ✅ Обновление работает
  ✅ Изоляция тенантов работает
  ✅ Логирование информативное
  ✅ Производительность приемлемая
  ✅ Документация актуальна
```

См. полный чеклист в [TESTING_GLOBAL_TENANT_RU.md](TESTING_GLOBAL_TENANT_RU.md)

### Чеклист для code review

```
Code Review - Data Sources:
  ✅ ETag используется для update/delete
  ✅ Задержка перед refreshData() после операций
  ✅ Ошибки обрабатываются gracefully
  ✅ Логирование добавлено
  ✅ tenantId валидируется
  ✅ Изоляция тенантов сохранена
  ✅ Код задокументирован
```

---

## 🔗 Связанные документы

### Другие компоненты

*(Будут добавлены)*

- Tenants
- Transactions
- Model Schemas
- Applications
- Data Plane

### Инфраструктура

*(Будут добавлены)*

- API Documentation
- Authentication & Authorization
- Deployment Guide
- Monitoring & Logging

---

## 📊 Статистика документации

### Data Sources

- **Документов:** 13
- **Страниц:** ~200
- **Code snippets:** ~70
- **curl примеров:** ~25
- **Чеклистов:** 15+

### Охват

| Тема | Покрытие |
|------|----------|
| Архитектура | ✅ 100% |
| CRUD операции | ✅ 100% |
| Изоляция тенантов | ✅ 100% |
| Тестирование | ✅ 100% |
| Troubleshooting | ✅ 100% |
| API Reference | ✅ 100% |
| Delete Operations | ✅ 100% |

---

## 🔍 Поиск по документации

### Поиск по ключевым словам

```bash
# GLOBAL TENANT
grep -r "GLOBAL TENANT" /*.md

# Изоляция
grep -r "isolation\|изоляция" /*.md

# API
grep -r "curl\|API" /*.md

# Тестирование
grep -r "test\|тест" /*.md
```

### Поиск по проблемам

```bash
# Проблемы с удалением
grep -r "delete\|удаление" /*.md

# Проблемы с созданием
grep -r "create\|создание" /*.md

# Проблемы с GLOBAL
grep -r "global" /*.md
```

---

## 📅 История обновлений

| Дата | Изменения | Документы |
|------|-----------|-----------|
| 2025-11-13 | GLOBAL TENANT fix, полная документация | 9 документов |
| 2025-11-12 | Delete fix | DATASOURCE_DELETE_FIX_RU.md |
| 2025-11-09 | Create fix | - |

---

## 👥 Кому что читать?

### Новый разработчик
1. ⭐ [DATASOURCES_SUMMARY_RU.md](DATASOURCES_SUMMARY_RU.md) - обзор
2. ⭐ [DATASOURCES_CHEATSHEET_RU.md](DATASOURCES_CHEATSHEET_RU.md) - шпаргалка
3. [TENANT_ISOLATION_RU.md](TENANT_ISOLATION_RU.md) - архитектура

### Тестировщик/QA
1. ⭐ [TESTING_GLOBAL_TENANT_RU.md](TESTING_GLOBAL_TENANT_RU.md) - UI тесты
2. ⭐ [DATASOURCE_CURL_TEST_RU.md](DATASOURCE_CURL_TEST_RU.md) - API тесты
3. [DATASOURCES_SUMMARY_RU.md](DATASOURCES_SUMMARY_RU.md) - обзор проблем

### Архитектор/Team Lead
1. ⭐ [TENANT_ISOLATION_RU.md](TENANT_ISOLATION_RU.md) - архитектура
2. ⭐ [CHANGELOG_DATASOURCES_RU.md](CHANGELOG_DATASOURCES_RU.md) - история
3. [DATASOURCES_README_RU.md](DATASOURCES_README_RU.md) - полный обзор

### Менеджер проекта
1. ⭐ [DATASOURCES_SUMMARY_RU.md](DATASOURCES_SUMMARY_RU.md) - краткая сводка
2. [CHANGELOG_DATASOURCES_RU.md](CHANGELOG_DATASOURCES_RU.md) - что изменилось
3. Чеклисты в [TESTING_GLOBAL_TENANT_RU.md](TESTING_GLOBAL_TENANT_RU.md)

### DevOps
1. [DATASOURCE_CURL_TEST_RU.md](DATASOURCE_CURL_TEST_RU.md) - API тесты
2. [DATASOURCES_CHEATSHEET_RU.md](DATASOURCES_CHEATSHEET_RU.md) - debugging
3. Производительность в [CHANGELOG_DATASOURCES_RU.md](CHANGELOG_DATASOURCES_RU.md)

---

## 🎓 Обучающие материалы

### Введение в BFS Portal

*(Будет добавлено)*

### Работа с Data Sources

1. **Основы** - [DATASOURCES_SUMMARY_RU.md](DATASOURCES_SUMMARY_RU.md)
2. **Практика** - [DATASOURCES_CHEATSHEET_RU.md](DATASOURCES_CHEATSHEET_RU.md)
3. **Углубленно** - [TENANT_ISOLATION_RU.md](TENANT_ISOLATION_RU.md)

### Тестирование

1. **UI Testing** - [TESTING_GLOBAL_TENANT_RU.md](TESTING_GLOBAL_TENANT_RU.md)
2. **API Testing** - [DATASOURCE_CURL_TEST_RU.md](DATASOURCE_CURL_TEST_RU.md)
3. **Troubleshooting** - [DATASOURCES_CHEATSHEET_RU.md](DATASOURCES_CHEATSHEET_RU.md)

---

## 🌐 Внешние ресурсы

### BFS API
- **Base URL:** `https://dp-eastus-poc-txservices-apis.azurewebsites.net`
- **Auth:** `X-BFS-Auth: dummytoken123`

### Apicurio Registry
- **URL:** `http://apicurio.52.158.160.62.nip.io`
- **Groups:** `bfs.online`, `paradigm.mybldr.bidtools`

### React/TypeScript
- [React Docs](https://react.dev)
- [TypeScript Docs](https://www.typescriptlang.org)
- [shadcn/ui](https://ui.shadcn.com)

---

## 📞 Контакты и поддержка

### BFS Portal Development Team

**Вопросы по документации:**
- Проверьте соответствующий документ
- Используйте поиск по документации
- Обратитесь к команде

**Технические проблемы:**
1. Проверьте консоль браузера (F12)
2. Проверьте Network tab
3. Прочитайте Troubleshooting
4. Обратитесь к команде

**Предложения по улучшению:**
- Welcome! Создайте issue/PR

---

## 📝 Как пользоваться этим индексом?

### Быстрый поиск

1. **По роли** - см. раздел "Кому что читать?"
2. **По проблеме** - см. раздел "По проблемам"
3. **По теме** - см. таблицы в начале

### Систематическое изучение

1. Начните с ⭐ документов для вашей роли
2. Прочитайте связанные документы
3. Попробуйте примеры из документации
4. Обратитесь к Troubleshooting при проблемах

### Справочное использование

1. Используйте поиск по ключевым словам
2. Проверяйте чеклисты
3. Копируйте code snippets

---

## ✨ Что нового?

### Последние обновления (2025-11-13)

✅ **Исправлено:** GLOBAL TENANT теперь показывает все data sources  
✅ **Добавлено:** 9 документов с полным описанием  
✅ **Улучшено:** Логирование и диагностика  
✅ **Протестировано:** Все сценарии работают  

### В разработке

⏳ Оптимистичное обновление UI  
⏳ Pagination для больших списков  
⏳ Batch API endpoint  

---

## 📄 Лицензия

Proprietary - BFS Internal Use Only

---

**Навигация:**
- [▶ Начать с обзора](DATASOURCES_SUMMARY_RU.md)
- [▶ Полный README](DATASOURCES_README_RU.md)
- [▶ Шпаргалка](DATASOURCES_CHEATSHEET_RU.md)

---

**Последнее обновление:** 13 ноября 2025  
**Версия индекса:** 1.0