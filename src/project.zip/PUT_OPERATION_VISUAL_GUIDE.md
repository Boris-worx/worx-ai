# 🎯 Visual Guide: PUT Operation for inv.response

## Current State → Desired State

```
┌─────────────────────────────────────────────────────────────┐
│                    BEFORE (Current)                         │
├─────────────────────────────────────────────────────────────┤
│  Artifact: bfs.online/inv.response                          │
│  Version: 1.0.0                                             │
│                                                             │
│  {                                                          │
│    "type": "object",                                        │
│    "name": "inv",        ← Current Value                   │
│    "properties": { ... }                                    │
│  }                                                          │
└─────────────────────────────────────────────────────────────┘
                         ↓
                    PUT Request
                         ↓
┌─────────────────────────────────────────────────────────────┐
│                     AFTER (Updated)                         │
├─────────────────────────────────────────────────────────────┤
│  Artifact: bfs.online/inv.response                          │
│  Version: 1.0.1        ← New Version Created               │
│                                                             │
│  {                                                          │
│    "type": "object",                                        │
│    "name": "TxServices_inv",  ← New Value                 │
│    "properties": { ... }                                    │
│  }                                                          │
└─────────────────────────────────────────────────────────────┘
```

---

## 🚀 Method 1: Quick Fix Button

```
┌──────────────────────────────────────────────────────────────┐
│  🏠 BFS Tenant Management Platform                           │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  [Tenants] [Transactions] [📄 Data Sources] [Apps] [Data]   │
│                              ↑                               │
│                         Click Here                           │
└──────────────────────────────────────────────────────────────┘

                         ↓

┌──────────────────────────────────────────────────────────────┐
│  Data Source Onboarding                                      │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌────────────────────────────────────────────────────────┐ │
│  │ [Tenant: Global ▼]  [⚙️ Columns]                       │ │
│  │                                                         │ │
│  │         [⚡ Quick Fix: inv → TxServices_inv]           │ │
│  │                  ↑                                      │ │
│  │            Click Here!                  [+ Add Data...] │ │
│  └────────────────────────────────────────────────────────┘ │
│                                                              │
│  [Data Sources Table]                                        │
└──────────────────────────────────────────────────────────────┘

                         ↓

┌──────────────────────────────────────────────────────────────┐
│  Processing...                                               │
│                                                              │
│  🔄 Updating...                                              │
└──────────────────────────────────────────────────────────────┘

                         ↓

┌──────────────────────────────────────────────────────────────┐
│  ✅ Success Toast                                            │
│                                                              │
│  Updated successfully!                                       │
│  inv.response → name: "TxServices_inv" (v1.0.1)              │
└──────────────────────────────────────────────────────────────┘
```

---

## 🧪 Method 2: PUT Test (Detailed)

```
┌──────────────────────────────────────────────────────────────┐
│  🏠 BFS Tenant Management Platform                           │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  [🗄️]  ← Database Icon in Top Right                         │
│   ↑                                                          │
│  Click Here                                                  │
└──────────────────────────────────────────────────────────────┘

                         ↓

┌──────────────────────────────────────────────────────────────┐
│  API Connection Diagnostics                          [✕]    │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  [Apicurio Registry] [BFS API] [🧪 PUT Test]                │
│                                  ↑                           │
│                             Click Here                       │
└──────────────────────────────────────────────────────────────┘

                         ↓

┌──────────────────────────────────────────────────────────────┐
│  🧪 Apicurio PUT Operation Test                              │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌────────────────────────────────────────────────────────┐ │
│  │ Test Details:                                          │ │
│  │ Target: bfs.online/inv.response                        │ │
│  │ Change: "name": "inv" → "name": "TxServices_inv"       │ │
│  │ Method: PUT                                            │ │
│  │ URL: https://apicurio-poc.../inv.response              │ │
│  └────────────────────────────────────────────────────────┘ │
│                                                              │
│  ┌────────────────────────────────────────────────────────┐ │
│  │              [▶ Run PUT Test]                          │ │
│  │                     ↑                                  │ │
│  │                Click Here                              │ │
│  └────────────────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────────────────┘

                         ↓

┌──────────────────────────────────────────────────────────────┐
│  Console Output (F12)                                        │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  🧪 ========== Apicurio PUT Test Started ==========         │
│  📦 Target: bfs.online/inv.response                          │
│  📦 Change: name: 'inv' → 'TxServices_inv'                   │
│                                                              │
│  📦 Step 1: Fetching current content...                      │
│  📦 Current name field: "inv"                                │
│                                                              │
│  📦 Step 2: Modifying content...                             │
│  📦 New name field: "TxServices_inv"                         │
│                                                              │
│  📦 Step 3: Sending PUT request...                           │
│  📦 PUT: Response status: 200                                │
│  📦 ✅ PUT successful                                        │
│                                                              │
│  📦 Step 4: Verifying the change...                          │
│  📦 Verified name field: "TxServices_inv"                    │
│  ✅ Change verified!                                         │
│                                                              │
│  🧪 ========== Test Completed Successfully ==========       │
└──────────────────────────────────────────────────────────────┘

                         ↓

┌──────────────────────────────────────────────────────────────┐
│  ✅ Test Result in UI                                        │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌────────────────────────────────────────────────────────┐ │
│  │ ✅ Test Passed                                         │ │
│  │                                                        │ │
│  │ Successfully updated artifact!                         │ │
│  │ Old value: "inv"                                       │ │
│  │ New value: "TxServices_inv"                            │ │
│  │ Version: 1.0.1                                         │ │
│  │                                                        │ │
│  │ [Details ▼]                                            │ │
│  └────────────────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────────────────┘
```

---

## 🔄 PUT Request Flow Diagram

```
┌────────────────┐
│  Application   │
│   (Browser)    │
└───────┬────────┘
        │
        │ 1. Get Current Content
        ▼
┌────────────────────────────────────────────────────────┐
│  GET /groups/bfs.online/artifacts/inv.response/        │
│      versions/latest/content                           │
└────────────────────────────────────────────────────────┘
        │
        ▼
┌────────────────┐
│   Response:    │
│ {              │
│   "name": "inv"│
│   ...          │
│ }              │
└───────┬────────┘
        │
        │ 2. Modify in JavaScript
        ▼
┌────────────────────────┐
│  const modified = {    │
│    ...content,         │
│    name: "TxServices_  │
│          inv"          │
│  }                     │
└────────┬───────────────┘
         │
         │ 3. Send PUT Request
         ▼
┌────────────────────────────────────────────────────────┐
│  PUT /groups/bfs.online/artifacts/inv.response         │
│  Content-Type: application/json                        │
│                                                        │
│  {                                                     │
│    "type": "object",                                   │
│    "name": "TxServices_inv",  ← Modified              │
│    "properties": { ... }                               │
│  }                                                     │
└────────────────────────────────────────────────────────┘
         │
         ▼
┌─────────────────────┐
│ Apicurio Registry   │
│                     │
│ ✅ Creates new      │
│    version: 1.0.1   │
│                     │
│ ✅ Stores updated   │
│    content          │
└──────────┬──────────┘
           │
           │ 4. Response
           ▼
┌──────────────────────┐
│  {                   │
│    "version": "1.0.1"│
│    "artifactId": "..." │
│    "groupId": "..."  │
│  }                   │
└──────────┬───────────┘
           │
           │ 5. Verify (optional)
           ▼
┌────────────────────────────────────────────────────────┐
│  GET /groups/bfs.online/artifacts/inv.response/        │
│      versions/latest/content                           │
└────────────────────────────────────────────────────────┘
           │
           ▼
┌──────────────────────────┐
│  Response:               │
│  {                       │
│    "name": "TxServices_  │
│             inv"  ✅     │
│    ...                   │
│  }                       │
└──────────────────────────┘
```

---

## 📊 What Happens Behind the Scenes

```
User Action
    ↓
┌─────────────────────────────────────────────────────┐
│  1. updateApicurioArtifact() called                 │
│     - groupId: "bfs.online"                         │
│     - artifactId: "inv.response"                    │
│     - content: { ...schema, name: "TxServices_inv" }│
└─────────────────────────────────────────────────────┘
    ↓
┌─────────────────────────────────────────────────────┐
│  2. fetch() with PUT method                         │
│     - URL: .../groups/.../artifacts/...             │
│     - Method: PUT                                   │
│     - Body: JSON.stringify(content)                 │
│     - Headers: Content-Type: application/json       │
└─────────────────────────────────────────────────────┘
    ↓
┌─────────────────────────────────────────────────────┐
│  3. Apicurio Registry Processing                    │
│     - Validates JSON schema                         │
│     - Creates new version (1.0.1)                   │
│     - Stores content                                │
│     - Returns metadata                              │
└─────────────────────────────────────────────────────┘
    ↓
┌─────────────────────────────────────────────────────┐
│  4. Application Updates                             │
│     - clearArtifactsCache()                         │
│     - Show success toast                            │
│     - Log to console                                │
└─────────────────────────────────────────────────────┘
```

---

## 🎯 Quick Reference

| What | Where | How |
|------|-------|-----|
| **Quick Fix** | Data Sources tab | Click "Quick Fix: inv → TxServices_inv" |
| **Full Test** | Database Icon → PUT Test | Click "Run PUT Test" |
| **View Logs** | Browser Console (F12) | Check detailed execution logs |
| **Verify** | Console or GET request | Check "name" field value |

---

## ✅ Success Indicators

### In UI
- ✅ Toast message: "Updated successfully!"
- ✅ Version shown (e.g., v1.0.1)
- ✅ Green checkmark icon

### In Console
- ✅ `📦 ✅ PUT successful`
- ✅ `✅ Change verified!`
- ✅ No error messages
- ✅ Status 200

### In Apicurio
- ✅ New version created
- ✅ `name` field = `"TxServices_inv"`
- ✅ All other fields preserved

---

## 🔍 Verification Commands

```bash
# Check updated content
curl https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/bfs.online/artifacts/inv.response/versions/latest/content | jq '.name'

# Expected output: "TxServices_inv"

# Check version list
curl https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/bfs.online/artifacts/inv.response/versions | jq '.versions'

# Expected: Array with new version 1.0.1
```
