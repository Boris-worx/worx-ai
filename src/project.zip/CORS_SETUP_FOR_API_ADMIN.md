# 🔧 CORS Setup Guide for API Administrator

## ❌ Current Problem

The BFS web application cannot connect to the API due to CORS (Cross-Origin Resource Sharing) policy.

**Error Message:**
```
❌ Error fetching tenants: TypeError: Failed to fetch
```

## 🎯 What is CORS?

CORS is a browser security feature that blocks web applications from making requests to a different domain unless the server explicitly allows it.

**Current Situation:**
- Web App Domain: `make.figma.com` (or your deployment domain)
- API Domain: `poc-apis-bfs.azurewebsites.net`
- Browser: **Blocking** the request (different domains)

## ✅ Solution: Enable CORS on API Server

The API server must send these HTTP headers in responses:

### Required CORS Headers

```http
Access-Control-Allow-Origin: *
Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS
Access-Control-Allow-Headers: X-BFS-Auth, Content-Type, If-Match
Access-Control-Max-Age: 86400
```

### For Preflight Requests (OPTIONS)

The browser sends an OPTIONS request before the actual request. The API must respond:

**Request from Browser:**
```http
OPTIONS /1.0/tenants HTTP/1.1
Host: poc-apis-bfs.azurewebsites.net
Origin: https://make.figma.com
Access-Control-Request-Method: GET
Access-Control-Request-Headers: x-bfs-auth
```

**API Must Respond:**
```http
HTTP/1.1 204 No Content
Access-Control-Allow-Origin: *
Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS
Access-Control-Allow-Headers: X-BFS-Auth, Content-Type, If-Match
Access-Control-Max-Age: 86400
```

## 🔧 Implementation by Platform

### Azure App Service (Current Platform)

#### Option 1: Via Azure Portal
1. Go to Azure Portal
2. Navigate to your App Service: `poc-apis-bfs`
3. Settings → CORS
4. Add allowed origin: `*` (or specific domain)
5. Save

#### Option 2: Via Code (ASP.NET Core Example)
```csharp
// In Startup.cs or Program.cs
public void ConfigureServices(IServiceCollection services)
{
    services.AddCors(options =>
    {
        options.AddPolicy("AllowAll",
            builder =>
            {
                builder.AllowAnyOrigin()
                       .AllowAnyMethod()
                       .AllowAnyHeader()
                       .WithExposedHeaders("ETag");
            });
    });
}

public void Configure(IApplicationBuilder app)
{
    app.UseCors("AllowAll");
    // ... other middleware
}
```

#### Option 3: Via web.config
```xml
<configuration>
  <system.webServer>
    <httpProtocol>
      <customHeaders>
        <add name="Access-Control-Allow-Origin" value="*" />
        <add name="Access-Control-Allow-Methods" value="GET, POST, PUT, DELETE, OPTIONS" />
        <add name="Access-Control-Allow-Headers" value="X-BFS-Auth, Content-Type, If-Match" />
      </customHeaders>
    </httpProtocol>
  </system.webServer>
</configuration>
```

### Node.js / Express

```javascript
const cors = require('cors');

app.use(cors({
  origin: '*', // or specific domain
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['X-BFS-Auth', 'Content-Type', 'If-Match'],
  exposedHeaders: ['ETag']
}));
```

### Python / Flask

```python
from flask_cors import CORS

app = Flask(__name__)
CORS(app, resources={
    r"/*": {
        "origins": "*",
        "methods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
        "allow_headers": ["X-BFS-Auth", "Content-Type", "If-Match"]
    }
})
```

## 🧪 Testing CORS Configuration

### Test 1: Using curl
```bash
curl -X OPTIONS \
  'https://poc-apis-bfs.azurewebsites.net/1.0/tenants' \
  -H 'Origin: https://make.figma.com' \
  -H 'Access-Control-Request-Method: GET' \
  -H 'Access-Control-Request-Headers: x-bfs-auth' \
  -v
```

**Expected Response:**
```
< HTTP/1.1 204 No Content
< Access-Control-Allow-Origin: *
< Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS
< Access-Control-Allow-Headers: X-BFS-Auth, Content-Type, If-Match
```

### Test 2: Using Browser Console
```javascript
fetch('https://poc-apis-bfs.azurewebsites.net/1.0/tenants', {
  method: 'GET',
  headers: {
    'X-BFS-Auth': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
  }
})
.then(res => console.log('✅ Success:', res.status))
.catch(err => console.error('❌ Error:', err));
```

### Test 3: Online CORS Tester
Visit: https://www.test-cors.org/
- Remote URL: `https://poc-apis-bfs.azurewebsites.net/1.0/tenants`
- Method: GET
- Add header: `X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`

## 📋 Checklist for API Admin

- [ ] Add `Access-Control-Allow-Origin: *` header
- [ ] Add `Access-Control-Allow-Methods` header
- [ ] Add `Access-Control-Allow-Headers` header with `X-BFS-Auth`
- [ ] Handle OPTIONS preflight requests
- [ ] Test with curl
- [ ] Test from browser
- [ ] Notify web app developer when ready

## 🔐 Security Considerations

### Production Recommendation
Instead of `Access-Control-Allow-Origin: *`, use specific domain:

```http
Access-Control-Allow-Origin: https://make.figma.com
```

Or multiple domains:
```csharp
var allowedOrigins = new[] {
    "https://make.figma.com",
    "https://app.yourdomain.com",
    "http://localhost:3000" // for development
};

services.AddCors(options =>
{
    options.AddPolicy("AllowSpecificOrigins",
        builder => builder.WithOrigins(allowedOrigins)
                          .AllowAnyMethod()
                          .AllowAnyHeader()
                          .WithExposedHeaders("ETag"));
});
```

## 📞 Contact Information

**When CORS is configured, notify:**
- Web App Developer
- DevOps Team

**Provide:**
- ✅ Confirmation that CORS is enabled
- ✅ List of allowed origins
- ✅ curl test results

## 📊 Current API Endpoints

All these endpoints need CORS:
```
GET    /1.0/tenants
GET    /1.0/tenants/{id}
POST   /1.0/tenants
PUT    /1.0/tenants/{id}
DELETE /1.0/tenants/{id}
```

**Custom Headers Used:**
- `X-BFS-Auth` - Required on all requests
- `If-Match` - Required on PUT/DELETE (contains ETag)
- `Content-Type` - application/json

## ✅ Expected Behavior After CORS Setup

1. **Browser Console (F12):**
   ```
   🌐 Fetching tenants from: https://poc-apis-bfs.azurewebsites.net/1.0/tenants
   📡 Response status: 200 OK
   ✅ Loaded 5 tenant(s) from API
   ```

2. **Web App UI:**
   ```
   BFS API: poc-apis-bfs.azurewebsites.net • 5 tenant(s) loaded ✓
   ```

3. **No Errors:**
   - ❌ No "Failed to fetch"
   - ❌ No "CORS policy" errors
   - ✅ Tenants appear in table

## 🚀 Quick Fix for Azure App Service

**Fastest Solution (2 minutes):**

1. Login to Azure Portal
2. Go to `poc-apis-bfs` App Service
3. Settings → Configuration → CORS
4. Add: `*` to Allowed Origins
5. Check "Enable Access-Control-Allow-Credentials" (optional)
6. Save
7. Restart App Service

**Test immediately after:**
```bash
curl -X GET 'https://poc-apis-bfs.azurewebsites.net/1.0/tenants' \
  -H 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
  -H 'Origin: https://make.figma.com' \
  -v
```

Look for `Access-Control-Allow-Origin` in response headers.

---

**Status:** Waiting for CORS configuration on `poc-apis-bfs.azurewebsites.net`  
**Priority:** High - Blocking web app functionality  
**Estimated Fix Time:** 5-10 minutes
