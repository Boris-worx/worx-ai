# 🎯 APICURIO - БЕЗ MOCK ДАННЫХ

## ✅ ЧТО ИЗМЕНИЛОСЬ

**УДАЛЕНЫ ВСЕ MOCK ДАННЫЕ** - система работает только с реальным Apicurio Registry API.

## 📦 ДВЕ ГРУППЫ ШАБЛОНОВ

### paradigm.bidtools2
```
https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/paradigm.bidtools2/artifacts/
```
- CDC_SQLServer_* шаблоны
- TxServices_SQLServer_* шаблоны

### bfs.online
```
https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/bfs.online/artifacts/
```
- TxServices_Informix_* шаблоны
- loc, loc1, stcode, inv, inv1-3, invap, invdes, invloc, keyi

## 🔄 НОВОЕ ПОВЕДЕНИЕ

| Сценарий | Старое (с MOCK) | Новое (без MOCK) |
|----------|----------------|------------------|
| API работает | Реальные данные | Реальные данные ✅ |
| API 403/404 | MOCK данные | Ошибка или кеш ⚠️ |
| Сеть недоступна | MOCK данные | Кеш или пусто ⚠️ |
| Нет кеша + ошибка | MOCK данные (18 шт) | Пустой список ⚠️ |

## 💾 КЕШИРОВАНИЕ

- **Длительность**: 30 минут
- **Хранилище**: localStorage + память
- **При ошибке**: Использует expired кеш
- **Очистка**: `clearArtifactsCache()`

## 📊 СТАТИСТИКА

```
Удалено строк:       ~1,105
Было строк:          ~1,900
Стало строк:         ~795
MOCK артефактов:     18 → 0
MOCK схем:           11 → 0
```

## ⚡ БЫСТРАЯ ПРОВЕРКА

### 1. Открыть шаблоны
```
Data Source Onboarding → Create from Template
```

### 2. Проверить консоль
Должно быть:
```
✅ 📦 Fetching all groups from: ...
✅ 📦 Found 2 groups: paradigm.bidtools2, bfs.online
✅ 📦 ✅ Loaded X artifacts from paradigm.bidtools2
✅ 📦 ✅ Loaded X artifacts from bfs.online
```

НЕ должно быть:
```
❌ using local Apicurio templates
❌ using mock data
❌ 18 available
```

### 3. Выбрать шаблон
- Должна загрузиться реальная схема из API
- При ошибке - toast с сообщением

## 📁 ФАЙЛЫ

### Изменены
- `/lib/apicurio.ts` - полная переработка
- `/components/DataCaptureSpecCreateDialog.tsx` - обновлены комментарии

### Документация
1. `APICURIO_MOCK_REMOVED_SUMMARY.txt` - краткая сводка
2. `APICURIO_REAL_DATA_ONLY.md` - справочник (EN)
3. `APICURIO_NO_MOCK_DATA_RU.md` - подробности (RU)
4. `APICURIO_NO_MOCK_CHECKLIST.md` - чеклист тестирования
5. `APICURIO_DOCS_NO_MOCK.md` - индекс документации

## 🧪 ТЕСТ В КОНСОЛИ

```javascript
// Проверить удаление MOCK функций
import('./lib/apicurio').then(module => {
  console.log('Mock functions removed:', {
    getMockApicurioArtifacts: typeof module.getMockApicurioArtifacts === 'undefined', // true ✅
    getMockArtifactSchema: typeof module.getMockArtifactSchema === 'undefined' // true ✅
  });
});

// Загрузить реальные данные
import('./lib/apicurio').then(async m => {
  const result = await m.searchApicurioArtifacts();
  console.log(`✅ Загружено ${result.count} реальных артефактов`);
  console.log('Группы:', [...new Set(result.artifacts.map(a => a.groupId))]);
});

// Очистить кеш
import('./lib/apicurio').then(m => {
  m.clearArtifactsCache();
  console.log('✅ Кеш очищен');
});
```

## ❓ ЧАСТЫЕ ВОПРОСЫ

**Q: Что если Apicurio недоступен?**  
A: Первая загрузка провалится. Повторные используют кеш (30 мин). После истечения - пустой список.

**Q: Можно ли вернуть MOCK данные?**  
A: Нет. Требование: **НЕТ MOCK ДАННЫХ**.

**Q: Как тестировать offline?**  
A: Загрузить шаблоны один раз (создаст кеш), потом работать offline 30 минут.

**Q: Как очистить кеш?**  
A: `clearArtifactsCache()` или `localStorage.removeItem('apicurio_artifacts_cache')`

## ⚠️ ВАЖНО

### ✅ Осталось
- Динамическая загрузка из API
- Автоопределение версий
- Кеширование
- Обработка CDC/AVRO/JSON
- Все utility функции

### ❌ Удалено
- Все MOCK данные
- Fallback на MOCK при ошибках
- Функция `getMockApicurioArtifacts()`
- Функция `getMockArtifactSchema()`
- ~1,105 строк кода

## 🎯 ИТОГ

```
✅ НЕТ MOCK ДАННЫХ
✅ ТОЛЬКО РЕАЛЬНЫЕ ДАННЫЕ ИЗ API  
✅ ДВЕ ГРУППЫ: paradigm.bidtools2 + bfs.online
✅ GRACEFUL DEGRADATION ЧЕРЕЗ КЕШ
✅ ПОНЯТНЫЕ ОШИБКИ ДЛЯ ПОЛЬЗОВАТЕЛЯ
```

---

**Дата**: 28 ноября 2024  
**Статус**: ✅ ГОТОВО К PRODUCTION

**Полная документация**: [APICURIO_DOCS_NO_MOCK.md](./APICURIO_DOCS_NO_MOCK.md)
