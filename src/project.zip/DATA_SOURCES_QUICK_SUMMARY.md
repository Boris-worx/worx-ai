# Data Sources User Story - Quick Answer ⚡

## Can Our Interface Support This? 🎯

**Answer:** 🟡 **YES - 70% Ready, needs 8 hours of work**

---

## User Story Requirements

**Data Sources must:**
- Be global or tenant-specific (BFS, Meritage, etc.)
- Have Data Capture Specifications (one per table)
- Support CRUD via TxServices API
- Examples: Bidtools (global), Online/Informix (BFS tenant)

---

## What's Already Working ✅

### 1. Data Source Onboarding Tab
- ✅ Full CRUD (Create, Read, Update, Delete)
- ✅ DataTable with sorting/search/filter
- ✅ Expandable rows for details
- ✅ API integration
- ✅ Permission control

### 2. Data Capture Specifications (Transaction Onboarding Tab)
- ✅ Full CRUD for schemas
- ✅ Real API: `/1.0/txns?TxnType=ModelSchema`
- ✅ JSON Schema support (draft-2020-12)
- ✅ Protected types (Customer, Location)
- ✅ Versioning (semver)

### 3. UI/UX
- ✅ Professional design
- ✅ Responsive
- ✅ Tenant selector ready
- ✅ Good component structure

**Working Features Score: 9/10** ⭐⭐⭐⭐⭐

---

## What's Missing ❌

### 🔴 Problem 1: No Tenant Field (CRITICAL)
```typescript
// Current
interface DataSource {
  DataSourceId: string;
  DataSourceName: string;
  Type: string;
  // ❌ Missing: TenantId
}

// Needed
interface DataSource {
  // ... existing
  TenantId?: string;  // ✅ Add this
}
```

**Impact:** Can't distinguish global (Bidtools) from tenant-specific (Online)

---

### 🟡 Problem 2: No Link Between DataSource and Specifications (IMPORTANT)
```
Current:
Data Sources Tab         Transaction Onboarding Tab
├── Bidtools            ├── Customer (no link to DS)
│   └── Mock specs ❌   ├── Quotes (no link to DS)
└── Online              └── Location (no link to DS)
    └── Mock specs ❌

Needed:
Data Sources Tab
├── Bidtools
│   ├── Quotes (real API) ✅
│   ├── QuoteDetails (real API) ✅
│   └── QuotePacks (real API) ✅
└── Online (Informix)
    ├── Customer (real API) ✅
    └── Order (real API) ✅
```

**Impact:** Shows mock data instead of real specifications

---

### 🟢 Problem 3: "Add Specification" Button (LOW)
```typescript
// Current
onClick={() => toast.info('Coming soon!')}

// Needed
onClick={() => openCreateDialog(dataSource)}
```

**Impact:** Can't create specs from Data Source view

---

## Work Needed (8 hours total)

### Phase 1: Add Tenant Support (2 hours) 🔴
```typescript
// 1. Add TenantId to interfaces
TenantId?: string;

// 2. Update API calls
getAllDataSources(activeTenantId)

// 3. Add Tenant column
{ key: 'TenantId', label: 'Tenant' }

// 4. Display badge
<Badge>{value || 'Global'}</Badge>
```

### Phase 2: Link DataSources to Specs (3 hours) 🟡
```typescript
// 1. Add dataSourceId to ModelSchema
dataSourceId?: string;

// 2. Load real specs for DataSource
const specs = await getAllModelSchemas(tenantId, dataSourceId);

// 3. Display real specs instead of mock
{specs.map(spec => <SpecRow spec={spec} />)}

// 4. Make "Add Spec" button work
onClick={() => createSpec(dataSource)}
```

### Phase 3: Testing (2 hours) ✅
- [ ] Test tenant filtering
- [ ] Test real specifications display
- [ ] Test create/edit/delete from DS view
- [ ] Test cross-tab consistency

### Phase 4: Optional Polish (1 hour) 🟢
- Add DataSource name in ModelSchemaView
- Better visual hierarchy
- Inline spec creation

---

## Visual Before/After

### Before (Current):
```
┌────────────────────────────────────────┐
│ Data Source Onboarding                │
├────────────────────────────────────────┤
│ Name      | Type       | Status        │
├────────────────────────────────────────┤
│ Bidtools  | SQL Server | Active        │ ← No tenant shown
│ Online    | Informix   | Active        │ ← No tenant shown
└────────────────────────────────────────┘

Click to expand:
├── Mock specs (Quotes, QuoteDetails) ❌
└── "Add Spec" → shows toast only ❌
```

### After (Needed):
```
┌────────────────────────────────────────────┐
│ 🏢 Global Tenant                           │
│ Data Source Onboarding                     │
├────────────────────────────────────────────┤
│ Name      | Type       | Tenant | Status  │
├────────────────────────────────────────────┤
│ Bidtools  | SQL Server | Global | Active  │ ✅
│ Databricks| Cloud      | Global | Active  │ ✅
└────────────────────────────────────────────┘

Click Bidtools to expand:
├── Quotes (v1.0.0) active ✅ Real from API
├── QuoteDetails (v1.0.0) active ✅ Real from API
└── QuotePacks (v1.0.0) active ✅ Real from API
    [+ Add Specification] → Opens dialog ✅

🏢 BFS Tenant (switch tenant)
┌────────────────────────────────────────────┐
│ Name      | Type       | Tenant | Status  │
├────────────────────────────────────────────┤
│ Online    | Informix   | BFS    | Active  │ ✅
│ Trend     | Legacy     | BFS    | Active  │ ✅
│ SAP       | ERP        | BFS    | Active  │ ✅
└────────────────────────────────────────────┘
```

---

## Compliance Score

| Requirement | Status | Score |
|-------------|--------|-------|
| Data Sources CRUD | ✅ Complete | 10/10 |
| Specifications CRUD | ✅ Complete | 10/10 |
| Cosmos Storage | ✅ Complete | 10/10 |
| API Integration | ✅ Complete | 10/10 |
| **Tenant Association** | ❌ Missing | 0/10 |
| **DS ↔ Spec Link** | ❌ Missing | 0/10 |
| ACE/CDC Support | N/A Backend | - |
| **Overall** | **70%** | **7/10** |

---

## Verdict

### ✅ Strengths
- Excellent CRUD implementation
- Real API integration working
- Professional UI/UX
- Good code structure
- Permission model solid

### ⚠️ Gaps
- No tenant field (2 hours to fix)
- No DS↔Spec link (3 hours to fix)
- Mock data shown (part of above fix)

### 🎯 Recommendation

**APPROVE with conditions:**
1. Add tenant support (Phase 1) - CRITICAL
2. Link DataSources to Specs (Phase 2) - IMPORTANT
3. Test thoroughly (Phase 3) - REQUIRED

**Effort:** 8 hours of focused work  
**Risk:** Low (straightforward implementation)  
**Priority:** Medium-High (needed for multi-tenant deployment)

---

## Next Steps

1. **Check API** (30 min)
   - Does API return `TenantId` field?
   - Does API support `?TenantId={id}` filtering?
   - Does API support `?DataSourceId={id}` for specs?

2. **Implement Phase 1** (2 hours)
   - Add TenantId to interfaces
   - Update API calls
   - Add Tenant column
   - Test filtering

3. **Implement Phase 2** (3 hours)
   - Add dataSourceId to ModelSchema
   - Load real specs for each DataSource
   - Replace mock data
   - Make "Add Spec" button work

4. **Test Everything** (2 hours)
   - Tenant filtering
   - Real specs display
   - Create/Edit/Delete from DS view
   - Cross-tab consistency

5. **Deploy** 🚀

---

## Files Created

1. **[DATA_SOURCES_USER_STORY_ANALYSIS.md](./DATA_SOURCES_USER_STORY_ANALYSIS.md)** - Full technical analysis (EN)
2. **[DATA_SOURCES_ПРОВЕРКА.md](./DATA_SOURCES_ПРОВЕРКА.md)** - Detailed review (RU)
3. **[DATA_SOURCES_QUICK_SUMMARY.md](./DATA_SOURCES_QUICK_SUMMARY.md)** - This file

---

**Bottom Line:** Interface is 70% ready. With 8 hours of work, it will fully support the User Story! 🎯

**Status:** ✅ Foundation Excellent, Backend Integration Needed
