# Data Sources - Полная документация

## 📋 Оглавление

Эта папка содержит полную документацию по компоненту Data Sources в BFS Portal, включая исправления изоляции тенантов, руководства по тестированию и шпаргалки для разработчиков.

## 🚀 Быстрый старт

**Новый разработчик? Начните здесь:**

1. **Прочитайте:** [DATASOURCES_CHEATSHEET_RU.md](DATASOURCES_CHEATSHEET_RU.md) - краткая шпаргалка
2. **Протестируйте:** [TESTING_GLOBAL_TENANT_RU.md](TESTING_GLOBAL_TENANT_RU.md) - инструкция по тестированию
3. **Изучите:** [TENANT_ISOLATION_RU.md](TENANT_ISOLATION_RU.md) - архитектура изоляции

## 📚 Документация

### Основные руководства

#### 1. [TENANT_ISOLATION_RU.md](TENANT_ISOLATION_RU.md)
**Архитектура изоляции данных между тенантами**

Описывает как работает изоляция данных в BFS Portal:
- Уровни изоляции (API, App, Component, UI)
- Роли пользователей и права доступа
- Логика фильтрации д��я GLOBAL и конкретных тенантов
- Примеры использования

**Читайте если:** Вам нужно понять как работает мультитенантность

#### 2. [GLOBAL_TENANT_DATASOURCES_FIX_RU.md](GLOBAL_TENANT_DATASOURCES_FIX_RU.md)
**Исправление отображения Data Sources для Global Tenant**

Документирует проблему и решение для GLOBAL TENANT:
- Описание проблемы (GLOBAL не видел все data sources)
- Причина проблемы (API без фильтра)
- Решение (параллельные запросы для всех тенантов)
- Результат и тестирование

**Читайте если:** Вы хотите понять как работает GLOBAL TENANT

#### 3. [DATASOURCE_DELETE_FIX_RU.md](DATASOURCE_DELETE_FIX_RU.md)
**Исправление удаления Data Sources**

Документирует проблему с удалением:
- Симптомы (запись исчезала, но возвращалась после refresh)
- Причина (асинхронность API)
- Решение (задержка 1 секунда перед refresh)

**Читайте если:** У вас проблемы с удалением/созданием

#### 4. [DATASOURCE_DELETE_GUIDE_RU.md](DATASOURCE_DELETE_GUIDE_RU.md)
**Полное руководство по удалению Data Sources**

Детальное описание функциональности удаления:
- UI компоненты и flow
- Права доступа и security
- Tenant isolation
- API endpoint и примеры
- Тестирование и troubleshooting

**Читайте если:** Вам нужно полное понимание функциональности удаления

#### 5. [DATASOURCE_DELETE_QUICK_START.md](DATASOURCE_DELETE_QUICK_START.md)
**Quick Start - Удаление Data Sources**

Краткая инструкция для быстрого старта:
- Как удалить Data Source за 5 шагов
- Права доступа
- Быстрые тесты
- Troubleshooting

**Читайте если:** Нужно быстро начать работать с удалением

### Руководства по тестированию

#### 6. [TESTING_GLOBAL_TENANT_RU.md](TESTING_GLOBAL_TENANT_RU.md)
**Инструкция по тестированию GLOBAL TENANT**

Полное руководство по тестированию:
- Быстрый тест (5 шагов)
- Детальные тесты (5 сценариев)
- Проверка через API (curl команды)
- Проверка производительности

### Справочники

#### 7. [DATASOURCES_CHEATSHEET_RU.md](DATASOURCES_CHEATSHEET_RU.md)
**Шпаргалка для разработчиков**

Краткий справочник:
- Быстрый старт
- Архитектура (диаграммы)
- API endpoints
- Типовые curl команды
- Debugging
- Code snippets
- Testing checklist

**Читайте если:** Вам нужен быстрый ответ

#### 8. [CHANGELOG_DATASOURCES_RU.md](CHANGELOG_DATASOURCES_RU.md)
**Changelog - Data Sources Improvements**

История всех изменений:
- 2025-11-13: GLOBAL TENANT Isolation Fix
- 2025-11-12: Data Source Delete Fix
- 2025-11-09: Data Source Create Fix
- Архитектура, Best Practices, Known Issues
- Future Improvements

**Читайте если:** Вам нужна история изменений

## 🎯 По задачам

### "Мне нужно понять как работает изоляция тенантов"
→ [TENANT_ISOLATION_RU.md](TENANT_ISOLATION_RU.md)

### "GLOBAL TENANT не показывает все data sources"
→ [GLOBAL_TENANT_DATASOURCES_FIX_RU.md](GLOBAL_TENANT_DATASOURCES_FIX_RU.md)

### "После удаления data source появляется снова"
→ [DATASOURCE_DELETE_FIX_RU.md](DATASOURCE_DELETE_FIX_RU.md)

### "Как протестировать GLOBAL TENANT?"
→ [TESTING_GLOBAL_TENANT_RU.md](TESTING_GLOBAL_TENANT_RU.md)

### "Нужны curl команды для API"
→ [DATASOURCE_CURL_TEST_RU.md](DATASOURCE_CURL_TEST_RU.md)

### "Быстро посмотреть синтаксис/команды"
→ [DATASOURCES_CHEATSHEET_RU.md](DATASOURCES_CHEATSHEET_RU.md)

### "Посмотреть историю изменений"
→ [CHANGELOG_DATASOURCES_RU.md](CHANGELOG_DATASOURCES_RU.md)

## 🔍 Структура кодовой базы

```
/
├── App.tsx                         ← Управление состоянием, загрузка данных
├── components/
│   ├── DataSourcesView.tsx         ← UI компонент, CRUD операции
│   ├── TenantSelector.tsx          ← Селектор тенантов
│   └── ui/                         ← shadcn/ui компоненты
├── lib/
│   └── api.ts                      ← API функции (getAllDataSources, etc.)
└── docs/                           ← Эта документация
    ├── TENANT_ISOLATION_RU.md
    ├── GLOBAL_TENANT_DATASOURCES_FIX_RU.md
    ├── DATASOURCE_DELETE_FIX_RU.md
    ├── TESTING_GLOBAL_TENANT_RU.md
    ├── DATASOURCE_CURL_TEST_RU.md
    ├── DATASOURCES_CHEATSHEET_RU.md
    ├── CHANGELOG_DATASOURCES_RU.md
    └── DATASOURCES_README_RU.md    ← Вы здесь
```

## 🏗️ Архитектура (кратко)

```
┌─────────────────────────────────────────┐
│            User Interface                │
│  (DataSourcesView.tsx + TenantSelector)  │
└────────────────┬────────────────────────┘
                 │
                 │ props & callbacks
                 ▼
┌─────────────────────────────────────────┐
│          State Management                │
│  (App.tsx: dataSources, activeTenantId)  │
└────────────────┬────────────────────────┘
                 │
                 │ API calls
                 ▼
┌─────────────────────────────────────────┐
│           API Layer                      │
│     (lib/api.ts: getAllDataSources)      │
└────────────────┬────────────────────────┘
                 │
                 │ HTTP requests
                 ▼
┌─────────────────────────────────────────┐
│           BFS API                        │
│  (dp-eastus-poc-txservices-apis...)      │
└─────────────────────────────────────────┘
```

### Изоляция тенантов

**GLOBAL TENANT (SuperUser):**
```typescript
// Делает запросы ко ВСЕМ тенантам
tenants.forEach(tenant => {
  getAllDataSources(tenant.TenantId)
})
→ Объединяет результаты
→ Показывает все data sources
```

**Конкретный тенант (BFS, Meritage, etc.):**
```typescript
// Делает один запрос с фильтром
getAllDataSources(activeTenantId)
→ Показывает только data sources этого тенанта
```

## 🧪 Тестирование

### Быстрый тест (30 секунд)

```bash
1. Login as Portal.SuperUser
2. Tab: Data Sources
3. Tenant: GLOBAL TENANT
   → Видите data sources из ВСЕХ тенантов? ✓
4. Tenant: BFS
   → Видите ТОЛЬКО BFS data sources? ✓
5. Create "test" для BFS
   → Появился в BFS? ✓
   → Появился в GLOBAL? ✓
   → НЕ появился в Meritage? ✓
```

Подробнее: [TESTING_GLOBAL_TENANT_RU.md](TESTING_GLOBAL_TENANT_RU.md)

### Тестирование API (curl)

```bash
# Все data sources тенанта BFS
curl -X GET "https://dp-eastus-poc-txservices-apis.azurewebsites.net/datasources?Filters=%7B%22TenantId%22%3A%22BFS%22%7D" \
  -H "X-BFS-Auth: dummytoken123"
```

Подробнее: [DATASOURCE_CURL_TEST_RU.md](DATASOURCE_CURL_TEST_RU.md)

## 🐛 Troubleshooting

### Проблема: GLOBAL TENANT не видит все data sources

**Симптом:** При выборе GLOBAL TENANT показываются не все data sources

**Диагностика:**
```javascript
// Откройте консоль браузера (F12)
// Ищите логи:
📡 Fetching data sources for GLOBAL tenant (all tenants)...
✅ Loaded X data sources for tenant BFS
✅ Loaded Y data sources for tenant Meritage
```

**Решение:** [GLOBAL_TENANT_DATASOURCES_FIX_RU.md](GLOBAL_TENANT_DATASOURCES_FIX_RU.md)

### Проблема: После create/delete не обновляется список

**Симптом:** Создали/удалили data source, но он не появляется/исчезает

**Решение:** [DATASOURCE_DELETE_FIX_RU.md](DATASOURCE_DELETE_FIX_RU.md)

### Проблема: ETag mismatch при update/delete

**Симптом:** `412 Precondition Failed`

**Решение:** Убедитесь что передаете актуальный ETag:
```typescript
await deleteDataSource(id, dataSource._etag);
```

## 📊 Метрики

### Производительность

| Операция | Ожидаемое время |
|----------|----------------|
| GET (1 тенант) | < 500ms |
| GET (GLOBAL, 3 тенанта) | < 2s |
| GET (GLOBAL, 10 тенантов) | < 5s |
| POST (создание) | < 1s |
| DELETE (удаление) | < 1s |
| PUT (обновление) | < 1s |

### Изоляция

| Роль | Тенанты видимые | Может создавать | Может удалять |
|------|----------------|----------------|--------------|
| Portal.SuperUser (GLOBAL) | Все | Для всех | Все |
| Portal.SuperUser (BFS) | Только BFS | Только BFS | Только BFS |
| Admin (BFS) | Только BFS | Только BFS | Только BFS |
| Developer (BFS) | Только BFS | Только BFS | Нет |
| Viewer (BFS) | Только BFS | Нет | Нет |

## 🔐 Безопасность

### API Authentication
- **Header:** `X-BFS-Auth: dummytoken123`
- **В продакшене:** Заменить на реальный JWT токен

### ETag для оптимистичной блокировки
- Предотвращает race conditions
- Обязателен для PUT и DELETE
- Формат: `If-Match: "etag-value"`

### Валидация на фронтенде
```typescript
// Проверка tenantId
if (!data.TenantId) {
  toast.error('Tenant is required');
  return;
}

// Проверка прав
if (userRole === 'viewer') {
  toast.error('Viewers cannot create data sources');
  return;
}
```

## 📝 Best Practices

### ✅ DO

```typescript
// Используйте ETag
await deleteDataSource(id, dataSource._etag);

// Добавляйте задержку после операций
await createDataSource(data);
await new Promise(resolve => setTimeout(resolve, 1000));
refreshData();

// Логируйте операции
console.log('🔧 Creating data source...');

// Обрабатывайте ошибки
try {
  await deleteDataSource(id, etag);
} catch (error) {
  console.error('Failed:', error);
  toast.error('Failed to delete');
}
```

### ❌ DON'T

```typescript
// Не забывайте ETag
await deleteDataSource(id); // ❌ Упадет с ошибкой

// Не refresh сразу после операции
await createDataSource(data);
refreshData(); // ❌ Может не увидеть новый data source

// Не игнорируйте ошибки
await deleteDataSource(id, etag); // ❌ Нет try/catch
```

## 🚀 Future Improvements

### В разработке
- [ ] Оптимистичное обновление UI (убрать 1 сек задержку)
- [ ] Pagination для больших списков
- [ ] Batch API endpoint для GLOBAL TENANT

### Планируется
- [ ] Virtual scrolling для >1000 записей
- [ ] Кэширование результатов
- [ ] Export to CSV/JSON
- [ ] Bulk operations (массовое удаление)
- [ ] Advanced filtering

## 📞 Контакты

**BFS Portal Development Team**

При возникновении вопросов:
1. Проверьте эту документацию
2. Проверьте консоль браузера на ошибки
3. Проверьте Network tab в DevTools
4. Обратитесь к команде разработки

## 📅 Актуальность

**Последнее обновление:** 13 ноября 2025

**Версия документации:** 1.0

**Протестировано на:**
- React 18+
- TypeScript 5+
- BFS API v1

## 📄 Лицензия

Proprietary - BFS Internal Use Only

---

**Навигация:**
- [◀ Назад к списку файлов](#-оглавление)
- [▶ Следующий документ: Шпаргалка](DATASOURCES_CHEATSHEET_RU.md)