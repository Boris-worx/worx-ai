# 🎯 Apicurio Dynamic Integration - ГОТОВО

**Дата:** 27 ноября 2025  
**Статус:** ✅ ПОЛНОСТЬЮ ДИНАМИЧЕСКАЯ ИНТЕГРАЦИЯ

---

## 🚀 Что изменилось

### До (хардкод):

```typescript
// ❌ Хардкод групп
const groups = ['paradigm.bidtools2', 'bfs.online'];

// ❌ Хардкод версий
if (groupId === 'paradigm.bidtools2') {
  versionPath = '1';
} else if (groupId === 'bfs.online') {
  versionPath = '1.0.0';
}
```

### После (динамика):

```typescript
// ✅ Динамическое получение групп
const groups = await getApicurioGroups();

// ✅ Динамическое получение версии
const versions = await getArtifactVersions(groupId, artifactId);
const latestVersion = getLatestVersion(versions);
```

---

## 🎯 Новый Flow

```
1. GET /groups/
   └─> Получаем ВСЕ группы динамически
   └─> Каждый groupId = название раздела в UI

2. GET /groups/{groupId}/artifacts/
   └─> Получаем артефакты для каждой группы
   └─> Список шаблонов

3. При выборе шаблона:
   GET /groups/{groupId}/artifacts/{artifactId}/versions
   └─> Получаем ВСЕ версии артефакта
   └─> Берём последнюю версию (по createdOn)
   
4. GET /groups/{groupId}/artifacts/{artifactId}/versions/{version}/content
   └─> Получаем схему с актуальной версией
   └─> Заполняем форму
```

---

## 📝 Новые API функции

### 1. `getApicurioGroups()` - Получить все группы

```typescript
export async function getApicurioGroups(): Promise<ApicurioGroup[]>
```

**Endpoint:** `GET /groups`

**Что возвращает:**
```json
{
  "groups": [
    {
      "id": "paradigm.bidtools2",
      "description": "Bid Tools Templates",
      "createdOn": "2025-11-18T15:35:18Z"
    },
    {
      "id": "bfs.online",
      "description": "BFS Online Templates",
      "createdOn": "2025-11-18T15:36:08Z"
    }
  ]
}
```

**Fallback:**
- При 403 или ошибке → возвращает дефолтные группы
- Приложение продолжает работать

---

### 2. `getGroupArtifacts(groupId)` - Получить артефакты группы

```typescript
export async function getGroupArtifacts(groupId: string): Promise<ApicurioArtifact[]>
```

**Endpoint:** `GET /groups/{groupId}/artifacts?limit=100`

**Пример:**
```typescript
const artifacts = await getGroupArtifacts('paradigm.bidtools2');
// Возвращает массив артефактов с добавленным groupId
```

**Fallback:**
- При 403 или ошибке → возвращает пустой массив
- Продолжает с другими группами

---

### 3. `getArtifactVersions(groupId, artifactId)` - Получить версии артефакта

```typescript
export async function getArtifactVersions(
  groupId: string, 
  artifactId: string
): Promise<ApicurioVersion[]>
```

**Endpoint:** `GET /groups/{groupId}/artifacts/{artifactId}/versions`

**Что возвращает:**
```json
{
  "versions": [
    {
      "version": "1.0.0",
      "createdOn": "2025-11-18T15:35:18Z",
      "modifiedOn": "2025-11-18T15:35:18Z",
      "state": "ENABLED"
    },
    {
      "version": "1.0.1",
      "createdOn": "2025-11-20T10:00:00Z",
      "modifiedOn": "2025-11-20T10:00:00Z",
      "state": "ENABLED"
    }
  ]
}
```

**Используется для:**
- Динамического определения актуальной версии
- Поддержки изменений версий на стороне Registry

---

### 4. `getLatestVersion(versions)` - Выбрать последнюю версию

```typescript
export function getLatestVersion(versions: ApicurioVersion[]): string | null
```

**Логика:**
- Сортирует по `createdOn` (самая свежая первой)
- Возвращает `version` самой новой

**Пример:**
```typescript
const versions = [
  { version: "1", createdOn: "2025-11-18" },
  { version: "1.0.0", createdOn: "2025-11-20" },
  { version: "2.0.0", createdOn: "2025-11-25" }
];

const latest = getLatestVersion(versions);
// Вернет: "2.0.0"
```

---

### 5. `getGroupDisplayName(groupId)` - Красивое имя группы

```typescript
export function getGroupDisplayName(groupId: string): string
```

**Mappings:**
```typescript
{
  'paradigm.bidtools2': 'Bid Tools Templates',
  'bfs.online': 'BFS Online Templates',
  'paradigm.bidtools': 'Bid Tools (Legacy)',
}
```

**Для неизвестных групп:** возвращает `groupId` как есть

**Используется в UI:**
```tsx
<CommandGroup heading={getGroupDisplayName(groupId)}>
```

---

## 🔧 Обновленные функции

### `searchApicurioArtifacts()` - ПОЛНОСТЬЮ ПЕРЕРАБОТАНА

**Было:**
```typescript
const groups = ['paradigm.bidtools2', 'bfs.online']; // ❌ Хардкод
for (const group of groups) {
  // fetch artifacts...
}
```

**Стало:**
```typescript
// ✅ Динамическое получение групп
const groups = await getApicurioGroups();
console.log(`📦 🎯 Found ${groups.length} groups`);

for (const group of groups) {
  const artifacts = await getGroupArtifacts(group.id);
  allArtifacts.push(...artifacts);
}
```

**Преимущества:**
- ✅ Автоматически подхватывает новые группы
- ✅ Не требует изменений кода при добавлении групп
- ✅ Гибкость и масштабируемость

---

### `getApicurioArtifact()` - ПОЛНОСТЬЮ ПЕРЕРАБОТАНА

**Было:**
```typescript
// ❌ Хардкод версий по groupId
let versionPath: string;
if (groupId === 'paradigm.bidtools2') {
  versionPath = '1';
} else if (groupId === 'bfs.online') {
  versionPath = '1.0.0';
} else {
  versionPath = 'branch=latest';
}
```

**Стало:**
```typescript
// ✅ Динамическое получение версии
if (!version) {
  const versions = await getArtifactVersions(groupId, artifactId);
  if (versions.length > 0) {
    const latestVersion = getLatestVersion(versions);
    versionPath = latestVersion || 'branch=latest';
    console.log(`📦 ✅ Using latest version: ${versionPath}`);
  } else {
    versionPath = 'branch=latest';
  }
} else {
  versionPath = version; // Используем переданную версию
}
```

**Преимущества:**
- ✅ Автоматически использует актуальную версию
- ✅ Поддерживает изменения версий на Registry
- ✅ Не требует обновления кода при новых версиях

---

## 📊 Новые интерфейсы

### `ApicurioGroup`

```typescript
export interface ApicurioGroup {
  id: string;
  description?: string;
  createdOn?: string;
  modifiedOn?: string;
}
```

### `ApicurioVersion`

```typescript
export interface ApicurioVersion {
  version: string;
  createdOn?: string;
  modifiedOn?: string;
  state?: string;
}
```

---

## 🎨 UI Изменения

### Было (хардкод):

```tsx
<CommandGroup
  heading={
    groupId === "paradigm.bidtools2"
      ? "Bid Tools Templates"
      : groupId === "bfs.online"
        ? "BFS Online Templates"
        : groupId
  }
>
```

### Стало (динамика):

```tsx
<CommandGroup heading={getGroupDisplayName(groupId)}>
```

**Преимущества:**
- ✅ Одна строка вместо тернарного оператора
- ✅ Легко добавить новые группы
- ✅ Централизованное управление названиями

---

## ✅ Преимущества новой системы

### 1. **Гибкость**
- ✅ Автоматически подхватывает новые группы
- ✅ Не требует изменений кода
- ✅ Registry управляет структурой

### 2. **Версионирование**
- ✅ Всегда использует актуальную версию
- ✅ Клиент может менять версии в Registry
- ✅ Приложение адаптируется автоматически

### 3. **Масштабируемость**
- ✅ Легко добавить новую группу (просто создать в Registry)
- ✅ Легко обновить версию (просто загрузить в Registry)
- ✅ Zero-code changes

### 4. **Надежность**
- ✅ Fallback на mock данные при ошибках
- ✅ Продолжает работать при 403
- ✅ Логирование для отладки

### 5. **Удобство**
- ✅ Понятные логи (`📦 🎯 DYNAMIC:`)
- ✅ Информативные сообщения
- ✅ Простая отладка

---

## 🧪 Примеры использования

### Получить все группы:

```typescript
const groups = await getApicurioGroups();
console.log('Groups:', groups.map(g => g.id));
// Output: Groups: ['paradigm.bidtools2', 'bfs.online']
```

### Получить артефакты группы:

```typescript
const artifacts = await getGroupArtifacts('paradigm.bidtools2');
console.log('Artifacts:', artifacts.length);
// Output: Artifacts: 7
```

### Получить версии артефакта:

```typescript
const versions = await getArtifactVersions(
  'bfs.online',
  'TxServices_Informix_inv.response'
);
const latest = getLatestVersion(versions);
console.log('Latest version:', latest);
// Output: Latest version: 1.0.0
```

### Получить контент с автоопределением версии:

```typescript
// Версия определится автоматически
const schema = await getApicurioArtifact(
  'paradigm.bidtools2',
  'TxServices_SQLServer_QuoteDetails.response'
);

// Или указать версию явно
const schemaV2 = await getApicurioArtifact(
  'paradigm.bidtools2',
  'TxServices_SQLServer_QuoteDetails.response',
  '2.0.0' // Явная версия
);
```

---

## 📝 Логи (для отладки)

### При получении групп:

```
📦 🎯 DYNAMIC: Fetching groups and artifacts from Apicurio Registry...
📦 🎯 Found 2 groups: paradigm.bidtools2, bfs.online
```

### При получении артефактов:

```
📦 Fetching artifacts from group paradigm.bidtools2
📦 ✅ Loaded 7 artifacts from paradigm.bidtools2
📦 Fetching artifacts from group bfs.online
📦 ✅ Loaded 11 artifacts from bfs.online
📦 ✅ Total artifacts loaded: 18 from 2 groups
```

### При получении версии:

```
📦 🎯 DYNAMIC: Fetching versions for TxServices_SQLServer_QuoteDetails.response...
📦 Fetched 3 versions for TxServices_SQLServer_QuoteDetails.response
📦 ✅ Using latest version: 2.0.0
```

### При получении контента:

```
📦 🎯 Fetching artifact from: .../versions/2.0.0/content
📦 Loaded schema from Apicurio Registry: TxServices_SQLServer_QuoteDetails.response
```

---

## 🎯 Сценарии использования

### Сценарий 1: Клиент добавил новую группу

**Действия клиента:**
1. Создать новую группу в Registry: `paradigm.widgets`
2. Загрузить артефакты в группу

**Приложение:**
- ✅ Автоматически находит группу через `getApicurioGroups()`
- ✅ Загружает артефакты через `getGroupArtifacts()`
- ✅ Отображает в UI с названием `paradigm.widgets`
- ✅ Или можно добавить mapping в `getGroupDisplayName()`: `'paradigm.widgets': 'Widget Templates'`

**Изменения в коде:** 0 (опционально 1 строка для красивого имени)

---

### Сценарий 2: Клиент обновил версию артефакта

**Действия клиента:**
1. Загрузить новую версию в Registry: `inv.response` версия `2.0.0`

**Приложение:**
- ✅ `getArtifactVersions()` находит новую версию
- ✅ `getLatestVersion()` выбирает `2.0.0` (самая свежая)
- ✅ `getApicurioArtifact()` загружает контент версии `2.0.0`

**Изменения в коде:** 0

---

### Сценарий 3: Клиент хочет использовать старую версию

**Действия клиента:**
1. Указать версию явно при вызове

```typescript
const schema = await getApicurioArtifact(
  'bfs.online',
  'TxServices_Informix_inv.response',
  '1.0.0' // Явно указываем старую версию
);
```

**Приложение:**
- ✅ Игнорирует автоопределение версии
- ✅ Использует указанную версию `1.0.0`

**Изменения в коде:** 1 параметр при вызове

---

## 🔄 Миграция (что изменилось)

### Файл: `/lib/apicurio.ts`

| Что изменилось | До | После |
|----------------|-----|-------|
| Новые функции | 2 | 7 (+5) |
| Новые интерфейсы | 2 | 4 (+2) |
| Хардкод групп | ✅ Да | ❌ Нет |
| Хардкод версий | ✅ Да | ❌ Нет |
| Динамика групп | ❌ Нет | ✅ Да |
| Динамика версий | ❌ Нет | ✅ Да |

### Файл: `/components/DataCaptureSpecCreateDialog.tsx`

| Что изменилось | До | После |
|----------------|-----|-------|
| Импортов | 5 | 6 (+1) |
| Хардкод названий | ✅ Да | ❌ Нет |
| Использует `getGroupDisplayName` | ❌ Нет | ✅ Да |

---

## ✅ Статус

- ✅ Код обновлен
- ✅ 5 новых функций добавлены
- ✅ 2 новых интерфейса добавлены
- ✅ UI обновлен
- ✅ Полностью динамическая интеграция
- ✅ Компилируется без ошибок
- ⏳ Готово к тестированию

---

## 🧪 Как проверить

### Тест 1: Проверить динамические группы

1. Открыть DevTools → Console
2. Data Source Onboarding → Add Specification → Apicurio Registry
3. Проверить логи:

```
✅ Должно быть:
📦 🎯 DYNAMIC: Fetching groups and artifacts from Apicurio Registry...
📦 🎯 Found N groups: ...

❌ НЕ должно быть:
📦 Fetching from group: paradigm.bidtools2 (старый лог)
```

### Тест 2: Проверить динамические версии

1. Выбрать любой template
2. Проверить логи:

```
✅ Должно быть:
📦 🎯 DYNAMIC: Fetching versions for ...
📦 ✅ Using latest version: X.X.X

❌ НЕ должно быть:
Хардкод версий в логах
```

### Тест 3: Проверить fallback

1. Отключить интернет
2. Попробовать загрузить templates
3. Проверить что:

```
✅ Приложение продолжает работать
✅ Показываются mock templates
✅ Форма заполняется
```

---

## 📚 API Endpoints (справка)

```
GET /groups/
GET /groups/{groupId}/artifacts?limit=100
GET /groups/{groupId}/artifacts/{artifactId}/versions
GET /groups/{groupId}/artifacts/{artifactId}/versions/{version}/content
```

**Base URL:**
```
https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3
```

---

## 🎉 Итог

**До:**
- ❌ Хардкод групп
- ❌ Хардкод версий
- ❌ Требовались изменения кода при добавлении групп
- ❌ Требовались изменения кода при обновлении версий

**После:**
- ✅ Полностью динамическое получение групп
- ✅ Полностью динамическое определение версий
- ✅ Zero-code changes при добавлении групп
- ✅ Zero-code changes при обновлении версий
- ✅ Масштабируемость
- ✅ Гибкость
- ✅ Надежность

---

**Дата:** 27 ноября 2025  
**Статус:** ✅ ПОЛНОСТЬЮ ГОТОВО
