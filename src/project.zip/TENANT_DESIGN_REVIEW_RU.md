# Проверка Дизайна - Multi-Tenant System 🏢

## User Story: Мультитенантность

**Требования:**
- ✅ Множественные тенанты с изоляцией данных
- ✅ Глобальный тенант с полной видимостью
- ⚠️ Data Sources, ModelSchemas, Transactions могут быть global или tenant-specific
- ❌ Cosmos использует partition key для изоляции

## Текущее Состояние UI/UX

### ✅ Что Работает Отлично

#### 1. Tenant Selector (Селектор Тенанта)
```
Расположение: Верхняя панель во всех вкладках
├── Tenants
├── Transaction Onboarding (ModelSchema)  
├── Data Source Onboarding
└── Data Plane (Transactions)
```

**Функциональность:**
- ✅ Показывает "Global Tenant" с бейджем "Default"
- ✅ Список всех тенантов (BFS, Meritage, Smith Douglas...)
- ✅ Иконка Building2 для визуального обозначения
- ✅ Для SuperUser - dropdown с выбором
- ✅ Для обычных юзеров - read-only, заблокирован на их тенант

**Пример UI:**
```
┌─────────────────────────────────┐
│  🏢  Global Tenant    [Default] │  ← SuperUser
└─────────────────────────────────┘

Click ▼
┌─────────────────────────────────┐
│  🏢  Global Tenant    [Default] │
│  ─────────────────────────────  │
│  Supplier Tenants               │
│  🏢  BFS                        │
│  🏢  Meritage                   │
│  🏢  Smith Douglas              │
└─────────────────────────────────┘
```

#### 2. Tenant Management (Управление Тенантами)
**Вкладка "Tenants":**

✅ **CRUD Operations:**
- Create: "Add New Tenant" кнопка
- Read: Таблица с TenantId, TenantName
- Update: "Edit" кнопка для редактирования
- Delete: "Delete" кнопка с подтверждением

✅ **Permissions:**
- Только Portal.SuperUser имеет доступ
- Portal.ViewOnlySuperUser - только просмотр
- Остальные роли не видят вкладку Tenants

✅ **Фильтрация в списке тенантов:**
```typescript
if (activeTenantId === 'global') {
  return tenants; // Показать все
}
return tenants.filter(tenant => tenant.TenantId === activeTenantId); // Только выбранный
```

#### 3. User → Tenant Binding (Привязка Юзера к Тенанту)
```typescript
// App.tsx
if (user && user.role !== 'superuser' && user.tenantId) {
  setActiveTenantId(user.tenantId); // Заблокировать на тенант юзера
}
```

✅ **Работает:**
- SuperUser может переключаться между global и любым тенантом
- Обычные юзеры заблокированы на свой tenantId
- Выбранный тенант сохраняется в localStorage

#### 4. Visual Design (Визуальный Дизайн)

✅ **Хорошие элементы:**
- Tenant selector хорошо видим (не спрятан)
- Building2 иконка ассоциируется с компанией/тенантом
- Badge "Default" для Global Tenant понятен
- Responsive: работает на desktop и mobile
- Dropdown группирует "Global" отдельно от "Supplier Tenants"

### ⚠️ Что Частично Работает

#### 1. Tenant Context в Data (Контекст Тенанта в Данных)

**Проблема:** activeTenantId передается в компоненты, но **НЕ используется для фильтрации данных**

```typescript
// App.tsx - activeTenantId передается в компоненты
<TransactionsView 
  activeTenantId={activeTenantId}  // ✅ Передается
  // ...
/>

// НО! getAllTransactions() НЕ принимает tenantId параметр
const refreshTransactions = async () => {
  const data = await getAllTransactions(); // ❌ Нет фильтрации по тенанту
  setTransactions(data);
};
```

**Результат:**
- UI готов к мультитенантности
- Но все данные загружаются вместе, без фильтрации

#### 2. Отсутствие Визуальных Индикаторов Тенанта

В таблицах транзакций, data sources, modelschemas **не показывается** какому тенанту принадлежат данные:

```
Текущий вид таблицы:
┌──────────┬───────────┬──────────┐
│ TxnId    │ TxnType   │ Actions  │
├──────────┼───────────┼──────────┤
│ Cust:001 │ Customer  │ View Edit│  ← Не видно что это BFS
│ Cust:002 │ Customer  │ View Edit│  ← Не видно что это Meritage
└──────────┴───────────┴──────────┘

Желаемый вид:
┌──────────┬───────────┬───────────┬──────────┐
│ TxnId    │ TxnType   │ Tenant    │ Actions  │
├──────────┼───────────┼───────────┼──────────┤
│ Cust:001 │ Customer  │ [BFS]     │ View Edit│
│ Cust:002 │ Customer  │ [Meritage]│ View Edit│
└──────────┴───────────┴───────────┴──────────┘
```

### ❌ Что Не Реализовано

#### 1. Tenant Fields в Data Structures

**Отсутствуют поля для tenant в интерфейсах:**

```typescript
// ❌ Transaction - нет TenantId
export interface Transaction {
  TxnId?: string;
  TxnType: string;
  Txn: any;
  // Нет: TenantId?: string;
  // Нет: PartitionKey?: string;
}

// ❌ ModelSchema - нет TenantId
export interface ModelSchema {
  id: string;
  model: string;
  // Нет: TenantId?: string;
}

// ❌ DataSource - нет TenantId
export interface DataSource {
  DataSourceId?: string;
  DataSourceName?: string;
  // Нет: TenantId?: string;
}
```

#### 2. API Tenant Filtering

**API функции не фильтруют по тенанту:**

```typescript
// Текущая реализация
export async function getAllTransactions(): Promise<Transaction[]> {
  const response = await fetch(`${API_BASE_URL}/txns`);
  return response.data; // ❌ Все данные вместе
}

// Должно быть
export async function getAllTransactions(tenantId?: string): Promise<Transaction[]> {
  let url = `${API_BASE_URL}/txns`;
  if (tenantId && tenantId !== 'global') {
    url += `?TenantId=${tenantId}`; // ✅ Фильтрация по тенанту
  }
  const response = await fetch(url);
  return response.data;
}
```

#### 3. Cosmos Partition Key

**Из User Story:** Cosmos использует partition key для хранения данных тенанта

**Примеры из таблицы:**
```
General Tenant → PartitionKey: "General Tenant"
BFS → PartitionKey: "BFS"
Smith Douglas → PartitionKey: "SmithDouglas"
```

**Проблема:** 
- Не знаем как API передает partition key
- Не знаем название поля (PartitionKey? partitionKey? TenantId?)
- Не реализована передача partition key в запросах

#### 4. Auto-Refresh при смене тенанта

**Проблема:** При переключении тенанта данные не перезагружаются

```typescript
// App.tsx
const handleTenantChange = (tenantId: string) => {
  setActiveTenantId(tenantId);
  toast.success(`Switched to ${tenantName}`);
  // ❌ Нет: refreshTransactions();
  // ❌ Нет: refreshDataSources();
}

// Должно быть:
useEffect(() => {
  if (activeTenantId) {
    refreshTransactions();
    refreshDataSources();
  }
}, [activeTenantId]); // ✅ Перезагрузка при смене тенанта
```

## Структура Cosmos (из User Story)

### Примеры из предоставленной таблицы:

#### General Tenant (Глобальные данные)
```
Tenant: General Tenant
├── DataSource: BidTools
│   ├── Quotes (v1) → Container: General-Bidtools
│   ├── QuoteDetails (v1) → Container: General-Bidtools
│   └── QuotePacks (v1) → Container: General-Bidtools
└── DataSource: Databricks
    └── Design (v1) → Container: General-Databricks
```

#### BFS Tenant (Специфичные для BFS)
```
Tenant: BFS
├── DataSource: Informix
│   ├── Customer (v1) → Container: BFS-Informix
│   └── Order (v1) → Container: BFS-Informix
└── DataSource: AS400
    ├── Customer (v1) → Container: BFS-AS400
    └── Order (v1) → Container: BFS-AS400
```

#### Smith Douglas Tenant
```
Tenant: Smith Douglas
└── DataSource: Informix
    ├── Customer (v1) → Container: SmithDouglas-Informix
    └── Order (v1) → Container: SmithDouglas-Informix
```

### Ключевые Наблюдения:

1. **Container Naming Pattern:**
   - `{TenantId}-{DataSourceName}`
   - Примеры: "BFS-Informix", "General-Bidtools"

2. **Partition Key = Tenant Name:**
   - General Tenant → "General Tenant"
   - BFS → "BFS"
   - Smith Douglas → "SmithDouglas"

3. **Одинаковые модели для разных тенантов:**
   - Customer существует у BFS и Smith Douglas
   - Order существует у BFS и Smith Douglas
   - Изоляция через partition key

## Рекомендации по Дизайну

### 🔴 Критичные (Блокируют мультитенантность)

#### 1. Добавить TenantId в интерфейсы
```typescript
export interface Transaction {
  TxnId?: string;
  TxnType: string;
  Txn: any;
  TenantId?: string;          // ✅ ДОБАВИТЬ
  PartitionKey?: string;      // ✅ ДОБАВИТЬ (если API использует)
}
```

#### 2. Обновить API функции
```typescript
export async function getAllTransactions(tenantId?: string): Promise<Transaction[]>
export async function getAllDataSources(tenantId?: string): Promise<DataSource[]>
export async function getAllModelSchemas(tenantId?: string): Promise<ModelSchema[]>
```

#### 3. Передавать activeTenantId в API вызовы
```typescript
const refreshTransactions = async () => {
  const data = await getAllTransactions(activeTenantId); // ✅ Передать тенант
  setTransactions(data);
};
```

### 🟡 Важные (Улучшают UX)

#### 4. Auto-refresh при смене тенанта
```typescript
useEffect(() => {
  refreshTransactions();
  refreshDataSources();
}, [activeTenantId]);
```

#### 5. Показывать tenant в таблицах
```typescript
// Добавить колонку Tenant с бейджем
<Badge variant={row.TenantId === 'General Tenant' ? 'secondary' : 'default'}>
  {row.TenantId || 'Global'}
</Badge>
```

#### 6. Индикатор текущего тенанта
```typescript
// В header каждой вкладки
<Alert className="mb-4">
  <Building2 className="h-4 w-4" />
  <AlertDescription>
    Viewing data for: <strong>{activeTenantName}</strong>
  </AlertDescription>
</Alert>
```

### 🟢 Nice to Have (Опциональные)

#### 7. Фильтры по тенанту в таблицах
```typescript
// Dropdown фильтр в DataTable
<Select value={filterTenant} onValueChange={setFilterTenant}>
  <SelectItem value="all">All Tenants</SelectItem>
  <SelectItem value="BFS">BFS</SelectItem>
  <SelectItem value="Meritage">Meritage</SelectItem>
</Select>
```

#### 8. Цветовое кодирование по тенантам
```typescript
const tenantColors = {
  'BFS': 'bg-blue-100',
  'Meritage': 'bg-green-100',
  'Smith Douglas': 'bg-purple-100',
  'General Tenant': 'bg-gray-100'
};
```

## Checklist для Тестирования

### Сценарий 1: SuperUser - Global View
- [ ] Залогиниться как SuperUser
- [ ] Выбрать "Global Tenant" в селекторе
- [ ] Перейти на Data Plane (Transactions)
- [ ] **Ожидается:** Видны транзакции от ВСЕХ тенантов
- [ ] **Сейчас:** Видны все транзакции (но нет маркировки тенанта)

### Сценарий 2: SuperUser - BFS Tenant View
- [ ] Выбрать "BFS" в tenant selector
- [ ] Перейти на Data Plane
- [ ] **Ожидается:** Видны только транзакции BFS
- [ ] **Сейчас:** Видны все транзакции (фильтрация не работает)

### Сценарий 3: Non-SuperUser (BFS User)
- [ ] Залогиниться как BFS Admin (tenantId: "BFS")
- [ ] **Ожидается:** 
  - Tenant selector заблокирован на "BFS"
  - Видны только BFS транзакции
  - Не видны транзакции других тенантов
- [ ] **Сейчас:**
  - ✅ Selector заблокирован
  - ❌ Видны все транзакции

### Сценарий 4: Data Source Isolation
- [ ] SuperUser выбирает "BFS"
- [ ] Открывает Data Source Onboarding
- [ ] **Ожидается:** 
  - Видны: "BFS-Informix", "BFS-AS400"
  - Не видны: "General-Bidtools", "SmithDouglas-Informix"
- [ ] **Сейчас:** Видны все data sources

### Сценарий 5: Create с Tenant Context
- [ ] SuperUser выбирает "BFS"
- [ ] Создает новую транзакцию
- [ ] **Ожидается:** 
  - TenantId автоматически = "BFS"
  - Создается в контейнере BFS
- [ ] **Сейчас:** Создается без TenantId

## Вопросы к Backend Team

### Нужно выяснить:

1. **Поле Tenant в API response:**
   - Как называется поле? `TenantId`, `tenantId`, `PartitionKey`?
   - Всегда ли оно присутствует?
   - Значение для глобальных данных: `null`, `"Global"`, `"General Tenant"`?

2. **API фильтрация:**
   - Поддерживает ли API query parameter `?TenantId={id}`?
   - Или фильтрация через header?
   - Или отдельные endpoints для каждого тенанта?

3. **Cosmos Container:**
   - Один контейнер с partition keys?
   - Или отдельные контейнеры для каждого тенанта?
   - Naming convention: `{Tenant}-{DataSource}`?

4. **Cross-tenant queries:**
   - Может ли SuperUser получить все данные одним запросом?
   - Или нужно делать отдельные запросы для каждого тенанта?

5. **Создание данных:**
   - Обязательно ли передавать TenantId при создании?
   - Или API определяет тенант из контекста аутентификации?

## Итоговая Оценка

### UI/UX Дизайн: ✅ **ОТЛИЧНО** (9/10)

**Что хорошо:**
- ✅ Tenant selector интуитивно понятен
- ✅ Global vs tenant концепция четкая
- ✅ Permissions модель правильная
- ✅ UI готов к мультитенантности
- ✅ Responsive и работает на всех устройствах

**Что нужно добавить:**
- ⚠️ Визуальные индикаторы тенанта в данных
- ⚠️ Информационное сообщение о текущем тенанте

### Backend Интеграция: ⚠️ **ЧАСТИЧНО** (4/10)

**Что работает:**
- ✅ Управление тенантами (CRUD)
- ✅ Tenant selector в UI
- ✅ User → tenant binding

**Что не работает:**
- ❌ Изоляция данных по тенантам
- ❌ Фильтрация API по tenant
- ❌ Partition key handling
- ❌ Auto-refresh при смене тенанта

### Общая Готовность: **60%** 🟡

**Фундамент заложен хорошо**, но нужно:
1. Добавить tenant fields в data structures
2. Реализовать API filtering
3. Добавить визуальные индикаторы
4. Протестировать изоляцию

**Статус:** Готов к доработке backend интеграции ✅
