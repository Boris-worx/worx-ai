# 🗑️ Руководство по удалению Data Sources

## ✅ Статус
Функциональность удаления Data Sources **полностью реализована и работает**.

## 🎯 Возможности

### 1. UI Компоненты
- **Кнопка Delete** в таблице Data Sources для каждой строки
- **AlertDialog** для подтверждения удаления
- **Toast уведомления** об успехе/ошибке
- **Блокировка UI** во время удаления (disabled состояние)

### 2. Безопасность и права доступа
```typescript
// Только эти роли могут удалять Data Sources:
const canDelete = userRole === 'superuser' || 
                  userRole === 'admin' || 
                  userRole === 'developer';
```

**Могут удалять:**
- ✅ Portal.SuperUser
- ✅ Admin
- ✅ Developer

**Не могут удалять:**
- ❌ ViewOnlySuperUser
- ❌ Viewer

### 3. Tenant Isolation
Приложение соблюдает изоляцию тенантов:
- Каждый тенант видит только свои Data Sources
- При удалении передается `TenantId` для валидации на сервере
- GLOBAL TENANT может удалять Data Sources любого тенанта

## 🔧 Как работает

### Шаг 1: Пользователь нажимает кнопку Delete
```typescript
<Button
  variant="outline"
  size="sm"
  onClick={() => handleDeleteClick(row)}
  className="h-8 w-8 p-0 text-muted-foreground hover:text-destructive"
  title="Delete data source"
>
  <DeleteIcon className="h-4 w-4" />
</Button>
```

### Шаг 2: Открывается AlertDialog
```typescript
const handleDeleteClick = (dataSource: DataSource) => {
  setDataSourceToDelete(dataSource);
  setIsDeleteDialogOpen(true);
};
```

Диалог показывает:
- Название Data Source, который будет удален
- Предупреждение: "This action cannot be undone"
- Кнопки: Cancel / Delete

### Шаг 3: Подтверждение удаления
```typescript
const handleDelete = async () => {
  if (!dataSourceToDelete) return;

  setIsSubmitting(true);
  try {
    const etag = dataSourceToDelete._etag || '';
    const idToDelete = getDataSourceId(dataSourceToDelete);
    const tenantIdToDelete = dataSourceToDelete.TenantId;
    
    // DELETE API call
    await deleteDataSource(idToDelete, etag, tenantIdToDelete);
    
    // Оптимистическое обновление UI
    setDataSources(dataSources.filter(ds => 
      getDataSourceId(ds) !== idToDelete
    ));
    
    // Закрыть диалог
    setIsDeleteDialogOpen(false);
    setDataSourceToDelete(null);
    
    // Success toast
    toast.success(`Data source "${name}" deleted successfully!`);
    
    // Обновить данные с сервера через 1 секунду
    setTimeout(() => {
      refreshData();
    }, 1000);
  } catch (error: any) {
    toast.error(`Failed to delete data source: ${error.message}`);
  } finally {
    setIsSubmitting(false);
  }
};
```

### Шаг 4: API запрос
```typescript
export async function deleteDataSource(
  dataSourceId: string,
  etag: string,
  tenantId?: string,
): Promise<void> {
  // Build URL with optional TenantId query parameter
  let url = `${API_BASE_URL}/datasources/${encodeURIComponent(dataSourceId)}`;
  if (tenantId) {
    url += `?TenantId=${encodeURIComponent(tenantId)}`;
  }

  const response = await fetch(url, {
    method: "DELETE",
    headers: getHeaders(etag), // X-BFS-Auth + If-Match (ETag)
  });

  if (!response.ok) {
    // 404 = уже удален (не ошибка)
    if (response.status === 404) {
      console.log('Data source already deleted');
      return;
    }
    throw new Error(`Failed to delete: ${response.status}`);
  }
}
```

## 🌐 API Endpoint

### DELETE /1.0/datasources/{dataSourceId}

**URL:** `https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/datasources/{id}`

**Headers:**
```
X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
If-Match: {etag}
```

**Query Parameters:**
```
TenantId={tenantId} (optional)
```

**Пример запроса:**
```bash
curl --location --request DELETE \
  'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/datasources/datasource_2f32c5e5-c817-4575-989a-81a470b3c7fe' \
  --header 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
  --header 'If-Match: "abc123etag"'
```

**Response:**
- **204 No Content** - успешное удаление
- **404 Not Found** - Data Source не найден (уже удален)
- **412 Precondition Failed** - ETag не совпадает (conflict)
- **403 Forbidden** - нет прав доступа

## 🔐 ETag Support (Optimistic Concurrency Control)

Приложение использует ETag для предотвращения конфликтов:
1. При загрузке Data Source сохраняется `_etag`
2. При удалении ETag отправляется в заголовке `If-Match`
3. Если Data Source был изменен другим пользователем, API вернет 412
4. Пользователь должен обновить данные и повторить попытку

## 🧪 Как протестировать

### Тест 1: Успешное удаление
1. Войдите как **SuperUser**, **Admin** или **Developer**
2. Перейдите на вкладку **Data Source Onboarding**
3. Выберите тенант (не global)
4. Найдите Data Source для удаления
5. Нажмите кнопку **🗑️ Delete** в строке
6. Подтвердите удаление в диалоге
7. Проверьте:
   - ✅ Показан toast "deleted successfully"
   - ✅ Data Source исчез из таблицы
   - ✅ После обновления страницы Data Source все еще отсутствует

### Тест 2: Права доступа
1. Войдите как **Viewer** или **ViewOnlySuperUser**
2. Перейдите на вкладку **Data Source Onboarding**
3. Проверьте:
   - ✅ Кнопка Delete **не отображается** в таблице

### Тест 3: Tenant Isolation
1. Войдите как **Admin** тенанта "BFS"
2. Создайте Data Source для "BFS"
3. Выберите тенант "Meritage" в селекторе
4. Проверьте:
   - ✅ Data Source от "BFS" **не виден**
   - ✅ Нельзя удалить Data Source другого тенанта

### Тест 4: Global Tenant
1. Войдите как **SuperUser**
2. Выберите **GLOBAL TENANT**
3. Найдите Data Source любого тенанта
4. Удалите его
5. Проверьте:
   - ✅ Удаление прошло успешно
   - ✅ Data Source удален из всех тенантов

### Тест 5: Data Source не найден (404)
1. Откройте Developer Console (F12)
2. Удалите Data Source
3. Сразу же нажмите Delete еще раз (до обновления UI)
4. Проверьте:
   - ✅ API вернет 404
   - ✅ Приложение обработает как успех (не показывает ошибку)

### Тест 6: Отмена удаления
1. Нажмите кнопку Delete
2. В диалоге нажмите **Cancel**
3. Проверьте:
   - ✅ Диалог закрыт
   - ✅ Data Source остался в таблице
   - ✅ Никаких API запросов не отправлено

## 📊 Логирование

Приложение логирует все операции удаления в консоль:

```javascript
// До запроса
console.log('🗑️ DELETE Data Source Request:');
console.log('  DataSourceId:', dataSourceId);
console.log('  TenantId:', tenantId);
console.log('  URL:', url);
console.log('  ETag:', etag);

// После ответа
console.log('📥 DELETE Response:');
console.log('  Status:', response.status);
console.log('  OK:', response.ok);
```

Для дебага откройте Browser Console (F12) и смотрите логи.

## ⚠️ Важные моменты

### 1. Каскадное удаление
⚠️ **ВНИМАНИЕ:** При удалении Data Source могут удаляться связанные данные:
- Data Capture Specifications для этого Data Source
- Transactions связанные с Data Source
- Metadata и другие зависимые объекты

**Рекомендация:** Перед удалением проверьте зависимости в деталях Data Source.

### 2. ETag обязателен
Если Data Source был изменен другим пользователем:
- API вернет **412 Precondition Failed**
- Нужно обновить страницу и повторить попытку

### 3. Tenant Isolation строгий
- Нельзя удалить Data Source другого тенанта (кроме Global Tenant)
- API проверяет `TenantId` на сервере
- Попытка обойти проверку вернет **403 Forbidden**

### 4. Восстановление невозможно
⚠️ **Действие необратимо!** Нет функции "восстановить удаленный Data Source"

**Рекомендация:** 
- Создайте backup перед массовым удалением
- Используйте soft delete (inactive status) вместо физического удаления

## 🎨 UI/UX Детали

### Кнопка Delete
- Иконка: `<Trash2>` (lucide-react)
- Цвет: muted-foreground (серый)
- Hover: text-destructive (красный)
- Размер: 32x32px (h-8 w-8)
- Tooltip: "Delete data source"

### AlertDialog
- Заголовок: "Delete Data Source"
- Описание: Показывает название Data Source
- Предупреждение: "This action cannot be undone"
- Кнопка Cancel: outline variant (белая)
- Кнопка Delete: красная (bg-red-600 hover:bg-red-700)
- Disabled состояние: во время удаления

### Toast Notifications
- **Success:** `Data source "Bidtools" deleted successfully!`
- **Error:** `Failed to delete data source: {error message}`

## 📱 Адаптивность

Кнопка Delete отображается как на desktop, так и на mobile:
- Desktop: полная кнопка с иконкой
- Mobile: компактная версия (h-8 w-8)

## 🔄 Обновление UI

После удаления:
1. **Немедленно** удаляем из локального state (оптимистическое обновление)
2. Закрываем диалог
3. Показываем success toast
4. Через 1 секунду вызываем `refreshData()` для синхронизации с сервером

Это обеспечивает:
- ⚡ Быстрый отклик UI
- ✅ Консистентность данных
- 🔄 Автоматическую синхронизацию

## 🚀 Готово к использованию

Функциональность удаления Data Sources **готова и протестирована**:
- ✅ API интеграция
- ✅ UI компоненты
- ✅ Права доступа
- ✅ Tenant isolation
- ✅ ETag support
- ✅ Error handling
- ✅ Toast notifications
- ✅ Логирование

## 📚 Связанные документы

- [INDEX_DOCUMENTATION_RU.md](./INDEX_DOCUMENTATION_RU.md) - главный индекс документации
- [DATASOURCES_README_RU.md](./DATASOURCES_README_RU.md) - полная документация Data Sources
- [TENANT_ISOLATION_RU.md](./TENANT_ISOLATION_RU.md) - архитектура изоляции тенантов
- [DATASOURCES_CHEATSHEET_RU.md](./DATASOURCES_CHEATSHEET_RU.md) - шпаргалка по Data Sources

---

**Вопросы?** Откройте issue или свяжитесь с разработчиком.
