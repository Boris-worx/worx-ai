# 🧪 Apicurio PUT Operation - Test Guide

## Что сделано

Реализована функция PUT для обновления артефактов в Apicurio Registry и создан тестовый компонент для проверки.

## Где находится тест

**Путь:** API Connection Diagnostics → вкладка "🧪 PUT Test"

**Как открыть:**
1. Кликните иконку Database в верхней панели навигации
2. Откроется диалог "API Connection Diagnostics"
3. Выберите вкладку "🧪 PUT Test"

## Что делает тест

Тест автоматически:

1. **Получает текущий контент** артефакта `bfs.online/inv.response`
   ```
   GET /groups/bfs.online/artifacts/inv.response/versions/latest/content
   ```

2. **Изменяет поле name**
   ```json
   // До:
   { "name": "inv" }
   
   // После:
   { "name": "TxServices_inv" }
   ```

3. **Отправляет PUT запрос**
   ```
   PUT /groups/bfs.online/artifacts/inv.response
   Content-Type: application/json
   
   { ...modifiedContent }
   ```

4. **Проверяет результат**
   - Получает обновлённый контент
   - Проверяет что `name` изменился на `"TxServices_inv"`
   - Показывает результат в UI

## Как запустить тест

### Шаг 1: Откройте тест
```
Navigation Bar → Database Icon → API Connection Diagnostics → 🧪 PUT Test
```

### Шаг 2: Откройте консоль браузера
```
Нажмите F12 → вкладка Console
```

### Шаг 3: Запустите тест
```
Нажмите кнопку "Run PUT Test"
```

### Шаг 4: Наблюдайте результат

**В консоли вы увидите:**
```
🧪 ========== Apicurio PUT Test Started ==========
📦 Target: bfs.online/inv.response
📦 Change: name: 'inv' → 'TxServices_inv'

📦 Step 1: Fetching current content...
📦 Current schema keys: [...]
📦 Current name field: "inv"

📦 Step 2: Modifying content...
📦 New name field: "TxServices_inv"

📦 Step 3: Sending PUT request...
📦 PUT: Updating artifact: https://apicurio-poc.../inv.response
📦 PUT: Content: {...}
📦 PUT: Response status: 200
📦 PUT: Response text: {...}
📦 ✅ PUT successful: {...}

📦 Step 4: Verifying the change...
📦 Verified name field: "TxServices_inv"
✅ Change verified!

🧪 ========== Test Completed Successfully ==========
```

**В UI вы увидите:**
```
✅ Test Passed

Successfully updated artifact!
Old value: "inv"
New value: "TxServices_inv"
Version: 1.0.1
```

## Возможные результаты

### ✅ Успех (200 OK)
```
Status: 200
Response: { "version": "1.0.1", ... }
```
→ Артефакт успешно обновлён, создана новая версия

### ❌ CORS Error
```
Access to fetch at 'https://apicurio-poc...' has been blocked by CORS policy
```
→ Нужно настроить CORS на Apicurio Registry

### ❌ 403 Forbidden
```
Status: 403
Response: Forbidden
```
→ Проверьте права доступа к Apicurio

### ❌ 404 Not Found
```
Status: 404
Response: Artifact not found
```
→ Проверьте что артефакт существует

### ❌ 405 Method Not Allowed
```
Status: 405
Response: Method PUT not allowed
```
→ Apicurio может не поддерживать PUT на этом endpoint

## API Endpoint Details

### PUT Request
```http
PUT /apis/registry/v3/groups/bfs.online/artifacts/inv.response
Host: apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io
Content-Type: application/json

{
  "type": "object",
  "name": "TxServices_inv",
  "properties": { ... },
  ...
}
```

### Expected Response (Success)
```json
{
  "version": "1.0.1",
  "createdOn": "2025-11-28T...",
  "artifactId": "inv.response",
  "groupId": "bfs.online"
}
```

## Что проверяет тест

- [x] PUT запрос отправляется корректно
- [x] Apicurio принимает запрос (status 200)
- [x] Новая версия создаётся
- [x] Изменения сохраняются
- [x] Можно получить обновлённый контент
- [x] Поле `name` изменилось на `"TxServices_inv"`

## Файлы

### Новые файлы
- ✅ `/components/ApicurioPutTest.tsx` - Тестовый компонент

### Изменённые файлы
- ✅ `/lib/apicurio.ts` - Добавлена функция `updateApicurioArtifact()`
- ✅ `/components/ApicurioConnectionTest.tsx` - Добавлена вкладка "PUT Test"

## Использование API функции

```typescript
import { updateApicurioArtifact, getApicurioArtifact } from '../lib/apicurio';

// Получить текущий контент
const content = await getApicurioArtifact('bfs.online', 'inv.response');

// Изменить контент
const modified = { ...content, name: 'TxServices_inv' };

// Отправить PUT запрос
const result = await updateApicurioArtifact(
  'bfs.online',
  'inv.response',
  modified
);

if (result.success) {
  console.log('✅ Updated! Version:', result.version);
} else {
  console.error('❌ Failed:', result.message);
}
```

## Troubleshooting

### Проблема: CORS Error
**Решение:** Настроить CORS на Apicurio Registry
```bash
# Azure Container App
az containerapp ingress cors enable \
  --name apicurio-poc \
  --allowed-origins "https://your-app.azurewebsites.net" "http://localhost:5173" \
  --allowed-methods GET POST PUT DELETE OPTIONS
```

### Проблема: 403 Forbidden
**Решение:** Проверить authentication/authorization в Apicurio

### Проблема: Изменения не сохраняются
**Решение:** 
1. Проверить что PUT запрос возвращает 200
2. Проверить что создаётся новая версия
3. Очистить кэш: `clearArtifactsCache()`

### Проблема: Тест не запускается
**Решение:**
1. Проверить что приложение запущено
2. Открыть консоль (F12) и проверить ошибки
3. Проверить что Apicurio Registry доступен

## Next Steps

После успешного теста вы можете:
1. Создать полноценный редактор шаблонов
2. Добавить UI для редактирования любых артефактов
3. Интегрировать в Data Source Onboarding
4. Добавить версионность и rollback

## ✅ Готово к тестированию!

Откройте API Connection Diagnostics → 🧪 PUT Test и запустите тест!
