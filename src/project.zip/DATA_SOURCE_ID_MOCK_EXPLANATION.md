# Data Source ID и Specifications - Объяснение ⚡

## Ваш Вопрос

> Почему у одного Data Source ID "datasource_23726607-c174-4..." с 2 спецификациями (Quotes, QuotePackOrder),  
> а у другого ID "datasource_f1e50808-5382-4..." с 3 спецификациями (Quotes, QuoteDetails, QuotePacks)?  
> **Это приходит с API?**

---

## 📊 Быстрый Ответ

**НЕТ, это НЕ приходит с API!** ❌

**Это MOCK данные, захардкоженные в коде!** 🔴

---

## Откуда Берутся Данные

### Data Source ID - Реальные из API ✅
```typescript
// /components/DataSourcesView.tsx line 860
getRowId={(row) => getDataSourceId(row)}

// Helper function (line 39)
const getDataSourceId = (ds: DataSource) => 
  ds.DatasourceId || ds.DataSourceId || '';
```

**Data Source ID приходят из реального API:**
- `datasource_23726607-c174-4...` ✅ Реальный ID из Cosmos DB
- `datasource_f1e50808-5382-4...` ✅ Реальный ID из Cosmos DB

---

### Data Capture Specifications - MOCK ❌
```typescript
// /components/DataSourcesView.tsx line 862
const specifications = getMockSpecifications(getDataSourceName(row));

// Mock function (lines 308-353)
const getMockSpecifications = (dataSourceName: string): DataCaptureSpecification[] => {
  if (dataSourceName === 'Bidtools') {
    return [
      { id: 'spec_quotes', table: 'Quotes', version: '2.0', date: '10/30/2025' },
      { id: 'spec_quotedetails', table: 'QuoteDetails', version: '2.1', date: '10/31/2025' },
      { id: 'spec_quotepacks', table: 'QuotePacks', version: '2.1', date: '10/31/2025' }
    ];
  } else if (dataSourceName === 'Databricks') {
    return [
      { id: 'spec_quotes_db', table: 'Quotes', version: '1.5', date: '10/27/2025' },
      { id: 'spec_quotepackorder_db', table: 'QuotePackOrder', version: '1.0', date: '10/27/2025' }
    ];
  }
  return [];
};
```

**Specifications НЕ приходят из API - это hardcoded mock!** ❌

---

## Почему Разное Количество Спецификаций?

### Databricks (2 спецификации) - MOCK
```javascript
if (dataSourceName === 'Databricks') {
  return [
    { table: 'Quotes', version: '1.5' },           // MOCK
    { table: 'QuotePackOrder', version: '1.0' }    // MOCK
  ];
}
```

### Bidtools (3 спецификации) - MOCK
```javascript
if (dataSourceName === 'Bidtools') {
  return [
    { table: 'Quotes', version: '2.0' },          // MOCK
    { table: 'QuoteDetails', version: '2.1' },    // MOCK
    { table: 'QuotePacks', version: '2.1' }       // MOCK
  ];
}
```

**Эти данные захардкожены в функции `getMockSpecifications`!**

---

## Визуальное Объяснение

### Что Вы Видите на Скриншоте:

```
┌─────────────────────────────────────────────────────────┐
│ datasource_23726607-c174-4... | Databricks | 11/4/2025 │ ← REAL from API
├─────────────────────────────────────────────────────────┤
│ Data Capture Specifications:                            │
│ ├── Quotes          1.5   10/27/2025                    │ ← MOCK
│ └── QuotePackOrder  1.0   10/27/2025                    │ ← MOCK
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│ datasource_f1e50808-5382-4... | Bidtools | 10/31/2025  │ ← REAL from API
├─────────────────────────────────────────────────────────┤
│ Data Capture Specifications:                            │
│ ├── Quotes         2.0   10/30/2025                     │ ← MOCK
│ ├── QuoteDetails   2.1   10/31/2025                     │ ← MOCK
│ └── QuotePacks     2.1   10/31/2025                     │ ← MOCK
└─────────────────────────────────────────────────────────┘
```

---

## Почему Это Проблема?

### 1. Inconsistent Data
- Data Sources - REAL ✅
- Specifications - FAKE ❌

### 2. Невозможно Управлять
- Нельзя создать новую спецификацию
- Нельзя удалить существующую
- Нельзя редактировать

### 3. Нет Связи с Реальным API
- Реальные спецификации есть в ModelSchemaView
- Но они не связаны с Data Sources

---

## Как Должно Быть (С Реальным API)

### Реальный API Endpoint:
```
GET /1.0/txns?TxnType=ModelSchema&dataSourceId=datasource_23726607-c174-4...
```

### Реальный Response:
```json
[
  {
    "id": "Quote:1",
    "model": "Quote",
    "version": 1,
    "semver": "1.0.0",
    "dataSourceId": "datasource_23726607-c174-4...",
    "dataSourceName": "Databricks",
    "profile": "data-capture"
  },
  {
    "id": "QuotePackOrder:1",
    "model": "QuotePackOrder",
    "version": 1,
    "semver": "1.0.0",
    "dataSourceId": "datasource_23726607-c174-4...",
    "dataSourceName": "Databricks",
    "profile": "data-capture"
  }
]
```

---

## Как Исправить

### Шаг 1: Загрузить Реальные Specs из API

```typescript
// Replace mock function with real API call
const [dataSourceSpecs, setDataSourceSpecs] = useState<Record<string, ModelSchema[]>>({});

const loadSpecsForDataSource = async (dataSourceId: string) => {
  try {
    // Get all ModelSchemas from API
    const allSchemas = await getAllModelSchemas();
    
    // Filter by dataSourceId
    const specs = allSchemas.filter(schema => 
      schema.dataSourceId === dataSourceId
    );
    
    setDataSourceSpecs(prev => ({ ...prev, [dataSourceId]: specs }));
  } catch (error) {
    console.error('Failed to load specs:', error);
  }
};
```

### Шаг 2: Обновить Expandable Row

```typescript
// Instead of:
const specifications = getMockSpecifications(getDataSourceName(row)); // ❌ MOCK

// Use:
const dataSourceId = getDataSourceId(row);
const specifications = dataSourceSpecs[dataSourceId] || []; // ✅ REAL

// Load specs when row expands
useEffect(() => {
  if (dataSourceId && !dataSourceSpecs[dataSourceId]) {
    loadSpecsForDataSource(dataSourceId);
  }
}, [dataSourceId]);
```

### Шаг 3: Отобразить Реальные Данные

```typescript
{specifications.map((spec) => (
  <tr key={spec.id}>
    <td>{spec.model}</td>                    {/* ✅ Real table name */}
    <td>{spec.semver}</td>                   {/* ✅ Real version */}
    <td>{spec.UpdateTime || spec.CreateTime}</td>  {/* ✅ Real date */}
    <td>
      <Button onClick={() => viewSpec(spec)}>View</Button>
      <Button onClick={() => editSpec(spec)}>Edit</Button>
      <Button onClick={() => deleteSpec(spec)}>Delete</Button>
    </td>
  </tr>
))}
```

---

## Сравнение: MOCK vs REAL

### MOCK (Сейчас) ❌

| Data Source | Specifications | Source |
|-------------|----------------|--------|
| Databricks | Quotes, QuotePackOrder | Hardcoded in code |
| Bidtools | Quotes, QuoteDetails, QuotePacks | Hardcoded in code |

**Проблемы:**
- ❌ Не обновляется
- ❌ Нельзя добавить новые
- ❌ Нельзя удалить
- ❌ Не синхронизировано с ModelSchemaView

---

### REAL (После Исправления) ✅

| Data Source | Specifications | Source |
|-------------|----------------|--------|
| Databricks | Query from API: `?dataSourceId=datasource_23726607...` | Real API |
| Bidtools | Query from API: `?dataSourceId=datasource_f1e50808...` | Real API |

**Преимущества:**
- ✅ Автоматически обновляется
- ✅ Можно добавлять новые
- ✅ Можно удалять
- ✅ Синхронизировано с ModelSchemaView

---

## Проверка: Как Узнать что Это MOCK?

### Признак 1: Hardcoded Function
```typescript
// Line 308-353 in DataSourcesView.tsx
const getMockSpecifications = (dataSourceName: string) => {
  // ❌ This is MOCK!
}
```

### Признак 2: Одинаковые Данные Всегда
- Databricks всегда показывает 2 спецификации
- Bidtools всегда показывает 3 спецификации
- Не зависит от реального состояния базы данных

### Признак 3: Кнопка "Add" Не Работает
```typescript
// Line 873
onClick={() => {
  toast.info('Add Data Capture Specification - Coming soon!');
}}
```
**Это подтверждает что это MOCK!**

---

## Реальные Данные Существуют!

### В ModelSchemaView (Transaction Onboarding Tab)

Реальные Data Capture Specifications УЖЕ ЕСТЬ в базе данных!

```
GET /1.0/txns?TxnType=ModelSchema
```

**Они просто не связаны с Data Sources в UI!**

---

## Action Plan

### Немедленно (1 час):
1. ✅ Добавить `dataSourceId` в ModelSchema interface
2. ✅ Загружать реальные specs из API
3. ✅ Заменить `getMockSpecifications` на реальные данные

### Результат:
- ✅ Databricks покажет реальные specs из API
- ✅ Bidtools покажет реальные specs из API
- ✅ Количество specs будет соответствовать реальности
- ✅ Можно будет создавать/редактировать/удалять

---

## Ответ на Ваш Вопрос

**Q: "Это приходит с API?"**

**A: ЧАСТИЧНО:**
- ✅ Data Source ID - ДА, приходит с API
- ✅ Data Source Name - ДА, приходит с API
- ✅ Created/Updated dates - ДА, приходят с API
- ❌ **Data Capture Specifications - НЕТ, это MOCK данные!**

**Почему разное количество спецификаций?**
- Потому что они захардкожены в функции `getMockSpecifications`
- Databricks → 2 specs (Quotes, QuotePackOrder)
- Bidtools → 3 specs (Quotes, QuoteDetails, QuotePacks)
- Это НЕ отражает реальное состояние базы данных!

---

## Код, Который Нужно Заменить

### УДАЛИТЬ (Lines 308-353):
```typescript
// ❌ DELETE THIS
const getMockSpecifications = (dataSourceName: string): DataCaptureSpecification[] => {
  if (dataSourceName === 'Bidtools') {
    return [...]; // MOCK
  } else if (dataSourceName === 'Databricks') {
    return [...]; // MOCK
  }
  return [];
};
```

### ДОБАВИТЬ:
```typescript
// ✅ ADD THIS
const [dataSourceSpecs, setDataSourceSpecs] = useState<Record<string, ModelSchema[]>>({});

const loadSpecsForDataSource = async (dataSourceId: string) => {
  try {
    const allSchemas = await getAllModelSchemas();
    const specs = allSchemas.filter(s => s.dataSourceId === dataSourceId);
    setDataSourceSpecs(prev => ({ ...prev, [dataSourceId]: specs }));
  } catch (error) {
    console.error('Failed to load specs:', error);
  }
};
```

---

## Bottom Line

**Data Source ID:** ✅ Реальный из API  
**Data Source Name:** ✅ Реальный из API  
**Specifications:** ❌ **MOCK - НУЖНО ИСПРАВИТЬ!**

**Время исправления:** ~1 час  
**Приоритет:** 🔴 Высокий (показываются фейковые данные)

---

**Следующий шаг:** Заменить mock данные на реальные API calls! 🚀
