# Architecture Diagram

## BFS Platform Management - Visual Architecture

---

## 🏗️ System Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                        USER BROWSER                          │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌────────────────────────────────────────────────────┐   │
│  │              React Application                      │   │
│  │                                                     │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────┐│   │
│  │  │   Tenants    │  │ Transactions │  │ Builder  ││   │
│  │  │     Tab      │  │     Tab      │  │   Tab    ││   │
│  │  └──────────────┘  └──────────────┘  └──────────┘│   │
│  │         │                 │                 │      │   │
│  │         └─────────────────┴─────────────────┘      │   │
│  │                         │                          │   │
│  │              ┌──────────▼──────────┐              │   │
│  │              │   State Manager     │              │   │
│  │              │  (React Hooks)      │              │   │
│  │              └──────────┬──────────┘              │   │
│  │                         │                          │   │
│  │              ┌──────────▼──────────┐              │   │
│  │              │    API Client       │              │   │
│  │              │   (/lib/api.ts)     │              │   │
│  │              └──────────┬──────────┘              │   │
│  └─────────────────────────┼─────────────────────────┘   │
│                            │                              │
└────────────────────────────┼──────────────────────────────┘
                             │
                  ┌──────────▼──────────┐
                  │   Demo Mode?        │
                  └──────────┬──────────┘
                             │
                 ┌───────────┴───────────┐
                 │                       │
        ┌────────▼────────┐    ┌────────▼────────┐
        │   Mock Data     │    │   REST API      │
        │  (In-Memory)    │    │  (Production)   │
        └─────────────────┘    └────────┬────────┘
                                        │
                             ┌──────────▼──────────┐
                             │  X-BFS-Auth Header  │
                             │    Validation       │
                             └──────────┬──────────┘
                                        │
                             ┌──────────▼──────────┐
                             │   Azure Cosmos DB   │
                             │   (NoSQL Database)  │
                             └─────────────────────┘
```

---

## 🎨 Component Architecture

```
App.tsx
  │
  ├── Tabs Navigation
  │   ├── Tenants Tab
  │   ├── Transactions Tab
  │   └── Builder Tab
  │
  ├─── TenantsView
  │     │
  │     ├── DataTable
  │     │   ├── Search
  │     │   ├── Sort
  │     │   └── Filter
  │     │
  │     ├── TenantDetail (Dialog)
  │     │   └── Cosmos DB Metadata
  │     │
  │     ├── TenantEditForm (Dialog)
  │     │   ├── Name Input
  │     │   └── ETag Handling
  │     │
  │     └── TenantImportDialog (Dialog)
  │         ├── File Upload
  │         ├── JSON Validation
  │         └── Bulk Import
  │
  ├─── TransactionsView
  │     │
  │     ├── DataTable
  │     │   ├── Search
  │     │   ├── Sort
  │     │   └── Filter
  │     │
  │     ├── TransactionDetail (Dialog)
  │     │   ├── Request JSON Tab
  │     │   └── Response JSON Tab
  │     │
  │     └── TransactionForm (Dialog)
  │         ├── Name Input
  │         ├── Request File Upload
  │         └── Response File Upload
  │
  └─── TransactionBuilder
        │
        ├── Tenant Selector
        ├── Transaction Input
        │   ├── File Upload
        │   ├── Paste URL
        │   └── Manual Entry
        │
        ├── Action Checkboxes
        │   ├── STORE
        │   ├── PUBLISH
        │   ├── RESPOND
        │   └── AGENT
        │
        └── Start Builder Button
```

---

## 📦 Technology Layers

```
┌─────────────────────────────────────────────────────┐
│              Presentation Layer                      │
│  React Components + Tailwind CSS + shadcn/ui       │
├─────────────────────────────────────────────────────┤
│              Business Logic Layer                    │
│  React Hooks (useState, useEffect, useRef)         │
│  Validation, Handlers, State Management            │
├─────────────────────────────────────────────────────┤
│              Data Access Layer                       │
│  API Client (/lib/api.ts)                          │
│  Fetch API, Response Handling                      │
├─────────────────────────────────────────────────────┤
│              Network Layer                           │
│  HTTP/HTTPS, REST API                              │
│  Headers: X-BFS-Auth, If-Match                     │
├─────────────────────────────────────────────────────┤
│              Backend Services                        │
│  Azure Cosmos DB                                    │
│  Authentication Service                             │
└─────────────────────────────────────────────────────┘
```

---

## 🔄 Data Flow

### Read Operation (GET)

```
User Interface
    │
    ├─ Click "Tenants" tab
    │
    ▼
Component (TenantsView)
    │
    ├─ useEffect(() => loadTenants())
    │
    ▼
API Client (/lib/api.ts)
    │
    ├─ getAllTenants()
    │
    ▼
Fetch API
    │
    ├─ GET /tenants
    ├─ Headers: X-BFS-Auth
    │
    ▼
REST API
    │
    ├─ Validate auth header
    ├─ Query Cosmos DB
    │
    ▼
Response
    │
    ├─ { status: 200, data: [...] }
    │
    ▼
Component State
    │
    ├─ setTenants(data)
    │
    ▼
UI Update
    │
    └─ Render table with tenants
```

### Write Operation (PUT)

```
User Interface
    │
    ├─ Click "Edit" button
    ├─ Change tenant name
    ├─ Click "Save"
    │
    ▼
Component (TenantEditForm)
    │
    ├─ handleSave()
    │
    ▼
API Client
    │
    ├─ updateTenant(id, name, etag)
    │
    ▼
Fetch API
    │
    ├─ PUT /tenants/{id}
    ├─ Headers:
    │   - X-BFS-Auth: {key}
    │   - If-Match: {etag}
    ├─ Body: { TenantName: "New Name" }
    │
    ▼
REST API
    │
    ├─ Validate auth header
    ├─ Check ETag match
    ├─ Update Cosmos DB
    │
    ▼
Response
    │
    ├─ { status: 200, data: {...} }
    │
    ▼
Component
    │
    ├─ onSuccess(updatedTenant)
    │
    ▼
Parent Component
    │
    ├─ Update state
    │
    ▼
UI Update
    │
    └─ Reflect changes in table
```

---

## 🔐 Security Architecture

```
┌─────────────────────────────────────────────────────┐
│                  Client Side                         │
│                                                      │
│  ✓ XSS Prevention (React escaping)                 │
│  ✓ Input Validation                                │
│  ✓ Secure JSON Parsing                             │
│  ✓ File Type Validation                            │
│                                                      │
└──────────────────┬──────────────────────────────────┘
                   │
                   │ HTTPS
                   │
┌──────────────────▼──────────────────────────────────┐
│                  API Layer                           │
│                                                      │
│  ✓ X-BFS-Auth Header Validation                    │
│  ✓ CORS Configuration                              │
│  ✓ Rate Limiting (recommended)                     │
│  ✓ Request Validation                              │
│                                                      │
└──────────────────┬──────────────────────────────────┘
                   │
┌──────────────────▼──────────────────────────────────┐
│                  Database Layer                      │
│                                                      │
│  ✓ ETag Concurrency Control                        │
│  ✓ Document-level Security                         │
│  ✓ Encryption at Rest                              │
│  ✓ Audit Trail (_ts, CreateTime)                   │
│                                                      │
└─────────────────────────────────────────────────────┘
```

---

## 📊 State Management Flow

```
┌─────────────────────────────────────────────────────┐
│              Component Lifecycle                     │
└─────────────────────────────────────────────────────┘
                      │
         ┌────────────▼────────────┐
         │   Component Mount       │
         │  (TenantsView)          │
         └────────────┬────────────┘
                      │
         ┌────────────▼────────────┐
         │   useEffect runs        │
         │   loadTenants()         │
         └────────────┬────────────┘
                      │
         ┌────────────▼────────────┐
         │   setIsLoading(true)    │
         └────────────┬────────────┘
                      │
         ┌────────────▼────────────┐
         │   API call              │
         │   await getAllTenants() │
         └────────────┬────────────┘
                      │
            ┌─────────┴─────────┐
            │                   │
    ┌───────▼──────┐    ┌──────▼───────┐
    │   Success    │    │    Error     │
    └───────┬──────┘    └──────┬───────┘
            │                   │
    ┌───────▼──────┐    ┌──────▼───────┐
    │ setTenants() │    │ toast.error()│
    └───────┬──────┘    └──────┬───────┘
            │                   │
            └─────────┬─────────┘
                      │
         ┌────────────▼────────────┐
         │  setIsLoading(false)    │
         └────────────┬────────────┘
                      │
         ┌────────────▼────────────┐
         │    Re-render            │
         │  (Updated UI)           │
         └─────────────────────────┘
```

---

## 🎨 Styling Architecture

```
┌─────────────────────────────────────────────────────┐
│              Tailwind CSS v4                         │
└─────────────────────────────────────────────────────┘
                      │
         ┌────────────┴────────────┐
         │                         │
┌────────▼──────────┐   ┌─────────▼─────────┐
│  CSS Variables    │   │  Utility Classes   │
│  (Design Tokens)  │   │  (Component Level) │
└────────┬──────────┘   └─────────┬─────────┘
         │                         │
         │  :root {                │  <div className=
         │    --background         │    "flex gap-4
         │    --foreground         │     p-6 rounded-lg
         │    --primary            │     bg-card">
         │    --radius             │
         │  }                      │
         │                         │
         └────────────┬────────────┘
                      │
         ┌────────────▼────────────┐
         │   Dark Mode Support     │
         │   .dark { ... }         │
         └────────────┬────────────┘
                      │
         ┌────────────▼────────────┐
         │   Compiled CSS          │
         │   (Production Build)    │
         └─────────────────────────┘
```

---

## 🔄 Demo vs Production Mode

```
                    Application Start
                          │
                ┌─────────▼─────────┐
                │  Check API_BASE_URL│
                └─────────┬─────────┘
                          │
                ┌─────────┴─────────┐
                │                   │
        ┌───────▼──────┐    ┌──────▼────────┐
        │  Demo Mode   │    │ Production    │
        │  (*.example) │    │ (Real URL)    │
        └───────┬──────┘    └──────┬────────┘
                │                   │
        ┌───────▼──────┐    ┌──────▼────────┐
        │ Mock Data    │    │ Fetch API     │
        │ Instant      │    │ HTTP Calls    │
        └───────┬──────┘    └──────┬────────┘
                │                   │
        ┌───────▼──────┐    ┌──────▼────────┐
        │ demoTenants  │    │ Cosmos DB     │
        │ Array        │    │ Documents     │
        └───────┬──────┘    └──────┬────────┘
                │                   │
                └─────────┬─────────┘
                          │
                ┌─────────▼─────────┐
                │   Component       │
                │   Receives Data   │
                └───────────────────┘
```

---

## 📱 Responsive Design Flow

```
                    User Device
                         │
           ┌─────────────┴─────────────┐
           │                           │
    ┌──────▼──────┐           ┌───────▼──────┐
    │   Mobile    │           │   Desktop    │
    │  < 768px    │           │   > 768px    │
    └──────┬──────┘           └───────┬──────┘
           │                           │
    ┌──────▼──────┐           ┌───────▼──────┐
    │ Tailwind    │           │  Tailwind    │
    │ Base Classes│           │  md: Classes │
    └──────┬──────┘           └───────┬──────┘
           │                           │
    ┌──────▼──────┐           ┌───────▼──────┐
    │ Stack       │           │  Grid        │
    │ Layout      │           │  Layout      │
    └──────┬──────┘           └───────┬──────┘
           │                           │
           └─────────────┬─────────────┘
                         │
                ┌────────▼────────┐
                │ Adaptive UI     │
                │ Components      │
                └─────────────────┘
```

---

## 🗂️ File Organization

```
/
├── components/          ← React Components
│   ├── ui/             ← shadcn/ui components (44)
│   ├── TenantsView     ← Feature components
│   └── ...
│
├── lib/                ← Shared utilities
│   └── api.ts         ← API client
│
├── styles/             ← Global styles
│   └── globals.css    ← Tailwind config + tokens
│
├── *.md               ← Documentation
│
└── App.tsx            ← Application entry point
```

---

## 🎯 Request/Response Flow

### Example: Create Tenant

```
UI: User fills form
    │
    ▼
UI: Click "Create"
    │
    ▼
Component: handleCreate()
    │
    ├─ Validate: name not empty
    │
    ▼
API Client: createTenant(name)
    │
    ├─ POST /tenants
    ├─ Headers:
    │   X-BFS-Auth: {key}
    ├─ Body:
    │   { TenantName: "Acme Corp" }
    │
    ▼
Network: HTTPS Request
    │
    ▼
API: Authenticate
    │
    ├─ Check X-BFS-Auth header
    │
    ▼
API: Process
    │
    ├─ Generate TenantId
    ├─ Add timestamps
    ├─ Create Cosmos document
    │
    ▼
API: Response
    │
    ├─ 200 OK
    ├─ Body: {
    │   status: { code: 200 },
    │   data: {
    │     TenantId: "tenant-123",
    │     TenantName: "Acme Corp",
    │     _etag: "...",
    │     ...
    │   }
    │ }
    │
    ▼
Component: Success
    │
    ├─ toast.success()
    ├─ Add to state
    ├─ Close dialog
    │
    ▼
UI: Table updated
    │
    └─ New row appears
```

---

## 🔍 Architecture Principles

### Separation of Concerns
```
Presentation ≠ Business Logic ≠ Data Access
```

### Single Responsibility
```
Each component has ONE clear purpose
```

### DRY (Don't Repeat Yourself)
```
DataTable component reused for:
- Tenants
- Transactions
```

### Component Composition
```
Small, focused components
Combined to build features
```

### Type Safety
```
TypeScript interfaces for all data
Compile-time error detection
```

---

**Architecture designed for scalability, maintainability, and developer experience!** 🚀
