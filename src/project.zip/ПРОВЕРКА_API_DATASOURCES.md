# 🔍 Быстрая проверка DataSource API

## Три способа проверить, что возвращает API:

---

## ✅ Способ 1: HTML тестер (САМЫЙ ПРОСТОЙ)

1. Откройте файл **`test-datasources-api.html`** в браузере
2. Нажмите кнопку **"🚀 Fetch DataSources"**
3. Получите полный анализ:
   - Сколько источников
   - Какие поля есть
   - Примеры значений
   - Полный JSON

**Что увидите:**
```
📊 Response Summary
├── Response Format: "data.datasources array"
├── Total DataSources: 5
├── Unique Fields: 12 fields

🔑 Fields Analysis
├── DatasourceId: string
├── DatasourceName: string
├── Type: string
├── Status: string
├── Description: string
└── ... все остальные поля с примерами
```

---

## ✅ Способ 2: Консоль браузера (АВТОМАТИЧЕСКИ)

1. Откройте приложение
2. Нажмите **F12** (DevTools)
3. Перейдите на вкладку **"Data Source Onboarding"**
4. Смотрите в консоль:

```javascript
🎯 First data source: { DatasourceId: "...", ... }
🔑 All fields in first data source: ["DatasourceId", "DatasourceName", ...]
📋 All unique fields across all data sources: [...]
💡 Field value examples: { ... }
```

---

## ✅ Способ 3: cURL (ДЛЯ РАЗРАБОТЧИКОВ)

```bash
curl -X GET \
  'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/datasources' \
  -H 'X-BFS-Auth: bfs-secret-key-12345' \
  -H 'Content-Type: application/json'
```

---

## 📋 Какие поля мы ожидаем увидеть:

### Основные поля:
- ✅ **DatasourceId** / DataSourceId - ID источника
- ✅ **DatasourceName** / DataSourceName - Название
- ✅ **Type** - Тип (SQL, NoSQL, API...)
- ✅ **Status** - Статус (Active, Inactive)
- ✅ **Description** - Описание
- ⚠️ **ConnectionString** - Строка подключения (чувствительные данные!)

### Временные метки:
- 📅 **CreateTime** - Когда создан
- 📅 **UpdateTime** - Когда обновлен

### Системные поля Cosmos DB:
- 🔧 **_rid** - Resource ID
- 🔧 **_self** - Self link
- 🔧 **_etag** - ETag (нужен для UPDATE/DELETE!)
- 🔧 **_attachments** - Attachments link
- 🔧 **_ts** - Unix timestamp

---

## ❓ Что проверить:

1. **Все ли основные поля присутствуют?**
   - [ ] ID есть?
   - [ ] Name есть?
   - [ ] _etag есть? (критично для редактирования!)

2. **Какие поля заполнены, какие пустые?**
   - [ ] Type заполнен?
   - [ ] Status заполнен?
   - [ ] Description заполнен?

3. **Есть ли новые поля, которых мы не знаем?**
   - [ ] Проверить список всех полей
   - [ ] Сравнить с нашим TypeScript интерфейсом

---

## 🎯 Быстрый чеклист:

```
✅ test-datasources-api.html открывается
✅ Кнопка "Fetch DataSources" работает
✅ Показывается количество Data Sources
✅ Видна таблица со всеми полями
✅ Можно скопировать JSON в буфер обмена
✅ Консоль браузера показывает детальную информацию
```

---

## 🐛 Если что-то не так:

**❌ CORS Error:**
- API блокирует запросы
- Проверьте настройки CORS на сервере

**❌ 401 Unauthorized:**
- Неверный API ключ
- Проверьте X-BFS-Auth header

**❌ Пустой массив:**
- В базе нет Data Sources
- Создайте тестовый источник

**❌ Незнакомый формат:**
- API вернул что-то новое
- Посмотрите Raw Response
- Добавьте обработку в getAllDataSources()

---

## 📝 Что делать с результатами:

### Если нашли новые поля:

1. **Обновить `/lib/api.ts`:**
   ```typescript
   export interface DataSource {
     NewField?: string;  // добавить
   }
   ```

2. **Обновить `/components/DataSourcesView.tsx`:**
   ```typescript
   { key: 'NewField', label: 'New Field', enabled: false }
   ```

3. **Добавить форматирование если нужно**

---

## 📚 Полная документация:

Смотрите `/DATASOURCE_API_INSPECTION.md` для детальной информации.

---

**Статус:** ✅ Готово  
**Дата:** 29 октября 2025
