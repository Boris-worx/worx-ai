# Новые Quote Типы - Быстрый Старт 🚀

## ✅ Что Добавлено

Три новых типа транзакций для Quote-системы:

1. **QuoteDetails** - строки/детали котировки
2. **QuotePack** - пакеты котировок
3. **QuotePackOrder** - заказы пакетов

## 🎯 Где Найти

**Data Plane** → Dropdown меню → Выберите тип:
- QuoteDetails
- QuotePack  
- QuotePackOrder

## 📝 Шаблоны

### QuoteDetails (строка котировки)
```json
{
  "quoteDetailId": "QD-12345",
  "quoteId": "QUOTE-789",
  "lineNumber": 1,
  "itemDescription": "Описание товара",
  "quantity": 1,
  "unitPrice": 100.00,
  "totalPrice": 100.00
}
```

### QuotePack (пакет)
```json
{
  "quotePackId": "QP-12345",
  "quoteId": "QUOTE-789",
  "packName": "Название пакета",
  "totalAmount": 1000.00,
  "quoteDetails": ["QD-001", "QD-002"],
  "isActive": true
}
```

### QuotePackOrder (заказ)
```json
{
  "quotePackOrderId": "QPO-12345",
  "quotePackId": "QP-789",
  "orderDate": "2025-10-29T12:00:00.000Z",
  "status": "pending",
  "totalAmount": 1000.00
}
```

## 🔄 Процесс

```
1. Quote (основная котировка)
   ↓
2. QuoteDetails (добавить строки)
   ↓
3. QuotePack (сгруппировать в пакет)
   ↓
4. QuotePackOrder (создать заказ)
```

## 🎨 Как Использовать в UI

1. Откройте **Data Plane**
2. Выберите **QuoteDetails** из dropdown
3. Нажмите **"+ Create New Transaction"**
4. Измените `quoteDetailId` на уникальный
5. Заполните поля
6. Нажмите **"Create Transaction"**

## 🧪 Быстрый Тест

```bash
# QuoteDetails
curl -X POST 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/txns' \
-H 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
-H 'Content-Type: application/json' \
-d '{
  "TxnType": "QuoteDetails",
  "Txn": {
    "quoteDetailId": "QD-TEST-001",
    "itemDescription": "Test",
    "quantity": 1,
    "unitPrice": 50
  }
}'

# Проверить
curl 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/txns?TxnType=QuoteDetails' \
-H 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
```

## ✅ Готово!

Все типы работают и готовы к использованию.

📖 **Полная документация**: [QUOTE_TYPES_ENABLED.md](/QUOTE_TYPES_ENABLED.md)
