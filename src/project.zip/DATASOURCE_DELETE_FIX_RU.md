# Исправление удаления Data Sources ✅

## Проблема
После удаления data source через API, элемент всё ещё может отображаться в списке из-за того, что backend не успевает обработать удаление до вызова `refreshData()`.

## Решение

### 1. Добавлена задержка перед refreshData() после удаления
Аналогично исправлению для создания data source, теперь также добавлена задержка в 1 секунду перед обновлением списка после удаления.

**Файл:** `/components/DataSourcesView.tsx`

```typescript
// До исправления:
await deleteDataSource(idToDelete, etag, tenantIdToDelete);
setDataSources(dataSources.filter(ds => getDataSourceId(ds) !== idToDelete));
toast.success(`Data source deleted successfully!`);
refreshData(); // ❌ Немедленное обновление - backend не успевает

// После исправления:
await deleteDataSource(idToDelete, etag, tenantIdToDelete);
setDataSources(dataSources.filter(ds => getDataSourceId(ds) !== idToDelete));
toast.success(`Data source deleted successfully!`);
// ✅ Задержка 1 секунда для обработки backend
setTimeout(() => {
  refreshData();
}, 1000);
```

### 2. Улучшено логирование в deleteDataSource()
Добавлено более детальное логирование для диагностики проблем с удалением.

**Файл:** `/lib/api.ts`

```typescript
console.log('🗑️ DELETE Data Source Request:');
console.log('  DataSourceId:', dataSourceId);
console.log('  TenantId:', tenantId || 'undefined');
console.log('  URL:', url);
console.log('  ETag:', etag);
console.log('  Method: DELETE');

// ...после получения ответа...

console.log('📥 DELETE Response:');
console.log('  Status:', response.status, response.statusText);
console.log('  OK:', response.ok);

// ...в случае успеха...

const responseText = await response.text();
if (responseText) {
  console.log('✅ DELETE Response body:', responseText);
} else {
  console.log('✅ Data source deleted successfully (no response body)');
}
```

## Тестирование

### Способ 1: Через приложение
1. Перейдите на вкладку "Data Source Onboarding"
2. Выберите тенант (например, "BFS")
3. Создайте новый data source с именем "TestDelete" и TenantId "BFS"
4. Подождите 1 секунду для обработки создания
5. Удалите созданный data source
6. Проверьте:
   - Элемент должен исчезнуть из списка немедленно (локальное удаление)
   - Через 1 секунду произойдёт обновление списка с backend
   - Элемент не должен появиться снова после обновления

### Способ 2: Через тестовый файл
Откройте файл `/test-datasources-bfs-api.html` в браузере:

1. **Test 3: Create DataSource**
   - Введите имя: `TestDelete`
   - Введите TenantId: `BFS`
   - Нажмите "Run Test"
   - Скопируйте ID созданного data source

2. **Проверка через консоль браузера:**
   ```javascript
   // Удаление data source
   const dataSourceId = 'YOUR_DATASOURCE_ID_HERE'; // ID из предыдущего шага
   const tenantId = 'BFS';
   
   const response = await fetch(
     `https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/datasources/${dataSourceId}?TenantId=${tenantId}`,
     {
       method: 'DELETE',
       headers: {
         'X-BFS-Auth': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
         'Content-Type': 'application/json'
       }
     }
   );
   
   console.log('DELETE Status:', response.status);
   const text = await response.text();
   console.log('DELETE Response:', text);
   ```

3. **Проверка что data source удалён:**
   ```javascript
   // Получить список data sources для BFS
   const filters = JSON.stringify({ TenantId: 'BFS' });
   const listResponse = await fetch(
     `https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/datasources?Filters=${encodeURIComponent(filters)}`,
     {
       method: 'GET',
       headers: {
         'X-BFS-Auth': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
         'Content-Type': 'application/json'
       }
     }
   );
   
   const data = await listResponse.json();
   console.log('DataSources for BFS:', data.data.DataSources);
   // Проверьте что TestDelete отсутствует в списке
   ```

### Способ 3: Через curl
```bash
# 1. Создать data source
curl --location 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/datasources' \
--header 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
--header 'Content-Type: application/json' \
--data '{
    "DatasourceName": "AS400",
    "TenantId": "BFS"
}'

# Скопируйте DatasourceId из ответа

# 2. Удалить data source
curl --location --request DELETE \
'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/datasources/YOUR_DATASOURCE_ID?TenantId=BFS' \
--header 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'

# 3. Проверить что data source удалён
curl --location 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/datasources?Filters=%7B%22TenantId%22%3A%22BFS%22%7D' \
--header 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
```

## Логирование в консоли

При удалении data source вы увидите в консоли браузера:

```
🗑️ Deleting data source:
  Data Source: {DatasourceId: "...", DatasourceName: "...", ...}
  ID to delete: datasource_abc123
  TenantId: BFS
  Name: AS400
  ETag: "..."

🗑️ DELETE Data Source Request:
  DataSourceId: datasource_abc123
  TenantId: BFS
  URL: https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/datasources/datasource_abc123?TenantId=BFS
  ETag: "..."
  Method: DELETE

📥 DELETE Response:
  Status: 200 OK
  OK: true

✅ Data source deleted successfully (no response body)
```

## Обработка ошибок

### 404 - Data Source не найден
Если data source уже удалён или не существует, API вернёт 404. Приложение обрабатывает это как успешное удаление:

```
⚠️ Data source not found (404) - treating as already deleted
```

### Другие ошибки
При других ошибках приложение покажет toast с сообщением об ошибке и выведет детальную информацию в консоль.

## Изменённые файлы
- ✅ `/components/DataSourcesView.tsx` - добавлена задержка перед refreshData()
- ✅ `/lib/api.ts` - улучшено логирование в deleteDataSource()

## Следующие шаги
1. Протестируйте создание и удаление data sources
2. Проверьте логи в консоли браузера
3. Убедитесь, что удалённые data sources не появляются снова после обновления
4. Проверьте работу с разными тенантами (BFS, Meritage, и т.д.)
