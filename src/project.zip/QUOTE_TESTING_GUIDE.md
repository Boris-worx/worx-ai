# Quote API Testing Guide

## Overview
This guide provides step-by-step instructions for testing the new Quote transaction type support in the BFS Data Plane application.

## Quote API Information

### API Endpoint
- **Base URL**: `https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/txns`
- **Auth Header**: `X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`

### Quote Schema
Quote transactions follow Max's canonical model with the following key fields:

#### Required Fields
- `quoteId` - Unique identifier for the quote

#### Optional Fields (from canonical model)
- `customerId` - Customer identifier
- `serviceRequestId` - Service request reference
- `isPublished` - Publication status (boolean)
- `customerRequestedByDate` - ISO 8601 datetime string
- `exportNotes` - Notes for export
- `categories` - Array of category objects
  - `categoryId` - Category identifier
  - `name` - Category name
  - `description` - Category description
- `accountNumber` - Account number string
- `erpUserId` - ERP user identifier
- And many more fields from the canonical model...

## Testing Steps

### 1. Access Data Plane Tab
1. Open the application
2. Navigate to the **Data Plane** tab
3. You should see Quote in the transaction type dropdown

### 2. Create a Quote Transaction

#### Method 1: Using the UI
1. Click the **Create New Transaction** button (Plus icon)
2. Select **Quote** from the Transaction Type dropdown
3. The form will auto-populate with a template:
```json
{
  "quoteId": "QUOTE-1730187533596",
  "customerId": null,
  "customerRequestedByDate": "2025-11-28T00:00:00.000Z",
  "exportNotes": "Quote notes",
  "categories": [
    {
      "categoryId": "35",
      "name": null,
      "description": null
    },
    {
      "categoryId": "37",
      "name": null,
      "description": null
    }
  ],
  "accountNumber": "",
  "erpUserId": "ONLINE",
  "isPublished": false
}
```

4. Modify the fields as needed:
   - Update `quoteId` to a unique value (e.g., "test-quote-1")
   - Set `accountNumber` (e.g., "579237")
   - Modify `exportNotes`
   - Update `customerRequestedByDate` to your desired date

5. Click **Create Transaction**
6. Check for success toast notification
7. The transaction list should refresh and show your new Quote

#### Method 2: Using Browser Console
```javascript
// Test Quote creation directly
const testQuote = {
  TxnType: "Quote",
  Txn: {
    quoteId: "test-quote-" + Date.now(),
    customerRequestedByDate: "2025-07-25T00:00:00.000Z",
    exportNotes: "Test quote from console",
    categories: [
      { categoryId: "35", name: null, description: null },
      { categoryId: "37", name: null, description: null }
    ],
    accountNumber: "579237",
    erpUserId: "ONLINE"
  }
};

// Make the API call
fetch('https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/txns', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'X-BFS-Auth': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
  },
  body: JSON.stringify(testQuote)
})
.then(r => r.json())
.then(data => console.log('Quote created:', data))
.catch(err => console.error('Error:', err));
```

### 3. View Quote Transactions

1. In the Data Plane tab, select **Quote** from the transaction type dropdown
2. Click **Refresh** (circular arrow icon)
3. The table should display all Quote transactions
4. You should see columns:
   - **TxnId** (in format "Quote:quote-id")
   - **Create Time**
   - **Update Time**
   - **Actions** (View, Edit, Delete buttons)

### 4. View Quote Details

1. Click the **View** (eye icon) button on any Quote row
2. A detail dialog will open showing:
   - Transaction Type: Quote
   - Transaction ID: Quote:your-quote-id
   - Create Time
   - Update Time
   - Full JSON data in a scrollable text area

### 5. Edit Quote Transaction

1. Click the **Edit** (pencil icon) button on any Quote row
2. The edit dialog opens with the current Quote data
3. Modify any fields (e.g., change `exportNotes` or update `accountNumber`)
4. Click **Save Changes**
5. Verify the update was successful via toast notification
6. The table should refresh with updated data

### 6. Delete Quote Transaction

1. Click the **Delete** (trash icon) button on any Quote row
2. A confirmation dialog appears
3. Click **Delete** to confirm
4. Verify deletion via toast notification
5. The Quote should disappear from the table

## Expected API Responses

### Create Quote Response
```json
{
  "status": {
    "code": 201,
    "message": "Created"
  },
  "data": {
    "TxnType": "Quote",
    "Txn": {
      "quoteId": "some-unique-id-1",
      "customerId": null,
      "serviceRequestId": null,
      "isPublished": null,
      // ... many more fields from canonical model
      "exportNotes": "Some notes",
      "customerRequestedByDate": "2025-07-25T00:00:00+00:00",
      "categories": [
        {
          "categoryId": "35",
          "name": null,
          "description": null
        },
        {
          "categoryId": "37",
          "name": null,
          "description": null
        }
      ],
      "accountNumber": "579237",
      "erpUserId": "ONLINE",
      "createTime": "2025-10-29T07:38:53.596946",
      "updateTime": "2025-10-29T07:38:53.596946",
      "_rid": "Q0N6AMKYK6kBAAAAAAAAAA==",
      "_etag": "\"2f001495-0000-0100-0000-6901c48d0000\"",
      "_ts": 1761723533
    }
  }
}
```

### Get Quote List Response
```json
{
  "status": {
    "code": 200,
    "message": "OK"
  },
  "data": {
    "TxnType": "Quote",
    "Txns": [
      {
        "quoteId": "some-unique-id-1",
        // ... full Quote object
      }
    ]
  }
}
```

## Verification Checklist

- [ ] Quote appears in transaction type dropdown
- [ ] Pre-filled template loads when creating Quote
- [ ] Quote creation succeeds with valid data
- [ ] Quote appears in transaction list with correct TxnId format (Quote:quoteId)
- [ ] View Quote details shows all fields correctly
- [ ] Edit Quote updates successfully
- [ ] Delete Quote removes the transaction
- [ ] All operations show appropriate toast notifications
- [ ] API logs in console show correct request/response format
- [ ] Error handling works for invalid data

## Troubleshooting

### Issue: Quote not appearing in dropdown
**Solution**: Refresh the page or check that `TRANSACTION_TYPES` in `/lib/api.ts` includes 'Quote'

### Issue: Create fails with validation error
**Solution**: Ensure `quoteId` is unique and required fields are present

### Issue: TxnId format incorrect
**Solution**: Check that the API is returning `quoteId` field and the transformation logic extracts it properly

### Issue: Cannot view/edit/delete
**Solution**: Verify user role has appropriate permissions (Portal.Admin, Portal.Developer, or Portal.SuperUser)

## Console Debugging

Open browser DevTools Console to see detailed logs:

1. **Request logs**: Shows the full POST/PUT/DELETE request
2. **Response logs**: Shows the API response structure
3. **Transformation logs**: Shows how raw API data is transformed to app format

Look for messages like:
```
POST Transaction Request:
  URL: https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/txns
  Headers: {Content-Type: 'application/json', X-BFS-Auth: '...'}
  Body: {TxnType: "Quote", Txn: {...}}

Response received:
  Status: 201 Created

Created transaction: {TxnId: "Quote:test-quote-1", TxnType: "Quote", ...}
```

## Next Steps

After verifying Quote functionality:
1. Test ReasonCode transaction type (similar process)
2. Test QuotePacks, QuoteDetails once enabled by API team
3. Verify compose functionality when Quote composition is enabled
4. Test Quote with related entities (Customer, Location)

## Related Documentation
- [TRANSACTION_CREATE_JSON_GUIDE.md](/TRANSACTION_CREATE_JSON_GUIDE.md) - General transaction creation guide
- [API_EXAMPLES.md](/API_EXAMPLES.md) - API request/response examples
- [TRANSACTIONS_DEBUGGING.md](/TRANSACTIONS_DEBUGGING.md) - Debugging guide
