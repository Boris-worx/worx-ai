# ✅ Интеграция BFS Online API endpoints

## Обзор

Приложение полностью интегрировано с BFS Online API для получения данных транзакций через endpoint `/1.1/txns` с фильтром `filters={"TxnType":"..."}`.

## API Endpoints

### Базовая конфигурация
```typescript
API_BASE_URL_V11 = "https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.1"
AUTH_HEADER = "X-BFS-Auth"
AUTH_TOKEN = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
```

### Поддерживаемые endpoints

#### 1. Keyi (Key Items)
```
GET https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.1/txns?filters={"TxnType":"keyi"}
```

#### 2. Inv (Inventory)
```
GET https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.1/txns?filters={"TxnType":"inv"}
```

#### 3. Inv1 (Inventory variant 1)
```
GET https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.1/txns?filters={"TxnType":"inv1"}
```

#### 4. Inv2 (Inventory variant 2)
```
GET https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.1/txns?filters={"TxnType":"inv2"}
```

#### 5. Inv3 (Inventory variant 3)
```
GET https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.1/txns?filters={"TxnType":"inv3"}
```

#### 6. Invap (Inventory AP)
```
GET https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.1/txns?filters={"TxnType":"invap"}
```

#### 7. Invdes (Inventory Descriptions)
```
GET https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.1/txns?filters={"TxnType":"invdes"}
```

#### 8. Invloc (Inventory Locations)
```
GET https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.1/txns?filters={"TxnType":"invloc"}
```

#### 9. Loc1 (Locations variant 1)
```
GET https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.1/txns?filters={"TxnType":"loc1"}
```

#### 10. Loc (Locations)
```
GET https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.1/txns?filters={"TxnType":"loc"}
```

#### 11. Stocode (Store Codes)
```
GET https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.1/txns?filters={"TxnType":"stocode"}
```

## Структура запроса

### Базовый запрос
```typescript
const filters = {
  TxnType: "inv"
};

const url = `${API_BASE_URL_V11}/txns?filters=${encodeURIComponent(JSON.stringify(filters))}`;

fetch(url, {
  method: "GET",
  headers: {
    "X-BFS-Auth": AUTH_TOKEN,
    "Content-Type": "application/json"
  },
  mode: "cors"
});
```

### Запрос с фильтром по тенанту
```typescript
const filters = {
  TxnType: "inv",
  TenantId: "1018-tenant"
};

const url = `${API_BASE_URL_V11}/txns?filters=${encodeURIComponent(JSON.stringify(filters))}`;
```

### Запрос с пагинацией
```typescript
const filters = {
  TxnType: "inv"
};

const url = `${API_BASE_URL_V11}/txns?filters=${encodeURIComponent(JSON.stringify(filters))}&continuationToken=${token}`;
```

## Структура ответа

### Формат BFS API v1.1
```json
{
  "status": {
    "code": 200,
    "message": "Success"
  },
  "data": {
    "TxnType": "inv",
    "TxnTotalCount": 1523,
    "Txns": [
      {
        "id": "inv-12345",
        "invid": "INV-001",
        "invdes": "Test Item",
        "ivstat": "A",
        "clsscd1": "CAT1",
        "unms": "EA",
        "createTime": "2025-11-25T10:00:00Z",
        "updateTime": "2025-11-25T11:00:00Z",
        "_etag": "\"0000d402-0000-0800-0000-67446b290000\"",
        "_rid": "rid12345",
        "_ts": 1732540201
      }
    ],
    "continuationToken": "token123"
  }
}
```

### Поля ответа

#### status
- `code` - HTTP код ответа (200 = успех)
- `message` - Сообщение о статусе запроса

#### data
- `TxnType` - Тип транзакции (соответствует запрошенному)
- `TxnTotalCount` - Общее количество транзакций (для пагинации)
- `Txns` - Массив объектов транзакций
- `continuationToken` - Токен для следующей страницы (опционально)

#### Поля транзакции (Txns[])
- `id` - Cosmos DB document ID
- Primary key поле (зависит от типа):
  - `invid` - для inv, inv1, inv2, inv3, invap, invdes, invloc, keyi
  - `loccd` / `Loccd` - для loc, loc1
  - `st` / `St` - для stocode
- Бизнес-поля (зависят от схемы типа)
- Системные поля:
  - `createTime` / `CreateTime`
  - `updateTime` / `UpdateTime`
  - `_etag` - ETag для оптимистичной блокировки
  - `_rid` - Cosmos DB Resource ID
  - `_ts` - Timestamp
  - `_self`, `_attachments` - Cosmos DB метаданные

## Обработка ID полей

### Логика определения Entity ID

Приложение использует следующую приоритетность для определения ID:

```typescript
let entityId = rawTxn.id;

if (!entityId) {
  // Bid Tools types
  if (rawTxn.CustomerId) entityId = rawTxn.CustomerId;
  else if (rawTxn.LocationId) entityId = rawTxn.LocationId;
  else if (rawTxn.quoteId) entityId = rawTxn.quoteId;
  else if (rawTxn.reasonCodeId) entityId = rawTxn.reasonCodeId;
  else if (rawTxn.InvoiceId) entityId = rawTxn.InvoiceId;
  
  // BFS Online Inventory types (inv, inv1, inv2, inv3, invap, invdes, invloc, keyi)
  else if (rawTxn.invid) entityId = rawTxn.invid;
  
  // BFS Online Location types (loc, loc1)
  else if (rawTxn.loccd || rawTxn.Loccd) entityId = rawTxn.loccd || rawTxn.Loccd;
  
  // BFS Online Store Code type (stocode)
  else if (rawTxn.st || rawTxn.St) entityId = rawTxn.st || rawTxn.St;
  
  // Cosmos DB fallback
  else if (rawTxn._rid) entityId = rawTxn._rid;
  
  // Last resort
  else entityId = `txn-${Date.now()}-${index}`;
}

const fullTxnId = `${TxnType}:${entityId}`;
```

### Примеры TxnId

#### Inventory types
```
Inv:INV-001
Inv1:INV1-123
Keyi:KEYI-456
```

#### Location types
```
Loc:LOC-EAST
Loc1:LOC1-001
```

#### Store Code type
```
Stocode:NY
```

## Обработка ошибок

### Unsupported TxnType
```json
{
  "status": {
    "code": 400,
    "message": "Unsupported TxnType"
  }
}
```
**Поведение:** Возвращается пустой массив `[]` (без ошибки в консоли)

### No Cosmos container configured
```json
{
  "status": {
    "code": 400,
    "message": "No Cosmos container configured for TxnType: inv"
  }
}
```
**Поведение:** Возвращается пустой массив `[]` (без ошибки в консоли)

### CORS Error
```
TypeError: Failed to fetch
```
**Поведение:** Выбрасывается исключение `CORS_BLOCKED`

### 403 Forbidden
```
HTTP 403 Forbidden
```
**Поведение:** Обрабатывается как критическая ошибка (не CORS)

## Функции API

### getTransactionsByType()
```typescript
async function getTransactionsByType(
  txnType: string,
  continuationToken?: string,
  tenantId?: string
): Promise<PaginatedTransactionsResponse>
```

**Параметры:**
- `txnType` - Тип транзакции (Inv, Loc, Keyi, etc.)
- `continuationToken` - Токен для следующей страницы (опционально)
- `tenantId` - ID тенанта для фильтрации (опционально)

**Возвращает:**
```typescript
{
  transactions: Transaction[];
  continuationToken: string | null;
  hasMore: boolean;
  totalCount?: number;
}
```

**Пример использования:**
```typescript
// Первая страница
const result = await getTransactionsByType('Inv', undefined, '1018-tenant');
console.log('Transactions:', result.transactions.length);
console.log('Total count:', result.totalCount);
console.log('Has more:', result.hasMore);

// Следующая страница
if (result.hasMore) {
  const nextPage = await getTransactionsByType('Inv', result.continuationToken, '1018-tenant');
}
```

## Логирование

### Успешный запрос
```
🌐 Data Plane API Request (v1.1):
  URL: https://.../1.1/txns?filters=%7B%22TxnType%22%3A%22inv%22%7D
  Filters: { TxnType: 'inv' }
  TenantId: 1018-tenant

📦 API Response [Inv]:
  status: 200
  hasData: true
  hasTxns: true
  txnsCount: 50
  totalCount: 1523
```

### Unsupported type (silent)
```
(no console output - returns empty array)
```

### CORS error
```
(throws CORS_BLOCKED exception)
```

## Тестирование

### 1. Проверка endpoint для Inv
```bash
curl -X GET "https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.1/txns?filters=%7B%22TxnType%22%3A%22inv%22%7D" \
  -H "X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855" \
  -H "Content-Type: application/json"
```

### 2. Проверка в приложении
```javascript
// 1. Открыть Data Plane
// 2. Нажать на "Inv (0)" в Transaction Types
// 3. Должны загрузиться транзакции из /1.1/txns?filters={"TxnType":"inv"}
// 4. Проверить консоль на наличие логов запроса
```

### 3. Проверка фильтрации по тенанту
```javascript
// 1. Выбрать тенант "1018-tenant"
// 2. Нажать на "Inv"
// 3. URL должен содержать: filters={"TxnType":"inv","TenantId":"1018-tenant"}
```

### 4. Проверка пагинации
```javascript
// 1. Загрузить большой тип (например, QuoteDetail)
// 2. Прокрутить до конца списка
// 3. Должна загрузиться следующая страница с continuationToken
```

## Mapping типов → endpoints

| UI Type | API TxnType | Primary Key Field | Endpoint |
|---------|-------------|-------------------|----------|
| Keyi | keyi | invid | /1.1/txns?filters={"TxnType":"keyi"} |
| Inv | inv | invid | /1.1/txns?filters={"TxnType":"inv"} |
| Inv1 | inv1 | invid | /1.1/txns?filters={"TxnType":"inv1"} |
| Inv2 | inv2 | invid | /1.1/txns?filters={"TxnType":"inv2"} |
| Inv3 | inv3 | invid | /1.1/txns?filters={"TxnType":"inv3"} |
| Invap | invap | invid | /1.1/txns?filters={"TxnType":"invap"} |
| Invdes | invdes | invid | /1.1/txns?filters={"TxnType":"invdes"} |
| Invloc | invloc | invid | /1.1/txns?filters={"TxnType":"invloc"} |
| Loc1 | loc1 | loccd/Loccd | /1.1/txns?filters={"TxnType":"loc1"} |
| Loc | loc | loccd/Loccd | /1.1/txns?filters={"TxnType":"loc"} |
| Stocode | stocode | st/St | /1.1/txns?filters={"TxnType":"stocode"} |

## Файлы

**Изменен:** `/lib/api.ts`
- Функция `getTransactionsByType()` (строки 776-986)
- Логика определения Entity ID (строки 924-942)
- Добавлена поддержка полей:
  - `invid` - для Inventory типов
  - `loccd` / `Loccd` - для Location типов
  - `st` / `St` - для Store Code типа

## Совместимость

✅ **API v1.1** - `/1.1/txns` endpoint  
✅ **Filters parameter** - `filters={"TxnType":"...","TenantId":"..."}`  
✅ **Continuation Token** - пагинация больших результатов  
✅ **TxnTotalCount** - отображение общего количества  
✅ **Мультитенантность** - фильтрация по TenantId  
✅ **CORS handling** - корректная обработка CORS ошибок  
✅ **Error handling** - silent fallback для unsupported types  

## Статус
🟢 **Готово** - Полная интеграция с BFS Online API v1.1 endpoints

## См. также
- `/NEW_TRANSACTION_TYPES_ADDED_RU.md` - Новые типы транзакций
- `/BFS_ONLINE_INV_TEMPLATE_ADDED_RU.md` - Шаблон Inv
- `/APICURIO_403_HANDLING_RU.md` - Обработка ошибок Apicurio
