# Azure AD Role Processing Flow

## Visual Flow for Portal.Developer

```
┌─────────────────────────────────────────────────────────────┐
│                    /.auth/me Response                        │
│                                                               │
│  {                                                            │
│    "user_claims": [                                           │
│      {"typ": "roles", "val": "Portal.Developer"},  ◄─────┐   │
│      {"typ": "name", "val": "Boris Belov"},               │   │
│      {"typ": "emailaddress", "val": "Boris@..."}          │   │
│    ]                                                       │   │
│  }                                                         │   │
└────────────────────────────────────────────────────────────┘   │
                            │                                    │
                            ▼                                    │
┌─────────────────────────────────────────────────────────────┐   │
│          extractUserInfo(authData)                           │   │
│          /lib/azure-auth.ts                                  │   │
│                                                               │   │
│  Step 1: Find role claims                                    │   │
│  ────────────────────────                                    │   │
│  const roleClaims = claims.filter(c =>                       │   │
│    c.typ === 'roles' ||                     ◄────────────────┘
│    c.typ === 'http://.../role'                               │
│  );                                                           │
│                                                               │
│  Found: [{"typ": "roles", "val": "Portal.Developer"}]  ✅    │
│                                                               │
│  Step 2: Extract role values                                 │
│  ──────────────────────────                                  │
│  roleClaims.forEach(claim => {                               │
│    const roles = claim.val.split(',');                       │
│    azureRoles.push(...roles);                                │
│  });                                                          │
│                                                               │
│  Result: azureRoles = ["Portal.Developer"]  ✅               │
└───────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│           parseAzureRole(azureRoles)                         │
│                                                               │
│  if (azureRoles.includes('Portal.SuperUser'))                │
│    return 'superuser';                              ❌       │
│                                                               │
│  if (azureRoles.includes('Portal.ViewOnlySuperUser'))        │
│    return 'viewonlysuperuser';                      ❌       │
│                                                               │
│  if (azureRoles.includes('Portal.Admin'))                    │
│    return 'admin';                                  ❌       │
│                                                               │
│  if (azureRoles.includes('Portal.Developer'))                │
│    return 'developer';                              ✅ MATCH │
│                                                               │
│  Result: role = "developer"                                  │
└───────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│         parseAzureAccess(azureRoles)                         │
│                                                               │
│  if (includes('Portal.SuperUser') ||                         │
│      includes('Portal.ViewOnlySuperUser'))                   │
│    return 'All';                                    ❌       │
│                                                               │
│  if (includes('Portal.Admin') ||                             │
│      includes('Portal.Developer') ||                         │
│      includes('Portal.Viewer'))                              │
│    return ['Transactions', 'Data Plane'];           ✅ MATCH │
│                                                               │
│  Result: access = ["Transactions", "Data Plane"]             │
└───────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                    Final User Object                         │
│                                                               │
│  {                                                            │
│    email: "Boris.Belov@myparadigm.com",                      │
│    name: "Boris Belov (contractor)",                         │
│    role: "developer",                     ◄── Internal role  │
│    azureRole: "Portal.Developer",         ◄── Display name   │
│    azureRoles: ["Portal.Developer"],      ◄── All roles      │
│    access: ["Transactions", "Data Plane"], ◄── Tab access    │
│    userId: "Boris.Belov@myparadigm.com"                      │
│  }                                                            │
└───────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                   UI Authorization Check                     │
│                   (in components)                            │
│                                                               │
│  hasAccess(section: string) {                                │
│    if (access === 'All') return true;                        │
│    if (Array.isArray(access))                                │
│      return access.includes(section);                        │
│  }                                                            │
│                                                               │
│  Tenants:           hasAccess('Tenants')                     │
│                     access.includes('Tenants')               │
│                     false  ✅ Correctly blocked              │
│                                                               │
│  Transactions:      hasAccess('Transactions')                │
│                     access.includes('Transactions')          │
│                     true   ✅ Correctly allowed              │
│                                                               │
│  Data Plane:        hasAccess('Data Plane')                  │
│                     access.includes('Data Plane')            │
│                     true   ✅ Correctly allowed              │
└───────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                   UI Display                                 │
│                                                               │
│  User Menu:         Developer (Portal.Developer)             │
│                     └─────┘   └──────────────────┘           │
│                      Label    Azure Role (gray)              │
│                                                               │
│  Profile Dialog:    Developer (Portal.Developer)             │
│                                                               │
│  Visible Tabs:      [Transactions] [Data Source]             │
│                     [Data Plane]                             │
│                                                               │
│  Hidden Tabs:       [Tenants] - SuperUser only               │
└───────────────────────────────────────────────────────────────┘
```

## Role Claim Type Support

The system supports multiple claim type formats:

```typescript
✅ "roles"                                              // Modern Azure AD
✅ "http://schemas.microsoft.com/ws/2008/06/identity/claims/role"  // Legacy format
```

Your JSON uses: `"roles"` ✅ **Supported!**

## Multiple Roles Support

The system can handle:
- Single role: `{"typ": "roles", "val": "Portal.Developer"}`
- Multiple roles (comma-separated): `{"typ": "roles", "val": "Portal.Developer,Portal.Viewer"}`
- Multiple role claims: Two separate claims with type "roles"

## Priority Order

When multiple roles are assigned, the system picks the highest privilege:

```
1. Portal.SuperUser           (highest)
2. Portal.ViewOnlySuperUser
3. Portal.Admin
4. Portal.Developer
5. Portal.Viewer              (lowest)
```

## Summary for Your Case

| Step | Input | Output | Status |
|------|-------|--------|--------|
| 1. Extract claim | `{"typ": "roles", "val": "Portal.Developer"}` | Found claim | ✅ |
| 2. Extract value | `"Portal.Developer"` | Added to array | ✅ |
| 3. Map to internal | `["Portal.Developer"]` | `"developer"` | ✅ |
| 4. Determine access | `["Portal.Developer"]` | `["Transactions", "Data Plane"]` | ✅ |
| 5. Block Tenants | Check access | `false` | ✅ |
| 6. Allow Transactions | Check access | `true` | ✅ |
| 7. Display format | `"developer"` + `"Portal.Developer"` | "Developer (Portal.Developer)" | ✅ |

## 🎉 Conclusion

**Everything works perfectly!** Your Azure AD configuration with `Portal.Developer` role will be correctly processed and provide the appropriate access level.
