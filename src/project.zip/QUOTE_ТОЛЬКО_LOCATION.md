# ✅ Quote: Только location-поля по умолчанию

## 🎯 Что изменилось

Для **Quote** по умолчанию теперь показываются **только 3 колонки**:
- ✅ location Address
- ✅ location Code  
- ✅ location Name

**ID и Created убраны** (но доступны в Column Selector)

---

## 📊 Визуально

### Было (5 колонок):
```
┌──────┬─────────┬──────────┬──────┬───────┬────────┐
│ ID   │ Created │ loc Addr │ Code │ Name  │ Actions│
├──────┼─────────┼──────────┼──────┼───────┼────────┤
│ Q:123│ 11/3/25 │ 123 Main │ LOC01│ Down  │ View   │
└──────┴─────────┴──────────┴──────┴───────┴────────┘
  ↑        ↑
Убрали  Убрали
```

### Стало (3 колонки):
```
┌──────────────────┬──────────┬──────────────┬─────────┐
│ location Address │ loc Code │ location Name│ Actions │
├──────────────────┼──────────┼──────────────┼─────────┤
│ 123 Main St      │ LOC001   │ Downtown     │ View    │
└──────────────────┴──────────┴──────────────┴─────────┘
         ↑              ↑            ↑
    Больше места   Фокус на     Всё нужное
                    location      видно
```

---

## ✨ Зачем?

### 1. Чище
```
✅ 3 колонки вместо 5
✅ Меньше информационного шума
✅ Фокус на главном
```

### 2. Удобнее
```
✅ Больше места для адресов
✅ Легче читать
✅ Меньше прокрутки
```

### 3. Логичнее
```
✅ Quote = location-данные
✅ ID есть в Badge слева
✅ Created нужна редко
```

---

## 🔍 Где ID и Created?

### ID всегда видно:
```
┌─────────────┬──────────────┐
│ Quote:12918 │ loc Address  │  ← ID здесь
│ Quote:12917 │ 123 Main St  │
└─────────────┴──────────────┘
```

### Created можно включить:
```
1. Нажать "Columns"
2. Включить "Created"
3. Apply
4. ✅ Видно в таблице
```

---

## 🎬 Примеры

### Просто посмотреть Quote:
```
Data Plane → Quote
Видишь:
- location Address: 123 Main St
- location Code: LOC001
- location Name: Downtown Project

✅ Всё понятно без ID и даты
```

### Нужен ID:
```
Columns → включить "ID"
Теперь видишь:
- ID: Quote:12918
- location Address: 123 Main St
- location Code: LOC001
- location Name: Downtown

✅ ID добавлен
```

### Анализ по датам:
```
Columns → включить "Created"
Теперь видишь:
- Created: 10/31/2025
- location Address: 123 Main St
- location Code: LOC001

✅ Можно фильтровать по датам
```

---

## ✅ Быстрая проверка

```
□ Открыл Data Plane
□ Выбрал Quote
□ Вижу 3 колонки:
  □ location Address ✓
  □ location Code ✓
  □ location Name ✓
□ НЕ вижу:
  □ ID (но есть в Badge)
  □ Created
□ Открыл Columns
□ Включил "ID" → появился
□ Включил "Created" → появился
□ Reset → вернулись 3 колонки
```

---

## 💡 Как вернуть ID и Created

### Временно (на сессию):
```
1. Columns → включить "ID"
2. Columns → включить "Created"
3. Apply
✅ Видны до обновления страницы
```

### Постоянно:
```
1. Columns → включить "ID" и "Created"
2. Apply
✅ Настройки сохранятся в браузере
```

### Сбросить:
```
Columns → Reset to Default
✅ Вернутся 3 location-колонки
```

---

## 📁 Что изменилось в коде

**Файл:** `/components/TransactionsView.tsx`

**Строки 65-66:**
```typescript
// Было:
{ key: 'TxnId', label: 'ID', enabled: true, locked: true },
{ key: 'CreateTime', label: 'Created', enabled: true },

// Стало:
{ key: 'TxnId', label: 'ID', enabled: false, locked: true },
{ key: 'CreateTime', label: 'Created', enabled: false },
```

**Версия:** 5 → 6 (сброс старых настроек)

---

## 🎯 Итого

### Изменения:
- ✅ ID: enabled true → **false**
- ✅ Created: enabled true → **false**
- ✅ location поля: **остались** enabled true

### Результат:
- ✅ 3 колонки вместо 5
- ✅ Фокус на location-данных
- ✅ Чище и понятнее

### Доступно:
- ✅ ID и Created в Column Selector
- ✅ Можно включить когда нужно
- ✅ Настройки сохраняются

---

**Статус:** ✅ Готово  
**Дата:** 3 ноября 2025

Теперь Quote показывает **только location**! 🎯
