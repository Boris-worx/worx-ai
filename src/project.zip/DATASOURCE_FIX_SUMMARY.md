# Data Source Onboarding - Исправления и тестирование

## Выполненные исправления

### 1. Замена прямых обращений к полям на вспомогательные функции
В компоненте `DataSourcesView.tsx` все прямые обращения к полям `DataSourceId` и `DataSourceName` заменены на вызовы вспомогательных функций:
- `getDataSourceId(dataSource)` - работает с обоими вариантами: `DatasourceId` и `DataSourceId`
- `getDataSourceName(dataSource)` - работает с обоими вариантами: `DatasourceName` и `DataSourceName`

Исправленные места:
- ✅ Успешное создание: toast сообщение
- ✅ Удаление: получение ID и имени для удаления
- ✅ Редактирование: инициализация формы и обновление списка
- ✅ Диалог удаления: отображение имени в подтверждении

### 2. Обновление конфигурации колонок
Названия колонок по умолчанию обновлены для соответствия API:
- `DataSourceId` → `DatasourceId`
- `DataSourceName` → `DatasourceName`

### 3. Исправление интеграции с DataTable
Создана функция преобразования `ColumnConfig` → `Column` с правильной логикой render:
- Использует вспомогательные функции для ID и Name
- Применяет `formatCellValue` для остальных полей
- Правильно передает колонки в DataTable

### 4. Добавлены отладочные логи

#### В `getAllDataSources()`:
```javascript
console.log('📦 Raw response (first 1000 chars):', responseText.substring(0, 1000));
console.log('📋 Response structure:', {
  isArray: Array.isArray(data),
  keys: Object.keys(data),
  hasData: !!data.data,
  dataKeys: data.data ? Object.keys(data.data) : null,
});
```

Добавлена поддержка формата BFS API:
```javascript
else if (data.status && data.data && Array.isArray(data.data.DataSources)) {
  console.log('✅ Format: status.data.DataSources (BFS API format)');
  dataSources = data.data.DataSources;
}
```

#### В `createDataSource()`:
```javascript
console.log('📤 POST Data Source Request:');
console.log('  URL:', `${API_BASE_URL}/datasources`);
console.log('  Body:', JSON.stringify(requestBody, null, 2));
console.log('📥 Response status:', response.status, response.statusText);
console.log('✅ Success response:', responseText);
```

## Структура API запросов

### POST /1.0/datasources
```json
{
  "DatasourceId": "ds-1730000000000",
  "DatasourceName": "My Data Source",
  "Type": "SQL",
  "ConnectionString": "Server=...",
  "Description": "Description text"
}
```

### GET /1.0/datasources
Ожидаемые форматы ответа (в порядке проверки):
1. `Array<DataSource>` - прямой массив
2. `{ data: { datasources: Array<DataSource> } }`
3. `{ data: Array<DataSource> }`
4. `{ datasources: Array<DataSource> }`
5. `{ value: Array<DataSource> }`
6. `{ status: {...}, data: { DataSources: Array<DataSource> } }` - формат BFS API (новый)

## Тестирование

### 1. Проверка загрузки данных
1. Открыть DevTools → Console
2. Перейти на вкладку "Data Source Onboarding"
3. Проверить логи:
   ```
   📦 Raw response (first 1000 chars): ...
   📋 Response structure: { isArray: ..., keys: [...], ... }
   ✅ Format: ... (какой формат распознан)
   Loaded X data source(s) from API
   First data source: { ... }
   ```

### 2. Проверка создания data source
1. Нажать "Add Data Source"
2. Заполнить форму:
   - Data Source Name: "Test Source" (обязательно)
   - Type: "SQL" (опционально)
   - Connection String: "..." (опционально)
   - Description: "..." (опционально)
3. Нажать "Create"
4. Проверить логи в консоли:
   ```
   📤 POST Data Source Request:
     URL: https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/datasources
     Body: { "DatasourceId": "ds-...", "DatasourceName": "Test Source", ... }
   📥 Response status: 200 OK (или ошибка)
   ✅ Success response: { ... }
   Created data source: { ... }
   ```

### 3. Проверка отображения в таблице
После создания проверить, что:
- ✅ Data Source ID отображается корректно
- ✅ Name отображается корректно
- ✅ Type, Status, CreateTime отображаются
- ✅ Кнопки View/Edit/Delete работают

### 4. Проверка редактирования
1. Нажать Edit на любом data source
2. Изменить Name
3. Сохранить
4. Проверить, что изменения отображаются в таблице

### 5. Проверка удаления
1. Нажать Delete
2. Подтвердить удаление
3. Проверить, что data source удален из списка

## Возможные проблемы

### Endpoint не найден
**Симптом**: `404 Not Found` при запросе к `/1.0/datasources`

**Причина**: Endpoint может не существовать в BFS API

**Решение**: 
1. Проверить Postman коллекцию - возможно endpoint находится по другому пути
2. Связаться с командой API для подтверждения endpoint
3. Возможно нужен другой путь, например:
   - `/1.0/tenants/{tenantId}/datasources`
   - `/1.0/config/datasources`
   - или это часть transaction types через `/1.0/txns?TxnType=DataSource`

### Пустые колонки в таблице
**Симптом**: Таблица отображается, но колонки ID и Name пустые

**Причина**: API возвращает поля с другой капитализацией

**Решение**: Уже исправлено вспомогательными функциями. Проверить логи:
```javascript
console.log('First data source:', dataSources[0]);
```
И посмотреть какие точно поля приходят от API.

### Ошибка "Missing DatasourceName"
**Симптом**: При создании data source API возвращает ошибку "Missing DatasourceName"

**Причина**: Уже исправлено - API функции используют правильную капитализацию `DatasourceName`

**Проверка**: Посмотреть в логах консоли тело POST запроса - должно быть `DatasourceName`, а не `DataSourceName`

## Следующие шаги

1. ✅ Открыть приложение и перейти на вкладку "Data Source Onboarding"
2. ✅ Проверить логи в консоли для понимания формата ответа API
3. ✅ Попробовать создать data source
4. ✅ Проверить, что данные корректно отображаются в таблице
5. ⚠️ Если endpoint не работает - проверить Postman коллекцию и документацию API
