# Data Capture Specifications - Requirements Check ✅

## User Story Requirements

### What is a Data Capture Specification?
> "A Data Capture Specification defines the data stored in Cosmos for a specific table in a Data Source database"

### Required Fields:
The Data Capture Specification must include:

1. ✅ **Tenant ID** - Associates spec with tenant
2. ✅ **Version ID** - Version of the specification
3. ✅ **Data Source ID** - Links to the Data Source
4. ✅ **Data Capture Specification Name** - Used with Tenant name to specify Cosmos container
5. ✅ **List of required fields** - Which fields are mandatory
6. ✅ **JSON structure of the data payload** - Full schema definition

---

## Current Implementation Analysis

### Current ModelSchema Interface
```typescript
// /lib/api.ts (line 43-57)
export interface ModelSchema {
  id: string;                // Unique identifier
  model: string;             // ✅ #4 - Specification Name
  version: number;           // ✅ #2 - Version ID (integer)
  state: string;             // Bonus: active/draft/archived
  semver: string;            // ✅ #2 - Version ID (semver format)
  jsonSchema: any;           // ✅ #6 - JSON Schema object
  CreateTime: string;
  UpdateTime: string;
  _etag?: string;
  _rid?: string;
  _ts?: number;
  _self?: string;
  _attachments?: string;
  // ❌ Missing: TenantId       // #1 - Tenant ID
  // ❌ Missing: DataSourceId   // #3 - Data Source ID
}
```

### JSON Schema Structure (Template)
```typescript
// /components/ModelSchemaView.tsx (line 48)
const defaultJsonSchema = {
  "$id": "",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "",
  "type": "object",
  "required": [],              // ✅ #5 - List of required fields
  "properties": {}             // ✅ #6 - Data payload structure
}
```

### Example: Customer Schema
```json
{
  "id": "ModelSchema-Customer-1",
  "model": "Customer",
  "version": 1,
  "semver": "1.0.0",
  "state": "active",
  "jsonSchema": {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "title": "Customer",
    "type": "object",
    "required": ["CustomerId", "Name"],  // ✅ Required fields
    "properties": {                       // ✅ Data structure
      "CustomerId": { "type": "integer" },
      "Name": { "type": "string" },
      "Email": { "type": "string" }
    }
  }
  // ❌ Missing: "TenantId": "BFS"
  // ❌ Missing: "DataSourceId": "Online-Informix"
}
```

---

## Requirement Compliance Check

| # | Requirement | Current Implementation | Status | Details |
|---|-------------|------------------------|--------|---------|
| 1 | **Tenant ID** | ❌ Not present | 🔴 **MISSING** | No TenantId field |
| 2 | **Version ID** | ✅ `version` + `semver` | ✅ **COMPLETE** | Double tracking (int + semver) |
| 3 | **Data Source ID** | ❌ Not present | 🔴 **MISSING** | No DataSourceId field |
| 4 | **Spec Name** | ✅ `model` field | ✅ **COMPLETE** | Used as spec name |
| 5 | **Required Fields** | ✅ `jsonSchema.required` | ✅ **COMPLETE** | Array of required field names |
| 6 | **JSON Structure** | ✅ `jsonSchema.properties` | ✅ **COMPLETE** | Full JSON Schema draft-2020-12 |

**Overall Compliance:** 🟡 **4/6 (67%)**

---

## Detailed Analysis

### ✅ What's Working (4/6 Requirements)

#### ✅ Requirement #2: Version ID
**Implementation:** Excellent - Double tracking
```typescript
version: 1           // Integer version for simple counting
semver: "1.0.0"     // Semantic version for proper versioning
```

**Why this is good:**
- `version` allows simple incrementing (1, 2, 3...)
- `semver` allows proper semantic versioning (1.0.0 → 1.1.0 → 2.0.0)
- Can track breaking changes vs minor updates

**Used in UI:**
- Version column shows integer
- Semver column shows full version
- State column shows if active/draft/archived

---

#### ✅ Requirement #4: Specification Name
**Implementation:** Perfect
```typescript
model: "Customer"    // Specification name = table name
```

**How it's used:**
- Identifies which table this spec defines
- Used in UI as primary identifier
- User Story says: "used with Tenant name to specify Cosmos container"

**Current Usage:**
```typescript
// Container naming would be:
const containerName = `${tenantName}-${model}`;
// Example: "BFS-Customer", "Global-Quotes"
```

---

#### ✅ Requirement #5: List of Required Fields
**Implementation:** Standard JSON Schema
```typescript
jsonSchema: {
  "required": ["CustomerId", "Name", "Email"]
}
```

**How it's accessed:**
```typescript
// /components/ModelSchemaView.tsx (line 168-170)
const getRequiredFields = (jsonSchema: any): string[] => {
  return jsonSchema?.required || [];
};
```

**Displayed in UI:**
- Detail view shows required fields as badges
- Helps users understand mandatory fields
- Used for validation

---

#### ✅ Requirement #6: JSON Structure of Data Payload
**Implementation:** Full JSON Schema draft-2020-12
```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "Customer",
  "type": "object",
  "properties": {
    "CustomerId": {
      "type": "integer",
      "description": "Unique customer identifier"
    },
    "Name": {
      "type": "string",
      "minLength": 1
    },
    "Email": {
      "type": "string",
      "format": "email"
    }
  }
}
```

**Features:**
- ✅ Supports all JSON Schema types
- ✅ Validation rules (minLength, format, etc.)
- ✅ Nested objects
- ✅ Arrays
- ✅ References ($ref)

**UI Features:**
- Pretty-printed JSON viewer
- Syntax highlighting
- Collapsible sections
- Edit with validation

---

### ❌ What's Missing (2/6 Requirements)

#### 🔴 Requirement #1: Tenant ID (CRITICAL)

**Current State:**
```typescript
export interface ModelSchema {
  // ... all fields
  // ❌ Missing: TenantId?: string;
}
```

**Why this is CRITICAL:**
- Can't associate spec with tenant
- Can't filter specs by tenant
- Can't enforce tenant isolation
- User Story explicitly requires: "used with Tenant name to specify Cosmos container"

**Impact on User Story:**
```
Cannot distinguish:
├── Global Tenant
│   ├── Bidtools → Quotes spec
│   └── Databricks → Design spec
└── BFS Tenant
    ├── Online → Customer spec
    └── SAP → Order spec
```

**Fix Required:**
```typescript
export interface ModelSchema {
  id: string;
  model: string;
  version: number;
  state: string;
  semver: string;
  TenantId?: string;          // ✅ ADD THIS
  jsonSchema: any;
  CreateTime: string;
  UpdateTime: string;
  _etag?: string;
}
```

**API Changes:**
```typescript
// Filter by tenant
const specs = await getAllModelSchemas(activeTenantId);

// API call:
// GET /1.0/txns?TxnType=ModelSchema&TenantId=BFS
```

**UI Changes:**
```typescript
// Add Tenant column to table
{ key: 'TenantId', label: 'Tenant', enabled: true }

// Display as badge
<Badge variant={!value ? 'secondary' : 'default'}>
  {value || 'Global'}
</Badge>

// Filter on tenant change
useEffect(() => {
  if (activeTenantId) {
    loadSchemasForTenant(activeTenantId);
  }
}, [activeTenantId]);
```

**Cosmos Container Naming:**
```typescript
// As per User Story requirement:
const containerName = `${tenantName}-${model}`;

// Examples:
// - "Global-Quotes"
// - "BFS-Customer"
// - "Meritage-Order"
```

---

#### 🔴 Requirement #3: Data Source ID (CRITICAL)

**Current State:**
```typescript
export interface ModelSchema {
  // ... all fields
  // ❌ Missing: DataSourceId?: string;
}
```

**Why this is CRITICAL:**
- Can't link spec to its Data Source
- Can't show specs under Data Source in UI
- Can't filter "Bidtools specs" vs "Online specs"
- User Story says: "Each Data Source has Data Capture Specifications"

**Impact on User Story:**
```
Current: Specs are orphaned
ModelSchema
├── Customer (which Data Source?)
├── Quotes (which Data Source?)
└── Order (which Data Source?)

Desired: Specs linked to Data Sources
Bidtools (Data Source)
├── Quotes (spec)
├── QuoteDetails (spec)
└── QuotePacks (spec)

Online (Data Source)
├── Customer (spec)
└── Order (spec)
```

**Fix Required:**
```typescript
export interface ModelSchema {
  id: string;
  model: string;
  version: number;
  state: string;
  semver: string;
  TenantId?: string;
  DataSourceId?: string;      // ✅ ADD THIS - Links to DataSource
  jsonSchema: any;
  CreateTime: string;
  UpdateTime: string;
  _etag?: string;
}
```

**API Changes:**
```typescript
// Filter by Data Source
const specs = await getAllModelSchemas(tenantId, dataSourceId);

// API call:
// GET /1.0/txns?TxnType=ModelSchema&DataSourceId=Bidtools
```

**UI Changes in DataSourcesView:**
```typescript
// When expanding Data Source row
const loadSpecsForDataSource = async (dataSourceId: string) => {
  const specs = await getAllModelSchemas(activeTenantId, dataSourceId);
  setDataSourceSpecs(prev => ({ ...prev, [dataSourceId]: specs }));
};

// Display real specs instead of mock
{specs.map(spec => (
  <div key={spec.id}>
    <span>{spec.model}</span>
    <Badge>v{spec.semver}</Badge>
    <Badge>{spec.state}</Badge>
  </div>
))}
```

**UI Changes in ModelSchemaView:**
```typescript
// Add DataSource column
{ key: 'DataSourceId', label: 'Data Source', enabled: true }

// Display DataSource name
const dataSource = dataSources.find(ds => ds.DataSourceId === value);
return dataSource?.DataSourceName || value || '-';
```

---

## Implementation Priority

### 🔴 Phase 1: Add TenantId (2 hours) - CRITICAL

**Why Critical:**
- Required for multi-tenant deployment
- Enables tenant isolation
- Allows proper filtering
- User Story explicitly requires it

**Changes:**
1. Update `ModelSchema` interface
2. Update API functions to pass `TenantId`
3. Add Tenant column to table
4. Filter by active tenant
5. Display tenant badge

**Testing:**
- Create spec in Global tenant → TenantId = "global" or null
- Create spec in BFS tenant → TenantId = "BFS"
- Switch tenants → see only relevant specs
- Protected types (Customer, Location) respect tenant

---

### 🔴 Phase 2: Add DataSourceId (3 hours) - CRITICAL

**Why Critical:**
- Links specs to Data Sources
- Enables hierarchical view
- Replaces mock data with real data
- Core requirement of User Story

**Changes:**
1. Update `ModelSchema` interface
2. Update API functions to filter by `DataSourceId`
3. Load real specs when expanding Data Source
4. Add DataSource column to ModelSchemaView
5. Pre-fill DataSourceId when creating from Data Source context

**Testing:**
- Expand Bidtools → see real Quotes, QuoteDetails, QuotePacks specs
- Expand Online → see real Customer, Order specs
- Create spec from Data Source → DataSourceId auto-filled
- Edit spec → DataSourceId preserved

---

### 🟢 Phase 3: UI Polish (1 hour) - OPTIONAL

**Nice to have:**
- Better visual hierarchy in expandable rows
- Inline spec creation from Data Source view
- DataSource name display in ModelSchemaView
- Cosmos container name preview

---

## Example: Complete Data Capture Specification

### Before (Current):
```json
{
  "id": "ModelSchema-Customer-1",
  "model": "Customer",
  "version": 1,
  "semver": "1.0.0",
  "state": "active",
  "jsonSchema": {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "title": "Customer",
    "type": "object",
    "required": ["CustomerId", "Name"],
    "properties": {
      "CustomerId": { "type": "integer" },
      "Name": { "type": "string" },
      "Email": { "type": "string", "format": "email" }
    }
  },
  "CreateTime": "2025-11-04T10:00:00Z",
  "UpdateTime": "2025-11-04T10:00:00Z",
  "_etag": "\"abc123\""
}
```

### After (With All Requirements):
```json
{
  "id": "ModelSchema-Customer-1",
  "model": "Customer",
  "version": 1,
  "semver": "1.0.0",
  "state": "active",
  "TenantId": "BFS",                        // ✅ #1 - Tenant ID
  "DataSourceId": "Online-Informix",        // ✅ #3 - Data Source ID
  "jsonSchema": {                            // ✅ #6 - JSON Structure
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "title": "Customer",
    "type": "object",
    "required": ["CustomerId", "Name"],     // ✅ #5 - Required Fields
    "properties": {
      "CustomerId": { "type": "integer" },
      "Name": { "type": "string" },
      "Email": { "type": "string", "format": "email" }
    }
  },
  "CreateTime": "2025-11-04T10:00:00Z",
  "UpdateTime": "2025-11-04T10:00:00Z",
  "_etag": "\"abc123\""
}

// Cosmos Container Name:
// "BFS-Customer" = `${TenantId}-${model}`
```

---

## Cosmos Container Naming

### User Story Requirement:
> "Data Capture Specification Name used with Tenant name to specify Cosmos container"

### Implementation:
```typescript
// Container naming formula
const cosmosContainerName = `${TenantId}-${model}`;

// Examples:
// Global tenant specs
"Global-Quotes"           // Bidtools Quotes table
"Global-QuoteDetails"     // Bidtools QuoteDetails table
"Global-QuotePacks"       // Bidtools QuotePacks table
"Global-Design"           // Databricks Design table

// BFS tenant specs
"BFS-Customer"            // Online Customer table
"BFS-Order"               // Online Order table
"BFS-Trend"               // Trend data
"BFS-SAP"                 // SAP data

// Meritage tenant specs
"Meritage-Project"
"Meritage-Estimate"
```

### Benefits:
- ✅ Clear separation by tenant
- ✅ Easy to identify which tenant owns data
- ✅ Supports multi-tenant Cosmos deployment
- ✅ Simple naming convention

---

## Visual Comparison

### Current Implementation:
```
Transaction Onboarding Tab (ModelSchemaView)
┌──────────────────────────────────────────┐
│ [+ Add Data Capture Spec] [Refresh]     │
│                                          │
│ ┌────────────────────────────────────┐  │
│ │ Model    | Version | State        │  │
│ ├────────────────────────────────────┤  │
│ │ Customer | 1       | active       │  │  ❌ No Tenant
│ │ Quotes   | 1       | active       │  │  ❌ No DataSource
│ │ Order    | 1       | active       │  │  ❌ Can't filter
│ └────────────────────────────────────┘  │
└──────────────────────────────────────────┘
```

### After Fixes:
```
🏢 BFS Tenant

Transaction Onboarding Tab (ModelSchemaView)
┌────────────────────────────────────────────────────────┐
│ [+ Add Data Capture Spec] [Refresh]                   │
│                                                        │
│ ┌──────────────────────────────────────────────────┐  │
│ │ Model    | DS         | Tenant | Ver | State    │  │
│ ├──────────────────────────────────────────────────┤  │
│ �� Customer | Online     | BFS    | 1   | active   │  │ ✅
│ │ Order    | Online     | BFS    | 1   | active   │  │ ✅
│ └──────────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────┘

🏢 Global Tenant

┌────────────────────────────────────────────────────────┐
│ ┌──────────────────────────────────────────────────┐  │
│ │ Model        | DS         | Tenant | Ver | State │  │
│ ├──────────────────────────────────────────────────┤  │
│ │ Quotes       | Bidtools   | Global | 1   | active│  │ ✅
│ │ QuoteDetails | Bidtools   | Global | 1   | active│  │ ✅
│ │ QuotePacks   | Bidtools   | Global | 1   | active│  │ ✅
│ │ Design       | Databricks | Global | 1   | active│  │ ✅
│ └──────────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────┘

Data Source Onboarding Tab
┌────────────────────────────────────────────────────────┐
│ Name      | Type       | Tenant | Status              │
├────────────────────────────────────────────────────────┤
│ Bidtools  | SQL Server | Global | Active              │
│  └─ Expand to see specs:                              │
│     ├── Quotes (v1.0.0) active       ✅ Real from API │
│     ├── QuoteDetails (v1.0.0) active ✅ Real from API │
│     └── QuotePacks (v1.0.0) active   ✅ Real from API │
└────────────────────────────────────────────────────────┘
```

---

## Summary

### ✅ What Meets Requirements (4/6)

1. ✅ **Version ID** - Excellent implementation with both integer and semver
2. ✅ **Spec Name** - Perfect, uses `model` field
3. ✅ **Required Fields** - Standard JSON Schema `required` array
4. ✅ **JSON Structure** - Full JSON Schema draft-2020-12 support

**Strengths:**
- JSON Schema implementation is perfect
- Version tracking is better than required (dual tracking)
- UI for viewing/editing schemas is excellent
- Protected types feature is bonus

---

### ❌ What's Missing (2/6)

1. ❌ **Tenant ID** - No field in interface
2. ❌ **Data Source ID** - No field in interface

**Impact:**
- Can't filter specs by tenant
- Can't associate spec with Data Source
- Can't show hierarchical view (DS → Specs)
- Can't construct Cosmos container names as required

---

### 🎯 Compliance Score

| Category | Score | Status |
|----------|-------|--------|
| **Required Fields Present** | 4/6 | 67% |
| **Required Fields Working** | 4/4 | 100% |
| **Missing Fields** | 0/2 | 0% |
| **Overall** | **67%** | 🟡 |

---

### 🚀 Action Plan

**To achieve 100% compliance:**

1. **Add TenantId field** (2 hours)
   - Update interface
   - Update API calls
   - Add UI column
   - Filter by tenant

2. **Add DataSourceId field** (3 hours)
   - Update interface
   - Update API calls
   - Link to Data Sources
   - Show hierarchical view

3. **Test thoroughly** (2 hours)
   - Tenant filtering
   - Data Source linking
   - Container naming
   - Cross-tab consistency

**Total Effort:** 7 hours  
**Result:** 100% User Story compliance ✅

---

## Files Created

- **[DATA_CAPTURE_SPEC_REQUIREMENTS_CHECK.md](./DATA_CAPTURE_SPEC_REQUIREMENTS_CHECK.md)** - This file
- **[DATA_SOURCES_USER_STORY_ANALYSIS.md](./DATA_SOURCES_USER_STORY_ANALYSIS.md)** - Full DS analysis
- **[DATA_SOURCES_ПРОВЕРКА.md](./DATA_SOURCES_ПРОВЕРКА.md)** - DS review (RU)
- **[DATA_SOURCES_QUICK_SUMMARY.md](./DATA_SOURCES_QUICK_SUMMARY.md)** - Quick summary

---

**Bottom Line:** Current implementation is 67% compliant. Adding TenantId and DataSourceId fields will achieve 100% compliance with User Story requirements. All other requirements are already met with excellent implementation quality! 🎯
