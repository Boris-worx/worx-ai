# Dialog Width Update - All Popups 75vw

## ✅ All Dialogs Updated to 75vw

All popup dialogs now use consistent width: **75% of viewport width** with minimum 500px.

---

## 🎯 Changes Made

### Width Formula:
```css
w-[75vw] min-w-[500px] max-w-[90vw]
```

**Breakdown:**
- `w-[75vw]` - Default width: 75% of viewport
- `min-w-[500px]` - Minimum width: 500px (for small screens)
- `max-w-[90vw]` - Maximum width: 90% (for very small screens)

---

## 📋 Updated Files

| File | Line | Old Width | New Width |
|------|------|-----------|-----------|
| TenantImportDialog.tsx | 161 | `w-[50vw]` | `w-[75vw]` |
| TenantDetail.tsx | 27 | `max-w-2xl` (672px) | `w-[75vw]` |
| TenantEditForm.tsx | 69 | *(none)* | `w-[75vw]` |
| TransactionDetail.tsx | 16 | `max-w-3xl` (768px) | `w-[75vw]` |
| TransactionForm.tsx | 96 | `max-w-2xl` (672px) | `w-[75vw]` |

---

## 📊 Width Comparison

### Before (Mixed Widths):
```
TenantImportDialog:   50vw (960px on 1920px screen)
TenantDetail:         672px (max-w-2xl)
TenantEditForm:       640px (default)
TransactionDetail:    768px (max-w-3xl)
TransactionForm:      672px (max-w-2xl)
```

### After (Consistent 75vw):
```
All Dialogs:          75vw (1440px on 1920px screen)
                      75vw (960px on 1280px screen)
                      500px on screens < 667px
```

---

## 🎨 Visual Result

### On Large Screen (1920px):
```
BEFORE:
┌──────────────────────┐     ← 672px (TenantDetail)
│ Tenant Detail  [×]  │
└──────────────────────┘

AFTER:
┌──────────────────────────────────────────────────┐
│ Tenant Detail                              [×]  │     ← 1440px (75vw)
└──────────────────────────────────────────────────┘
```

### On Medium Screen (1280px):
```
BEFORE:
┌──────────────────────┐     ← 672px (fixed)
│ Import JSON    [×]  │
└──────────────────────┘

AFTER:
┌──────────────────────────────────────┐
│ Import Tenants from JSON       [×]  │     ← 960px (75vw)
└──────────────────────────────────────┘
```

### On Small Screen (800px):
```
BEFORE:
┌──────────────────────┐     ← 672px (too wide!)
│ Dialog        [×]  │
└──────────────────────┘

AFTER:
┌──────────────────────────────┐
│ Dialog                 [×]  │     ← 600px (75vw)
└──────────────────────────────┘
```

### On Very Small Screen (600px):
```
Both:
┌─────────────────────────────┐
│ Dialog                [×]  │     ← 540px (90vw, max)
└─────────────────────────────┘
```

---

## 💡 Benefits

### Consistency
- ✅ All dialogs same width
- ✅ Predictable UX
- ✅ Professional appearance

### Responsive
- ✅ Scales with screen size
- ✅ Never too small (500px min)
- ✅ Never too wide (90vw max)

### Space Utilization
- ✅ More room for content
- ✅ Less horizontal overflow
- ✅ Better for JSON display
- ✅ Better for long strings

---

## 🧪 Test on Different Screens

### Desktop (1920x1080):
- Dialog width: **1440px** (75vw)
- Plenty of space for content
- JSON displays without wrapping

### Laptop (1366x768):
- Dialog width: **1024px** (75vw)
- Good balance
- Readable content

### Tablet (768px width):
- Dialog width: **576px** (75vw)
- Compact but usable
- Content may wrap

### Mobile (375px width):
- Dialog width: **500px** (min-w enforced)
- Actually wider than screen!
- max-w-[90vw] prevents this: **338px** (90vw)

---

## 📐 Responsive Behavior

```
Screen Width    Dialog Width    Calculation
─────────────   ────────────    ───────────
2560px          1920px          75vw
1920px          1440px          75vw
1600px          1200px          75vw
1366px          1024px          75vw
1280px          960px           75vw
1024px          768px           75vw
800px           600px           75vw
667px           500px           min-w enforced
600px           540px           90vw (max-w)
400px           360px           90vw (max-w)
```

---

## ✅ All Dialogs Updated

### Tenant Management
- ✅ TenantDetail - View full metadata
- ✅ TenantEditForm - Edit tenant name
- ✅ TenantImportDialog - Import from JSON

### Transaction Management
- ✅ TransactionDetail - View Request/Response
- ✅ TransactionForm - Create new transaction

**5 dialogs total - all now 75vw!**

---

## 🎯 Consistent UX

All popups now provide:
- Wide enough for JSON content
- Consistent width across app
- Responsive to screen size
- Professional appearance

**No more mixed widths!** 🎉
