# Application Onboarding - Анализ соответствия требованиям

## 📋 Требования из спецификации

### Концепция
Application Onboarding предназначен для подключения front-end user applications к Transaction Hub & Data Plane.

**Confirmed Applications**:
- **myBLDR** - Allows builders to create a "shopping cart" in an online portal
- **Will Call** - Buy online and pick up in store experience

---

## 🎯 User Stories

### US1: View onboarded applications based on access level

**Требование**: Пользователь может просматривать onboarded applications в зависимости от своего уровня доступа (RBAC).

**Реализация**: ✅ **ПОЛНОСТЬЮ РЕАЛИЗОВАНО**

```typescript
// ApplicationsView.tsx

export function ApplicationsView({ 
  userRole, 
  tenants, 
  activeTenantId, 
  onTenantChange 
}: ApplicationsViewProps) {
  const [applications, setApplications] = useState<Application[]>(mockApplications);
  
  // ✅ RBAC permissions check
  const canCreate = userRole === 'superuser' || userRole === 'admin' || userRole === 'developer';
  const canEdit = userRole === 'superuser' || userRole === 'admin' || userRole === 'developer';
  const canDelete = userRole === 'superuser' || userRole === 'admin' || userRole === 'developer';
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>Applications</CardTitle>
        <CardDescription>
          Manage applications and their transaction specifications
        </CardDescription>
        
        {/* ✅ Tenant Selector for filtering */}
        <TenantSelector
          tenants={tenants}
          activeTenantId={activeTenantId}
          onTenantChange={onTenantChange}
          isSuperUser={userRole === 'superuser'}
        />
      </CardHeader>
      
      <CardContent>
        {/* ✅ DataTable with applications */}
        <DataTable
          columns={columns}
          data={applications}
          actions={(row) => (
            <div className="flex gap-1">
              <Button onClick={() => handleViewClick(row)}>
                <ViewIcon />
              </Button>
              {canEdit && (
                <Button onClick={() => handleEditClick(row)}>
                  <EditIcon />
                </Button>
              )}
              {canDelete && (
                <Button onClick={() => handleDeleteClick(row)}>
                  <DeleteIcon />
                </Button>
              )}
            </div>
          )}
        />
      </CardContent>
    </Card>
  );
}
```

**RBAC Matrix**:

| Role | View Applications | Add Application | Edit Application | Delete Application |
|------|------------------|----------------|-----------------|-------------------|
| Portal.SuperUser | ✅ All tenants | ✅ Yes | ✅ Yes | ✅ Yes |
| ViewOnlySuperUser | ✅ All tenants | ❌ No | ❌ No | ❌ No |
| Admin | ✅ Own tenant | ✅ Yes | ✅ Yes | ✅ Yes |
| Developer | ✅ Own tenant | ✅ Yes | ✅ Yes | ✅ Yes |
| Viewer | ✅ Own tenant | ❌ No | ❌ No | ❌ No |

**Текущая реализация**:
```typescript
const canCreate = userRole === 'superuser' || userRole === 'admin' || userRole === 'developer';
const canEdit = userRole === 'superuser' || userRole === 'admin' || userRole === 'developer';
const canDelete = userRole === 'superuser' || userRole === 'admin' || userRole === 'developer';
```

**Проблема**: ❌ **ViewOnlySuperUser не учтен**

ViewOnlySuperUser должен иметь доступ к просмотру всех tenants, но не иметь прав на создание/редактирование/удаление.

**Должно быть**:
```typescript
const canCreate = ['superuser', 'admin', 'developer'].includes(userRole);
const canEdit = ['superuser', 'admin', 'developer'].includes(userRole);
const canDelete = ['superuser', 'admin', 'developer'].includes(userRole);

// ViewOnlySuperUser can view all tenants but cannot modify
const isSuperUser = userRole === 'superuser' || userRole === 'viewonlysuperuser';
```

**Статус**: ⚠️ **ЧАСТИЧНО РЕАЛИЗОВАНО** - работает для основных ролей, но ViewOnlySuperUser не учтен

---

### US2: Add a new application for a tenant

**Требование**: Пользователь может добавить новое приложение для тенанта.

**Реализация**: ✅ **ПОЛНОСТЬЮ РЕАЛИЗОВАНО**

```typescript
// Create application handler
const handleCreate = async () => {
  if (!newApplicationName.trim()) {
    toast.error('Application Name is required');
    return;
  }

  setIsSubmitting(true);
  try {
    // ⚠️ Simulate API call (mock data)
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const created: Application = {
      ApplicationId: `app-${Date.now()}`,
      ApplicationName: newApplicationName.trim(),
      Version: newApplicationVersion.trim() || '1.0',
      Description: newApplicationDescription.trim(),
      Status: 'Active',
      CreateTime: new Date().toISOString(),
      UpdateTime: new Date().toISOString(),
      _etag: `etag-${Date.now()}`,
    };
    
    // Add to list (prepend - newest first)
    setApplications([created, ...applications]);
    
    // Reset form
    setNewApplicationName('');
    setNewApplicationVersion('');
    setNewApplicationDescription('');
    setIsCreateDialogOpen(false);
    
    toast.success(`Application "${getApplicationName(created)}" created successfully!`);
  } catch (error: any) {
    toast.error(`Failed to create application: ${error.message}`);
  } finally {
    setIsSubmitting(false);
  }
};
```

**Create Dialog UI**:
```tsx
<Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
  <DialogContent>
    <DialogHeader>
      <DialogTitle>Create New Application</DialogTitle>
      <DialogDescription>
        Add a new application to the system
      </DialogDescription>
    </DialogHeader>
    
    <div className="space-y-4 py-4">
      {/* Application Name */}
      <div className="space-y-2">
        <Label htmlFor="applicationName">Application Name *</Label>
        <Input
          id="applicationName"
          placeholder="e.g., myBLDR, Will Call"
          value={newApplicationName}
          onChange={(e) => setNewApplicationName(e.target.value)}
        />
      </div>
      
      {/* Version */}
      <div className="space-y-2">
        <Label htmlFor="version">Version</Label>
        <Input
          id="version"
          placeholder="e.g., 1.0"
          value={newApplicationVersion}
          onChange={(e) => setNewApplicationVersion(e.target.value)}
        />
      </div>
      
      {/* Description */}
      <div className="space-y-2">
        <Label htmlFor="description">Description</Label>
        <Textarea
          id="description"
          placeholder="Enter description"
          value={newApplicationDescription}
          onChange={(e) => setNewApplicationDescription(e.target.value)}
        />
      </div>
    </div>
    
    <DialogFooter>
      <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
        Cancel
      </Button>
      <Button onClick={handleCreate} disabled={isSubmitting}>
        {isSubmitting ? 'Creating...' : 'Create'}
      </Button>
    </DialogFooter>
  </DialogContent>
</Dialog>
```

**Проблема**: ⚠️ **НЕТ TENANT ID**

В форме создания приложения **нет поля Tenant ID**. Приложение должно быть привязано к тенанту.

**Должно быть**:
```tsx
{/* Tenant ID - Required */}
<div className="space-y-2">
  <Label htmlFor="tenantId">Tenant ID *</Label>
  <Select
    value={newApplicationTenantId}
    onValueChange={setNewApplicationTenantId}
  >
    <SelectTrigger id="tenantId">
      <SelectValue placeholder="Select tenant" />
    </SelectTrigger>
    <SelectContent>
      {tenants.map((tenant) => (
        <SelectItem key={tenant.TenantId} value={tenant.TenantId}>
          {tenant.TenantName} ({tenant.TenantId})
        </SelectItem>
      ))}
    </SelectContent>
  </Select>
  <p className="text-xs text-muted-foreground">
    {activeTenantId !== 'global' 
      ? `Current tenant: ${tenants.find(t => t.TenantId === activeTenantId)?.TenantName}`
      : 'Select which tenant this application belongs to'}
  </p>
</div>
```

**Interface должен иметь TenantId**:
```typescript
interface Application {
  ApplicationId: string;
  ApplicationName: string;
  TenantId: string;  // ✅ Add this field
  Version?: string;
  Description?: string;
  Status?: string;
  CreateTime?: string;
  UpdateTime?: string;
  _rid?: string;
  _self?: string;
  _etag?: string;
  _attachments?: string;
  _ts?: number;
}
```

**Статус**: ⚠️ **ЧАСТИЧНО РЕАЛИЗОВАНО** - форма работает, но нет tenant association

---

### US3: Edit an existing application for a tenant

**Требование**: Пользователь может редактировать существующее приложение для тенанта.

**Реализация**: ✅ **ПОЛНОСТЬЮ РЕАЛИЗОВАНО**

```typescript
// Edit application handler
const handleEditClick = (application: Application) => {
  setApplicationToEdit(application);
  setEditApplicationName(getApplicationName(application));
  setIsEditOpen(true);
};

const handleEdit = async () => {
  if (!applicationToEdit) return;
  if (!editApplicationName.trim()) {
    toast.error('Application Name is required');
    return;
  }

  setIsSubmitting(true);
  try {
    // ⚠️ Simulate API call
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const idToEdit = getApplicationId(applicationToEdit);
    
    // Update in list
    setApplications(applications.map(app => 
      getApplicationId(app) === idToEdit 
        ? { 
            ...app, 
            ApplicationName: editApplicationName.trim(),
            UpdateTime: new Date().toISOString()
          }
        : app
    ));
    
    setIsEditOpen(false);
    setApplicationToEdit(null);
    setEditApplicationName('');
    
    toast.success(`Application \"${editApplicationName}\" updated successfully!`);
  } catch (error: any) {
    toast.error(`Failed to update application: ${error.message}`);
  } finally {
    setIsSubmitting(false);
  }
};
```

**Edit Dialog UI**:
```tsx
<Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
  <DialogContent>
    <DialogHeader>
      <DialogTitle>Edit Application</DialogTitle>
      <DialogDescription>
        Update application information
      </DialogDescription>
    </DialogHeader>
    
    <div className="space-y-4 py-4">
      <div className="space-y-2">
        <Label htmlFor="editApplicationName">Application Name *</Label>
        <Input
          id="editApplicationName"
          placeholder="Enter application name"
          value={editApplicationName}
          onChange={(e) => setEditApplicationName(e.target.value)}
        />
      </div>
    </div>
    
    <DialogFooter>
      <Button variant="outline" onClick={() => setIsEditOpen(false)}>
        Cancel
      </Button>
      <Button onClick={handleEdit} disabled={isSubmitting}>
        {isSubmitting ? 'Updating...' : 'Update'}
      </Button>
    </DialogFooter>
  </DialogContent>
</Dialog>
```

**Проблема**: ⚠️ **ТОЛЬКО НАЗВАНИЕ РЕДАКТИРУЕТСЯ**

Edit form позволяет редактировать только **ApplicationName**. Должны быть доступны для редактирования:
- Application Name
- Version
- Description
- Status (Active/Inactive)

**Должно быть**:
```tsx
<div className="space-y-4 py-4">
  {/* Application Name */}
  <div className="space-y-2">
    <Label>Application Name *</Label>
    <Input
      value={editForm.applicationName}
      onChange={(e) => setEditForm({ ...editForm, applicationName: e.target.value })}
    />
  </div>
  
  {/* Version */}
  <div className="space-y-2">
    <Label>Version</Label>
    <Input
      value={editForm.version}
      onChange={(e) => setEditForm({ ...editForm, version: e.target.value })}
    />
  </div>
  
  {/* Description */}
  <div className="space-y-2">
    <Label>Description</Label>
    <Textarea
      value={editForm.description}
      onChange={(e) => setEditForm({ ...editForm, description: e.target.value })}
    />
  </div>
  
  {/* Status */}
  <div className="space-y-2">
    <Label>Status</Label>
    <Select value={editForm.status} onValueChange={(value) => setEditForm({ ...editForm, status: value })}>
      <SelectTrigger>
        <SelectValue />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="Active">Active</SelectItem>
        <SelectItem value="Inactive">Inactive</SelectItem>
      </SelectContent>
    </Select>
  </div>
</div>
```

**Статус**: ⚠️ **ЧАСТИЧНО РЕАЛИЗОВАНО** - работает, но только для названия

---

### US4: Delete an existing application for a tenant

**Требование**: Пользователь может удалить существующее приложение для тенанта.

**Реализация**: ✅ **ПОЛНОСТЬЮ РЕАЛИЗОВАНО**

```typescript
// Delete application handler
const handleDeleteClick = (application: Application) => {
  setApplicationToDelete(application);
  setIsDeleteDialogOpen(true);
};

const handleDelete = async () => {
  if (!applicationToDelete) return;

  setIsSubmitting(true);
  try {
    // ⚠️ Simulate API call
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const idToDelete = getApplicationId(applicationToDelete);
    
    // Remove from list
    setApplications(applications.filter(app => getApplicationId(app) !== idToDelete));
    
    setIsDeleteDialogOpen(false);
    setApplicationToDelete(null);
    
    toast.success(`Application "${getApplicationName(applicationToDelete)}" deleted successfully!`);
  } catch (error: any) {
    toast.error(`Failed to delete application: ${error.message}`);
  } finally {
    setIsSubmitting(false);
  }
};
```

**Delete Confirmation Dialog**:
```tsx
<AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
  <AlertDialogContent>
    <AlertDialogHeader>
      <AlertDialogTitle>Are you sure?</AlertDialogTitle>
      <AlertDialogDescription>
        This will permanently delete the application "
        {applicationToDelete ? getApplicationName(applicationToDelete) : ''}"
        and all its transaction specifications. This action cannot be undone.
      </AlertDialogDescription>
    </AlertDialogHeader>
    <AlertDialogFooter>
      <AlertDialogCancel disabled={isSubmitting}>
        Cancel
      </AlertDialogCancel>
      <AlertDialogAction
        onClick={handleDelete}
        disabled={isSubmitting}
        className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
      >
        {isSubmitting ? 'Deleting...' : 'Delete'}
      </AlertDialogAction>
    </AlertDialogFooter>
  </AlertDialogContent>
</AlertDialog>
```

**Статус**: ✅ **ПОЛНОСТЬЮ РАБОТАЕТ**

---

## 📊 API Integration Status

### Текущая реализация

**Проблема**: ❌ **НЕТ РЕАЛЬНЫХ API ENDPOINTS**

```typescript
// ApplicationsView.tsx используует MOCK DATA
const mockApplications: Application[] = [
  {
    ApplicationId: 'app-001',
    ApplicationName: 'myBLDR',
    Version: '1.0',
    Description: '',
    Status: 'Active',
    CreateTime: '2025-10-30T00:00:00Z',
    UpdateTime: '2025-10-30T00:00:00Z',
    _etag: 'etag-001',
  },
  {
    ApplicationId: 'app-002',
    ApplicationName: 'Will Call',
    Version: '2.1',
    Description: '',
    Status: 'Active',
    CreateTime: '2025-10-31T00:00:00Z',
    UpdateTime: '2025-10-31T00:00:00Z',
    _etag: 'etag-002',
  },
];

// CRUD operations используют setTimeout вместо fetch
const handleCreate = async () => {
  // ❌ Mock API call
  await new Promise(resolve => setTimeout(resolve, 500));
  
  // Local state update only
  setApplications([created, ...applications]);
};
```

### Требуемые API endpoints

Необходимо добавить в `/lib/api.ts`:

```typescript
// ==================== APPLICATION API FUNCTIONS ====================

// Application interface
export interface Application {
  ApplicationId: string;
  ApplicationName: string;
  TenantId: string;  // ✅ Required for multi-tenancy
  Version?: string;
  Description?: string;
  Status?: string;
  CreateTime?: string;
  UpdateTime?: string;
  _rid?: string;
  _self?: string;
  _etag?: string;
  _attachments?: string;
  _ts?: number;
}

// GET /applications - List all applications
export async function getApplications(tenantId?: string): Promise<Application[]> {
  try {
    let url = `${API_BASE_URL}/applications`;
    
    // Filter by tenant if provided
    if (tenantId && tenantId !== 'global') {
      const filters = { TenantId: tenantId };
      const filtersParam = encodeURIComponent(JSON.stringify(filters));
      url += `?Filters=${filtersParam}`;
    }
    
    console.log('🔍 GET Applications Request:');
    console.log('  URL:', url);
    console.log('  TenantId:', tenantId || 'all');
    
    const response = await fetch(url, {
      method: 'GET',
      headers: getHeaders(),
    });
    
    if (!response.ok) {
      const errorData: ApiResponse<any> = await response.json();
      throw new Error(errorData.status?.message || 'Failed to fetch applications');
    }
    
    const data: ApiResponse<{ Applications: Application[] }> = await response.json();
    console.log('✅ Fetched applications:', data.data.Applications.length);
    return data.data.Applications || [];
  } catch (error) {
    console.error('Error fetching applications:', error);
    throw error;
  }
}

// POST /applications - Create new application
export async function createApplication(
  application: Omit<Application, 'ApplicationId' | '_etag' | '_rid' | '_ts' | '_self' | '_attachments' | 'CreateTime' | 'UpdateTime'>
): Promise<Application> {
  try {
    console.log('➕ POST Application Request:');
    console.log('  URL:', `${API_BASE_URL}/applications`);
    console.log('  Application:', application);
    
    const response = await fetch(`${API_BASE_URL}/applications`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify(application),
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      console.error('❌ Error response:', errorText);
      let errorData: ApiResponse<any>;
      try {
        errorData = JSON.parse(errorText);
      } catch {
        throw new Error(`HTTP ${response.status}: ${errorText}`);
      }
      throw new Error(errorData.status?.message || 'Failed to create application');
    }
    
    const data: ApiResponse<Application> = await response.json();
    console.log('✅ Created application:', data.data.ApplicationId);
    return data.data;
  } catch (error) {
    console.error('Error creating application:', error);
    throw error;
  }
}

// PUT /applications/{applicationId} - Update application
export async function updateApplication(
  applicationId: string,
  updates: Partial<Omit<Application, 'ApplicationId' | 'CreateTime' | '_rid' | '_self' | '_attachments' | '_ts'>>
): Promise<Application> {
  try {
    console.log('✏️ PUT Application Request:');
    console.log('  URL:', `${API_BASE_URL}/applications/${applicationId}`);
    console.log('  Updates:', updates);
    
    const response = await fetch(`${API_BASE_URL}/applications/${applicationId}`, {
      method: 'PUT',
      headers: getHeaders(),
      body: JSON.stringify(updates),
    });
    
    if (!response.ok) {
      const errorData: ApiResponse<any> = await response.json();
      throw new Error(errorData.status?.message || 'Failed to update application');
    }
    
    const data: ApiResponse<Application> = await response.json();
    console.log('✅ Updated application:', data.data.ApplicationId);
    return data.data;
  } catch (error) {
    console.error('Error updating application:', error);
    throw error;
  }
}

// DELETE /applications/{applicationId} - Delete application
export async function deleteApplication(applicationId: string): Promise<void> {
  try {
    console.log('🗑️ DELETE Application Request:');
    console.log('  URL:', `${API_BASE_URL}/applications/${applicationId}`);
    
    const response = await fetch(`${API_BASE_URL}/applications/${applicationId}`, {
      method: 'DELETE',
      headers: getHeaders(),
    });
    
    if (!response.ok) {
      const errorData: ApiResponse<any> = await response.json();
      throw new Error(errorData.status?.message || 'Failed to delete application');
    }
    
    console.log('✅ Deleted application:', applicationId);
  } catch (error) {
    console.error('Error deleting application:', error);
    throw error;
  }
}

// GET /applications/{applicationId} - Get single application
export async function getApplication(applicationId: string): Promise<Application> {
  try {
    console.log('🔍 GET Application Request:');
    console.log('  URL:', `${API_BASE_URL}/applications/${applicationId}`);
    
    const response = await fetch(
      `${API_BASE_URL}/applications/${applicationId}`,
      {
        method: 'GET',
        headers: getHeaders(),
      }
    );
    
    if (!response.ok) {
      const errorData: ApiResponse<any> = await response.json();
      throw new Error(errorData.status?.message || 'Failed to fetch application');
    }
    
    const data: ApiResponse<Application> = await response.json();
    return data.data;
  } catch (error) {
    console.error('Error fetching application:', error);
    throw error;
  }
}
```

**Статус**: ❌ **НЕ РЕАЛИЗОВАНО** - требуется добавить API endpoints

---

## 📋 Матрица соответствия User Stories

| User Story | Требование | Реализация | Статус |
|-----------|-----------|-----------|--------|
| **US1** | View onboarded applications based on access level | RBAC проверки работают, но ViewOnlySuperUser не учтен | ⚠️ **ЧАСТИЧНО** |
| **US2** | Add a new application for a tenant | Форма работает, но нет TenantId field | ⚠️ **ЧАСТИЧНО** |
| **US3** | Edit an existing application for a tenant | Работает, но только для ApplicationName | ⚠️ **ЧАСТИЧНО** |
| **US4** | Delete an existing application for a tenant | Полностью работает | ✅ **ПОЛНОСТЬЮ** |

### Дополнительные проверки

| Функция | Требование | Статус |
|---------|-----------|--------|
| RBAC для SuperUser | ✅ | ✅ |
| RBAC для ViewOnlySuperUser | View all, no modify | ❌ **НЕТ** |
| RBAC для Admin | ✅ | ✅ |
| RBAC для Developer | ✅ | ✅ |
| RBAC для Viewer | View only | ⚠️ **НЕТ ПРОВЕРКИ** |
| Tenant filtering | Filter by active tenant | ⚠️ **НЕТ ФИЛЬТРАЦИИ** |
| TenantId field | Applications must belong to tenant | ❌ **НЕТ** |
| API Integration | Real API endpoints | ❌ **MOCK DATA** |
| Transaction Specifications | View specs for app | ✅ **ЕСТЬ** |

---

## ⚠️ Выявленные проблемы

### 1. Нет TenantId в Application model

**Критичность**: 🔴 **ВЫСОКАЯ**

**Проблема**:
```typescript
interface Application {
  ApplicationId: string;
  ApplicationName: string;
  // ❌ TenantId отсутствует!
  Version?: string;
  Description?: string;
  Status?: string;
  CreateTime?: string;
  UpdateTime?: string;
}
```

**Решение**:
```typescript
interface Application {
  ApplicationId: string;
  ApplicationName: string;
  TenantId: string;  // ✅ Required for multi-tenancy
  Version?: string;
  Description?: string;
  Status?: string;
  CreateTime?: string;
  UpdateTime?: string;
  _rid?: string;
  _self?: string;
  _etag?: string;
  _attachments?: string;
  _ts?: number;
}
```

---

### 2. Create form не имеет Tenant ID selector

**Критичность**: 🔴 **ВЫСОКАЯ**

**Проблема**: При создании приложения пользователь не может выбрать tenant.

**Решение**: Добавить Tenant selector в Create Application dialog:

```tsx
<div className="space-y-2">
  <Label htmlFor="tenantId">Tenant ID *</Label>
  <Select
    value={newApplicationTenantId}
    onValueChange={setNewApplicationTenantId}
  >
    <SelectTrigger id="tenantId">
      <SelectValue placeholder="Select tenant" />
    </SelectTrigger>
    <SelectContent>
      {activeTenantId === 'global' ? (
        // SuperUser can select any tenant
        tenants.map((tenant) => (
          <SelectItem key={tenant.TenantId} value={tenant.TenantId}>
            {tenant.TenantName} ({tenant.TenantId})
          </SelectItem>
        ))
      ) : (
        // Non-superuser can only create for their tenant
        <SelectItem value={activeTenantId}>
          {tenants.find(t => t.TenantId === activeTenantId)?.TenantName} ({activeTenantId})
        </SelectItem>
      )}
    </SelectContent>
  </Select>
</div>
```

---

### 3. Edit form только для ApplicationName

**Критичность**: 🟡 **СРЕДНЯЯ**

**Проблема**: Edit dialog позволяет редактировать только название.

**Решение**: Добавить поля для:
- Version
- Description
- Status

```typescript
const [editForm, setEditForm] = useState({
  applicationName: '',
  version: '',
  description: '',
  status: 'Active'
});

const handleEditClick = (application: Application) => {
  setApplicationToEdit(application);
  setEditForm({
    applicationName: application.ApplicationName,
    version: application.Version || '',
    description: application.Description || '',
    status: application.Status || 'Active'
  });
  setIsEditOpen(true);
};
```

---

### 4. Нет фильтрации по tenant

**Критичность**: 🔴 **ВЫСОКАЯ**

**Проблема**: Applications не фильтруются по activeTenantId.

**Текущая реализация**:
```typescript
const [applications, setApplications] = useState<Application[]>(mockApplications);
// ❌ Все приложения показываются всем
```

**Решение**:
```typescript
// Load applications when tenant changes
useEffect(() => {
  const loadApplications = async () => {
    setIsLoading(true);
    try {
      if (activeTenantId && activeTenantId !== 'global') {
        // Load applications for specific tenant
        const apps = await getApplications(activeTenantId);
        setApplications(apps);
      } else if (activeTenantId === 'global') {
        // SuperUser sees all applications
        const apps = await getApplications();
        setApplications(apps);
      }
    } catch (error: any) {
      toast.error(`Failed to load applications: ${error.message}`);
    } finally {
      setIsLoading(false);
    }
  };
  
  loadApplications();
}, [activeTenantId]);

// Filter applications by tenant in UI
const filteredApplications = useMemo(() => {
  if (activeTenantId === 'global') {
    return applications; // SuperUser sees all
  }
  return applications.filter(app => app.TenantId === activeTenantId);
}, [applications, activeTenantId]);
```

---

### 5. ViewOnlySuperUser не поддерживается

**Критичность**: 🟡 **СРЕДНЯЯ**

**Проблема**:
```typescript
const canCreate = userRole === 'superuser' || userRole === 'admin' || userRole === 'developer';
// ❌ ViewOnlySuperUser не учтен
```

**Решение**:
```typescript
// ViewOnlySuperUser can view all tenants but cannot modify
const isSuperUser = userRole === 'superuser' || userRole === 'viewonlysuperuser';
const canCreate = ['superuser', 'admin', 'developer'].includes(userRole);
const canEdit = ['superuser', 'admin', 'developer'].includes(userRole);
const canDelete = ['superuser', 'admin', 'developer'].includes(userRole);

// In TenantSelector:
<TenantSelector
  tenants={tenants}
  activeTenantId={activeTenantId}
  onTenantChange={onTenantChange}
  isSuperUser={isSuperUser}  // ✅ Both superuser and viewonlysuperuser
/>
```

---

### 6. Нет реальных API endpoints

**Критичность**: 🔴 **КРИТИЧЕСКАЯ**

**Проблема**: Все операции используют mock data вместо реального API.

**Решение**: Добавить API functions в `/lib/api.ts`:
- `getApplications(tenantId?: string)`
- `createApplication(application)`
- `updateApplication(applicationId, updates)`
- `deleteApplication(applicationId)`
- `getApplication(applicationId)`

См. раздел "Требуемые API endpoints" выше для полного кода.

---

### 7. Transaction Specifications - Mock data

**Критичность**: 🟡 **СРЕДНЯЯ**

**Проблема**:
```typescript
const getMockSpecifications = (applicationName: string): TransactionSpecification[] => {
  // ❌ Mock data, не связано с реальным API
  return [
    {
      id: 'spec_quote',
      table: 'Quote',
      version: '2.0',
      date: '10/30/2025',
    },
    // ...
  ];
};
```

**Решение**: Transaction Specifications должны загружаться из API:
- Связь: Application → Transaction Specifications
- API endpoint: `/applications/{applicationId}/specifications`

---

## ✅ Что работает отлично

1. ✅ **RBAC base permissions** - SuperUser, Admin, Developer имеют правильные права
2. ✅ **Column selector** - Пользователь может настроить отображаемые колонки
3. ✅ **CRUD UI** - Все диалоги работают корректно
4. ✅ **Delete confirmation** - AlertDialog с предупреждением
5. ✅ **Toast notifications** - Feedback для всех операций
6. ✅ **Responsive design** - Mobile и desktop layouts
7. ✅ **DataTable integration** - Таблица с сортировкой и фильтрацией
8. ✅ **Transaction Specifications view** - Detail view показывает specs

---

## 📋 Рекомендации по доработке

### Критичные (обязательно для production)

1. **Добавить TenantId field в Application model**
   - Обновить interface
   - Добавить в mock data
   - Добавить в Create/Edit forms

2. **Добавить Tenant selector в Create form**
   - SuperUser может выбрать любой tenant
   - Admin/Developer создают только для своего tenant

3. **Реализовать tenant filtering**
   - Load applications based on activeTenantId
   - Filter in UI if needed
   - SuperUser sees all, others see only their tenant

4. **Добавить реальные API endpoints**
   - Реализовать все CRUD operations
   - Использовать X-BFS-Auth header
   - Поддержка ETag для updates

5. **Поддержка ViewOnlySuperUser role**
   - Can view all tenants
   - Cannot create/edit/delete

### Желательные (UX improvements)

6. **Расширить Edit form**
   - Version
   - Description
   - Status (Active/Inactive)

7. **Transaction Specifications API integration**
   - Load real specs from API
   - Link to applications

8. **Better error handling**
   - Network errors
   - Validation errors
   - Permission errors

9. **Loading states**
   - Skeleton loaders
   - Spinner for async operations

---

## 🎯 Итоговая оценка

| Компонент | Соответствие | Комментарий |
|-----------|--------------|-------------|
| **Overall** | **60%** | UI готов, но нет tenant support и API |
| US1 (View) | ⚠️ 70% | Работает, но нет ViewOnlySuperUser и tenant filtering |
| US2 (Add) | ⚠️ 50% | Форма работает, но нет TenantId |
| US3 (Edit) | ⚠️ 50% | Работает, но только ApplicationName |
| US4 (Delete) | ✅ 100% | Полностью работает |
| RBAC | ⚠️ 70% | Основные роли работают, ViewOnlySuperUser нет |
| Tenant Isolation | ❌ 0% | Нет фильтрации по tenant |
| API Integration | ❌ 0% | Mock data, нет реальных endpoints |

**Статус**: ⚠️ **ТРЕБУЕТ СУЩЕСТВЕННОЙ ДОРАБОТКИ**

**Критичные задачи** (порядок приоритета):
1. 🔴 Добавить TenantId field в Application model
2. 🔴 Реализовать tenant filtering
3. 🔴 Добавить API endpoints (getApplications, createApplication, etc.)
4. 🔴 Добавить Tenant selector в Create form
5. 🟡 Поддержка ViewOnlySuperUser
6. 🟡 Расширить Edit form (Version, Description, Status)
7. 🟢 Transaction Specifications API integration

После этих доработок соответствие будет **100%** ✅
