# 📊 Apicurio Registry: Visual Map

**Дата:** 27 ноября 2025

---

## 🗺️ Архитектура запросов

```
┌─────────────────────────────────────────────────────────────────┐
│                     Figma Make Application                      │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             │ searchApicurioArtifacts()
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│               Apicurio Registry (Base URL)                      │
│  https://apicurio-poc.proudpond-b12a57e6.eastus...io/...v3      │
└───────────────────────┬─────────────────────────────────────────┘
                        │
                        │ GET /groups/{groupId}/artifacts
                        │
         ┌──────────────┴──────────────┐
         │                             │
         ▼                             ▼
┌────────────────────┐        ┌────────────────────┐
│ paradigm.bidtools2 │        │    bfs.online      │
│   (Group 1)        │        │    (Group 2)       │
└────────────────────┘        └────────────────────┘
         │                             │
         │ 7 artifacts                 │ 11 artifacts
         │                             │
         ▼                             ▼
┌────────────────────┐        ┌────────────────────┐
│  UI: Bid Tools     │        │ UI: BFS Online     │
│     Templates      │        │    Templates       │
└────────────────────┘        └────────────────────┘
```

---

## 📦 Group 1: paradigm.bidtools2

```
https://apicurio-poc.../groups/paradigm.bidtools2/artifacts
                            │
                            │
          ┌─────────────────┴─────────────────┐
          │                                   │
          ▼                                   ▼
    ┌──────────┐                      ┌──────────────┐
    │ CDC      │                      │  TxServices  │
    │ (AVRO)   │                      │   (JSON)     │
    │ 3 items  │                      │   4 items    │
    └──────────┘                      └──────────────┘
          │                                   │
          │                                   │
          ▼                                   ▼
    ┌──────────────────────┐      ┌────────────────────────┐
    │ • LineTypes          │      │ • QuoteDetails         │
    │ • ServiceRequests    │      │ • QuotePacks           │
    │ • WorkflowCustomers  │      │ • Quotes               │
    └──────────────────────┘      │ • ReasonCodes          │
                                  └────────────────────────┘

UI Display:
┌─────────────────────────────────────────┐
│ 📋 Bid Tools Templates                  │
│                                         │
│    • LineTypes (CDC)                    │
│    • ServiceRequests (CDC)              │
│    • WorkflowCustomers (CDC)            │
│    • QuoteDetails                       │
│    • QuotePacks                         │
│    • Quotes                             │
│    • ReasonCodes                        │
└─────────────────────────────────────────┘
```

---

## 📦 Group 2: bfs.online

```
https://apicurio-poc.../groups/bfs.online/artifacts
                            │
                            │
                            ▼
                    ┌──────────────┐
                    │   Informix   │
                    │  TxServices  │
                    │   (JSON)     │
                    │  11 items    │
                    └──────────────┘
                            │
                            │
          ┌─────────────────┼─────────────────┐
          │                 │                 │
          ▼                 ▼                 ▼
    ┌──────────┐     ┌──────────┐     ┌──────────┐
    │ Location │     │Inventory │     │  Other   │
    ├──────────┤     ├──────────┤     ├──────────┤
    │ • loc    │     │ • inv    │     │ • stcode │
    │ • loc1   │     │ • inv1   │     │ • keyi   │
    │ • invloc │     │ • inv2   │     └──────────┘
    └──────────┘     │ • inv3   │
                     │ • invap  │
                     │ • invdes │
                     └──────────┘

UI Display:
┌─────────────────────────────────────────┐
│ 📋 BFS Online Templates                 │
│                                         │
│    • loc, loc1                          │
│    • inv, inv1, inv2, inv3              │
│    • invap, invdes, invloc              │
│    • keyi, stcode                       │
└─────────────────────────────────────────┘
```

---

## 🔄 Data Flow

```
┌───────────────────────────────────────────────────────────┐
│ 1. User opens "Create Data Capture Specification"        │
└────────────────────────┬──────────────────────────────────┘
                         │
                         ▼
┌───────────────────────────────────────────────────────────┐
│ 2. Click "Select Template" dropdown                       │
└────────────────────────┬──────────────────────────────────┘
                         │
                         ▼
┌───────────────────────────────────────────────────────────┐
│ 3. App calls searchApicurioArtifacts()                    │
└────────────────────────┬──────────────────────────────────┘
                         │
         ┌───────────────┴───────────────┐
         │                               │
         ▼                               ▼
┌──────────────────┐           ┌──────────────────┐
│ GET /groups/     │           │ GET /groups/     │
│ paradigm.        │           │ bfs.online/      │
│ bidtools2/       │           │ artifacts        │
│ artifacts        │           │                  │
└────────┬─────────┘           └────────┬─────────┘
         │                               │
         │ Response:                     │ Response:
         │ 7 artifacts                   │ 11 artifacts
         │                               │
         └───────────────┬───────────────┘
                         │
                         ▼
┌───────────────────────────────────────────────────────────┐
│ 4. Combine results (18 total)                            │
└────────────────────────┬──────────────────────────────────┘
                         │
                         ▼
┌───────────────────────────────────────────────────────────┐
│ 5. Group by groupId                                       │
│    {                                                      │
│      'paradigm.bidtools2': [7 artifacts],                │
│      'bfs.online': [11 artifacts]                        │
│    }                                                      │
└────────────────────────┬──────────────────────────────────┘
                         │
                         ▼
┌───────────────────────────────────────────────────────────┐
│ 6. Display in UI with custom headings                    │
│    • paradigm.bidtools2 → "Bid Tools Templates"          │
│    • bfs.online → "BFS Online Templates"                 │
└───────────────────────────────────────────────────────────┘
                         │
                         ▼
┌───────────────────────────────────────────────────────────┐
│ 7. User selects a template                               │
└────────────────────────┬──────────────────────────────────┘
                         │
                         ▼
┌───────────────────────────────────────────────────────────┐
│ 8. App calls getApicurioArtifact(groupId, artifactId)    │
└────────────────────────┬──────────────────────────────────┘
                         │
                         ▼
┌───────────────────────────────────────────────────────────┐
│ GET /groups/{groupId}/artifacts/{artifactId}/             │
│     versions/{version}/content                            │
│                                                           │
│ For CDC (AVRO): version = "1.0.0"                        │
│ For TxServices (JSON): version = "branch=latest"         │
└────────────────────────┬──────────────────────────────────┘
                         │
                         ▼
┌───────────────────────────────────────────────────────────┐
│ 9. Parse schema and pre-fill form fields                 │
└───────────────────────────────────────────────────────────┘
```

---

## 🎯 Template Selection UI

```
┌──────────────────────────────────────────────────────────┐
│ Create Data Capture Specification                       │
├──────────────────────────────────────────────────────────┤
│                                                          │
│ Template Source:                                         │
│   ○ Manual Entry                                         │
│   ● Apicurio Registry                                    │
│                                                          │
│ Select Template:  [▼ Choose template...]                │
│                                                          │
│ ┌────────────────────────────────────────────────────┐  │
│ │ 🔍 Search templates...                             │  │
│ ├────────────────────────────────────────────────────┤  │
│ │                                                    │  │
│ │ 📋 Bid Tools Templates (7)                        │  │
│ │    Source: paradigm.bidtools2                     │  │
│ │                                                    │  │
│ │    CDC Format (AVRO):                             │  │
│ │    ✓ LineTypes (CDC)                              │  │
│ │    ✓ ServiceRequests (CDC)                        │  │
│ │    ✓ WorkflowCustomers (CDC)                      │  │
│ │                                                    │  │
│ │    TxServices Format (JSON):                      │  │
│ │    ✓ QuoteDetails                                 │  │
│ │    ✓ QuotePacks                                   │  │
│ │    ✓ Quotes                                       │  │
│ │    ✓ ReasonCodes                                  │  │
│ │                                                    │  │
│ │ ─────────────────────────────────────────────     │  │
│ │                                                    │  │
│ │ 📋 BFS Online Templates (11)                      │  │
│ │    Source: bfs.online                             │  │
│ │                                                    │  │
│ │    Informix TxServices (JSON):                    │  │
│ │    ✓ inv, inv1, inv2, inv3                        │  │
│ │    ✓ invap, invdes, invloc                        │  │
│ │    ✓ keyi, loc, loc1, stcode                      │  │
│ │                                                    │  │
│ └────────────────────────────────────────────────────┘  │
│                                                          │
│ [Cancel]                                    [Create]     │
└──────────────────────────────────────────────────────────┘
```

---

## 📊 Artifact Distribution

```
Total: 18 artifacts
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

paradigm.bidtools2 (7 artifacts - 39%)
████████████████████████████████████████

bfs.online (11 artifacts - 61%)
████████████████████████████████████████████████████████████


By Type:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

AVRO (3 artifacts - 17%)
█████████████████

JSON (15 artifacts - 83%)
███████████████████████████████████████████████████████████████████████████████


By Database:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

SQLServer (7 artifacts - 39%)
████████████████████████████████████████

Informix (11 artifacts - 61%)
████████████████████████████████████████████████████████████
```

---

## 🔗 URL Structure

```
Base URL:
https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3

Groups Endpoint:
{baseUrl}/groups
          └─ paradigm.bidtools2
          └─ bfs.online

Artifacts Endpoint:
{baseUrl}/groups/{groupId}/artifacts
          └─ paradigm.bidtools2/artifacts
                    └─ CDC_SQLServer_LineTypes
                    └─ CDC_SQLServer_ServiceRequests
                    └─ CDC_SQLServer_WorkflowCustomers
                    └─ TxServices_SQLServer_QuoteDetails.response
                    └─ TxServices_SQLServer_QuotePacks.response
                    └─ TxServices_SQLServer_Quotes.response
                    └─ TxServices_SQLServer_ReasonCodes.response
          
          └─ bfs.online/artifacts
                    └─ TxServices_Informix_loc1.response
                    └─ TxServices_Informix_loc.response
                    └─ TxServices_Informix_stcode.response
                    └─ TxServices_Informix_inv.response
                    └─ TxServices_Informix_inv1.response
                    └─ TxServices_Informix_inv2.response
                    └─ TxServices_Informix_inv3.response
                    └─ TxServices_Informix_invap.response
                    └─ TxServices_Informix_invdes.response
                    └─ TxServices_Informix_invloc.response
                    └─ TxServices_Informix_keyi.response

Content Endpoint:
{baseUrl}/groups/{groupId}/artifacts/{artifactId}/versions/{version}/content
          └─ For AVRO: versions/1.0.0/content
          └─ For JSON: versions/branch=latest/content
```

---

## 🎨 Visual Summary

```
╔═══════════════════════════════════════════════════════════╗
║           APICURIO REGISTRY INTEGRATION                   ║
╚═══════════════════════════════════════════════════════════╝

                    ┌─────────────┐
                    │  Apicurio   │
                    │  Registry   │
                    └──────┬──────┘
                           │
              ┌────────────┴────────────┐
              │                         │
        ┌─────▼──────┐          ┌──────▼─────┐
        │ paradigm.  │          │ bfs.online │
        │ bidtools2  │          │            │
        └─────┬──────┘          └──────┬─────┘
              │                        │
        7 artifacts               11 artifacts
              │                        │
    ┌─────────┴─────────┐        ┌────┴────┐
    │                   │        │         │
┌───▼───┐        ┌──────▼───┐  ┌─▼────────▼──┐
│ AVRO  │        │   JSON   │  │    JSON     │
│  (3)  │        │   (4)    │  │    (11)     │
└───┬───┘        └──────┬───┘  └─┬──────────┬┘
    │                   │        │          │
    └───────────┬───────┘        │          │
                │                │          │
                ▼                ▼          ▼
        ┌───────────────┐  ┌────────────────────┐
        │  Bid Tools    │  │   BFS Online       │
        │  Templates    │  │   Templates        │
        └───────────────┘  └────────────────────┘
                │                    │
                └──────────┬─────────┘
                           │
                           ▼
                ┌──────────────────┐
                │  UI Dropdown     │
                │  (18 templates)  │
                └──────────────────┘
```

---

## 📝 Legend

```
Symbol              Meaning
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
│                   Connection / Flow
▼                   Direction of data flow
┌─┐                 Container / Component
├─┤                 Section divider
└─┘                 End of container
●                   Selected option
○                   Unselected option
✓                   Available / Present
📦                  Group / Package
📋                  Template / List
🔍                  Search
```

---

**Дата:** 27 ноября 2025  
**Всего групп:** 2  
**Всего артефактов:** 18 (7 + 11)  
**Форматов:** AVRO (3) + JSON (15)
