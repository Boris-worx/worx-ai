# 🔧 Model Schema Edit & Delete Fix

## ✅ Status: FIXED

Исправлены ошибки при редактировании и удалении Model Schema.

## 🐛 Проблемы

### **Error 1: UPDATE Failed**
```
❌ Error response: {"status": {"code": 400, "message": "ModelSchema id mismatch or missing"}, "data": {}}
```

**Причина**: API ожидает, что `id` будет внутри объекта `Txn` и совпадет с `TxnId` в URL.

**Было**:
```json
PUT /txns/ModelSchema:Location:1
{
  "TxnType": "ModelSchema",
  "Txn": {
    "model": "Location",
    "version": 1,
    "state": "active",
    "semver": "1.0.0",
    "jsonSchema": {...}
  }
}
```

**Стало**:
```json
PUT /txns/ModelSchema:Location:1
{
  "TxnType": "ModelSchema",
  "Txn": {
    "id": "Location:1",  ← ДОБАВЛЕНО (БЕЗ префикса "ModelSchema:")
    "model": "Location",
    "version": 1,
    "state": "active",
    "semver": "1.0.0",
    "jsonSchema": {...}
  }
}
```

**ВАЖНО**: `id` должен быть БЕЗ префикса "ModelSchema:", только "Location:1"!

### **Error 2: DELETE Failed**
```
❌ Error response: {"status": {"code": 400, "message": "Unsupported TxnType"}, "data": {}}
```

**Причина**: API не поддерживает hard delete для ModelSchema (это правильное поведение для схем данных).

**Решение**: Реализовано **soft delete** - изменение `state` на `"deleted"`.

**Было**:
```
DELETE /txns/ModelSchema:Location:1
→ Error: Unsupported TxnType
```

**Стало**:
```
DELETE /txns/ModelSchema:Location:1
→ Error: Unsupported TxnType
→ Fallback: PUT /txns/ModelSchema:Location:1
   Body: { TxnType: "ModelSchema", Txn: { ...existingData, state: "deleted" } }
→ Success: Schema marked as deleted
```

## 🔧 Исправления

### **1. updateModelSchema() в `/lib/api.ts`**

```typescript
// Construct full TxnId with ModelSchema prefix
const txnId = schemaId.startsWith('ModelSchema:') 
  ? schemaId 
  : `ModelSchema:${schemaId}`;

// Extract id WITHOUT the "ModelSchema:" prefix
// Example: "ModelSchema:Location:1" -> "Location:1"
const idWithoutPrefix = txnId.replace(/^ModelSchema:/, '');

// Добавляем id БЕЗ префикса в объект Txn
const txnDataWithId = {
  ...schemaData,
  id: idWithoutPrefix, // Include id WITHOUT prefix
};

const response = await fetch(`${API_BASE_URL}/txns/${encodeURIComponent(txnId)}`, {
  method: "PUT",
  headers: getHeaders(etag),
  body: JSON.stringify({
    TxnType: "ModelSchema",
    Txn: txnDataWithId, // ← Используем данные с id БЕЗ префикса
  }),
});
```

### **2. deleteModelSchema() в `/lib/api.ts`**

**Реализовано Soft Delete с автоматическим fallback:**

```typescript
// 1. Пытаемся hard delete
const url = `${API_BASE_URL}/txns/${encodeURIComponent(txnId)}`;
const response = await fetch(url, {
  method: "DELETE",
  headers: getHeaders(etag),
});

// 2. Если получаем "Unsupported TxnType", делаем soft delete
if (errorData.status?.message === 'Unsupported TxnType') {
  console.log('ℹ️ Hard delete not supported, trying soft delete (state: "deleted")');
  
  // Получаем текущие данные схемы
  const getCurrentResponse = await fetch(
    `${API_BASE_URL}/txns/${encodeURIComponent(txnId)}`,
    { method: "GET", headers: getHeaders() }
  );
  
  const currentData = await getCurrentResponse.json();
  const currentSchema = currentData.data.Txn;
  
  // Extract id WITHOUT the "ModelSchema:" prefix
  const idWithoutPrefix = txnId.replace(/^ModelSchema:/, '');
  
  // Обновляем state на "deleted"
  const updatedSchema = {
    ...currentSchema,
    id: idWithoutPrefix, // Use id WITHOUT prefix
    state: "deleted",
  };
  
  // PUT запрос для soft delete
  await fetch(`${API_BASE_URL}/txns/${encodeURIComponent(txnId)}`, {
    method: "PUT",
    headers: getHeaders(etag),
    body: JSON.stringify({
      TxnType: "ModelSchema",
      Txn: updatedSchema,
    }),
  });
  
  console.log('✅ Model schema soft deleted (state: "deleted")');
}
```

### **3. Фильтрация удаленных схем в UI**

**В `/components/ModelSchemaView.tsx`:**

```typescript
// Фильтруем схемы со state: "deleted"
const activeSchemas = schemas.filter(s => s.state !== 'deleted');
```

## 📊 API Patterns

### **Общий формат**

| Operation | Method | URL | Body | Query Params | Notes |
|-----------|--------|-----|------|--------------|-------|
| **Create** | POST | `/txns` | `{ TxnType, Txn }` | - | - |
| **Read** | GET | `/txns?TxnType=ModelSchema` | - | `TxnType` | - |
| **Update** | PUT | `/txns/{TxnId}` | `{ TxnType, Txn }` | - | Txn must include `id` |
| **Delete** | ~~DELETE~~ → **PUT** | `/txns/{TxnId}` | `{ TxnType, Txn }` | - | **Soft delete**: `state: "deleted"` |

### **Важные моменты**

1. **TxnId Format**: Всегда `ModelSchema:{model}:{version}`
   - Пример: `ModelSchema:Location:1`

2. **ETag Required**: PUT и DELETE требуют `If-Match` header
   ```typescript
   headers: {
     'If-Match': schema._etag
   }
   ```

3. **Txn Object**: Должен содержать `id` для UPDATE
   ```typescript
   {
     id: "ModelSchema:Location:1",
     model: "Location",
     version: 1,
     state: "active",
     semver: "1.0.0",
     jsonSchema: {...}
   }
   ```

4. **Soft Delete**: DELETE реализован через UPDATE с `state: "deleted"`
   - API не поддерживает hard delete для ModelSchema
   - При попытке DELETE автоматически делается soft delete
   - UI фильтрует схемы с `state: "deleted"`

5. **ID Format**: `id` в объекте `Txn` должен быть БЕЗ префикса "ModelSchema:"
   - ✅ Правильно: `"id": "Location:1"`
   - ❌ Неправильно: `"id": "ModelSchema:Location:1"`
   - URL всё еще использует полный `TxnId`: `/txns/ModelSchema:Location:1`

## 🧪 Тестирование

### **Scenario 1: Update Schema**

1. **Открыть Model Schema View**
2. **Нажать Edit на любой схеме**
3. **Изменить поле** (например, `state` на `deprecated`)
4. **Сохранить**
5. **Ожидаемый результат**: 
   - ✅ Success toast: "Model schema updated successfully"
   - ✅ Таблица автоматически обновилась
   - ✅ Изменения видны в таблице

### **Scenario 2: Delete Schema**

1. **Открыть Model Schema View**
2. **Нажать Delete на любой схеме**
3. **Подтвердить удаление**
4. **Ожидаемый результат**:
   - ℹ️ Console: "Hard delete not supported, trying soft delete"
   - ✅ Success toast: "Model schema deleted successfully"
   - ✅ Схема помечена как `state: "deleted"` в API
   - ✅ Схема скрыта из таблицы (фильтр)
   - ✅ Таблица автоматически обновилась

## 🔍 Debug Logging

Обе функции логируют полную информацию:

```typescript
// UPDATE
console.log('📝 PUT Model Schema Request:');
console.log('  SchemaId:', schemaId);
console.log('  TxnId:', txnId);
console.log('  URL:', url);
console.log('  ETag:', etag);
console.log('  Body:', JSON.stringify({...}, null, 2));

// DELETE (с soft delete fallback)
console.log('🗑️ DELETE Model Schema Request:');
console.log('  SchemaId:', schemaId);
console.log('  TxnId:', txnId);
console.log('  URL:', url);
console.log('  ETag:', etag);

// При soft delete:
console.log('ℹ️ Hard delete not supported, trying soft delete (state: "deleted")');
console.log('📝 Soft delete: updating state to "deleted"');
console.log('✅ Model schema soft deleted (state: "deleted")');
```

## 📝 Permissions

Edit и Delete доступны для:
- ✅ **Portal.SuperUser** (полный доступ)
- ✅ **Portal.Admin** (read/write)
- ✅ **Portal.Developer** (read/write)
- ❌ **Portal.ViewOnlySuperUser** (read-only)
- ❌ **Portal.Viewer** (read-only)

## ✅ Testing Checklist

- [x] UPDATE: `id` включен в объект `Txn`
- [x] UPDATE: ETag передается в `If-Match` header
- [x] UPDATE: Таблица обновляется после успешного изменения
- [x] DELETE: `TxnType=ModelSchema` добавлен в query параметры
- [x] DELETE: ETag передается в `If-Match` header
- [x] DELETE: Подтверждение удаления через AlertDialog
- [x] DELETE: Таблица обновляется после успешного удаления
- [x] Error handling: Отображение ошибок через toast
- [x] Permissions: Кнопки доступны только для нужных ролей
- [x] Console logging: Полная информация о запросах

## 🎯 Result

**CRUD операции для Model Schema**:
- ✅ **C**reate - POST `/txns` with `TxnType: "ModelSchema"`
- ✅ **R**ead - GET `/txns?TxnType=ModelSchema`
- ✅ **U**pdate - PUT `/txns/{TxnId}` with `Txn.id` (FIXED)
- ✅ **D**elete - **Soft Delete** via PUT with `state: "deleted"` (FIXED)

## 🔄 Soft Delete Workflow

```
User clicks Delete
    ↓
Try DELETE /txns/{TxnId}
    ↓
API returns "Unsupported TxnType"
    ↓
Fetch current schema (GET)
    ↓
Update with state: "deleted" (PUT)
    ↓
Schema marked as deleted in database
    ↓
UI filters out deleted schemas
    ↓
User sees schema removed from table
```

## ⚠️ Important Notes

1. **ModelSchema не поддерживает hard delete** - это правильное поведение для схем данных
2. **Soft delete** - лучшая практика для схем, так как на них могут ссылаться другие данные
3. **UI автоматически скрывает** схемы со `state: "deleted"`
4. **Схемы остаются в базе** и могут быть восстановлены через API (изменив state обратно)

## 🔮 Future Enhancements

Возможные улучшения:
- [ ] Кнопка "Show Deleted" для просмотра удаленных схем
- [ ] Функция "Restore" для восстановления удаленных схем
- [ ] Bulk operations (удаление нескольких схем)
- [ ] История изменений схем (audit log)

---

**Статус**: Готово к использованию! 🎉

Last Updated: Oct 29, 2025
