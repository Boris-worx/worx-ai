# Model Schema Protected Types

## Overview
Добавлена защита системных типов в Global Transaction Spec от редактирования и удаления.

## Protected Types
Следующие типы моделей защищены и **не могут быть изменены или удалены**:
- **Customer** - Базовый тип для клиентов
- **Location** - Базовый тип для локаций

## What Changed

### Visual Indicators
1. **Lock Icon** - Защищенные типы отображаются с иконкой замка 🔒 рядом с названием модели
2. **Tooltip** - При наведении на иконку замка показывается пояснение "Protected system type - cannot be edited or deleted"

### Disabled Actions
Для защищенных типов:
- ✅ **View** - доступен (можно просматривать схему)
- ❌ **Edit** - заблокирован с tooltip пояснением
- ❌ **Delete** - заблокирован с tooltip пояснением

## Implementation Details

### Code Location
`/components/ModelSchemaView.tsx`

### Key Changes
1. Добавлен массив `PROTECTED_TYPES` с защищенными типами
2. Функция `isProtectedType()` для проверки защищенности
3. Импортирован компонент `Lock` из lucide-react
4. Импортирован компонент `Tooltip` из shadcn/ui
5. Обновлен рендеринг колонки `model` для отображения Lock icon
6. Обновлены функции `actions` и `actionsCompact` для условной блокировки кнопок

### Protected Types Array
```typescript
const PROTECTED_TYPES = ['Customer', 'Location'];
const isProtectedType = (modelName: string): boolean => {
  return PROTECTED_TYPES.includes(modelName);
};
```

## User Experience

### Desktop View
- Кнопки Edit и Delete отображаются как disabled с tooltip
- Lock icon рядом с названием модели
- Hover на Lock icon показывает пояснение

### Mobile View (Compact)
- Icon-only кнопки отображаются как disabled
- Tooltip доступен при нажатии/hover
- Сохранена консистентность с desktop версией

## Why These Types Are Protected

### Customer
- Базовый стандартный тип для всех customer-related транзакций
- Используется как основа для многих бизнес-процессов
- Изменение может нарушить существующие транзакции

### Location
- Базовый стандартный тип для всех location-related данных
- Критичен для географической привязки транзакций
- Изменение может привести к несовместимости данных

## Benefits

### 1. Data Integrity
- Защита критичных системных типов от случайного изменения
- Предотвращение breaking changes в production

### 2. Clear Communication
- Визуальная индикация защищенных типов
- Понятные tooltip сообщения для пользователей

### 3. Consistent UX
- Единообразная логика для desktop и mobile
- Disabled кнопки вместо скрытых для лучшего UX

## Testing

### Test Scenarios
1. ✅ Попытка редактирования Customer - кнопка disabled
2. ✅ Попытка удаления Customer - кнопка disabled
3. ✅ Попытка редактирования Location - кнопка disabled
4. ✅ Попытка удаления Location - кнопка disabled
5. ✅ Просмотр Customer/Location - работает нормально
6. ✅ Другие типы - Edit/Delete доступны как обычно
7. ✅ Lock icon отображается только для protected types
8. ✅ Tooltip показывает правильное сообщение

### Manual Testing
```bash
1. Перейти на вкладку "Global Transaction Spec"
2. Найти записи Customer и Location
3. Проверить наличие Lock icon
4. Навести на Lock icon - проверить tooltip
5. Проверить что кнопки Edit и Delete disabled
6. Навести на disabled кнопки - проверить tooltip
7. Проверить что View работает нормально
8. Проверить что другие типы редактируются как обычно
```

## Future Enhancements

### Potential Additions
- Конфигурируемый список защищенных типов из API
- Разные уровни защиты (read-only fields vs full protection)
- Audit log для попыток изменения защищенных типов
- Permission-based protection (SuperUser может редактировать)

### Configuration Option
```typescript
// Future: Load from API or config
const getProtectedTypes = async (): Promise<string[]> => {
  // Could be loaded from backend configuration
  return ['Customer', 'Location', 'Product', ...];
};
```

## Related Files
- `/components/ModelSchemaView.tsx` - Main implementation
- `/components/ui/tooltip.tsx` - Tooltip component
- `/lib/api.ts` - API functions (updateModelSchema, deleteModelSchema)

## Notes
- Защита применяется только на UI уровне
- Backend API все еще может принимать изменения (если вызывается напрямую)
- Рекомендуется добавить аналогичную защиту на API уровне для полной безопасности

---
**Last Updated:** December 2024  
**Status:** ✅ Implemented and Ready for Testing
