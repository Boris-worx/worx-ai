# Исправление API Endpoints для Applications и TransactionSpec

## Проблема

Возникали ошибки при загрузке Applications и Transaction Specifications:

```
❌ Unexpected error fetching applications: Error: TxnType query parameter is required.
❌ Unexpected error fetching transaction specifications: Error: TxnType query parameter is required.
```

## Причина

Функции `getApplications()` и `getTransactionSpecifications()` в `/lib/api.ts` неправильно передавали параметр `TxnType` в API:

**Было (неправильно):**
```typescript
// Передавали TxnType через Filters как JSON
const filters: any = { TxnType: 'Application' };
const filtersParam = encodeURIComponent(JSON.stringify(filters));
url += `?Filters=${filtersParam}`;
```

**Стало (правильно):**
```typescript
// Передаем TxnType как обычный query параметр
let url = `${API_BASE_URL}/txns?TxnType=Application`;
```

## Исправления

### 1. Функция `getApplications()` (строка ~3001)

✅ **Изменено:**
- Заменили `?Filters={...}` на `?TxnType=Application`
- Добавили `&TenantId=...` как отдельный query параметр
- Исправили обработку BFS API response: `responseData.data.Txns` вместо `data.data.txns`
- Добавили логирование для отладки

### 2. Функция `getTransactionSpecifications()` (строка ~3457)

✅ **Изменено:**
- Заменили `?Filters={...}` на `?TxnType=TransactionSpec`
- Добавили `&TenantId=...` как отдельный query параметр
- Исправили обработку BFS API response: `responseData.data.Txns` вместо `data.data.txns`
- Добавили клиентскую фильтрацию по `ApplicationId` (если API не поддерживает nested field filtering)

## Формат BFS API Response

Теперь правильно обрабатываем ответ от BFS API:

```typescript
{
  status: {
    code: 200,
    message: "Success"
  },
  data: {
    TxnType: "Application",
    Txns: [
      {
        TxnId: "Application:app-123",
        TxnType: "Application",
        Txn: {
          ApplicationId: "app-123",
          ApplicationName: "My App",
          TenantId: "tenant1",
          // ... остальные поля
        },
        CreateTime: "2024-01-01T00:00:00Z",
        _etag: "...",
        // ... metadata
      }
    ]
  }
}
```

## Тестирование

После исправления проверьте:

1. ✅ Applications загружаются без ошибок
2. ✅ Transaction Specifications загружаются без ошибок
3. ✅ Фильтрация по TenantId работает
4. ✅ Фильтрация Transaction Specs по ApplicationId работает (client-side)
5. ✅ При недоступности API используются mock данные

## Console Output

Теперь в консоли должны видеть:

```
🔍 GET Applications Request (via /txns):
  URL: https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/txns?TxnType=Application
  TenantId: tenant1
📦 Applications API response: {...}
✅ Fetched applications from /txns: 3

🔍 GET Transaction Specifications Request (via /txns):
  URL: https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/txns?TxnType=TransactionSpec
  ApplicationId: app-123
  TenantId: tenant1
📦 Transaction Specifications API response: {...}
✅ Fetched transaction specifications from /txns: 5
```

## Статус

✅ **Исправлено** - Applications и Transaction Specifications теперь загружаются через правильные BFS API endpoints с корректными query параметрами.
