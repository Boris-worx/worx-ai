# Technical Development Details

## Project Overview

**BFS Transaction and Data Management** is a full-featured web application for managing tenants (suppliers) and ERP transactions on the BFS (Business Financial Services) platform. The application provides an intuitive interface for working with data through a RESTful API and supports full CRUD operation lifecycle.

## Technology Stack

### Core Stack

#### Frontend Framework
- **React 18** - Modern library for building user interfaces
- **TypeScript** - Static typing for improved code reliability
- **Vite** - Fast build tool and next-generation dev server

#### Styling & UI
- **Tailwind CSS v4.0** - Utility-first CSS framework for rapid development
- **shadcn/ui** - Collection of high-quality, accessible React components
  - 40+ ready-to-use components (Button, Dialog, Table, Card, Badge, etc.)
  - Fully customizable with dark theme support
  - Built on Radix UI for maximum accessibility

#### State Management & Data Fetching
- **React Hooks** (useState, useEffect, useMemo) - built-in state management
- **Native Fetch API** - for HTTP requests to BFS API
- **Sonner** - Toast notifications for user feedback

#### Icons & Assets
- **Lucide React** - Icons for common UI elements
- **Custom SVG Icons** - Custom icons for branding and specific functions
  - TenantsIcon, GridIcon, ListIcon
  - BugIcon, MoonIcon, SunIcon
  - SearchIcon, ViewIcon, EditIcon, DeleteIcon, RefreshIcon

### API Integration

#### BFS API
- **Base URL**: `https://dp-eastus-poc-txservices-apis.azurewebsites.net`
- **Authentication**: Custom header `X-BFS-Auth` with token
- **Endpoints**:
  - `/Tenant` - tenant management
  - `/Transaction?TxnType={type}` - transaction management by type
- **ETag Support** - optimistic locking for PUT/DELETE operations
- **CORS Configuration** - configured on API side for frontend integration

#### Transaction Types
The application supports 10 ERP transaction types:
- Customer, Vendor, Employee, Invoice
- PurchaseOrder, SalesOrder, Item, Account
- JournalEntry, Payment

## Application Architecture

### Component Structure

```
App.tsx (Root)
├── Header
│   ├── Logo (WTS Paradigm Builder SVG)
│   ├── Navigation (Desktop)
│   │   ├── Tenants Tab
│   │   ├── Transaction Onboarding Tab
│   │   └── Data Plane Tab
│   └── Actions
│       ├── Bug Report Button
│       ├── Theme Toggle
│       └── Mobile Menu
├── Main Content
│   ├── TenantsView
│   │   ├── DataTable
│   │   ├── TenantDetail Dialog
│   │   ├── TenantEditForm Dialog
│   │   └── TenantImportDialog
│   ├── ModelSchemaView (Transaction Onboarding)
│   │   └── TransactionBuilder
│   │       ├── Type Selector
│   │       ├── Dynamic Form
│   │       └── JSON Preview
│   └── TransactionsView (Data Plane)
│       ├── Type Selector Sidebar
│       ├── DataTable
│       ├── TransactionDetail Dialog
│       ├── TransactionEditDialog
│       └── Actions (View/Edit/Delete)
└── Footer
    ├── Powered By Paradigm Logo
    └── Copyright
```

### Key Components

#### 1. **DataTable** (Universal Table Component)
```typescript
interface DataTableProps<T> {
  data: T[];
  columns: ColumnDef<T>[];
  renderActions?: (row: T) => React.ReactNode;
  searchPlaceholder?: string;
  isLoading?: boolean;
}
```
- Search across all fields
- Pagination
- Responsive design
- Custom renderers for columns
- Actions for each row

#### 2. **TenantsView**
- CRUD operations for tenants
- Import from JSON/CSV
- Data validation (TenantId, CompanyName required)
- Auto-refresh after operations
- Sort by creation date

#### 3. **TransactionsView**
- View transactions by type
- Dynamic loading of type counters
- ETag-based edit/delete operations
- Status and location display
- Compact layout for large data volumes

#### 4. **ModelSchemaView / TransactionBuilder**
- Create transactions without code
- Dynamic form generation based on type
- Real-time JSON preview
- Validation before submission
- Support for nested objects

#### 5. **Theme System**
- Light/Dark modes
- Switcher in header
- State persistence in component
- CSS Variables for customization

### API Layer (`/lib/api.ts`)

```typescript
// Core types
interface Tenant {
  TenantId: string;
  CompanyName: string;
  Industry?: string;
  // ... other fields
}

interface Transaction {
  TxnId: string;
  TxnType: string;
  Txn: any; // Dynamic structure
  CreateTime: string;
  _etag?: string;
}

// API functions
- getAllTenants(): Promise<Tenant[]>
- createTenant(tenant: Omit<Tenant, 'CreateTime'>): Promise<Tenant>
- updateTenant(id: string, tenant: any, etag: string): Promise<void>
- deleteTenant(id: string, etag: string): Promise<void>

- getTransactionsByType(txnType: string): Promise<Transaction[]>
- createTransaction(txnType: string, txnData: any): Promise<Transaction>
- updateTransaction(id: string, txnType: string, data: any, etag: string): Promise<void>
- deleteTransaction(id: string, txnType: string, etag: string): Promise<void>
```

#### Error Handling
- CORS blocking - special message
- Network errors - retry logic
- Validation errors - display in form
- API errors - toast notifications

## Design System

### Color Palette

```css
/* Brand colors */
--primary-blue: #1D6BCD;
--primary-blue-hover: #1858A8;
--background: #f4f6f8;

/* Dark theme */
--dark-bg: #1a1a1a;
--dark-card: #2a2a2a;
```

### Typography

- **Headings**: IBM Plex Sans
  - H1: 38px (desktop), 24px (mobile)
  - Weights: 400, 500, 600, 700
  
- **Body Text**: Inter
  - Body: 14-16px
  - Labels: 12-14px
  - Weights: 400, 500, 600

### UI Patterns

#### Buttons
```css
.button {
  display: flex;
  padding: 8px 16px;
  gap: 6px;
  border-radius: 4px;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
}

.button-primary {
  background: #1D6BCD;
  color: white;
}

.button-primary:hover {
  background: #1858A8;
}
```

#### Cards
- Border radius: 8px
- Shadow: subtle drop shadow
- Padding: 24px (desktop), 16px (mobile)

#### Badges
- Status badges: blue for "Active"
- Size: xs (text-xs)
- Padding: 4px 8px

## Implementation Features

### 1. Responsive Design
- **Mobile-first approach**
- Breakpoints: 
  - Mobile: < 768px
  - Desktop: ≥ 768px
- Adaptive navigation with hamburger menu
- Hide/show columns in tables
- Responsive dialogs

### 2. Performance Optimization
- **useMemo** for filtering and sorting data
- Lazy loading transactions by type
- Debouncing for search
- Virtualization of long lists via shadcn ScrollArea

### 3. Accessibility (A11y)
- Semantic HTML
- ARIA labels for icon buttons
- Keyboard navigation
- Focus management in dialogs
- Screen reader friendly

### 4. Error Handling
```typescript
// Centralized error handling
const handleApiError = (error: any) => {
  if (error.message === 'CORS_BLOCKED') {
    toast.error('Cannot connect to API');
  } else if (error.message === 'Unsupported TxnType') {
    // Silent handling
  } else {
    toast.error(`Error: ${error.message}`);
  }
};
```

### 5. Data Validation
- Client-side validation before submission
- Required fields: TenantId, CompanyName (for tenants)
- Format validation for JSON import
- Type checking with TypeScript

## Data Import

### Formats
1. **Simple JSON** - simplified format for quick import
2. **API Format JSON** - full API format with metadata
3. **CSV** - tabular format with header mapping

### Import Validation
- File format verification
- Required field validation
- Deduplication by TenantId
- Preview before import

## Security

### API Security
- **X-BFS-Auth header** - authentication token
- **ETag validation** - conflict prevention
- **CORS policy** - only allowed origins
- **HTTPS only** - traffic encryption

### Client-side
- No sensitive data storage
- Environment variables for configuration
- User input sanitization

## Testing & Quality

### Testing
- Manual testing of all user flows
- API endpoint testing via Postman
- Cross-browser compatibility (Chrome, Firefox, Safari, Edge)
- Mobile device testing

### Code Quality
- TypeScript strict mode
- ESLint for linting
- Prettier for formatting
- Consistent code style

## Deployment

### Build Process
```bash
# Development
npm run dev

# Production build
npm run build

# Preview production build
npm run preview
```

### Build Output
- Optimized JS bundles
- Minified CSS
- Tree-shaking for unused code
- Code splitting for better loading

### Hosting Options
- **Vercel** - recommended (native Vite support)
- **Netlify** - alternative
- **Azure Static Web Apps** - for enterprise
- **GitHub Pages** - for static hosting

## Documentation

### Technical Documentation
- `API_CONNECTION_INFO.md` - API connection details
- `ARCHITECTURE_DIAGRAM.md` - architecture diagrams
- `TECH_STACK.md` - technology overview
- `PROJECT_STRUCTURE.md` - project structure

### User Documentation
- `QUICK_START.md` - quick start guide
- `TENANT_IMPORT_GUIDE.md` - tenant import guide
- `TRANSACTION_BUILDER_GUIDE.md` - transaction creation
- `USER_STORIES.md` - user scenarios

### Developer Guides
- `CONTRIBUTING.md` - how to contribute
- `API_DEBUGGING_GUIDE.md` - API debugging
- `CORS_FIX_FOR_DEVELOPER.md` - CORS troubleshooting

## Versioning and Git

### Repository Structure
```
main branch
├── feature/* - new features
├── bugfix/* - bug fixes
└── docs/* - documentation updates
```

### Commit Convention
```
feat: added new feature
fix: fixed bug
docs: updated documentation
style: styling changes
refactor: code refactoring
test: added tests
chore: dependency updates
```

## Future Improvements

### Planned Features
- [ ] Batch operations for tenants/transactions
- [ ] Advanced filtering and sorting
- [ ] Export to Excel/PDF
- [ ] Audit log for tracking changes
- [ ] User authentication and authorization
- [ ] Real-time updates via WebSockets
- [ ] Offline mode with sync
- [ ] Multi-language support

### Technical Improvements
- [ ] Unit and integration tests
- [ ] E2E tests with Playwright
- [ ] Performance monitoring
- [ ] Error tracking (Sentry)
- [ ] Analytics (GA4)
- [ ] CI/CD pipeline
- [ ] Docker containerization

## Conclusion

The application is built using modern best practices and provides reliable, scalable, and maintainable code. The architecture allows easy addition of new features and integration of additional API endpoints.

### Key Achievements
✅ Full CRUD for tenants and transactions  
✅ Responsive design for all devices  
✅ Dark/light themes  
✅ Data import from multiple formats  
✅ Real-time validation and feedback  
✅ Performant and optimized  
✅ Accessible and user-friendly  
✅ Complete documentation  

---

**Built with**: React, TypeScript, Tailwind CSS, Vite, shadcn/ui  
**API**: BFS Transaction Services  
**Date**: October 2025  
**Version**: 1.0.0
