# Apicurio Registry - Real Data Only 🎯

## Quick Summary

**NO MOCK DATA** - The system now works exclusively with real data from Apicurio Registry.

## Two Groups Only

### 📦 paradigm.bidtools2
```
https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/paradigm.bidtools2/artifacts/
```
- CDC_SQLServer_* templates
- TxServices_SQLServer_* templates

### 📦 bfs.online
```
https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/bfs.online/artifacts/
```
- TxServices_Informix_* templates (loc, loc1, stcode, inv, inv1, inv2, inv3, invap, invdes, invloc, keyi)

## What Changed

### ❌ Removed
- All mock artifacts (18 items)
- All mock schemas (11 different types)
- ~1,105 lines of mock data code
- Fallback to mock data on errors

### ✅ Kept
- Dynamic API integration
- Caching mechanism (30 min)
- Version detection
- Error handling
- Schema processing (AVRO/JSON)

## Behavior

### Success Case
1. Loads templates from Apicurio Registry
2. Shows only real artifacts from the two groups
3. Uses cache for 30 minutes

### Error Case
1. **With cache**: Uses expired cache data
2. **No cache**: Returns empty list
3. **On template load error**: Shows error toast to user

## Cache Strategy

```typescript
// Cache duration: 30 minutes
// Storage: localStorage + in-memory
// Fallback: expired cache on API error
// Clear: on demand via clearArtifactsCache()
```

## Known Groups (Hardcoded Fallback)

```typescript
const KNOWN_GROUPS = [
  { id: 'paradigm.bidtools2', description: 'Bid Tools Templates' },
  { id: 'bfs.online', description: 'BFS Online Templates' },
];
```

Used only when:
- API returns 403 Forbidden
- API returns error
- Filtering API response to our groups only

## API Functions

All functions now work with real data only:

```typescript
// Get groups (filtered to our two groups)
getApicurioGroups(): Promise<ApicurioGroup[]>

// Get artifacts from a group
getGroupArtifacts(groupId: string): Promise<ApicurioArtifact[]>

// Get artifact versions
getArtifactVersions(groupId, artifactId): Promise<ApicurioVersion[]>

// Get artifact schema (throws error if not found)
getApicurioArtifact(groupId, artifactId, version?): Promise<any>

// Search all artifacts (from both groups)
searchApicurioArtifacts(namePattern?): Promise<ApicurioSearchResponse>
```

## Error Handling

### Before (with mock data)
```typescript
if (error) {
  return getMockData(); // ❌ Silent fallback
}
```

### Now (real data only)
```typescript
if (error) {
  // Use cache if available
  if (cache) return cache;
  
  // Otherwise throw/return empty
  throw new Error('...');
  // or return { artifacts: [], count: 0 };
}
```

## Testing Checklist

### Basic Flow
- [ ] Open Data Source Onboarding → Create from Template
- [ ] Verify only real templates are shown
- [ ] Select a template from paradigm.bidtools2
- [ ] Select a template from bfs.online
- [ ] Verify schema loads from Apicurio

### Cache Testing
- [ ] Open dialog (loads from API)
- [ ] Close and reopen (uses cache)
- [ ] Wait 30 minutes (cache expires)
- [ ] Open again (reloads from API)

### Error Testing
- [ ] Disconnect internet
- [ ] Open dialog with cache (should work)
- [ ] Clear localStorage
- [ ] Open dialog without cache (should show error/empty)

## Files Changed

1. `/lib/apicurio.ts` - Complete rewrite (795 lines, down from ~1,900)
2. `/components/DataCaptureSpecCreateDialog.tsx` - Updated comments

## Impact

### Positive ✅
- No fake data confusion
- Smaller bundle size
- Clearer error messages
- Real data only = real testing

### Negative ⚠️
- Requires Apicurio Registry to be accessible
- No offline fallback (except cache)
- Errors are visible to users

## Console Messages

### Success
```
📦 Fetching all groups from: ...
📦 Found 2 groups: paradigm.bidtools2, bfs.online
📦 ✅ Loaded 7 artifacts from paradigm.bidtools2
📦 ✅ Loaded 11 artifacts from bfs.online
📦 ✅ Total artifacts loaded: 18 from 2 groups
```

### With Cache
```
📦 Using cached Apicurio artifacts (age: 120 seconds)
```

### Error (no cache)
```
❌ Apicurio Registry error: Failed to fetch
❌ No artifacts available and no cache. Apicurio Registry is unavailable.
```

### Error (with cache)
```
❌ Apicurio Registry error: Failed to fetch
📦 Using expired cache data due to API error
```

## Quick Reference

| Scenario | Before | Now |
|----------|--------|-----|
| API works | Real data | Real data ✅ |
| API 403 | Mock data | Error or cache |
| API 404 | Mock data | Error or cache |
| Network error | Mock data | Cache or empty |
| Cache available | Real/Mock | Cache ✅ |
| No cache + error | Mock data | Empty list ⚠️ |

---

**Status**: ✅ Complete  
**Date**: November 28, 2024  
**No Mock Data**: Guaranteed 🎯
