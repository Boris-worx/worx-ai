# 🏗️ Визуальная архитектура Transaction Hub & Data Plane

---

## 📱 Структура приложения

```
┌─────────────────────────────────────────────────────────────────┐
│                    🏢 BFS Management Platform                    │
│                  Transaction Hub & Data Plane                    │
└─────────────────────────────────────────────────────────────────┘

                    ┌──────────────────────┐
                    │   RBAC & Auth        │
                    │  5 Roles System      │
                    └──────────────────────┘
                             │
          ┌──────────────────┼──────────────────┐
          │                  │                  │
    Global Tenant    Tenant-Specific    Tenant Isolation
   (Paradigm)         (BFS, etc.)       (PartitionKey)
```

---

## 🗂️ Пять вкладок (Navigation Tabs)

```
┌────────────────────────────────────────────────────────────────────┐
│  [Tenants]  [Transactions]  [Applications]  [Data Sources]  [Data Plane]  │
└────────────────────────────────────────────────────────────────────┘
     │             │                │               │              │
     ✅            ✅               ✅              ✅             ✅
   ГОТОВО       ГОТОВО          ГОТОВО          ГОТОВО         ГОТОВО
```

---

## 1️⃣ Tenants Tab

```
┌──────────────────────────────────────────────────────────────┐
│  📋 TENANTS (или "My Tenant" для tenant-specific users)      │
├──────────────────────────────────────────────────────────────┤
│                                                               │
│  [+ Add Tenant]  [Import JSON]  [Refresh]  [Column Selector] │
│                                                               │
│  ┌──────────────────────────────────────────────────────┐   │
│  │ Tenant ID      │ Tenant Name      │ Created  │ ...   │   │
│  ├──────────────────────────────────────────────────────┤   │
│  │ tenant-1       │ Paradigm         │ 2024-... │ [Actions] │
│  │ tenant-2       │ BFS              │ 2024-... │ [Actions] │
│  │ tenant-3       │ Smith Douglas    │ 2024-... │ [Actions] │
│  └──────────────────────────────────────────────────────┘   │
│                                                               │
│  Actions: 👁️ View  ✏️ Edit  🗑️ Delete                      │
└──────────────────────────────────────────────────────────────┘

API: /tenants (GET, POST, PUT, DELETE)
```

---

## 2️⃣ Transactions Tab (ModelSchemaView)

```
┌──────────────────────────────────────────────────────────────┐
│  📊 TRANSACTIONS                                              │
│  (Data Capture Specifications / Model Schemas)               │
├──────────────────────────────────────────────────────────────┤
│                                                               │
│  [Tenant: Global ▼]  [+ Add Spec]  [Column Selector]         │
│                                                               │
│  ┌──────────────────────────────────────────────────────┐   │
│  │ Model     │ Version │ State  │ Properties │ ...      │   │
│  ├──────────────────────────────────────────────────────┤   │
│  │ Customer  │ 1       │ active │ {...}      │ [Actions] │  │
│  │ Location  │ 1       │ active │ {...}      │ [Actions] │  │
│  │ Quote     │ 2       │ active │ {...}      │ [Actions] │  │
│  └──────────────────────────────────────────────────────┘   │
│                                                               │
│  Actions: 👁️ View JSON  ✏️ Edit  🗑️ Delete                 │
│  Protected Types: 🔒 Customer, Location (cannot delete)      │
└──────────────────────────────────────────────────────────────┘

API: /1.0/txns?TxnType=ModelSchema
```

---

## 3️⃣ Data Sources Tab

```
┌──────────────────────────────────────────────────────────────┐
│  📁 DATA SOURCES                                              │
│  (Data Source Onboarding)                                    │
├──────────────────────────────────────────────────────────────┤
│                                                               │
│  [Tenant: Global ▼]  [+ Add Source]  [Refresh]  [Columns]    │
│                                                               │
│  ┌──────────────────────────────────────────────────────┐   │
│  │ ▶ Bidtools     │ TenantId    │ Active  │ 2024-...    │   │
│  │   └─ Data Capture Specs (expandable):                 │   │
│  │      ┌────────────────────────────────────────┐       │   │
│  │      │ Table  │ Version │ Date   │ Actions    │       │   │
│  │      ├────────────────────────────────────────┤       │   │
│  │      │ Quote  │ 1.0     │ ...    │ 👁️ ✏️ 🗑️   │       │   │
│  │      │ Order  │ 1.0     │ ...    │ 👁️ ✏️ 🗑️   │       │   │
│  │      └────────────────────────────────────────┘       │   │
│  │                                                         │   │
│  │ ▶ Databricks   │ TenantId    │ Active  │ 2024-...    │   │
│  │ ▶ SAP          │ TenantId    │ Active  │ 2024-...    │   │
│  └──────────────────────────────────────────────────────┘   │
│                                                               │
│  Data Capture Specs: 👁️ View  ✏️ Edit  🗑️ Delete  ➕ Add    │
└──────────────────────────────────────────────────────────────┘

API: 
- /datasources (GET, POST, PUT, DELETE)
- /1.0/txns?TxnType=DataCaptureSpec&DatasourceId={id}
```

---

## 4️⃣ Applications Tab ⭐ ГЛАВНАЯ ВКЛАДКА

```
┌──────────────────────────────────────────────────────────────┐
│  📱 APPLICATIONS                                              │
│  (Application Onboarding + Transaction Specifications)       │
├──────────────────────────────────────────────────────────────┤
│                                                               │
│  [Tenant: Global ▼]  [+ Add Application]  [Refresh]  [Cols]  │
│                                                               │
│  ┌──────────────────────────────────────────────────────┐   │
│  │ ▶ myBLDR       │ v2.0  │ Active │ 2024-... │ [Actions] │  │
│  │   └─ Transaction Specifications (expandable):          │  │
│  │      ┌────────────────────────────────────────┐        │  │
│  │      │ Spec Name      │ Ver │ Status │ Actions │       │  │
│  │      ├────────────────────────────────────────┤        │  │
│  │      │ Customer Data  │ 1.0 │ Active │ 👁️ ✏️ 🗑️│       │  │
│  │      │ Quote Data     │ 1.0 │ Active │ 👁️ ✏️ 🗑️│       │  │
│  │      │ Order Data     │ 2.0 │ Active │ 👁️ ✏️ 🗑️│       │  │
│  │      │                │     │        │ ➕ Add  │       │  │
│  │      └────────────────────────────────────────┘        │  │
│  │                                                          │  │
│  │ ▶ Will Call    │ v1.5  │ Active │ 2024-... │ [Actions] │  │
│  │   └─ Transaction Specifications:                        │  │
│  │      ┌────────────────────────────────────────┐        │  │
│  │      │ Inventory Data │ 1.0 │ Active │ 👁️ ✏️ 🗑️│       │  │
│  │      │                │     │        │ ➕ Add  │       │  │
│  │      └────────────────────────────────────────┘        │  │
│  └──────────────────────────────────────────────────────┘   │
│                                                               │
│  Transaction Specs Actions:                                  │
│  - 👁️ View (JSON Schema)                                    │
│  - ✏️ Edit (Update schema)                                  │
│  - 🗑️ Delete                                                │
│  - ➕ Add New Transaction Specification                      │
└──────────────────────────────────────────────────────────────┘

APIs:
- Applications: /1.0/txns?TxnType=Application
- Transaction Specs: /1.0/txns?TxnType=TransactionSpec&ApplicationId={id}

CRUD Operations:
✅ Create Application
✅ Read Applications
✅ Update Application
✅ Delete Application
✅ Create Transaction Specification ← КЛЮЧЕВАЯ ФУНКЦИОНАЛЬНОСТЬ!
✅ Read Transaction Specifications
✅ Update Transaction Specification
✅ Delete Transaction Specification
```

---

## 5️⃣ Data Plane Tab

```
┌──────────────────────────────────────────────────────────────┐
│  🗄️ DATA PLANE                                               │
│  (View Transaction Data)                                     │
├──────────────────────────────────────────────────────────────┤
│                                                               │
│  [Tenant: Global ▼]  [TxnType: Quote ▼]  [Column Selector]   │
│                                                               │
│  ┌──────────────────────────────────────────────────────┐   │
│  │ ▶ Quote-001    │ BFS      │ 2024-...  │ [View]       │   │
│  │   └─ JSON Data (expandable):                          │   │
│  │      {                                                 │   │
│  │        "QuoteNumber": "Q-12345",                       │   │
│  │        "CustomerName": "ABC Corp",                     │   │
│  │        "Items": [...],                                 │   │
│  │        ...                                             │   │
│  │      }                                                  │   │
│  │                                                          │   │
│  │ ▶ Quote-002    │ BFS      │ 2024-...  │ [View]       │   │
│  │ ▶ Quote-003    │ Smith    │ 2024-...  │ [View]       │   │
│  └──────────────────────────────────────────────────────┘   │
│                                                               │
│  TxnTypes: Customer, Location, Quote                         │
└──────────────────────────────────────────────────────────────┘

API: /1.0/txns?TxnType={type}&TenantId={id}
```

---

## 🔄 Data Flow Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                        DATA FLOW                             │
└─────────────────────────────────────────────────────────────┘

1. Data Sources (ERP Systems)
   │
   │  SAP    │  Online  │  Trend  │  Bidtools
   │  (ERP)  │  (ERP)   │  (ERP)  │  (Database)
   │
   └─────────────┬────────────────────────────────────┘
                 │
                 ▼
2. Data Capture Specifications (ModelSchema)
   │
   │  Define: What data structure from ERP
   │  Example: Customer { CustomerName, CustomerNumber, ... }
   │
   └─────────────┬────────────────────────────────────┘
                 │
                 ▼
3. Transaction Hub & Data Plane
   │
   │  Store: Cosmos DB
   │  Access: Real-time API
   │
   └─────────────┬────────────────────────────────────┘
                 │
                 ▼
4. Applications (User-facing)
   │
   │  myBLDR (shopping cart for builders)
   │  Will Call (buy online, pick up in store)
   │
   └─────────────┬────────────────────────────────────┘
                 │
                 ▼
5. Transaction Specifications
   │
   │  Define: What data THIS application needs
   │  Example: myBLDR needs → Customer, Quote, Order
   │  Format: JSON Schema
   │
   └─────────────┬────────────────────────────────────┘
                 │
                 ▼
6. Data Plane (View)
   │
   │  View actual transaction data
   │  Filter by TxnType, Tenant
   │
   └───────────────────────────────────────────────────────────┘
```

---

## 🔐 RBAC Permissions Matrix

```
┌─────────────────────────────────────────────────────────────┐
│                    RBAC PERMISSIONS                          │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  Role                │ Tenants │ Trans │ Apps │ DS │ DP     │
│  ────────────────────┼─────────┼───────┼──────┼────┼─────   │
│  Portal.SuperUser    │ ✅ CRUD │ ✅ CRUD│ ✅ CRUD│ ✅ CRUD│ ✅ View │
│  (Global)            │ All     │ All   │ All  │ All│ All    │
│                      │         │       │      │    │        │
│  ViewOnlySuperUser   │ 👁️ View │ 👁️ View│ 👁️ View│ 👁️ View│ 👁️ View │
│  (Global)            │ All     │ All   │ All  │ All│ All    │
│                      │         │       │      │    │        │
│  Admin               │ ✅ Own  │ ✅ CRUD│ ✅ CRUD│ ✅ CRUD│ ✅ View │
│  (Tenant-specific)   │         │ Own   │ Own  │ Own│ Own    │
│                      │         │       │      │    │        │
│  Developer           │ ✅ Own  │ ✅ CRUD│ ✅ CRUD│ ✅ CRUD│ ✅ View │
│  (Tenant-specific)   │         │ Own   │ Own  │ Own│ Own    │
│                      │         │       │      │    │        │
│  Viewer              │ 👁️ Own  │ 👁️ View│ 👁️ View│ 👁️ View│ 👁️ View │
│  (Tenant-specific)   │         │ Own   │ Own  │ Own│ Own    │
│                      │         │       │      │    │        │
└─────────────────────────────────────────────────────────────┘

Legend:
- ✅ CRUD = Create, Read, Update, Delete
- 👁️ View = Read-only
- All = Access to all tenants
- Own = Access to own tenant only
- Trans = Transactions (ModelSchema)
- DS = Data Sources
- DP = Data Plane
```

---

## 📁 File Structure

```
/
├── App.tsx                              ← Main entry point
├── components/
│   ├── AuthContext.tsx                  ← RBAC logic
│   ├── LoginDialog.tsx                  ← Authentication
│   ├── TenantSelector.tsx               ← Tenant switcher
│   │
│   ├── TenantsView.tsx                  ← Tab 1: Tenants
│   ├── ModelSchemaView.tsx              ← Tab 2: Transactions (ModelSchema)
│   ├── ApplicationsView.tsx             ← Tab 4: Applications ⭐
│   │   ├── TransactionSpecificationDialog.tsx       ← Create/Edit Spec
│   │   └── TransactionSpecificationViewDialog.tsx   ← View Spec
│   ├── DataSourcesView.tsx              ← Tab 3: Data Sources
│   ├── TransactionsView.tsx             ← Tab 5: Data Plane
│   │
│   ├── DataTable.tsx                    ← Reusable table
│   ├── ColumnSelector.tsx               ← Column config
│   └── ui/                              ← shadcn/ui components
│
└── lib/
    ├── api.ts                           ← ALL API functions ⭐
    └── apicurio-utils.ts                ← Apicurio Registry
```

---

## 🔌 API Endpoints Summary

```
┌─────────────────────────────────────────────────────────────┐
│                      API ENDPOINTS                           │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  BASE URL: https://dp-eastus-poc-txservices-apis.           │
│            azurewebsites.net/1.0                             │
│                                                               │
│  Header: X-BFS-Auth: {your-auth-key}                        │
│                                                               │
├─────────────────────────────────────────────────────────────┤
│  TENANTS:                                                    │
│    GET    /tenants           - List all tenants             │
│    POST   /tenants           - Create tenant                │
│    GET    /tenants/{id}      - Get tenant details           │
│    PUT    /tenants/{id}      - Update tenant                │
│    DELETE /tenants/{id}      - Delete tenant                │
│                                                               │
├─────────────────────────────────────────────────────────────┤
│  DATA SOURCES:                                               │
│    GET    /datasources       - List data sources            │
│    POST   /datasources       - Create data source           │
│    PUT    /datasources/{id}  - Update data source           │
│    DELETE /datasources/{id}  - Delete data source           │
│                                                               │
├─────────────────────────────────────────────────────────────┤
│  TRANSACTIONS (Universal endpoint):                          │
│    GET    /1.0/txns?TxnType={type}                          │
│    POST   /1.0/txns          - Create with TxnType          │
│    PUT    /1.0/txns/{id}     - Update with TxnType          │
│    DELETE /1.0/txns/{id}     - Delete                       │
│                                                               │
│  TxnTypes:                                                   │
│    - ModelSchema         (Data Capture Specifications)      │
│    - DataCaptureSpec     (Specs for Data Sources)           │
│    - Application         (Applications) ⭐                   │
│    - TransactionSpec     (Transaction Specifications) ⭐     │
│    - Customer            (Customer data - Data Plane)       │
│    - Location            (Location data - Data Plane)       │
│    - Quote               (Quote data - Data Plane)          │
│                                                               │
└─────────────────────────────────────────────────────────────┘
```

---

## 🎯 Transaction Onboarding Flow (Main Feature)

```
┌─────────────────────────────────────────────────────────────┐
│              TRANSACTION ONBOARDING FLOW                     │
└─────────────────────────────────────────────────────────────┘

Step 1: Navigate to Applications Tab
   │
   └─→ [Applications] tab
   
Step 2: Select or Create Application
   │
   ├─→ Click [+ Add Application]
   │   └─→ Enter: Name, Version, Description, Tenant
   │   └─→ Click [Create]
   │
   └─→ Or select existing Application
   
Step 3: Add Transaction Specification
   │
   └─→ Click on Application row (expand)
       └─→ See Transaction Specifications table
           │
           ├─→ Click [+ Add Transaction Specification]
           │   └─→ Enter:
           │       - Spec Name (e.g., "Customer Data")
           │       - Version (e.g., "1.0")
           │       - Description
           │       - Status (Active/Inactive)
           │       - JSON Schema:
           │         {
           │           "$schema": "...",
           │           "title": "Customer Data for myBLDR",
           │           "type": "object",
           │           "required": ["CustomerName", "CustomerNumber"],
           │           "properties": {
           │             "CustomerName": { "type": "string" },
           │             "CustomerNumber": { "type": "string" },
           │             "CustomerContact": { "type": "string" }
           │           }
           │         }
           │   └─→ Click [Create Specification]
           │
           ├─→ View: Click 👁️ icon → See JSON Schema
           ├─→ Edit: Click ✏️ icon → Modify schema
           └─→ Delete: Click 🗑️ icon → Remove spec

Step 4: Specification is Active
   │
   └─→ Stored in Cosmos DB
   └─→ Available to Application via API
   └─→ Transaction Hub orchestrates data flow
```

---

## ✅ Checklist Summary

```
┌─────────────────────────────────────────────────────────────┐
│                    IMPLEMENTATION CHECKLIST                  │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  ✅ Tenants Tab                                              │
│     ✅ View all tenants (Global users)                       │
│     ✅ View own tenant (Tenant-specific users)               │
│     ✅ Create tenant                                         │
│     ✅ Edit tenant                                           │
│     ✅ Delete tenant                                         │
│     ✅ Import JSON                                           │
│     ✅ Real API integration                                  │
│                                                               │
│  ✅ Transactions Tab (ModelSchemaView)                       │
│     ✅ View Data Capture Specifications                      │
│     ✅ Create specification                                  │
│     ✅ Edit specification                                    │
│     ✅ Delete specification                                  │
│     ✅ JSON Schema validation                                │
│     ✅ Protected types (Customer, Location)                  │
│     ✅ Real API integration                                  │
│                                                               │
│  ✅ Data Sources Tab                                         │
│     ✅ View data sources                                     │
│     ✅ Create data source                                    │
│     ✅ Edit data source                                      │
│     ✅ Delete data source                                    │
│     ✅ Data Capture Specifications (expandable)              │
│     ✅ Apicurio Registry integration                         │
│     ✅ Real API integration                                  │
│                                                               │
│  ✅ Applications Tab ⭐ MAIN FEATURE                         │
│     ✅ View applications                                     │
│     ✅ Create application                                    │
│     ✅ Edit application                                      │
│     ✅ Delete application                                    │
│     ✅ Transaction Specifications (expandable) ⭐            │
│        ✅ View specifications                                │
│        ✅ Create specification ⭐                            │
│        ✅ Edit specification ⭐                              │
│        ✅ Delete specification ⭐                            │
│        ✅ JSON Schema editor                                 │
│        ✅ Validation                                         │
│     ✅ Real API integration                                  │
│                                                               │
│  ✅ Data Plane Tab                                           │
│     ✅ View transactions                                     │
│     ✅ Filter by TxnType                                     │
│     ✅ Expandable JSON view                                  │
│     ✅ Tenant filtering                                      │
│     ✅ Real API integration                                  │
│                                                               │
│  ✅ Cross-cutting Features                                   │
│     ✅ RBAC (5 roles)                                        │
│     ✅ Multi-tenancy                                         │
│     ✅ Global Tenant                                         │
│     ✅ Tenant isolation                                      │
│     ✅ ETag support                                          │
│     ✅ Responsive design                                     │
│     ✅ Column selector                                       │
│     ✅ Search & filter                                       │
│     ✅ Pagination                                            │
│     ✅ Error handling                                        │
│     ✅ Loading states                                        │
│     ✅ Empty states                                          │
│                                                               │
└─────────────────────────────────────────────────────────────┘
```

---

## 🎉 Final Verdict

```
╔═══════════════════════════════════════════════════════════╗
║                                                            ║
║              ✅ ВСЕ ТРЕБОВАНИЯ РЕАЛИЗОВАНЫ!               ║
║                                                            ║
║  Особенно важно:                                          ║
║  ⭐ Transaction Specifications CRUD                       ║
║     полностью функционален в Applications Tab             ║
║                                                            ║
║  Статус: ГОТОВО К PRODUCTION                              ║
║                                                            ║
╚═══════════════════════════════════════════════════════════╝
```

---

**Создано:** 14 ноября 2025  
**Версия:** 1.0
