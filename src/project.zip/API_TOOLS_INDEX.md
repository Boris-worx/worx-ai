# 🛠️ API Tools & Documentation Index

Быстрый навигатор по всем инструментам и документации для работы с BFS API.

---

## 🎯 Быстрые ссылки:

| Что нужно | Файл | Время |
|-----------|------|-------|
| **Проверить DataSource API прямо сейчас** | `test-datasources-api.html` | 2 мин |
| **Быстрая инструкция (RU)** | `БЫСТРЫЙ_СТАРТ_ПРОВЕРКА_API.md` | 3 мин |
| **Краткое руководство (RU)** | `ПРОВЕРКА_API_DATASOURCES.md` | 5 мин |
| **Полная документация (EN)** | `DATASOURCE_API_INSPECTION.md` | 10 мин |
| **Обзор всех инструментов** | `API_INSPECTION_README.md` | 7 мин |
| **История изменений** | `DATA_SOURCE_DISPLAY_UPDATE.md` | 5 мин |

---

## 📚 По типу задачи:

### 🔍 Inspection & Testing

#### DataSource API
- **`test-datasources-api.html`** - Интерактивный HTML тестер
- **`DATASOURCE_API_INSPECTION.md`** - Полное руководство по инспекции
- **`ПРОВЕРКА_API_DATASOURCES.md`** - Краткое руководство (RU)
- **`БЫСТРЫЙ_СТАРТ_ПРОВЕРКА_API.md`** - Quick start (RU)

#### Other APIs
- **`test-quote-api.html`** - Тестер для Quote API
- **`API_EXAMPLES.md`** - Примеры работы со всеми API endpoints
- **`API_DEBUGGING_GUIDE.md`** - Отладка API запросов

### 📖 General Documentation

#### API Connection
- **`API_CONNECTION_INFO.md`** - Информация о подключении к API
- **`BFS_API_SETUP.md`** - Настройка BFS API
- **`QUICK_START_BFS.md`** - Быстрый старт с BFS Platform

#### API Guides
- **`API_TRANSACTIONS_DEBUG.md`** - Отладка транзакций API
- **`CORS_FIX_FOR_DEVELOPER.md`** - Решение проблем с CORS
- **`CORS_SETUP_FOR_API_ADMIN.md`** - Настройка CORS на сервере

### 🧪 Testing & Verification

#### DataSource Testing
- **`DATASOURCE_TESTING_GUIDE.md`** - Руководство по тестированию Data Sources
- **`DATASOURCE_VERIFICATION.md`** - Чеклист проверки Data Sources
- **`DATASOURCE_FIX_SUMMARY.md`** - История исправлений

#### General Testing
- **`VERIFICATION_CHECKLIST.md`** - Общий чеклист проверки
- **`TEST_FORMATS.md`** - Тестирование форматов импорта
- **`ROLE_TESTING_GUIDE.md`** - Тестирование ролей

### 📊 Samples & Examples

#### Sample Files
- **`sample-datasources.json`** (если есть) - Примеры Data Sources
- **`sample-response.json`** - Пример ответа API
- **`sample-request.json`** - Пример запроса к API
- **`sample-transactions.json`** - Примеры транзакций
- **`sample-tenants.json`** - Примеры тенантов

#### Import Examples
- **`sample-tenants-api-format.json`** - Формат API для тенантов
- **`sample-tenants-import.json`** - Формат импорта тенантов
- **`sample-tenants-simple.json`** - Упрощенный формат

### 🔧 Code Files

#### API Layer
- **`/lib/api.ts`** - Все API функции и TypeScript интерфейсы
- **Enhanced logging in:**
  - `getAllDataSources()` - DataSources API
  - `getAllTransactions()` - Transactions API
  - `getAllTenants()` - Tenants API

#### UI Components
- **`/components/DataSourcesView.tsx`** - Data Source Onboarding UI
- **`/components/TransactionsView.tsx`** - Transaction Onboarding UI
- **`/components/TenantsView.tsx`** - Tenants UI
- **`/components/DataTable.tsx`** - Universal table with pagination

---

## 🎬 Сценарии использования:

### Scenario 1: "Хочу проверить, что возвращает DataSource API"
```
1. Открыть: test-datasources-api.html
2. Нажать: 🚀 Fetch DataSources
3. Изучить: Fields Analysis таблицу
4. Прочитать: БЫСТРЫЙ_СТАРТ_ПРОВЕРКА_API.md
```

### Scenario 2: "DataSource не отображаются правильно"
```
1. Открыть приложение + DevTools (F12)
2. Перейти на Data Source Onboarding
3. Смотреть консоль на наличие ошибок
4. Прочитать: DATASOURCE_VERIFICATION.md
5. Использовать: test-datasources-api.html для debug
```

### Scenario 3: "Нужно добавить новое поле в UI"
```
1. Проверить API: test-datasources-api.html
2. Найти новое поле в Fields Analysis
3. Обновить: /lib/api.ts (TypeScript interface)
4. Обновить: /components/DataSourcesView.tsx (columns)
5. Прочитать: DATASOURCE_API_INSPECTION.md (раздел "What to do with results")
```

### Scenario 4: "CORS ошибка при подключении к API"
```
1. Прочитать: CORS_FIX_FOR_DEVELOPER.md
2. Если админ: CORS_SETUP_FOR_API_ADMIN.md
3. Проверить: API_DEBUGGING_GUIDE.md
4. Тест через cURL в ПРОВЕРКА_API_DATASOURCES.md
```

### Scenario 5: "Нужно понять всю систему API"
```
1. Начать с: QUICK_START_BFS.md
2. Подробнее: BFS_API_SETUP.md
3. Примеры: API_EXAMPLES.md
4. Отладка: API_DEBUGGING_GUIDE.md
5. Специфика: DATASOURCE_API_INSPECTION.md
```

---

## 📋 По уровню детализации:

### ⚡ Quick Start (3-5 минут)
```
1. БЫСТРЫЙ_СТАРТ_ПРОВЕРКА_API.md
2. QUICK_START_BFS.md
3. test-datasources-api.html
```

### 📖 Medium Detail (5-10 минут)
```
1. ПРОВЕРКА_API_DATASOURCES.md
2. API_CONNECTION_INFO.md
3. DATASOURCE_TESTING_GUIDE.md
4. API_EXAMPLES.md
```

### 📚 Full Documentation (10+ минут)
```
1. DATASOURCE_API_INSPECTION.md
2. API_INSPECTION_README.md
3. BFS_API_SETUP.md
4. API_DEBUGGING_GUIDE.md
5. DATASOURCE_VERIFICATION.md
```

---

## 🌍 По языку:

### 🇷🇺 Русский
```
- БЫСТРЫЙ_СТАРТ_ПРОВЕРКА_API.md
- ПРОВЕРКА_API_DATASOURCES.md
- БЫСТРЫЙ_СТАРТ.md (если есть)
```

### 🇬🇧 English
```
- DATASOURCE_API_INSPECTION.md
- API_INSPECTION_README.md
- API_DEBUGGING_GUIDE.md
- API_EXAMPLES.md
- DATASOURCE_TESTING_GUIDE.md
```

### 🌐 Mixed/Both
```
- test-datasources-api.html (UI в EN, но интуитивно понятен)
- API_TOOLS_INDEX.md (этот файл)
- API_CONNECTION_INFO.md
```

---

## 🔗 Связанные системы:

### Data Sources
```
API: /1.0/datasources
Docs: DATASOURCE_API_INSPECTION.md
Tool: test-datasources-api.html
Component: /components/DataSourcesView.tsx
```

### Transactions
```
API: /1.0/transactions
Docs: API_TRANSACTIONS_DEBUG.md
Component: /components/TransactionsView.tsx
Guide: TRANSACTION_CREATE_JSON_GUIDE.md
```

### Tenants
```
API: /1.0/tenants
Docs: TENANT_FEATURES.md
Component: /components/TenantsView.tsx
Import: TENANT_IMPORT_GUIDE.md
```

### Model Schema
```
API: /1.0/modelschema
Docs: MODELSCHEMA_ALL_FIXES_SUMMARY.md
Component: /components/ModelSchemaView.tsx
Protection: MODELSCHEMA_PROTECTED_TYPES.md
```

---

## 🎓 Learning Path:

### Новичок (Day 1)
```
1. QUICK_START_BFS.md - Понять систему
2. test-datasources-api.html - Попробовать инструмент
3. БЫСТРЫЙ_СТАРТ_ПРОВЕРКА_API.md - Быстрая инструкция
```

### Intermediate (Day 2-3)
```
1. API_EXAMPLES.md - Изучить примеры
2. DATASOURCE_API_INSPECTION.md - Полное руководство
3. API_DEBUGGING_GUIDE.md - Научиться debug
4. DATASOURCE_TESTING_GUIDE.md - Те��тирование
```

### Advanced (Week 1+)
```
1. /lib/api.ts - Изучить код API layer
2. API_INSPECTION_README.md - Все инструменты
3. Все *_VERIFICATION.md файлы
4. Создать свои тесты и утилиты
```

---

## 🔍 Поиск по проблемам:

### "Не могу подключиться к API"
```
→ API_CONNECTION_INFO.md
→ CORS_FIX_FOR_DEVELOPER.md
→ BFS_API_SETUP.md
```

### "Данные не отображаются"
```
→ test-datasources-api.html (проверить API)
→ DATASOURCE_VERIFICATION.md
→ API_DEBUGGING_GUIDE.md
→ Console в браузере (F12)
```

### "Нужно добавить новое поле"
```
→ test-datasources-api.html (найти поле)
→ DATASOURCE_API_INSPECTION.md (раздел "What to do")
→ /lib/api.ts (обновить interface)
→ /components/DataSourcesView.tsx (добавить в UI)
```

### "CORS ошибка"
```
→ CORS_FIX_FOR_DEVELOPER.md
→ CORS_SETUP_FOR_API_ADMIN.md
→ API_DEBUGGING_GUIDE.md
```

### "401 Unauthorized"
```
→ API_CONNECTION_INFO.md (проверить ключ)
→ BFS_API_SETUP.md (настройка аутентификации)
→ test-datasources-api.html (проверить header)
```

### "Неожиданный формат данных"
```
→ test-datasources-api.html (Raw Response)
→ DATASOURCE_API_INSPECTION.md (раздел "Response formats")
→ /lib/api.ts (добавить новый case)
```

---

## 📊 Статистика документации:

```
Total Files: ~100+ документов
API-related: 20+ файлов
Testing: 15+ файлов
Quick Guides: 10+ файлов
Samples: 8+ файлов
```

---

## ✅ Quick Checklist:

Перед началом работы убедитесь, что у вас есть:

```
□ Доступ к BFS API
□ API ключ (X-BFS-Auth)
□ Браузер с DevTools
□ Редактор кода
□ Git для версионирования
□ Postman или cURL (опционально)
```

Для работы с DataSource API:

```
□ test-datasources-api.html работает
□ Прочитан БЫСТРЫЙ_СТАРТ_ПРОВЕРКА_API.md
□ API возвращает данные
□ Понимаю структуру ответа
□ Знаю, какие поля доступны
```

---

## 🎯 Рекомендуемый порядок изучения:

### Начинающим (Start Here!)
```
1. 📄 QUICK_START_BFS.md
2. 🛠️ test-datasources-api.html
3. 📖 БЫСТРЫЙ_СТАРТ_ПРОВЕРКА_API.md
```

### Продолжающим
```
4. 📚 DATASOURCE_API_INSPECTION.md
5. 📝 API_EXAMPLES.md
6. 🔍 API_DEBUGGING_GUIDE.md
```

### Опытным
```
7. 🔧 /lib/api.ts (исходный код)
8. 📊 API_INSPECTION_README.md
9. ✅ Все *_VERIFICATION.md файлы
```

---

## 💡 Pro Tips:

1. **Добавьте в закладки:**
   - `test-datasources-api.html`
   - `БЫСТРЫЙ_СТАРТ_ПРОВЕРКА_API.md`
   - `API_TOOLS_INDEX.md` (этот файл)

2. **Используйте консоль браузера:**
   - Всегда открывайте DevTools (F12)
   - Смотрите Network tab для API запросов
   - Проверяйте Console для логов

3. **Сохраняйте примеры:**
   - Копируйте JSON из HTML тестера
   - Документируйте новые находки
   - Обновляйте sample файлы

4. **Держите документацию актуальной:**
   - Обновляйте после изменений API
   - Добавляйте новые примеры
   - Документируйте breaking changes

---

## 📞 Дополнительная помощь:

Если не нашли нужную информацию:

1. **Проверьте README.md** в корне проекта
2. **Ищите по ключевым словам** в файлах
3. **Смотрите исходный код** в `/lib/api.ts`
4. **Используйте Git history** для истории изменений

---

**Обновлено:** 29 октября 2025  
**Версия:** 1.0  
**Статус:** ✅ Production Ready
