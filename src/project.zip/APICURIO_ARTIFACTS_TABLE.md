# 📋 Apicurio Registry: Quick Reference Table

**Base URL:** `https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3`

## ⚠️ ВАЖНО: Версионирование

```
paradigm.bidtools2 → версия: "1"        (не 1.0.0!)
bfs.online         → версия: "1.0.0"
```

**URL примеры:**
- ✅ `.../paradigm.bidtools2/artifacts/.../versions/1/content`
- ✅ `.../bfs.online/artifacts/.../versions/1.0.0/content`

---

## 🎯 Quick Summary

| Группа | URL | UI Название | Артефактов | Формат | Version |
|--------|-----|-------------|-----------|--------|---------|
| `paradigm.bidtools2` | `/groups/paradigm.bidtools2/artifacts` | Bid Tools Templates | 7 | 3 AVRO + 4 JSON | **1** |
| `bfs.online` | `/groups/bfs.online/artifacts` | BFS Online Templates | 11 | 11 JSON | **1.0.0** |
| **TOTAL** | | | **18** | **3 AVRO + 15 JSON** | |

---

## 📦 Group 1: paradigm.bidtools2 (7 artifacts)

### CDC Format - AVRO (3):

| Artifact ID | Display Name | Type |
|------------|--------------|------|
| `CDC_SQLServer_LineTypes` | LineTypes (CDC) | AVRO |
| `CDC_SQLServer_ServiceRequests` | ServiceRequests (CDC) | AVRO |
| `CDC_SQLServer_WorkflowCustomers` | WorkflowCustomers (CDC) | AVRO |

### TxServices Format - JSON (4):

| Artifact ID | Display Name | Type |
|------------|--------------|------|
| `TxServices_SQLServer_QuoteDetails.response` | QuoteDetails | JSON |
| `TxServices_SQLServer_QuotePacks.response` | QuotePacks | JSON |
| `TxServices_SQLServer_Quotes.response` | Quotes | JSON |
| `TxServices_SQLServer_ReasonCodes.response` | ReasonCodes | JSON |

---

## 📦 Group 2: bfs.online (11 artifacts)

### Informix TxServices - JSON (11):

| Artifact ID | Display Name | Type |
|------------|--------------|------|
| `TxServices_Informix_loc1.response` | loc1 | JSON |
| `TxServices_Informix_loc.response` | loc | JSON |
| `TxServices_Informix_stcode.response` | stcode | JSON |
| `TxServices_Informix_inv.response` | inv | JSON |
| `TxServices_Informix_inv1.response` | inv1 | JSON |
| `TxServices_Informix_inv2.response` | inv2 | JSON |
| `TxServices_Informix_inv3.response` | inv3 | JSON |
| `TxServices_Informix_invap.response` | invap | JSON |
| `TxServices_Informix_invdes.response` | invdes | JSON |
| `TxServices_Informix_invloc.response` | invloc | JSON |
| `TxServices_Informix_keyi.response` | keyi | JSON |

---

## 🧪 Quick Test URLs

### List all groups:
```
GET /groups
```

### Get paradigm.bidtools2 artifacts:
```
GET /groups/paradigm.bidtools2/artifacts?limit=100
```

### Get bfs.online artifacts:
```
GET /groups/bfs.online/artifacts?limit=100
```

### Get specific artifact (example: QuoteDetails from paradigm.bidtools2):
```
GET /groups/paradigm.bidtools2/artifacts/TxServices_SQLServer_QuoteDetails.response/versions/1/content
```

### Get specific artifact (example: CDC LineTypes from paradigm.bidtools2):
```
GET /groups/paradigm.bidtools2/artifacts/CDC_SQLServer_LineTypes/versions/1/content
```

### Get specific artifact (example: loc from bfs.online):
```
GET /groups/bfs.online/artifacts/TxServices_Informix_loc.response/versions/1.0.0/content
```

---

## 📊 Full URLs (копировать для тестирования)

### paradigm.bidtools2:

```bash
# List artifacts
curl "https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/paradigm.bidtools2/artifacts?limit=100"

# Get QuoteDetails schema (VERSION: 1)
curl "https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/paradigm.bidtools2/artifacts/TxServices_SQLServer_QuoteDetails.response/versions/1/content"

# Get LineTypes CDC schema (VERSION: 1)
curl "https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/paradigm.bidtools2/artifacts/CDC_SQLServer_LineTypes/versions/1/content"
```

### bfs.online:

```bash
# List artifacts
curl "https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/bfs.online/artifacts?limit=100"

# Get loc1 schema (VERSION: 1.0.0)
curl "https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/bfs.online/artifacts/TxServices_Informix_loc1.response/versions/1.0.0/content"

# Get inv schema (VERSION: 1.0.0)
curl "https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/bfs.online/artifacts/TxServices_Informix_inv.response/versions/1.0.0/content"
```

---

## ✅ Expected Response

### GET /groups/paradigm.bidtools2/artifacts

**Should return 7 artifacts:**

```json
{
  "artifacts": [
    {
      "artifactId": "CDC_SQLServer_LineTypes",
      "groupId": "paradigm.bidtools2",
      "artifactType": "AVRO",
      "name": "LineTypes (CDC)"
    },
    {
      "artifactId": "CDC_SQLServer_ServiceRequests",
      "groupId": "paradigm.bidtools2",
      "artifactType": "AVRO",
      "name": "ServiceRequests (CDC)"
    },
    {
      "artifactId": "CDC_SQLServer_WorkflowCustomers",
      "groupId": "paradigm.bidtools2",
      "artifactType": "AVRO",
      "name": "WorkflowCustomers (CDC)"
    },
    {
      "artifactId": "TxServices_SQLServer_QuoteDetails.response",
      "groupId": "paradigm.bidtools2",
      "artifactType": "JSON",
      "name": "QuoteDetails"
    },
    {
      "artifactId": "TxServices_SQLServer_QuotePacks.response",
      "groupId": "paradigm.bidtools2",
      "artifactType": "JSON",
      "name": "QuotePacks"
    },
    {
      "artifactId": "TxServices_SQLServer_Quotes.response",
      "groupId": "paradigm.bidtools2",
      "artifactType": "JSON",
      "name": "Quotes"
    },
    {
      "artifactId": "TxServices_SQLServer_ReasonCodes.response",
      "groupId": "paradigm.bidtools2",
      "artifactType": "JSON",
      "name": "ReasonCodes"
    }
  ],
  "count": 7
}
```

### GET /groups/bfs.online/artifacts

**Should return 11 artifacts:**

```json
{
  "artifacts": [
    { "artifactId": "TxServices_Informix_loc1.response", "groupId": "bfs.online", "artifactType": "JSON", "name": "loc1" },
    { "artifactId": "TxServices_Informix_loc.response", "groupId": "bfs.online", "artifactType": "JSON", "name": "loc" },
    { "artifactId": "TxServices_Informix_stcode.response", "groupId": "bfs.online", "artifactType": "JSON", "name": "stcode" },
    { "artifactId": "TxServices_Informix_inv.response", "groupId": "bfs.online", "artifactType": "JSON", "name": "inv" },
    { "artifactId": "TxServices_Informix_inv1.response", "groupId": "bfs.online", "artifactType": "JSON", "name": "inv1" },
    { "artifactId": "TxServices_Informix_inv2.response", "groupId": "bfs.online", "artifactType": "JSON", "name": "inv2" },
    { "artifactId": "TxServices_Informix_inv3.response", "groupId": "bfs.online", "artifactType": "JSON", "name": "inv3" },
    { "artifactId": "TxServices_Informix_invap.response", "groupId": "bfs.online", "artifactType": "JSON", "name": "invap" },
    { "artifactId": "TxServices_Informix_invdes.response", "groupId": "bfs.online", "artifactType": "JSON", "name": "invdes" },
    { "artifactId": "TxServices_Informix_invloc.response", "groupId": "bfs.online", "artifactType": "JSON", "name": "invloc" },
    { "artifactId": "TxServices_Informix_keyi.response", "groupId": "bfs.online", "artifactType": "JSON", "name": "keyi" }
  ],
  "count": 11
}
```

---

## 📊 Statistics

```
Total Groups:     2
Total Artifacts:  18

paradigm.bidtools2:
  ├─ CDC (AVRO):       3 artifacts
  ├─ TxServices (JSON): 4 artifacts
  └─ TOTAL:            7 artifacts

bfs.online:
  ├─ Informix (JSON):  11 artifacts
  └─ TOTAL:            11 artifacts
```

---

**Дата:** 27 ноября 2025
