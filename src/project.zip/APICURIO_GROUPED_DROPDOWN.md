# ✅ Apicurio Templates: Grouped Dropdown

## 🎯 Цель

Визуально разделить артефакты в выпадающем списке по группам (**paradigm.bidtools** и **bfs.online**) для лучшей навигации.

## 📊 Было vs Стало

### Было:
```
Select Apicurio Template
  ├─ LineTypes (CDC)
  ├─ loc
  ├─ loc1
  ├─ QuoteDetails
  ├─ QuotePacks
  ├─ Quotes
  ├─ ReasonCodes
  ├─ ServiceRequests (CDC)
  ├─ stcode
  └─ WorkflowCustomers (CDC)
```

❌ Все артефакты в одном списке  
❌ Непонятно откуда какие артефакты  
❌ SQL Server и Informix схемы смешаны

### Стало:
```
Select Apicurio Template

📦 SQL Server Templates (paradigm.bidtools)
  ├─ LineTypes (CDC)
  ├─ QuoteDetails
  ├─ QuotePacks
  ├─ Quotes
  ├─ ReasonCodes
  ├─ ServiceRequests (CDC)
  └─ WorkflowCustomers (CDC)

─────────────────────────────

🗄️ Informix Templates (bfs.online)
  ├─ loc
  ├─ loc1
  └─ stcode
```

✅ Артефакты сгруппированы по типу источника  
✅ Визуальный разделитель между группами  
✅ Иконки для идентификации (📦 SQL Server, 🗄️ Informix)  
✅ Понятная навигация

## 🔧 Изменения в коде

### File: `/components/DataCaptureSpecCreateDialog.tsx`

**Старый код:**
```tsx
<SelectContent>
  {apicurioArtifacts
    .slice()
    .sort((a, b) => {
      const nameA = getArtifactDisplayName(a).toLowerCase();
      const nameB = getArtifactDisplayName(b).toLowerCase();
      return nameA.localeCompare(nameB);
    })
    .map((artifact) => (
      <SelectItem
        key={artifact.artifactId}
        value={artifact.artifactId}
        className="text-xs"
      >
        {getArtifactDisplayName(artifact)}
      </SelectItem>
    ))}
</SelectContent>
```

**Новый код:**
```tsx
<SelectContent>
  {/* Group artifacts by groupId */}
  {(() => {
    // Group artifacts by groupId
    const grouped = apicurioArtifacts.reduce((acc, artifact) => {
      const group = artifact.groupId || 'other';
      if (!acc[group]) acc[group] = [];
      acc[group].push(artifact);
      return acc;
    }, {} as Record<string, typeof apicurioArtifacts>);

    // Sort groups: paradigm.bidtools first, then bfs.online, then others
    const groupOrder = ['paradigm.bidtools', 'bfs.online'];
    const sortedGroups = Object.keys(grouped).sort((a, b) => {
      const indexA = groupOrder.indexOf(a);
      const indexB = groupOrder.indexOf(b);
      if (indexA !== -1 && indexB !== -1) return indexA - indexB;
      if (indexA !== -1) return -1;
      if (indexB !== -1) return 1;
      return a.localeCompare(b);
    });

    return sortedGroups.map((groupId, groupIndex) => (
      <div key={groupId}>
        {/* Group header */}
        {groupIndex > 0 && <Separator className="my-1" />}
        <div className="px-2 py-1.5 text-xs text-muted-foreground">
          {groupId === 'paradigm.bidtools' ? '📦 SQL Server Templates' : 
           groupId === 'bfs.online' ? '🗄️ Informix Templates' : 
           groupId}
        </div>
        
        {/* Artifacts in this group */}
        {grouped[groupId]
          .slice()
          .sort((a, b) => {
            const nameA = getArtifactDisplayName(a).toLowerCase();
            const nameB = getArtifactDisplayName(b).toLowerCase();
            return nameA.localeCompare(nameB);
          })
          .map((artifact) => (
            <SelectItem
              key={artifact.artifactId}
              value={artifact.artifactId}
              className="text-xs pl-6"
            >
              {getArtifactDisplayName(artifact)}
            </SelectItem>
          ))}
      </div>
    ));
  })()}
  
  {apicurioArtifacts.length === 0 && !isLoadingArtifacts && (
    <SelectItem value="none" disabled>
      No templates available
    </SelectItem>
  )}
</SelectContent>
```

## 📋 Как работает группировка

### 1. **Group Artifacts by groupId**
```typescript
const grouped = apicurioArtifacts.reduce((acc, artifact) => {
  const group = artifact.groupId || 'other';
  if (!acc[group]) acc[group] = [];
  acc[group].push(artifact);
  return acc;
}, {} as Record<string, typeof apicurioArtifacts>);
```

**Result:**
```javascript
{
  "paradigm.bidtools": [
    { artifactId: "CDC_SQLServer_LineTypes", ... },
    { artifactId: "TxServices_SQLServer_QuoteDetails.response", ... },
    { artifactId: "TxServices_SQLServer_QuotePacks.response", ... },
    // ... 7 artifacts total
  ],
  "bfs.online": [
    { artifactId: "TxServices_Informix_loc.response", ... },
    { artifactId: "TxServices_Informix_loc1.response", ... },
    { artifactId: "TxServices_Informix_stcode.response", ... }
  ]
}
```

### 2. **Sort Groups (Priority Order)**
```typescript
const groupOrder = ['paradigm.bidtools', 'bfs.online'];
const sortedGroups = Object.keys(grouped).sort((a, b) => {
  const indexA = groupOrder.indexOf(a);
  const indexB = groupOrder.indexOf(b);
  if (indexA !== -1 && indexB !== -1) return indexA - indexB;
  if (indexA !== -1) return -1;
  if (indexB !== -1) return 1;
  return a.localeCompare(b);
});
```

**Priority:**
1. `paradigm.bidtools` (first)
2. `bfs.online` (second)
3. Other groups (alphabetically)

### 3. **Render with Headers and Separators**
```tsx
{sortedGroups.map((groupId, groupIndex) => (
  <div key={groupId}>
    {/* Separator between groups */}
    {groupIndex > 0 && <Separator className="my-1" />}
    
    {/* Group header with icon */}
    <div className="px-2 py-1.5 text-xs text-muted-foreground">
      {groupId === 'paradigm.bidtools' ? '📦 SQL Server Templates' : 
       groupId === 'bfs.online' ? '🗄️ Informix Templates' : 
       groupId}
    </div>
    
    {/* Artifacts in group (sorted alphabetically, indented) */}
    {grouped[groupId]
      .sort(...)
      .map((artifact) => (
        <SelectItem className="text-xs pl-6">
          {getArtifactDisplayName(artifact)}
        </SelectItem>
      ))}
  </div>
))}
```

## 🎨 UI Features

### Group Headers
- **paradigm.bidtools** → `📦 SQL Server Templates`
- **bfs.online** → `🗄️ Informix Templates`
- Other groups → Display `groupId` as-is

### Visual Separators
- `<Separator />` between groups (not before first group)

### Indentation
- Group headers: `px-2` (8px padding)
- Artifacts: `pl-6` (24px left padding) for visual hierarchy

### Sorting
- **Groups**: Custom order (paradigm.bidtools first, bfs.online second)
- **Artifacts within group**: Alphabetically by display name

## 📸 Visual Preview

```
┌─────────────────────────────────────────┐
│ Select Apicurio Template                │
├─────────────────────────────────────────┤
│ 📦 SQL Server Templates                 │
│   ├─ LineTypes (CDC)                    │
│   ├─ QuoteDetails                       │
│   ├─ QuotePacks                         │
│   ├─ Quotes                             │
│   ├─ ReasonCodes                        │
│   ├─ ServiceRequests (CDC)              │
│   └─ WorkflowCustomers (CDC)            │
├─────────────────────────────────────────┤
│ 🗄️ Informix Templates                   │
│   ├─ loc                                │
│   ├─ loc1                               │
│   └─ stcode                             │
└─────────────────────────────────────────┘
```

## 🧪 Как протестировать

### 1. Открыть Create Data Capture Spec Dialog
```
Data Source Onboarding → Select Data Source → Create Data Capture Spec
```

### 2. Открыть Apicurio Templates dropdown
```
Click on "Select a Apicurio Template" dropdown
```

### 3. Проверить группировку
```
✅ Видите "📦 SQL Server Templates" header
✅ 7 артефактов под SQL Server (paradigm.bidtools)
✅ Separator line
✅ Видите "🗄️ Informix Templates" header
✅ 3 артефакта под Informix (bfs.online)
✅ Artifacts внутри группы отсортированы alphabetically
✅ Artifacts имеют indent (pl-6)
```

### 4. Выбрать Informix template
```
Select "loc1" → Should load:
  - Spec Name: loc1
  - Container Name: loc1s
  - Primary Key Field: loc1Id
  - Schema from bfs.online/TxServices_Informix_loc1.response
```

## ✅ Преимущества

### 1. **Лучшая навигация**
- Сразу видно какие схемы из SQL Server
- Сразу видно какие схемы из Informix

### 2. **Визуальная иерархия**
- Group headers с иконками
- Indented artifacts
- Separators между группами

### 3. **Расширяемость**
```typescript
// Добавить новую группу - просто добавить в groupOrder
const groupOrder = ['paradigm.bidtools', 'bfs.online', 'new-group'];

// Добавить иконку для новой группы
{groupId === 'paradigm.bidtools' ? '📦 SQL Server Templates' : 
 groupId === 'bfs.online' ? '🗄️ Informix Templates' : 
 groupId === 'new-group' ? '🔧 New Database Templates' :
 groupId}
```

### 4. **Сортировка в группах**
- Artifacts сортируются alphabetically внутри своей группы
- Не смешиваются между группами

## 🔍 Edge Cases

### No artifacts
```tsx
{apicurioArtifacts.length === 0 && !isLoadingArtifacts && (
  <SelectItem value="none" disabled>
    No templates available
  </SelectItem>
)}
```

### Unknown group
```typescript
const group = artifact.groupId || 'other';
// Falls back to 'other' if groupId is missing
```

### Single group
```tsx
{groupIndex > 0 && <Separator className="my-1" />}
// No separator before first group
```

## ✅ Готово!

Теперь Apicurio Templates dropdown:
- ✅ Группирует артефакты по источнику (SQL Server vs Informix)
- ✅ Визуально разделяет группы с иконками
- ✅ Сортирует группы по priority order
- ✅ Сортирует артефакты внутри групп alphabetically
- ✅ Легко расширяется для новых групп

**Намного лучшая UX для работы с multiple Apicurio groups!** 🎉
