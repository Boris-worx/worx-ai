# 🔍 DataSource API Inspection Guide

## Цель
Этот документ описывает, как проверить, какие именно данные возвращает BFS API для Data Sources (`/1.0/datasources`).

---

## 📋 Методы проверки

### Метод 1: Использование тестового HTML файла (Рекомендуется)

Создан специальный файл `/test-datasources-api.html` для детального анализа API.

#### Как использовать:

1. **Откройте файл в браузере:**
   ```bash
   # Просто откройте файл test-datasources-api.html в браузере
   # Или через локальный сервер
   ```

2. **Нажмите кнопку "🚀 Fetch DataSources"**

3. **Получите подробный анализ:**
   - ✅ **Response Summary** - формат ответа, количество источников
   - ✅ **Fields Analysis** - таблица всех полей с типами и примерами
   - ✅ **Raw API Response** - полный JSON ответ
   - ✅ **First DataSource Object** - первый объект для детального анализа

#### Что вы увидите:

```
📊 Response Summary
├── Response Format: "data.datasources array"
├── Total DataSources: 5
├── Unique Fields: 12 fields
├── ID Field: "DatasourceId" (5/5 have values)
├── Name Field: "DatasourceName" (5/5 have values)
├── Type Field: "Type" (3/5 have values)
├── Status Field: "Status" (5/5 have values)
└── Description Field: "Description" (4/5 have values)

🔑 Fields Analysis
┌─────────────────────┬────────┬────────────────────────┐
│ Field Name          │ Type   │ Sample Value           │
├─────────────────────┼────────┼────────────────────────┤
│ DatasourceId        │ string │ "ds-12345"            │
│ DatasourceName      │ string │ "Main Database"       │
│ Type                │ string │ "SQL"                 │
│ Status              │ string │ "Active"              │
│ Description         │ string │ "Production DB"       │
│ ConnectionString    │ string │ "Server=..."          │
│ CreateTime          │ string │ "2025-10-15T..."      │
│ UpdateTime          │ string │ "2025-10-20T..."      │
│ _rid                │ string │ "abc123"              │
│ _self               │ string │ "/dbs/..."            │
│ _etag               │ string │ "\"abc-123\""         │
│ _ts                 │ number │ 1730233445            │
└─────────────────────┴────────┴────────────────────────┘
```

---

### Метод 2: Консоль браузера в приложении

При загрузке Data Sources в основном приложении, консоль автоматически выводит подробную информацию.

#### Как проверить:

1. **Откройте приложение** в браузере
2. **Откройте DevTools** (F12)
3. **Перейдите на вкладку "Data Source Onboarding"**
4. **Смотрите в консоли:**

```javascript
📦 Raw response (first 1000 chars): {...}
📋 Response structure: {
  isArray: false,
  keys: ["status", "data"],
  hasData: true,
  dataKeys: ["datasources"]
}
✅ Format: data.datasources array
Loaded 5 data source(s) from API

🎯 First data source: {
  DatasourceId: "ds-12345",
  DatasourceName: "Main Database",
  Type: "SQL",
  Status: "Active",
  ...
}

🔑 All fields in first data source: [
  "DatasourceId",
  "DatasourceName", 
  "Type",
  "Status",
  "Description",
  "ConnectionString",
  "CreateTime",
  "UpdateTime",
  "_rid",
  "_self",
  "_etag",
  "_ts"
]

📋 All unique fields across all data sources: [
  "ConnectionString",
  "CreateTime",
  "DatasourceId",
  "DatasourceName",
  "Description",
  "Status",
  "Type",
  "UpdateTime",
  "_attachments",
  "_etag",
  "_rid",
  "_self",
  "_ts"
]

💡 Field value examples: {
  DatasourceId: "ds-12345",
  DatasourceName: "Main Database",
  Type: "SQL",
  Status: "Active",
  Description: "Production database",
  ConnectionString: "Server=tcp:...",
  CreateTime: "2025-10-15T10:30:00Z",
  UpdateTime: "2025-10-20T14:45:00Z",
  _rid: "abc123",
  _self: "dbs/xyz/colls/abc/docs/123/",
  _etag: "\"00000000-0000-0000-0000-000000000000\"",
  _ts: 1730233445
}
```

---

### Метод 3: Postman или cURL

#### Используя cURL:

```bash
curl -X GET \
  'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/datasources' \
  -H 'X-BFS-Auth: bfs-secret-key-12345' \
  -H 'Content-Type: application/json'
```

#### Используя Postman:

1. **Method:** GET
2. **URL:** `https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/datasources`
3. **Headers:**
   - `X-BFS-Auth`: `bfs-secret-key-12345`
   - `Content-Type`: `application/json`
4. **Send** и смотрите ответ

---

## 📊 Ожидаемая структура данных

### Формат ответа API

BFS API может возвращать данные в разных форматах. Приложение поддерживает все эти варианты:

#### Формат 1: Direct Array
```json
[
  {
    "DatasourceId": "ds-1",
    "DatasourceName": "Database 1",
    ...
  }
]
```

#### Формат 2: Nested in data.datasources
```json
{
  "status": {
    "code": 200,
    "message": "Success"
  },
  "data": {
    "datasources": [
      {
        "DatasourceId": "ds-1",
        ...
      }
    ]
  }
}
```

#### Формат 3: BFS Standard Format
```json
{
  "status": {
    "code": 200,
    "message": "Success"
  },
  "data": {
    "DataSources": [
      {
        "DatasourceId": "ds-1",
        ...
      }
    ]
  }
}
```

---

## 🔑 Известные поля DataSource

На основе интерфейса TypeScript и API документации:

| Поле | Тип | Описание | Примечания |
|------|-----|----------|-----------|
| `DatasourceId` или `DataSourceId` | string | Уникальный идентификатор | **Обязательное** |
| `DatasourceName` или `DataSourceName` | string | Название источника данных | **Обязательное** |
| `Type` | string | Тип источника (SQL, NoSQL, API, etc.) | Опционально |
| `Status` | string | Статус (Active, Inactive) | Опционально |
| `Description` | string | Описание источника | Опционально |
| `ConnectionString` | string | Строка подключения | Опционально, **чувствительные данные** |
| `CreateTime` | string (ISO 8601) | Дата создания | Автоматически |
| `UpdateTime` | string (ISO 8601) | Дата обновления | Автоматически |
| `_rid` | string | Resource ID (Cosmos DB) | Системное поле |
| `_self` | string | Self link (Cosmos DB) | Системное поле |
| `_etag` | string | Entity tag для оптимистической блокировки | **Требуется для PUT/DELETE** |
| `_attachments` | string | Attachments link (Cosmos DB) | Системное поле |
| `_ts` | number | Timestamp (Unix epoch) | Системное поле |

---

## 🎯 Что проверить

### ✅ Обязательные поля
- [ ] `DatasourceId` или `DataSourceId` присутствует
- [ ] `DatasourceName` или `DataSourceName` присутствует
- [ ] `_etag` присутствует (нужен для операций UPDATE/DELETE)

### ✅ Опциональные поля
- [ ] `Type` - есть ли у источников тип?
- [ ] `Status` - есть ли статус?
- [ ] `Description` - есть ли описания?
- [ ] `ConnectionString` - хранятся ли строки подключения?
- [ ] `CreateTime` / `UpdateTime` - есть ли временные метки?

### ✅ Cosmos DB поля
- [ ] `_rid`, `_self`, `_attachments` - системные поля Cosmos DB
- [ ] `_ts` - Unix timestamp

### ✅ Дополнительные поля
- [ ] Есть ли другие кастомные поля, которые мы не учли?

---

## 🔧 Что делать с результатами

### Если находим новые поля:

1. **Обновить интерфейс TypeScript** в `/lib/api.ts`:
   ```typescript
   export interface DataSource {
     // ... существующие поля
     NewField?: string;  // добавить новое поле
   }
   ```

2. **Добавить в default columns** в `/components/DataSourcesView.tsx`:
   ```typescript
   const getDefaultColumns = (): ColumnConfig[] => [
     // ...
     { key: 'NewField', label: 'New Field', enabled: false },
   ];
   ```

3. **Обновить formatCellValue** если нужно специальное форматирование:
   ```typescript
   if (key === 'NewField') {
     return <Badge>{value}</Badge>;
   }
   ```

### Если находим несоответствия:

1. **Case sensitivity** - API возвращает `DatasourceId` или `DataSourceId`?
   - Уже обработано через helper функции

2. **Empty values** - какие поля могут быть null/undefined?
   - Проверить логику `isEmptyValue`

3. **Data types** - типы соответствуют ожидаемым?
   - Обновить TypeScript интерфейс

---

## 📝 Checklist для анализа

- [ ] **Запустить test-datasources-api.html** и получить полную картину
- [ ] **Проверить консоль браузера** в основном приложении
- [ ] **Сравнить с TypeScript интерфейсом** - все ли поля учтены?
- [ ] **Проверить значения по умолчанию** - какие поля пустые?
- [ ] **Документировать новые поля** в этом файле
- [ ] **Обновить UI** если нужно показывать дополнительные поля

---

## 🐛 Troubleshooting

### Проблема: "CORS_BLOCKED"
**Решение:** API блокирует CORS запросы. Проверьте настройки CORS на сервере.

### Проблема: "401 Unauthorized"
**Решение:** Проверьте заголовок `X-BFS-Auth`. Возможно нужен новый API ключ.

### Проблема: "Empty array"
**Решение:** Возможно, в базе нет Data Sources. Создайте тестовый источник.

### Проблема: "Unknown response format"
**Решение:** API вернул неожиданный формат. Проверьте Raw Response и добавьте новый вариант парсинга в `getAllDataSources()`.

---

## 📚 Связанные файлы

- `/lib/api.ts` - API функции и TypeScript интерфейсы
- `/components/DataSourcesView.tsx` - UI компонент для Data Sources
- `/test-datasources-api.html` - Тестовый инструмент
- `/API_EXAMPLES.md` - Примеры работы с API
- `/DATASOURCE_TESTING_GUIDE.md` - Руководство по тестированию

---

## ✅ Результаты анализа

После проверки API заполните:

**Дата проверки:** _____________

**Общее количество Data Sources:** _____

**Найденные поля:**
```
[Вставьте список полей из консоли]
```

**Новые поля (не в интерфейсе):**
```
[Список полей, которых нет в TypeScript интерфейсе]
```

**Поля с данными:**
```
[Какие поля реально заполнены]
```

**Пустые поля:**
```
[Какие поля всегда пустые]
```

**Рекомендации:**
```
[Нужно ли обновить UI, добавить новые колонки, изменить форматирование?]
```

---

**Статус:** ✅ Готов к использованию  
**Версия:** 1.0  
**Дата создания:** 29 октября 2025
