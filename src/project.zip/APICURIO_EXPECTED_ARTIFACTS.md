# 📦 Apicurio Registry: Ожидаемые артефакты (Expected Artifacts)

**Дата:** 27 ноября 2025  
**Base URL:** `https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3`

---

## 🎯 Группы (Groups)

Приложение запрашивает артефакты из **2 групп**:

```
1. paradigm.bidtools2   (Bid Tools Templates)
2. bfs.online           (BFS Online Templates)
```

---

## 📋 Группа 1: `paradigm.bidtools2`

**URL:** `https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/paradigm.bidtools2/artifacts`

**UI Название:** "Bid Tools Templates"

**Всего артефактов:** 7

### CDC Format (AVRO) - 3 артефакта:

| # | Artifact ID | Type | Display Name | Description |
|---|------------|------|--------------|-------------|
| 1 | `CDC_SQLServer_LineTypes` | AVRO | LineTypes (CDC) | CDC AVRO schema for LineTypes |
| 2 | `CDC_SQLServer_ServiceRequests` | AVRO | ServiceRequests (CDC) | CDC AVRO schema for ServiceRequests |
| 3 | `CDC_SQLServer_WorkflowCustomers` | AVRO | WorkflowCustomers (CDC) | CDC AVRO schema for WorkflowCustomers |

### TxServices Format (JSON) - 4 артефакта:

| # | Artifact ID | Type | Display Name | Description |
|---|------------|------|--------------|-------------|
| 4 | `TxServices_SQLServer_QuoteDetails.response` | JSON | QuoteDetails | JSON schema for QuoteDetails |
| 5 | `TxServices_SQLServer_QuotePacks.response` | JSON | QuotePacks | JSON schema for QuotePacks |
| 6 | `TxServices_SQLServer_Quotes.response` | JSON | Quotes | JSON schema for Quotes |
| 7 | `TxServices_SQLServer_ReasonCodes.response` | JSON | ReasonCodes | JSON schema for ReasonCodes |

### API Requests для paradigm.bidtools2:

```bash
# Получить список всех артефактов в группе
GET https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/paradigm.bidtools2/artifacts?limit=100

# Получить конкретный артефакт (пример: QuoteDetails)
GET https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/paradigm.bidtools2/artifacts/TxServices_SQLServer_QuoteDetails.response/versions/branch=latest/content

# Получить конкретный артефакт с версией (пример: LineTypes CDC)
GET https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/paradigm.bidtools2/artifacts/CDC_SQLServer_LineTypes/versions/1.0.0/content
```

---

## 📋 Группа 2: `bfs.online`

**URL:** `https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/bfs.online/artifacts`

**UI Название:** "BFS Online Templates"

**Всего артефактов:** 11

### Informix TxServices Schemas (JSON) - 11 артефактов:

| # | Artifact ID | Type | Display Name | Description |
|---|------------|------|--------------|-------------|
| 1 | `TxServices_Informix_loc1.response` | JSON | loc1 | Response schema for Informix TxServices loc1 |
| 2 | `TxServices_Informix_loc.response` | JSON | loc | Response schema for Informix TxServices loc |
| 3 | `TxServices_Informix_stcode.response` | JSON | stcode | Response schema for Informix TxServices stcode |
| 4 | `TxServices_Informix_inv.response` | JSON | inv | Response schema for Informix TxServices inv (Inventory) |
| 5 | `TxServices_Informix_inv1.response` | JSON | inv1 | Response schema for Informix TxServices inv1 (Inventory variant 1) |
| 6 | `TxServices_Informix_inv2.response` | JSON | inv2 | Response schema for Informix TxServices inv2 (Inventory variant 2) |
| 7 | `TxServices_Informix_inv3.response` | JSON | inv3 | Response schema for Informix TxServices inv3 (Inventory variant 3) |
| 8 | `TxServices_Informix_invap.response` | JSON | invap | Response schema for Informix TxServices invap (Inventory AP) |
| 9 | `TxServices_Informix_invdes.response` | JSON | invdes | Response schema for Informix TxServices invdes (Inventory Descriptions) |
| 10 | `TxServices_Informix_invloc.response` | JSON | invloc | Response schema for Informix TxServices invloc (Inventory Location) |
| 11 | `TxServices_Informix_keyi.response` | JSON | keyi | Response schema for Informix TxServices keyi (Keyword Inventory) |

### API Requests для bfs.online:

```bash
# Получить список всех артефактов в группе
GET https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/bfs.online/artifacts?limit=100

# Получить конкретный артефакт (пример: loc1)
GET https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/bfs.online/artifacts/TxServices_Informix_loc1.response/versions/branch=latest/content

# Получить конкретный артефакт (пример: inv)
GET https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/bfs.online/artifacts/TxServices_Informix_inv.response/versions/branch=latest/content
```

---

## 📊 Статистика

| Метрика | Значение |
|---------|----------|
| Всего групп | 2 |
| Всего артефактов | 18 |
| paradigm.bidtools2 | 7 артефактов (3 AVRO + 4 JSON) |
| bfs.online | 11 артефактов (11 JSON) |

---

## 🔄 API Request Flow

### При открытии Create Dialog:

```javascript
// 1. Запрос к группе paradigm.bidtools2
GET /groups/paradigm.bidtools2/artifacts?limit=100

Response:
{
  "artifacts": [
    {
      "artifactId": "CDC_SQLServer_LineTypes",
      "groupId": "paradigm.bidtools2",
      "artifactType": "AVRO",
      "name": "LineTypes (CDC)",
      ...
    },
    // ... 6 more artifacts
  ],
  "count": 7
}

// 2. Запрос к группе bfs.online
GET /groups/bfs.online/artifacts?limit=100

Response:
{
  "artifacts": [
    {
      "artifactId": "TxServices_Informix_loc1.response",
      "groupId": "bfs.online",
      "artifactType": "JSON",
      "name": "loc1",
      ...
    },
    // ... 10 more artifacts
  ],
  "count": 11
}

// 3. Combine и group
const grouped = {
  'paradigm.bidtools2': [7 artifacts],
  'bfs.online': [11 artifacts]
}

// 4. Display в UI с custom headings
'paradigm.bidtools2' → "Bid Tools Templates"
'bfs.online' → "BFS Online Templates"
```

---

## 🎨 UI Display

### Template Selection Dropdown:

```
┌─────────────────────────────────────────────┐
│ Select Template:  [▼ Choose template...]   │
├─────────────────────────────────────────────┤
│                                             │
│ 📋 Bid Tools Templates (7)                 │
│    Source: paradigm.bidtools2               │
│                                             │
│    CDC Format (AVRO):                       │
│    • LineTypes (CDC)                        │
│    • ServiceRequests (CDC)                  │
│    • WorkflowCustomers (CDC)                │
│                                             │
│    TxServices Format (JSON):                │
│    • QuoteDetails                           │
│    • QuotePacks                             │
│    • Quotes                                 │
│    • ReasonCodes                            │
│                                             │
│ 📋 BFS Online Templates (11)               │
│    Source: bfs.online                       │
│                                             │
│    Informix TxServices (JSON):              │
│    • inv, inv1, inv2, inv3                  │
│    • invap, invdes, invloc                  │
│    • keyi, loc, loc1, stcode                │
│                                             │
└─────────────────────────────────────────────┘
```

---

## 🧪 Testing URLs

### Получить список всех групп:

```bash
GET https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups
```

**Ожидаемый ответ должен содержать:**
```json
{
  "groups": [
    {
      "groupId": "paradigm.bidtools2",
      ...
    },
    {
      "groupId": "bfs.online",
      ...
    }
  ]
}
```

### Проверить наличие артефактов в paradigm.bidtools2:

```bash
curl -X GET "https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/paradigm.bidtools2/artifacts?limit=100"
```

**Должно вернуть 7 артефактов:**
- CDC_SQLServer_LineTypes
- CDC_SQLServer_ServiceRequests
- CDC_SQLServer_WorkflowCustomers
- TxServices_SQLServer_QuoteDetails.response
- TxServices_SQLServer_QuotePacks.response
- TxServices_SQLServer_Quotes.response
- TxServices_SQLServer_ReasonCodes.response

### Проверить наличие артефактов в bfs.online:

```bash
curl -X GET "https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/bfs.online/artifacts?limit=100"
```

**Должно вернуть 11 артефактов:**
- TxServices_Informix_loc1.response
- TxServices_Informix_loc.response
- TxServices_Informix_stcode.response
- TxServices_Informix_inv.response
- TxServices_Informix_inv1.response
- TxServices_Informix_inv2.response
- TxServices_Informix_inv3.response
- TxServices_Informix_invap.response
- TxServices_Informix_invdes.response
- TxServices_Informix_invloc.response
- TxServices_Informix_keyi.response

---

## ⚠️ Important Notes

### 1. Версионирование:

**CDC артефакты (AVRO):**
```
Используют версию: 1.0.0
GET /artifacts/{artifactId}/versions/1.0.0/content
```

**TxServices артефакты (JSON):**
```
Используют branch: latest
GET /artifacts/{artifactId}/versions/branch=latest/content
```

### 2. CORS:

Apicurio Registry должен разрешать CORS для:
```
Origin: http://localhost:5173
Origin: https://your-production-domain.com
```

### 3. Fallback на Mock данные:

Если Apicurio недоступен или возвращает 403/404:
- ✅ Приложение автоматически использует mock данные
- ✅ Mock содержит все 18 артефактов
- ✅ UI продолжает работать

### 4. Naming Convention:

**CDC Format:**
```
Pattern: CDC_{Database}_{TableName}
Example: CDC_SQLServer_LineTypes
Type: AVRO
```

**TxServices Format:**
```
Pattern: TxServices_{Database}_{EntityName}.response
Example: TxServices_SQLServer_QuoteDetails.response
Type: JSON
```

---

## 🔍 Troubleshooting

### Группа не найдена (404):

```
❌ Error: Group 'paradigm.bidtools2' not found
```

**Решение:**
1. Проверить что группа создана в Apicurio
2. Проверить URL: `/groups/paradigm.bidtools2/artifacts`
3. Fallback на mock данные работает автоматически

### Артефакты не возвращаются:

```
✅ Response 200 OK
{
  "artifacts": [],
  "count": 0
}
```

**Решение:**
1. Загрузить артефакты в группу через Apicurio UI
2. Использовать Apicurio CLI для bulk upload
3. Fallback на mock данные работает

### 403 Forbidden:

```
❌ Error 403: Access forbidden
```

**Решение:**
1. Это нормально если Apicurio требует authentication
2. Приложение автоматически использует mock данные
3. CORS может блокировать запросы - проверить CORS настройки

---

## 📚 Related Documentation

| Документ | Описание |
|----------|----------|
| `/APICURIO_BIDTOOLS2_ЗАМЕНА.md` | Полная документация изменений |
| `/APICURIO-INTEGRATION.md` | Руководство по интеграции Apicurio |
| `/APICURIO-MOCK-DATA-FIX.md` | Mock данные и fallback |
| `/lib/apicurio.ts` | Код интеграции |

---

## ✅ Production Checklist

**Перед deployment в production убедиться:**

### Apicurio Registry:

- [ ] Группа `paradigm.bidtools2` создана
- [ ] Все 7 артефактов загружены в `paradigm.bidtools2`
- [ ] Группа `bfs.online` создана
- [ ] Все 11 артефактов загружены в `bfs.online`
- [ ] CORS настроен для production domain
- [ ] Authentication настроен (если требуется)

### Приложение:

- [ ] URL Apicurio Registry корректен
- [ ] Mock данные актуальны (fallback)
- [ ] Ошибки обрабатываются корректно
- [ ] UI тестирование пройдено

### Testing:

- [ ] curl тесты для каждой группы выполнены
- [ ] Каждый артефакт доступен через API
- [ ] UI отображает все 18 артефактов
- [ ] Fallback на mock работает

---

## 🎯 Summary

**Приложение ожидает получить от Apicurio Registry:**

```
┌──────────────────────────────────────────┐
│ Apicurio Registry                        │
├──────────────────────────────────────────┤
│                                          │
│ 📦 paradigm.bidtools2 (7 artifacts)     │
│    ├─ CDC_SQLServer_LineTypes (AVRO)    │
│    ├─ CDC_SQLServer_ServiceRequests     │
│    ├─ CDC_SQLServer_WorkflowCustomers   │
│    ├─ TxServices_..._QuoteDetails.resp  │
│    ├─ TxServices_..._QuotePacks.resp    │
│    ├─ TxServices_..._Quotes.resp        │
│    └─ TxServices_..._ReasonCodes.resp   │
│                                          │
│ 📦 bfs.online (11 artifacts)            │
│    ├─ TxServices_Informix_loc1.response │
│    ├─ TxServices_Informix_loc.response  │
│    ├─ TxServices_Informix_stcode.resp   │
│    ├─ TxServices_Informix_inv.response  │
│    ├─ TxServices_Informix_inv1.response │
│    ├─ TxServices_Informix_inv2.response │
│    ├─ TxServices_Informix_inv3.response │
│    ├─ TxServices_Informix_invap.resp    │
│    ├─ TxServices_Informix_invdes.resp   │
│    ├─ TxServices_Informix_invloc.resp   │
│    └─ TxServices_Informix_keyi.response │
│                                          │
│ TOTAL: 18 artifacts                     │
└──────────────────────────────────────────┘
```

**Дата:** 27 ноября 2025  
**Всего артефактов:** 18 (7 + 11)  
**Всего групп:** 2
