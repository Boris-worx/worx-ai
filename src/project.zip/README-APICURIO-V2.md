# Apicurio Registry Integration v2.0

> **Обновлено:** 27 ноября 2025  
> **Версия:** 2.0 (Real API Only - No Mock Data)  
> **Статус:** ✅ Очистка завершена, готово к тестированию

---

## 🚀 Quick Start

### 1. Проверить что Apicurio доступен
```bash
curl https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/search/artifacts?name=Value
```

### 2. Создать Data Capture Specification
```
1. Открыть: Data Source Onboarding
2. Выбрать data source
3. Нажать: "Add Specification"
4. Выбрать схему из Apicurio (dropdown)
5. Заполнить форму (auto-fill работает)
6. Create!
```

### 3. Проверить в Data Plane
```
В будущей версии: Data Capture Specs автоматически 
станут Transaction Types в Data Plane.
```

---

## 📚 Документация

### ⭐ Начните здесь:

| Документ | Описание | Когда читать |
|----------|----------|--------------|
| **[APICURIO_КРАТКИЙ_ИТОГ.md](./APICURIO_КРАТКИЙ_ИТОГ.md)** | Краткий обзор текущего состояния | Первым делом (5 мин) |
| **[APICURIO_CHECKLIST_RU.md](./APICURIO_CHECKLIST_RU.md)** | Чеклист и тесты | Для тестирования (30 мин) |
| **[APICURIO-REAL-API-ТОЛЬКО.md](./APICURIO-REAL-API-ТОЛЬКО.md)** | Полная техническая документация | Для разработчиков (20 мин) |
| **[СЛЕДУЮЩИЕ_ШАГИ_APICURIO_RU.md](./СЛЕДУЮЩИЕ_ШАГИ_APICURIO_RU.md)** | Дорожная карта Phase 1-4 | Для планирования (30 мин) |

### 🔧 Дополнительно:

| Документ | Статус | Примечания |
|----------|--------|------------|
| [APICURIO-CORS-SOLUTION.md](./APICURIO-CORS-SOLUTION.md) | ✅ Актуально | КРИТИЧНО если CORS не работает |
| [APICURIO-INTEGRATION.md](./APICURIO-INTEGRATION.md) | ✅ Частично актуально | Технические детали v3 API |
| [APICURIO-DISCOVERED-SPECS.md](./APICURIO-DISCOVERED-SPECS.md) | ⚠️ Может быть устаревшим | Список артефактов в Apicurio |

### ❌ Устаревшие (не читать):

| Документ | Причина |
|----------|---------|
| [APICURIO-MOCK-DATA-FIX.md](./APICURIO-MOCK-DATA-FIX.md) | Mock данные удалены |
| [APICURIO-STATUS.md](./APICURIO-STATUS.md) | Описывает mock mode |
| [README-APICURIO.md](./README-APICURIO.md) | Версия 1.0, устарела |

---

## 🎯 Что работает сейчас

### ✅ API Integration (Real API Only)

Все функции работают **только с реальным Apicurio Registry v3 API**:

```typescript
// ❌ БОЛЬШЕ НЕТ:
const USE_MOCK_APICURIO = true; // Удалено
if (USE_MOCK_APICURIO) { ... } // Удалено
return mockData; // Удалено

// ✅ ТЕПЕРЬ:
const response = await fetch(`${APICURIO_REGISTRY_URL}/artifacts/${artifactId}`);
return await response.json(); // Прямой возврат из API
```

**Функции:**
- `getApicurioGroups()` - v3 не использует groups
- `getApicurioArtifacts(query)` - поиск артефактов ✅
- `getApicurioArtifactContent(groupId, artifactId)` - загрузка схемы ✅ **ОЧИЩЕНО**
- `getAllDataSourceSpecifications()` - discovery ✅
- `getJsonSchemasForDataSource(name)` - фильтрация ✅
- `createApicurioArtifact()` - создание ✅

### ✅ UI Components

**Data Source Onboarding:**
- Создание Data Capture Specifications
- Auto-loading схем из Apicurio
- Auto-fill формы из схемы
- Discovery Dialog для просмотра всех артефактов

**Data Plane (будущее):**
- Отображение Transaction Types из Data Capture Specs
- Валидация транзакций по схемам
- Metadata и версионирование

---

## ⚙️ Конфигурация

### Apicurio Registry Endpoint

```typescript
// /lib/api.ts
const APICURIO_REGISTRY_URL = 
  "https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3";
```

### v3 API Endpoints

```
Search:     GET  /search/artifacts?name={query}
Get Schema: GET  /artifacts/{artifactId}
Create:     POST /groups/{groupId}/artifacts
```

### CORS Requirements

**Необходимо:**
```
Access-Control-Allow-Origin: * 
# или
Access-Control-Allow-Origin: https://your-app-domain.com

Access-Control-Allow-Methods: GET, POST, PUT, DELETE
Access-Control-Allow-Headers: Content-Type, Accept
```

**Если CORS не настроен:**
- ❌ Все API вызовы будут падать с `TypeError: Failed to fetch`
- ❌ Невозможно загрузить схемы
- ❌ Data Capture Specs нельзя создать с auto-fill

**Решения:** См. [APICURIO-CORS-SOLUTION.md](./APICURIO-CORS-SOLUTION.md)

---

## 🧪 Тестирование

### Быстрый тест (2 минуты)

```javascript
// Browser Console
fetch('https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/search/artifacts?name=Value')
  .then(r => r.json())
  .then(d => {
    console.log('✅ Success!');
    console.log('Artifacts found:', d.count);
    console.log('First 5:', d.artifacts.slice(0, 5).map(a => a.artifactId));
  })
  .catch(e => {
    console.error('❌ Error:', e.message);
    if (e.message.includes('CORS')) {
      console.log('→ CORS не настроен. См. /APICURIO-CORS-SOLUTION.md');
    }
  });
```

### Полный тест (10 минут)

См. [APICURIO_CHECKLIST_RU.md](./APICURIO_CHECKLIST_RU.md) → "Полное тестирование"

---

## 🗺️ Roadmap

### ✅ Phase 0: Foundation (ЗАВЕРШЕНО)
- Интеграция Apicurio v3 API
- UI для создания Data Capture Specs
- Auto-loading и auto-fill

### ✅ Phase 1: Cleanup (ЗАВЕРШЕНО - 27 Nov 2025)
- Удаление всех mock данных
- Очистка feature flags
- Обновление документации

### ⏳ Phase 2: Data Plane Integration (ЭТА НЕДЕЛЯ)
- Автоматическое создание ModelSchema из Data Capture Spec
- UI обновления в Data Plane
- Badge и metadata display

### 🔜 Phase 3: Validation (СЛЕДУЮЩАЯ НЕДЕЛЯ)
- JSON Schema validation для транзакций
- Error display в UI
- End-to-end testing

### 🔜 Phase 4: Advanced Features (БУДУЩЕЕ)
- Версионирование схем
- Bulk import
- Schema Registry UI
- Real-time sync

**Детали:** См. [СЛЕДУЮЩИЕ_ШАГИ_APICURIO_RU.md](./СЛЕДУЮЩИЕ_ШАГИ_APICURIO_RU.md)

---

## 🔧 Архитектура

### Current Flow
```
User creates Data Capture Spec
        ↓
Load schemas from Apicurio (REAL API)
        ↓
Auto-fill form from schema
        ↓
Save to Cosmos DB
        ↓
Done ✅
```

### Future Flow (Phase 2)
```
User creates Data Capture Spec
        ↓
Load schemas from Apicurio (REAL API)
        ↓
Auto-fill form from schema
        ↓
Save to Cosmos DB
        ↓
Auto-create ModelSchema (Transaction Type)  ← NEW
        ↓
Appears in Data Plane automatically  ← NEW
        ↓
Can create transactions with validation  ← NEW
```

### Integration Points

```typescript
// Phase 1 (Current)
DataSourcesView
    → DataCaptureSpecCreateDialog
        → getJsonSchemasForDataSource() [REAL API]
            → getApicurioArtifacts() [REAL API]
        → getApicurioArtifactContent() [REAL API, NO MOCK]
        → createDataCaptureSpec()

// Phase 2 (Next)
createDataCaptureSpec()
    → createModelSchemaFromDataCaptureSpec() [NEW]
        → ModelSchemaView shows new type
            → TransactionCreateDialog validates against schema
```

---

## 📊 Tenant Isolation

### Data Capture Specs
- ✅ Каждый spec привязан к `tenantId`
- ✅ Users видят только specs своего тенанта
- ✅ Global tenant видит все specs

### Transaction Types (Phase 2)
- ✅ ModelSchemas наследуют `tenantId` от Data Capture Spec
- ✅ Transaction Types изолированы по тенантам
- ✅ Валидация работает в пределах тенанта

### Apicurio Artifacts
- ⚠️ Apicurio не знает о тенантах (shared registry)
- ✅ Tenant isolation на уровне Data Capture Specs
- ✅ Один артефакт может использоваться multiple tenants

---

## 🐛 Troubleshooting

### Проблема: CORS Error
```
❌ TypeError: Failed to fetch
❌ CORS policy: No 'Access-Control-Allow-Origin' header
```
**Решение:** [APICURIO-CORS-SOLUTION.md](./APICURIO-CORS-SOLUTION.md)

### Проблема: No schemas found
```
✅ Found 0 schemas (JSON + AVRO) for {dataSourceName}
```
**Причины:**
- Нет артефактов с таким именем в Apicurio
- Search query не соответствует artifactId
- Артефакты другого типа (не JSON/AVRO)

**Решение:**
1. Проверить содержимое Apicurio: `curl .../search/artifacts?name=Value`
2. Скорректировать search query
3. Проверить фильтры в `getJsonSchemasForDataSource()`

### Проблема: Schema не загружается
```
❌ Failed to fetch artifact content: 404 Not Found
```
**Причины:**
- Неправильный artifactId
- Артефакт не существует
- Проблемы с доступом

**Решение:**
1. Проверить artifactId в консоли
2. Проверить что артефакт существует: `curl .../artifacts/{artifactId}`
3. Проверить права доступа к Apicurio

### Проблема: Form не заполняется автоматически
```
✅ Fetched schema for {artifactId}
⚠️ Form остается пустой
```
**Причины:**
- Schema не в JSON Schema формате
- AVRO schema вместо JSON Schema
- Неполная schema

**Решение:**
1. Проверить формат schema в console.log
2. Проверить `processSchema()` функцию в `/lib/apicurio.ts`
3. Добавить transformation если нужно

---

## 💻 Development

### Ключевые файлы

```
/lib/api.ts                              - Apicurio API functions (2200-2450)
/lib/apicurio.ts                         - Helper utilities
/components/DataCaptureSpecCreateDialog.tsx  - Create dialog
/components/DataSourcesView.tsx          - Data Source Onboarding view
/components/ModelSchemaView.tsx          - Data Plane view (future)
```

### Добавить новую функцию

```typescript
// /lib/api.ts

export async function myNewApicurioFunction(param: string): Promise<any> {
  try {
    console.log(`📡 Starting my new function...`);
    
    const url = `${APICURIO_REGISTRY_URL}/my-endpoint/${param}`;
    const response = await fetch(url, {
      method: "GET",
      headers: {
        "Accept": "application/json",
        "Content-Type": "application/json",
      },
    });

    if (!response.ok) {
      throw new Error(`Failed: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    console.log(`✅ Success`);
    return data;
  } catch (error) {
    console.error("❌ Error:", error);
    throw error; // Don't fallback to mock data
  }
}
```

### Debugging

**Enable verbose logging:**
```typescript
// Browser Console
localStorage.setItem('DEBUG_APICURIO', 'true');
```

**Watch network requests:**
```
DevTools → Network → Filter: "apicurio-poc"
```

**Check console logs:**
```
📡 = API call start
✅ = Success
❌ = Error
⚠️ = Warning
```

---

## 🚀 Deployment

### Development
```bash
npm install
npm run dev
```

### Production Checklist

- [ ] CORS настроен на Apicurio Registry
- [ ] API endpoint доступен из production domain
- [ ] Error monitoring настроен (Sentry, etc.)
- [ ] Performance testing пройден
- [ ] Security audit пройден
- [ ] User acceptance testing пройден
- [ ] Documentation обновлена

### Environment Variables (future)

```bash
VITE_APICURIO_REGISTRY_URL=https://apicurio-poc...
VITE_APICURIO_API_KEY=xxx  # если нужна аутентификация
```

---

## 📈 Metrics & Monitoring (future)

### Key Metrics
- API response time (target: <500ms)
- Success rate (target: >99%)
- Schema loading time (target: <1s)
- Error rate (target: <1%)

### Monitoring
```typescript
// Track Apicurio API performance
console.time('apicurio-fetch');
const artifacts = await getApicurioArtifacts('Value');
console.timeEnd('apicurio-fetch');
```

---

## 🤝 Contributing

### Перед коммитом:

1. ✅ Код компилируется без ошибок
2. ✅ TypeScript types корректны
3. ✅ Нет console.errors (только console.log/warn)
4. ✅ Функции протестированы
5. ✅ Documentation обновлена

### Pull Request Checklist:

- [ ] Ссылка на issue/task
- [ ] Описание изменений
- [ ] Screenshots (если UI изменения)
- [ ] Тесты пройдены
- [ ] Documentation обновлена

---

## 📞 Support

### Документация
- **Quick Start:** Этот файл, раздел "Quick Start"
- **Troubleshooting:** Этот файл, раздел "Troubleshooting"
- **API Reference:** [APICURIO-REAL-API-ТОЛЬКО.md](./APICURIO-REAL-API-ТОЛЬКО.md)
- **Roadmap:** [СЛЕДУЮЩИЕ_ШАГИ_APICURIO_RU.md](./СЛЕДУЮЩИЕ_ШАГИ_APICURIO_RU.md)

### Полезные ссылки
- Apicurio Registry: https://www.apicur.io/registry/
- JSON Schema: https://json-schema.org/
- Cosmos DB: https://docs.microsoft.com/azure/cosmos-db/

---

## 📝 Version History

### v2.0 (27 Nov 2025) - Real API Only
- ✅ Removed all mock data from `getApicurioArtifactContent`
- ✅ Removed feature flags (`USE_MOCK_APICURIO`)
- ✅ Updated documentation
- ✅ Code cleanup and optimization

### v1.0 (Nov 2025) - Initial Integration
- Initial Apicurio v3 API integration
- Mock data for development
- Basic UI for Data Capture Specs
- Discovery Dialog

---

## ✅ Summary

**Current State:**
- ✅ All mock data removed
- ✅ Real API integration complete
- ✅ Code compiles without errors
- ✅ Documentation updated

**Next Steps:**
1. Test CORS configuration
2. Test Data Capture Spec creation
3. Implement Phase 2 (Data Plane integration)

**Timeline:**
- Phase 1: ✅ Complete (27 Nov 2025)
- Phase 2: 🔜 This week
- Phase 3: 🔜 Next week
- Phase 4: 🔜 Future

---

**Start here:** [APICURIO_КРАТКИЙ_ИТОГ.md](./APICURIO_КРАТКИЙ_ИТОГ.md) для быстрого обзора

**Need help?** См. раздел "Troubleshooting" выше или [APICURIO_CHECKLIST_RU.md](./APICURIO_CHECKLIST_RU.md)

**Last Updated:** 27 November 2025
