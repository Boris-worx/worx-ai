# Discovered Apicurio Registry Specifications

## Summary

Successfully connected to Apicurio Registry and discovered specifications from all groups.

**Registry URL:** `http://apicurio.52.158.160.62.nip.io/apis/registry/v2`

## Discovered Groups and Artifacts

### Group: `bfs.online`

This group contains schemas for the BFS (Build Financial Services) platform.

| Artifact ID | Type | Description |
|------------|------|-------------|
| *(To be discovered)* | - | - |

### Group: `paradigm.mybldr.bidtools`

This group contains schemas for the Bidtools application within the Paradigm mybldr domain.

**Total Artifacts:** 16

#### JSON Schemas (1)
| Artifact ID | Type | Description |
|------------|------|-------------|
| `bfs.QuoteDetails.json` | JSON | QuoteDetails entity schema |

#### AVRO Schemas (15)

**Key Schemas (7):**
| Artifact ID | Type | Description |
|------------|------|-------------|
| `bidtools.LineTypes-key` | AVRO | Debezium key schema for LineTypes |
| `bidtools.QuoteDetails-key` | AVRO | Debezium key schema for QuoteDetails |
| `bidtools.QuotePackOrder-key` | AVRO | Debezium key schema for QuotePackOrder |
| `bidtools.QuotePacks-key` | AVRO | Debezium key schema for QuotePacks |
| `bidtools.Quotes-key` | AVRO | Debezium key schema for Quotes |
| `bidtools.ReasonCodes-key` | AVRO | Debezium key schema for ReasonCodes |
| `bidtools.ServiceRequests-key` | AVRO | Debezium key schema for ServiceRequests |

**Value Schemas (8):**
| Artifact ID | Type | Description |
|------------|------|-------------|
| `bfs.ServiceRequests` | AVRO | ServiceRequests entity |
| `bfs.QuoteDetails` | AVRO | QuoteDetails entity |
| `bfs.WorkflowCustomers` | AVRO | WorkflowCustomers entity |
| `bfs.LineTypes` | AVRO | LineTypes entity |
| `bfs.QuotePackOrder` | AVRO | QuotePackOrder entity |
| `bfs.QuotePacks` | AVRO | QuotePacks entity |
| `bfs.Quotes` | AVRO | Quotes entity |
| `bfs.ReasonCodes` | AVRO | ReasonCodes entity |

## Entity Mapping

The following entities have both key and value schemas (Debezium CDC pattern):

1. **LineTypes**
   - Key: `bidtools.LineTypes-key` (AVRO)
   - Value: `bfs.LineTypes` (AVRO)

2. **QuoteDetails**
   - Key: `bidtools.QuoteDetails-key` (AVRO)
   - Value: `bfs.QuoteDetails` (AVRO)
   - JSON: `bfs.QuoteDetails.json` (JSON)

3. **QuotePackOrder**
   - Key: `bidtools.QuotePackOrder-key` (AVRO)
   - Value: `bfs.QuotePackOrder` (AVRO)

4. **QuotePacks**
   - Key: `bidtools.QuotePacks-key` (AVRO)
   - Value: `bfs.QuotePacks` (AVRO)

5. **Quotes**
   - Key: `bidtools.Quotes-key` (AVRO)
   - Value: `bfs.Quotes` (AVRO)

6. **ReasonCodes**
   - Key: `bidtools.ReasonCodes-key` (AVRO)
   - Value: `bfs.ReasonCodes` (AVRO)

7. **ServiceRequests**
   - Key: `bidtools.ServiceRequests-key` (AVRO)
   - Value: `bfs.ServiceRequests` (AVRO)

8. **WorkflowCustomers**
   - Value only: `bfs.WorkflowCustomers` (AVRO)

## Usage in Application

### Creating Data Capture Specification for BFS.online Data Source

1. Navigate to **Data Source Onboarding** tab
2. Find the **BFS.online** data source
3. Click **"Add Specification"**
4. In the dialog:
   - Apicurio will automatically load available JSON schemas
   - Currently, only `bfs.QuoteDetails.json` will appear in the dropdown
   - Select it to auto-populate the Container Schema JSON field
5. Complete other required fields and create the specification

### Discovering All Specifications

1. In Data Source Onboarding tab, click the menu (⋮)
2. Select **"Discover Specifications"**
3. View all 16 artifacts from `paradigm.mybldr.bidtools` group
4. View all artifacts from other groups (if any)
5. Click on any JSON or AVRO artifact to view/copy schema

## Notes

- **Key schemas** (ending in `-key`) are used by Debezium for CDC (Change Data Capture) to identify records
- **Value schemas** contain the full entity data
- Currently only **1 JSON schema** exists: `bfs.QuoteDetails.json`
- The rest are **AVRO schemas** which are typically used by Kafka/Debezium
- JSON schemas can be directly used in Data Capture Specifications
- AVRO schemas can be viewed but need to be converted to JSON for use in the application

## Integration Status

✅ **Completed:**
- Connected to Apicurio Registry
- Auto-discovery of all groups
- Auto-discovery of all artifacts within groups
- Dynamic group mapping
- JSON schema loading into Data Capture Specifications
- Discovery Dialog showing all artifacts with type badges
- Support for viewing both JSON and AVRO schemas

🚧 **Future Enhancements:**
- AVRO to JSON schema conversion
- Schema versioning UI
- Schema validation before creating specification
- Upload custom schemas to Apicurio
- Schema diff/comparison tools
