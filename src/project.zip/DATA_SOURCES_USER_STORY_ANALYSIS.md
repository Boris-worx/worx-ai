# Data Sources User Story - Interface Analysis ✅

## User Story Requirements

### Data Sources Overview:
1. ✅ Connected to Data Plane via ACE (IBM App Connect Enterprise) - *backend concern*
2. ✅ CDC (Change Data Capture) support - *backend concern*
3. ⚠️ **Can be associated with global tenant or specific tenant** - *UI must support*
4. ⚠️ **Each Data Source has Data Capture Specifications (one per table)** - *UI must show*
5. ✅ Stored in Cosmos, CRUD via TxServices API - *already implemented*

### Example Data Sources:
```
Global Tenant:
├── Bidtools (SQL Server)
│   ├── Quotes
│   ├── QuoteDetails
│   └── QuotePacks
└── Databricks
    └── Design

BFS Tenant:
├── Online (Informix)
│   ├── Customer
│   └── Order
├── Trend
└── SAP
```

---

## Current Implementation Analysis

### ✅ What's Working Great

#### 1. Data Sources Tab (`/components/DataSourcesView.tsx`)

**CRUD Operations:** ✅ Fully Implemented
```typescript
- Create: "Add New Data Source" button → createDataSource()
- Read: DataTable with all data sources → getAllDataSources()
- Update: Edit button → updateDataSource()
- Delete: Delete button with confirmation → deleteDataSource()
```

**UI Features:** ✅ Excellent
- DataTable with sorting, searching, filtering
- Column selector (show/hide columns)
- Expandable rows for details
- Permission-based access (Admin/Developer can create/edit/delete)
- Tenant selector integration
- Responsive design

**Data Source Fields:**
```typescript
export interface DataSource {
  DataSourceId?: string;
  DatasourceId?: string;      // Handles both naming conventions
  DataSourceName?: string;
  DatasourceName?: string;
  Type?: string;              // e.g., "SQL Server", "Informix"
  ConnectionString?: string;
  Description?: string;
  Status?: string;
  CreateTime?: string;
  UpdateTime?: string;
  _etag?: string;             // For optimistic concurrency
  // ... Cosmos metadata
}
```

**Example Types:** ✅ Already Supported
- SQL Server ✅ (for Bidtools)
- Informix ✅ (for Online)
- Can easily add: Databricks, SAP, Trend

---

#### 2. Data Capture Specifications

**Current State:** 🟡 Partially Implemented

**Location 1: DataSourcesView - Mock Display**
```typescript
// Interface defined (line 42-49)
interface DataCaptureSpecification {
  id: string;
  table: string;
  version: string;
  date: string;
  schema: any;
}

// Mock data for display (line 308-350)
const getMockSpecifications = (dataSourceName: string) => {
  if (dataSourceName === 'Bidtools') {
    return [
      { id: 'spec-1', table: 'Quotes', version: '1.0', ... },
      { id: 'spec-2', table: 'QuoteDetails', version: '1.0', ... },
      { id: 'spec-3', table: 'QuotePacks', version: '1.0', ... }
    ];
  }
  // ... more examples
};
```

**Location 2: ModelSchemaView - Real API Integration** ✅
```typescript
// Transaction Onboarding tab
// Manages real Data Capture Specifications via API
// Endpoint: /1.0/txns?TxnType=ModelSchema

export interface ModelSchema {
  id: string;
  model: string;              // Table name (e.g., "Quotes", "Customer")
  version: number;
  state: string;              // "active", "draft", "archived"
  semver: string;             // "1.0.0"
  jsonSchema: any;            // JSON Schema (draft-2020-12)
  CreateTime: string;
  UpdateTime: string;
  _etag?: string;
}
```

**Full CRUD for Schemas:** ✅ Implemented
- Create: "Add Data Capture Spec" button
- Read: Table with all schemas
- Update: Edit button (with protected types)
- Delete: Delete button (with protected types)
- View: Detail dialog with formatted JSON

---

### ⚠️ What Needs Improvement

#### 1. **No Tenant Association** 🔴 CRITICAL

**Problem:** Both DataSource and ModelSchema lack TenantId field

```typescript
// Current - NO tenant field
export interface DataSource {
  DataSourceId?: string;
  DataSourceName?: string;
  // ❌ Missing: TenantId?: string;
}

export interface ModelSchema {
  id: string;
  model: string;
  // ❌ Missing: TenantId?: string;
  // ❌ Missing: dataSourceId?: string;  // Link to DataSource
}
```

**Impact:**
- Cannot distinguish global vs tenant-specific data sources
- Cannot filter "Bidtools" (global) from "Online (Informix)" (BFS tenant)
- User Story explicitly requires this distinction

**Solution:**
```typescript
export interface DataSource {
  DataSourceId?: string;
  DataSourceName?: string;
  Type?: string;
  TenantId?: string;          // ✅ ADD: "global" or specific tenant
  // ... rest
}

export interface ModelSchema {
  id: string;
  model: string;
  version: number;
  TenantId?: string;          // ✅ ADD: associate with tenant
  dataSourceId?: string;      // ✅ ADD: link to DataSource
  // ... rest
}
```

---

#### 2. **No Link Between DataSource and ModelSchema** 🟡 IMPORTANT

**Problem:** Data Capture Specifications are separate from Data Sources

```
Current State:
┌─────────────────────────────────────┐
│  Data Source Onboarding Tab        │
│  ├── Bidtools (SQL Server)         │
│  ├── Online (Informix)             │
│  └── [Shows mock specifications]   │  ❌ Not real data
└─────────────────────────────────────┘

┌─────────────────────────────────────┐
│  Transaction Onboarding Tab        │
│  ├── Customer (ModelSchema)        │
│  ├── Quotes (ModelSchema)          │
│  └── [Real API data]               │  ✅ Working
│  ❌ But no link to DataSource      │
└─────────────────────────────────────┘
```

**User Story Expectation:**
```
Desired State:
┌─────────────────────────────────────┐
│  Data Source Onboarding Tab        │
│  ├── Bidtools (SQL Server)         │
│  │   ├── Quotes (spec v1.0)        │  ✅ Real from API
│  │   ├── QuoteDetails (v1.0)       │  ✅ Real from API
│  │   └── QuotePacks (v1.0)         │  ✅ Real from API
│  └── Online (Informix)             │
│      ├── Customer (v1.0)           │  ✅ Real from API
│      └── Order (v1.0)              │  ✅ Real from API
└─────────────────────────────────────┘
```

**Solution:**
1. Add `dataSourceId` field to ModelSchema
2. Query API: `/1.0/txns?TxnType=ModelSchema&DataSourceId={id}`
3. Display real schemas under each Data Source

---

#### 3. **Mock Data in DataSourcesView** 🟡 MEDIUM

**Current Implementation:**
```typescript
// DataSourcesView.tsx line 308-350
const getMockSpecifications = (dataSourceName: string) => {
  // Returns hardcoded mock data
  // ❌ Not connected to real API
}

// UI displays mock specs in expandable rows
{specifications.map((spec) => (
  <div>{spec.table}</div>  // ❌ Mock data
))}
```

**Problem:**
- Shows "Quotes", "QuoteDetails" as mock
- Real schemas exist in ModelSchemaView
- Inconsistent data across tabs

**Solution:**
```typescript
// Fetch real schemas from API
const getDataSourceSpecifications = async (dataSourceId: string) => {
  const schemas = await getAllModelSchemas(); // Already exists!
  return schemas.filter(s => s.dataSourceId === dataSourceId);
};

// Display real schemas
{realSchemas.map((schema) => (
  <div>{schema.model} (v{schema.semver})</div>  // ✅ Real data
))}
```

---

#### 4. **"Add Specification" Button Not Functional** 🟢 LOW

**Current State:**
```typescript
// DataSourcesView.tsx line 873
onClick={() => {
  toast.info('Add Data Capture Specification - Coming soon!');
}}
```

**User Story Requirement:**
> "Data Capture Specifications can be added, changed and deleted via API"

**Solution:**
- Link to ModelSchemaView create dialog
- Pre-fill `dataSourceId` when creating from Data Source context
- Or: implement inline creation dialog

---

### 🎯 Compliance with User Story

| Requirement | Status | Notes |
|-------------|--------|-------|
| **Data Sources CRUD** | ✅ Complete | Create, Read, Update, Delete all working |
| **Cosmos Storage** | ✅ Complete | Uses Cosmos DB metadata (_etag, _rid, etc.) |
| **TxServices API** | ✅ Complete | Integrated with real BFS API |
| **Global/Tenant Association** | ❌ Missing | No TenantId field in DataSource |
| **Data Capture Specifications** | 🟡 Partial | Exists in ModelSchemaView but not linked |
| **One Spec Per Table** | ✅ Supported | ModelSchema has model name (table) |
| **Spec CRUD** | ✅ Complete | Full CRUD in ModelSchemaView |
| **ACE Integration** | N/A | Backend concern |
| **CDC Support** | N/A | Backend concern |

**Overall Status:** 🟡 **70% Complete**

---

## Visual Comparison

### Current UI:

```
┌──────────────────────────────────────────────────┐
│ Data Source Onboarding Tab                       │
├──────────────────────────────────────────────────┤
│ [+ Add Data Source] [Refresh] [Column Selector] │
│                                                   │
│ ┌─────────────────────────────────────────────┐ │
│ │ Name          | Type         | Status       │ │
│ ├─────────────────────────────────────────────┤ │
│ │ Bidtools      | SQL Server   | Active       │ │ ← No tenant shown
│ │ Online        | Informix     | Active       │ │ ← No tenant shown
│ │ Databricks    | Cloud        | Active       │ │ ← No tenant shown
│ └─────────────────────────────────────────────┘ │
│                                                   │
│ Click row to expand:                             │
│ ┌─────────────────────────────────────────────┐ │
│ │ Data Capture Specifications:                │ │
│ │ • Quotes (v1.0)              ❌ Mock data   │ │
│ │ • QuoteDetails (v1.0)        ❌ Mock data   │ │
│ │ • QuotePacks (v1.0)          ❌ Mock data   │ │
│ │ [+ Add Specification]        ❌ Not working │ │
│ └─────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────┐
│ Transaction Onboarding Tab (ModelSchemaView)     │
├──────────────────────────────────────────────────┤
│ [+ Add Data Capture Spec] [Refresh]             │
│                                                   │
│ ┌─────────────────────────────────────────────┐ │
│ │ Model     | Version | State    | Actions   │ │
│ ├─────────────────────────────────────────────┤ │
│ │ Customer  | 1       | active   | View Edit │ │ ← Real API data
│ │ Quotes    | 1       | active   | View Edit │ │ ← Real API data
│ │ Location  | 1       | active   | View      │ │ ← Protected type
│ └─────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────┘
```

### Desired UI (After Fixes):

```
┌──────────────────────────────────────────────────┐
│ Data Source Onboarding Tab                       │
├──────────────────────────────────────────────────┤
│ 🏢 [Global Tenant ▼]                             │  ← Tenant selector
│ [+ Add Data Source] [Refresh]                    │
│                                                   │
│ ┌─────────────────────────────────────────────┐ │
│ │ Name      | Type       | Tenant  | Status   │ │
│ ├─────────────────────────────────────────────┤ │
│ │ Bidtools  | SQL Server | Global  | Active   │ │ ✅ Tenant visible
│ │ Databricks| Cloud      | Global  | Active   │ │ ✅ Tenant visible
│ └─────────────────────────────────────────────┘ │
│                                                   │
│ 🏢 [BFS Tenant ▼]                                │  ← Switch to BFS
│                                                   │
│ ┌─────────────────────────────────────────────┐ │
│ │ Name      | Type       | Tenant  | Status   │ │
│ ├─────────────────────────────────────────────┤ │
│ │ Online    | Informix   | BFS     | Active   │ │ ✅ Filtered by tenant
│ │ Trend     | Legacy     | BFS     | Active   │ │ ✅ Filtered by tenant
│ │ SAP       | ERP        | BFS     | Active   │ │ ✅ Filtered by tenant
│ └─────────────────────────────────────────────┘ │
│                                                   │
│ Click row to expand (Bidtools):                  │
│ ┌─────────────────────────────────────────────┐ │
│ │ Data Capture Specifications:                │ │
│ │ • Quotes (v1.0.0)            ✅ Real API    │ │
│ │ • QuoteDetails (v1.0.0)      ✅ Real API    │ │
│ │ • QuotePacks (v1.0.0)        ✅ Real API    │ │
│ │ [+ Add Specification]        ✅ Working     │ │
│ └─────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────┘
```

---

## Implementation Roadmap

### Phase 1: Add Tenant Support (2 hours) 🔴 CRITICAL

#### Step 1.1: Update Interfaces
```typescript
// /lib/api.ts

export interface DataSource {
  DataSourceId?: string;
  DatasourceId?: string;
  DataSourceName?: string;
  DatasourceName?: string;
  Type?: string;
  TenantId?: string;          // ✅ ADD THIS
  PartitionKey?: string;      // ✅ ADD THIS (if needed)
  ConnectionString?: string;
  Description?: string;
  Status?: string;
  CreateTime?: string;
  UpdateTime?: string;
  _etag?: string;
}

export interface ModelSchema {
  id: string;
  model: string;
  version: number;
  state: string;
  semver: string;
  TenantId?: string;          // ✅ ADD THIS
  dataSourceId?: string;      // ✅ ADD THIS - Link to DataSource
  jsonSchema: any;
  CreateTime: string;
  UpdateTime: string;
  _etag?: string;
}
```

#### Step 1.2: Update API Functions
```typescript
// /lib/api.ts

export async function getAllDataSources(tenantId?: string): Promise<DataSource[]> {
  let url = `${API_BASE_URL}/datasources`;
  
  // Filter by tenant if specified
  if (tenantId && tenantId !== 'global') {
    url += `?TenantId=${tenantId}`;
  }
  
  const response = await fetch(url, {
    method: "GET",
    headers: getHeaders(),
  });
  // ... rest
}

export async function getAllModelSchemas(tenantId?: string, dataSourceId?: string): Promise<ModelSchema[]> {
  let url = `${API_BASE_URL}/txns?TxnType=ModelSchema`;
  
  // Add filters
  const params = [];
  if (tenantId && tenantId !== 'global') {
    params.push(`TenantId=${tenantId}`);
  }
  if (dataSourceId) {
    params.push(`DataSourceId=${dataSourceId}`);
  }
  if (params.length > 0) {
    url += '&' + params.join('&');
  }
  
  const response = await fetch(url, {
    method: "GET",
    headers: getHeaders(),
  });
  // ... rest
}
```

#### Step 1.3: Update Components
```typescript
// /App.tsx

const refreshDataSources = async () => {
  setIsLoadingDataSources(true);
  try {
    const data = await getAllDataSources(activeTenantId); // ✅ Pass tenant
    setDataSources(data);
  } catch (error: any) {
    toast.error(`Failed to load data sources: ${error.message}`);
  } finally {
    setIsLoadingDataSources(false);
  }
};

// Auto-refresh when tenant changes
useEffect(() => {
  if (activeTenantId) {
    refreshDataSources();
  }
}, [activeTenantId]);
```

#### Step 1.4: Add Tenant Column
```typescript
// /components/DataSourcesView.tsx

const getDefaultColumns = (): ColumnConfig[] => [
  { key: 'DatasourceId', label: 'Data Source ID', enabled: true, locked: true },
  { key: 'DatasourceName', label: 'Name', enabled: true },
  { key: 'Type', label: 'Type', enabled: true },
  { key: 'TenantId', label: 'Tenant', enabled: true },  // ✅ ADD THIS
  { key: 'Status', label: 'Status', enabled: true },
  // ... rest
];

// In cell rendering
if (key === 'TenantId') {
  const tenantName = value || 'Global';
  return (
    <Badge variant={!value ? 'secondary' : 'default'}>
      {tenantName}
    </Badge>
  );
}
```

**Time Estimate:** 2 hours  
**Priority:** 🔴 Critical

---

### Phase 2: Link Data Sources to Specifications (3 hours) 🟡 IMPORTANT

#### Step 2.1: Fetch Real Specifications for Data Source
```typescript
// /components/DataSourcesView.tsx

// Replace mock specifications with real API call
const [dataSourceSpecs, setDataSourceSpecs] = useState<Record<string, ModelSchema[]>>({});

const loadSpecificationsForDataSource = async (dataSourceId: string) => {
  try {
    const specs = await getAllModelSchemas(activeTenantId, dataSourceId);
    setDataSourceSpecs(prev => ({
      ...prev,
      [dataSourceId]: specs
    }));
  } catch (error) {
    console.error('Failed to load specifications:', error);
  }
};

// Load when row expands
const handleRowExpand = (dataSource: DataSource) => {
  const dsId = getDataSourceId(dataSource);
  if (!dataSourceSpecs[dsId]) {
    loadSpecificationsForDataSource(dsId);
  }
};
```

#### Step 2.2: Display Real Specifications
```typescript
// In expandable row content
const specifications = dataSourceSpecs[getDataSourceId(row)] || [];

{specifications.length > 0 ? (
  <div className="space-y-2">
    {specifications.map((spec) => (
      <div key={spec.id} className="flex items-center justify-between p-2 border rounded">
        <div>
          <span className="font-medium">{spec.model}</span>
          <Badge variant="outline" className="ml-2">v{spec.semver}</Badge>
          <Badge 
            variant={spec.state === 'active' ? 'default' : 'secondary'} 
            className="ml-2"
          >
            {spec.state}
          </Badge>
        </div>
        <div className="flex gap-2">
          <Button size="sm" variant="ghost" onClick={() => viewSpec(spec)}>
            <Eye className="h-4 w-4" />
          </Button>
          {canEdit && !isProtectedType(spec.model) && (
            <Button size="sm" variant="ghost" onClick={() => editSpec(spec)}>
              <Pencil className="h-4 w-4" />
            </Button>
          )}
          {canDelete && !isProtectedType(spec.model) && (
            <Button size="sm" variant="ghost" onClick={() => deleteSpec(spec)}>
              <Trash2 className="h-4 w-4" />
            </Button>
          )}
        </div>
      </div>
    ))}
  </div>
) : (
  <div className="text-center py-4 text-muted-foreground">
    No specifications defined
  </div>
)}
```

#### Step 2.3: Implement "Add Specification" Button
```typescript
// Replace toast with actual dialog
const [isAddSpecDialogOpen, setIsAddSpecDialogOpen] = useState(false);
const [selectedDataSourceForSpec, setSelectedDataSourceForSpec] = useState<DataSource | null>(null);

const handleAddSpecification = (dataSource: DataSource) => {
  setSelectedDataSourceForSpec(dataSource);
  setIsAddSpecDialogOpen(true);
};

// In dialog, pre-fill dataSourceId
const handleCreateSpec = async () => {
  const newSpec = {
    model: modelName,
    version: 1,
    state: 'active',
    semver: '1.0.0',
    dataSourceId: getDataSourceId(selectedDataSourceForSpec), // ✅ Link to DataSource
    TenantId: activeTenantId !== 'global' ? activeTenantId : undefined,
    jsonSchema: JSON.parse(jsonSchemaText)
  };
  
  await createModelSchema(newSpec);
  // Refresh specifications for this data source
  await loadSpecificationsForDataSource(getDataSourceId(selectedDataSourceForSpec));
};
```

**Time Estimate:** 3 hours  
**Priority:** 🟡 Important

---

### Phase 3: Update ModelSchemaView (1 hour) 🟢 OPTIONAL

#### Add DataSource Column
```typescript
// /components/ModelSchemaView.tsx

const getDefaultColumns = (): ColumnConfig[] => [
  { key: 'id', label: 'ID', enabled: true, locked: true },
  { key: 'model', label: 'Model', enabled: true },
  { key: 'dataSourceId', label: 'Data Source', enabled: true },  // ✅ ADD
  { key: 'version', label: 'Version', enabled: true },
  { key: 'state', label: 'State', enabled: true },
  { key: 'semver', label: 'SemVer', enabled: true },
  // ... rest
];

// Display DataSource name instead of ID
if (key === 'dataSourceId') {
  const dataSource = dataSources.find(ds => 
    getDataSourceId(ds) === value
  );
  return dataSource ? getDataSourceName(dataSource) : value || '-';
}
```

**Time Estimate:** 1 hour  
**Priority:** 🟢 Optional (nice to have)

---

### Phase 4: Testing (2 hours)

#### Test Scenarios:

**Test 1: Tenant Filtering**
- [ ] SuperUser selects "Global Tenant"
- [ ] See: Bidtools, Databricks
- [ ] Switch to "BFS Tenant"
- [ ] See: Online, Trend, SAP
- [ ] Do NOT see: Bidtools, Databricks

**Test 2: Data Capture Specifications**
- [ ] Expand "Bidtools" data source
- [ ] See real specifications: Quotes, QuoteDetails, QuotePacks
- [ ] NOT mock data
- [ ] Each spec shows correct version, state

**Test 3: Add Specification**
- [ ] Click "Add Specification" under Bidtools
- [ ] Create dialog opens
- [ ] Create "Orders" specification
- [ ] Specification appears under Bidtools
- [ ] Specification also appears in Transaction Onboarding tab

**Test 4: Edit/Delete Specification**
- [ ] From Data Source view, click Edit on "Quotes"
- [ ] Update version to 1.1.0
- [ ] Changes reflect in both tabs
- [ ] Try to delete "Customer" (protected) → disabled
- [ ] Delete "Orders" → confirmation → removed

**Test 5: Cross-Tab Consistency**
- [ ] Create spec in Data Source Onboarding
- [ ] Go to Transaction Onboarding tab
- [ ] Verify spec appears there
- [ ] Edit in Transaction Onboarding
- [ ] Go back to Data Source Onboarding
- [ ] Verify changes reflected

**Time Estimate:** 2 hours

---

## Summary & Recommendations

### ✅ Current Strengths

1. **Excellent CRUD Implementation**
   - Both DataSource and ModelSchema have full CRUD
   - API integration working
   - Permission-based access control

2. **Good UI/UX Foundation**
   - DataTable component with sorting/filtering
   - Expandable rows for details
   - Column selector
   - Responsive design

3. **Real API Integration**
   - ModelSchemaView uses real `/1.0/txns?TxnType=ModelSchema`
   - DataSourcesView structure ready for API
   - Cosmos DB metadata handling

4. **Protected Types**
   - Customer, Location cannot be edited/deleted
   - Good data safety

### ⚠️ Gaps to Address

1. **🔴 CRITICAL: No Tenant Association**
   - Add TenantId to DataSource interface
   - Add TenantId to ModelSchema interface
   - Filter by activeTenantId
   - Display tenant in tables

2. **🟡 IMPORTANT: No DataSource ↔ ModelSchema Link**
   - Add dataSourceId to ModelSchema
   - Load real specifications for each DataSource
   - Replace mock data with API calls

3. **🟢 NICE TO HAVE: UI Improvements**
   - Show DataSource name in ModelSchemaView
   - Inline spec creation from DataSource view
   - Better visual hierarchy

### 🎯 Final Verdict

**Can Current Interface Support User Story?** 🟡 **YES, with 8 hours of work**

| Aspect | Status | Work Needed |
|--------|--------|-------------|
| Data Sources CRUD | ✅ Ready | 0 hours |
| Specifications CRUD | ✅ Ready | 0 hours |
| Tenant Association | ❌ Missing | 2 hours |
| DS ↔ Spec Link | ❌ Missing | 3 hours |
| UI Polish | ⚠️ Partial | 1 hour |
| Testing | ⏳ Needed | 2 hours |

**Total Effort:** ~8 hours

**Recommendation:**
1. **Phase 1 is CRITICAL** - Must add tenant support
2. **Phase 2 is IMPORTANT** - Should link DS to specs
3. **Phase 3 is OPTIONAL** - Nice to have
4. **Phase 4 is REQUIRED** - Must test thoroughly

**After completion:** Interface will fully support User Story! 🚀

---

**Next Steps:**
1. Check API response for actual field names (TenantId? tenantId? PartitionKey?)
2. Implement Phase 1 (tenant support)
3. Implement Phase 2 (link data sources to specs)
4. Test all scenarios
5. Deploy!

**Status:** Interface is 70% ready, needs backend integration completion
