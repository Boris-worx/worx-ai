# Data Capture Specifications - Проверка Требований ✅

## User Story Требования

### Что такое Data Capture Specification?
> "Определяет данные, хранящиеся в Cosmos для конкретной таблицы в Data Source базе данных"

### Обязательные Поля:

Data Capture Specification ДОЛЖНА включать:

1. ✅ **Tenant ID** - Связь с тенантом
2. ✅ **Version ID** - Версия спецификации
3. ✅ **Data Source ID** - Связь с источником данных
4. ✅ **Specification Name** - Имя (используется с Tenant name для Cosmos container)
5. ✅ **List of required fields** - Список обязательных полей
6. ✅ **JSON structure** - Полная структура данных

---

## 📊 Результат Проверки

### Текущая Реализация (ModelSchema):
```typescript
export interface ModelSchema {
  id: string;
  model: string;             // ✅ #4 - Specification Name
  version: number;           // ✅ #2 - Version ID (число)
  state: string;             // ✅ Бонус - active/draft/archived
  semver: string;            // ✅ #2 - Version ID (semver)
  jsonSchema: any;           // ✅ #6 - JSON структура
  // jsonSchema.required     // ✅ #5 - Required fields
  CreateTime: string;
  UpdateTime: string;
  _etag?: string;
  // ❌ Нет: TenantId         // #1 - Tenant ID
  // ❌ Нет: DataSourceId     // #3 - Data Source ID
}
```

---

## ✅ Что Работает Отлично (4 из 6)

### ✅ #2: Version ID - Отлично!
```typescript
version: 1           // Целое число для простоты
semver: "1.0.0"     // Semantic version для правильного версионирования
```

**Почему это отлично:**
- Двойное отслеживание версий
- `version` для простого подсчета (1, 2, 3...)
- `semver` для правильного версионирования (1.0.0 → 1.1.0 → 2.0.0)
- Можно отслеживать breaking changes vs minor updates

**В UI:**
- Version колонка показывает число
- Semver колонка показывает полную версию
- State показывает active/draft/archived

---

### ✅ #4: Specification Name - Идеально!
```typescript
model: "Customer"    // Имя спецификации = имя таблицы
```

**Как используется:**
- Идентифицирует какую таблицу определяет спецификация
- Используется в UI как основной идентификатор
- User Story: "используется с Tenant name для Cosmos container"

**Naming Convention:**
```typescript
const containerName = `${TenantId}-${model}`;
// Примеры:
// "BFS-Customer"
// "Global-Quotes"
// "Meritage-Order"
```

---

### ✅ #5: List of Required Fields - JSON Schema Standard
```typescript
jsonSchema: {
  "required": ["CustomerId", "Name", "Email"]
}

// Функция для извлечения
const getRequiredFields = (jsonSchema: any): string[] => {
  return jsonSchema?.required || [];
};
```

**В UI:**
- Detail view показывает required fields как badges
- Помогает понять обязательные поля
- Используется для валидации

---

### ✅ #6: JSON Structure of Data Payload - Полная Поддержка!
```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "Customer",
  "type": "object",
  "properties": {
    "CustomerId": {
      "type": "integer",
      "description": "Unique customer identifier"
    },
    "Name": {
      "type": "string",
      "minLength": 1
    },
    "Email": {
      "type": "string",
      "format": "email"
    }
  }
}
```

**Возможности:**
- ✅ Все типы JSON Schema
- ✅ Правила валидации (minLength, format, etc.)
- ✅ Nested objects
- ✅ Arrays
- ✅ References ($ref)

**UI Фичи:**
- Pretty-printed JSON viewer
- Syntax highlighting
- Collapsible sections
- Edit с валидацией

---

## ❌ Что Отсутствует (2 из 6)

### 🔴 #1: Tenant ID (КРИТИЧНО!)

**Текущее Состояние:**
```typescript
// ❌ Нет поля TenantId
```

**Почему КРИТИЧНО:**
- Нельзя связать спецификацию с тенантом
- Нельзя фильтровать по тенанту
- Нельзя обеспечить tenant isolation
- User Story явно требует: "используется с Tenant name для Cosmos container"

**Проблема:**
```
Не можем отличить:
├── Global Tenant
│   ├── Bidtools → Quotes spec
│   └── Databricks → Design spec
└── BFS Tenant
    ├── Online → Customer spec
    └── SAP → Order spec
```

**Решение:**
```typescript
export interface ModelSchema {
  // ... existing fields
  TenantId?: string;  // ✅ ДОБАВИТЬ ЭТО
}

// API вызовы
const specs = await getAllModelSchemas(activeTenantId);
// GET /1.0/txns?TxnType=ModelSchema&TenantId=BFS

// UI колонка
{ key: 'TenantId', label: 'Tenant', enabled: true }

// Отображение
<Badge variant={!value ? 'secondary' : 'default'}>
  {value || 'Global'}
</Badge>
```

**Cosmos Container Naming:**
```typescript
// Формула
const containerName = `${TenantId}-${model}`;

// Примеры:
"Global-Quotes"        // Bidtools Quotes
"BFS-Customer"         // Online Customer
"Meritage-Project"     // Meritage Project
```

---

### 🔴 #3: Data Source ID (КРИТИЧНО!)

**Текущее Состояние:**
```typescript
// ❌ Нет поля DataSourceId
```

**Почему КРИТИЧНО:**
- Нельзя связать спецификацию с Data Source
- Нельзя показать specs под Data Source в UI
- Нельзя фильтровать "Bidtools specs" vs "Online specs"
- User Story: "Each Data Source has Data Capture Specifications"

**Проблема:**
```
Сейчас: Specs без привязки
ModelSchema
├── Customer (из какого Data Source?)
├── Quotes (из какого Data Source?)
└── Order (из какого Data Source?)

Нужно: Specs связаны с Data Sources
Bidtools (Data Source)
├── Quotes (spec)
├── QuoteDetails (spec)
└── QuotePacks (spec)

Online (Data Source)
├── Customer (spec)
└── Order (spec)
```

**Решение:**
```typescript
export interface ModelSchema {
  // ... existing fields
  TenantId?: string;
  DataSourceId?: string;  // ✅ ДОБАВИТЬ ЭТО
}

// API вызовы
const specs = await getAllModelSchemas(tenantId, dataSourceId);
// GET /1.0/txns?TxnType=ModelSchema&DataSourceId=Bidtools

// В DataSourcesView при раскрытии строки
const loadSpecsForDataSource = async (dataSourceId: string) => {
  const specs = await getAllModelSchemas(activeTenantId, dataSourceId);
  setDataSourceSpecs(prev => ({ ...prev, [dataSourceId]: specs }));
};

// Отображение реальных specs вместо mock
{specs.map(spec => (
  <div key={spec.id}>
    <span>{spec.model}</span>
    <Badge>v{spec.semver}</Badge>
    <Badge>{spec.state}</Badge>
  </div>
))}
```

---

## 📋 Compliance Таблица

| № | Требование | Реализация | Статус | Детали |
|---|------------|------------|--------|--------|
| 1 | **Tenant ID** | ❌ Нет | 🔴 **ОТСУТСТВУЕТ** | Нет поля TenantId |
| 2 | **Version ID** | ✅ version + semver | ✅ **ГОТОВО** | Двойное отслеживание |
| 3 | **Data Source ID** | ❌ Нет | 🔴 **ОТСУТСТВУЕТ** | Нет поля DataSourceId |
| 4 | **Spec Name** | ✅ model | ✅ **ГОТОВО** | Используется как имя |
| 5 | **Required Fields** | ✅ jsonSchema.required | ✅ **ГОТОВО** | Массив обязательных полей |
| 6 | **JSON Structure** | ✅ jsonSchema.properties | ✅ **ГОТОВО** | Полная JSON Schema |

**Общая Оценка:** 🟡 **4/6 (67%)**

---

## Пример Полной Спецификации

### До (Сейчас):
```json
{
  "id": "ModelSchema-Customer-1",
  "model": "Customer",
  "version": 1,
  "semver": "1.0.0",
  "state": "active",
  "jsonSchema": {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "title": "Customer",
    "type": "object",
    "required": ["CustomerId", "Name"],
    "properties": {
      "CustomerId": { "type": "integer" },
      "Name": { "type": "string" },
      "Email": { "type": "string", "format": "email" }
    }
  },
  "CreateTime": "2025-11-04T10:00:00Z",
  "UpdateTime": "2025-11-04T10:00:00Z"
}
```

### После (Со Всеми Требованиями):
```json
{
  "id": "ModelSchema-Customer-1",
  "model": "Customer",
  "version": 1,
  "semver": "1.0.0",
  "state": "active",
  "TenantId": "BFS",                        // ✅ #1 - Tenant ID
  "DataSourceId": "Online-Informix",        // ✅ #3 - Data Source ID
  "jsonSchema": {                            // ✅ #6 - JSON Structure
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "title": "Customer",
    "type": "object",
    "required": ["CustomerId", "Name"],     // ✅ #5 - Required Fields
    "properties": {
      "CustomerId": { "type": "integer" },
      "Name": { "type": "string" },
      "Email": { "type": "string", "format": "email" }
    }
  },
  "CreateTime": "2025-11-04T10:00:00Z",
  "UpdateTime": "2025-11-04T10:00:00Z"
}

// Cosmos Container: "BFS-Customer"
```

---

## Визуальное Сравнение

### Сейчас:
```
Transaction Onboarding Tab
┌──────────────────────────────────────┐
│ Model    | Version | State          │
├──────────────────────────────────────┤
│ Customer | 1       | active         │  ❌ No Tenant
│ Quotes   | 1       | active         │  ❌ No DataSource
│ Order    | 1       | active         │  ❌ Can't filter
└──────────────────────────────────────┘
```

### После Исправления:
```
🏢 BFS Tenant

Transaction Onboarding Tab
┌──────────────────────────────────────────────────┐
│ Model    | DS     | Tenant | Ver | State       │
├──────────────────────────────────────────────────┤
│ Customer | Online | BFS    | 1   | active      │ ✅
│ Order    | Online | BFS    | 1   | active      │ ✅
└──────────────────────────────────────────────────┘

🏢 Global Tenant
┌──────────────────────────────────────────────────┐
│ Model        | DS         | Tenant | Ver | State│
├──────────────────────────────────────────────────┤
│ Quotes       | Bidtools   | Global | 1   | act. │ ✅
│ QuoteDetails | Bidtools   | Global | 1   | act. │ ✅
│ QuotePacks   | Bidtools   | Global | 1   | act. │ ✅
│ Design       | Databricks | Global | 1   | act. │ ✅
└──────────────────────────────────────────────────┘

Data Source Onboarding Tab
┌──────────────────────────────────────────────────┐
│ Bidtools (SQL Server) [Global]                   │
│  └─ Data Capture Specifications:                │
│     ├── Quotes (v1.0.0) active     ✅ Real API  │
│     ├── QuoteDetails (v1.0.0) act. ✅ Real API  │
│     └── QuotePacks (v1.0.0) active ✅ Real API  │
└──────────────────────────────────────────────────┘
```

---

## 🚀 План Действий

### Фаза 1: Добавить TenantId (2 часа) 🔴

**Изменения:**
1. Обновить интерфейс ModelSchema
2. Обновить API функции (передавать tenantId)
3. Добавить Tenant колонку в таблицу
4. Фильтровать по активному тенанту
5. Отображать tenant badge

**Результат:**
- Specs фильтруются по тенанту
- Видно какой spec принадлежит какому тенанту
- Cosmos container naming работает

---

### Фаза 2: Добавить DataSourceId (3 часа) 🔴

**Изменения:**
1. Обновить интерфейс ModelSchema
2. Обновить API функции (фильтровать по dataSourceId)
3. Загружать реальные specs при раскрытии Data Source
4. Добавить DataSource колонку в ModelSchemaView
5. Pre-fill DataSourceId при создании из Data Source контекста

**Результат:**
- Specs связаны с Data Sources
- В DataSourcesView показываются реальные specs
- Hierarchical view работает

---

### Фаза 3: Тестирование (2 часа) ✅

**Тесты:**
- [ ] Tenant filtering работает
- [ ] Data Source linking работает
- [ ] Real specs показываются в DataSourcesView
- [ ] Create/Edit/Delete из обеих вкладок
- [ ] Cross-tab consistency
- [ ] Container naming корректен

---

## 📊 Итоговая Оценка

### ✅ Сильные Стороны

**Что Отлично (4/6):**
1. ✅ Version tracking - лучше чем требуется
2. ✅ Specification naming - идеально
3. ✅ Required fields - стандарт JSON Schema
4. ✅ JSON structure - полная поддержка draft-2020-12

**Качество:**
- JSON Schema реализация идеальная
- UI для просмотра/редактирования отличный
- Protected types - бонус
- Versioning с двойным отслеживанием

---

### ⚠️ Что Нужно (2/6)

**Отсутствует:**
1. ❌ TenantId field
2. ❌ DataSourceId field

**Влияние:**
- Не работает фильтрация по тенанту
- Нет связи spec с Data Source
- Не работает hierarchical view
- Cosmos container naming неполный

---

### 🎯 Финальный Счет

| Категория | Оценка | Статус |
|-----------|--------|--------|
| **Обязательные поля присутствуют** | 4/6 | 67% |
| **Присутствующие поля работают** | 4/4 | 100% |
| **Отсутствующие поля** | 0/2 | 0% |
| **ИТОГО** | **67%** | 🟡 |

---

## 🎯 Вердикт

### Может ли интерфейс поддержать User Story?

**Ответ:** 🟡 **ДА - 67% готово, нужно 7 часов работы**

**Что Готово:**
- ✅ JSON Schema implementation - отлично
- ✅ Version tracking - отлично  
- ✅ Required fields - отлично
- ✅ Data structure - отлично

**Что Нужно:**
- ❌ TenantId field (2 часа)
- ❌ DataSourceId field (3 часа)
- ✅ Testing (2 часа)

**Усилия:** 7 часов  
**Результат:** 100% compliance ✅

---

## 📚 Документация

1. **[DATA_CAPTURE_SPEC_REQUIREMENTS_CHECK.md](./DATA_CAPTURE_SPEC_REQUIREMENTS_CHECK.md)** - Полный анализ (EN)
2. **[DATA_CAPTURE_SPEC_ПРОВЕРКА_ТРЕБОВАНИЙ.md](./DATA_CAPTURE_SPEC_ПРОВЕРКА_ТРЕБОВАНИЙ.md)** - Этот файл (RU)
3. **[DATA_SOURCES_USER_STORY_ANALYSIS.md](./DATA_SOURCES_USER_STORY_ANALYSIS.md)** - DS анализ
4. **[DATA_SOURCES_ПРОВЕРКА.md](./DATA_SOURCES_ПРОВЕРКА.md)** - DS проверка

---

**Bottom Line:** Текущая реализация на 67% соответствует требованиям. Добавление TenantId и DataSourceId полей обеспечит 100% соответствие. Все остальные требования уже выполнены с отличным качеством! 🎯

**Следующие шаги:**
1. Добавить TenantId (2 часа)
2. Добавить DataSourceId (3 часа)
3. Протестировать (2 часа)
4. Deploy! 🚀
