# Technology Stack & Architecture

## BFS Platform Management Application

**Complete technology breakdown and architectural decisions**

---

## 🎯 Core Technologies

### Frontend Framework
**React 18+**
- Component-based architecture
- Hooks for state management (useState, useEffect, useRef)
- Functional components only (no class components)
- Virtual DOM for efficient rendering
- Server-side rendering ready

### Type Safety
**TypeScript**
- Static type checking
- Interface definitions for all data structures
- Type-safe API responses
- Enhanced IDE support and autocomplete
- Reduced runtime errors

### Styling
**Tailwind CSS v4**
- Utility-first CSS framework
- Custom design tokens via CSS variables
- Dark mode support built-in
- Responsive design utilities
- Zero runtime overhead
- JIT (Just-In-Time) compilation

**Custom CSS Variables:**
```css
:root {
  --background: #ffffff;
  --foreground: oklch(0.145 0 0);
  --primary: #030213;
  --radius: 0.625rem;
  /* ... and 30+ more tokens */
}
```

---

## 🧩 UI Component Library

### shadcn/ui
**44 Pre-built Components**

Component library built on:
- **Radix UI** - Headless, accessible primitives
- **Tailwind CSS** - Styling
- **CVA (Class Variance Authority)** - Variant management

**Key Components Used:**
- **Data Display:** Card, Table, Badge, Alert
- **Forms:** Input, Textarea, Select, Checkbox, Label
- **Dialogs:** Dialog, Alert Dialog, Sheet
- **Navigation:** Tabs, Breadcrumb
- **Feedback:** Toast (Sonner), Progress, Skeleton
- **Layout:** Scroll Area, Separator, Aspect Ratio

**Benefits:**
- ✅ Fully accessible (WCAG 2.1 compliant)
- ✅ Keyboard navigation
- ✅ Screen reader support
- ✅ Customizable without wrapper components
- ✅ Copy-paste friendly (not installed as dependency)

### Icons
**Lucide React**
- 1000+ consistent icons
- Tree-shakeable (only import what you use)
- Customizable size and color
- SVG-based for crisp rendering

**Icons Used:**
- `Building2` - Tenants
- `Receipt` - Transactions
- `Wrench` - Builder
- `Plus`, `Trash2`, `Pencil` - Actions
- `Upload`, `Link2`, `Play` - File operations
- `RefreshCw`, `X`, `FileJson` - UI actions

---

## 📡 Data & API Layer

### HTTP Client
**Native Fetch API**
- Modern browser API
- Promise-based
- No external dependencies
- Streaming support

### API Architecture
**RESTful API**
- Standard HTTP methods (GET, POST, PUT, DELETE)
- JSON request/response bodies
- Status code-based error handling

**Endpoints:**
```
GET    /tenants           - List all tenants
GET    /tenants/{id}      - Get tenant details
POST   /tenants           - Create tenant
PUT    /tenants/{id}      - Update tenant
DELETE /tenants/{id}      - Delete tenant

GET    /transactions      - List all transactions
GET    /transactions/{id} - Get transaction details
POST   /transactions      - Create transaction
```

### Authentication
**Custom Header-Based Auth**
```http
X-BFS-Auth: {api-key}
```
- Client secret/key header
- Every endpoint protected
- Configurable in single location

### Concurrency Control
**ETag-Based Optimistic Locking**
```http
If-Match: "e600adff-0000-0300-0000-68df16be0000"
```
- Used for PUT and DELETE operations
- Prevents lost updates
- Cosmos DB native support

---

## 💾 Backend & Database

### Database
**Azure Cosmos DB**
- NoSQL document database
- JSON document storage
- Automatic indexing
- Global distribution ready
- ACID transactions

**Data Models:**
```typescript
// Tenant Document
{
  TenantId: string;
  TenantName: string;
  CreateTime: string;
  UpdateTime: string;
  _rid: string;
  _self: string;
  _etag: string;
  _attachments: string;
  _ts: number;
}

// Transaction Document
{
  TransactionId: string;
  TransactionName: string;
  RequestJSON: any;
  ResponseJSON: any;
  CreateTime: string;
  UpdateTime: string;
  _etag: string;
}
```

---

## 🔧 Browser APIs

### File Operations
**FileReader API**
- Client-side file reading
- Support for text files (JSON, YAML, TXT)
- Async file processing
- No server upload needed for preview

**Usage:**
```typescript
const reader = new FileReader();
reader.onload = (e) => {
  const content = e.target?.result as string;
  const json = JSON.parse(content);
};
reader.readAsText(file);
```

### Clipboard
**Clipboard API**
- Read from clipboard
- Paste URL functionality
- Permission-based access

**Usage:**
```typescript
const text = await navigator.clipboard.readText();
```

### Notifications
**Sonner (Toast Library)**
- Non-blocking notifications
- Success, error, info variants
- Auto-dismiss or persistent
- Stacking support
- Accessible announcements

**Usage:**
```typescript
toast.success('Operation completed');
toast.error('Something went wrong');
toast.info('Demo mode active');
```

---

## 🏗️ Architecture Patterns

### Component Architecture

**Container/Presentational Pattern:**
```
TenantsView (Container)
  ├── DataTable (Presentational)
  ├── TenantDetail (Presentational)
  ├── TenantEditForm (Presentational)
  └── TenantImportDialog (Presentational)
```

**Benefits:**
- Separation of concerns
- Reusable presentational components
- Testable business logic
- Clear data flow

### State Management
**React Hooks (Local State)**
- `useState` - Component state
- `useEffect` - Side effects (API calls, subscriptions)
- `useRef` - DOM references and mutable values

**No global state library needed:**
- Application is relatively simple
- Tab-based navigation isolates state
- Each view manages its own data
- No complex state sharing needed

### Data Fetching Pattern
**Fetch-on-Mount with Manual Refresh**

```typescript
useEffect(() => {
  loadData();
}, []); // Load on mount

const loadData = async () => {
  const data = await api.getAllItems();
  setState(data);
};

// Manual refresh available
<Button onClick={loadData}>Refresh</Button>
```

**Benefits:**
- Simple and predictable
- Works well with demo mode
- No stale data complexity
- User-controlled updates

---

## 🎨 Design System

### Color System
**OKLCH Color Space**
- Perceptually uniform colors
- Better than RGB/HSL
- Consistent lightness
- Smooth gradients

**Semantic Tokens:**
- `--background` / `--foreground`
- `--primary` / `--primary-foreground`
- `--secondary` / `--secondary-foreground`
- `--muted` / `--muted-foreground`
- `--accent` / `--accent-foreground`
- `--destructive` / `--destructive-foreground`

### Dark Mode
**CSS Variable Swap**
```css
:root { --background: #ffffff; }
.dark { --background: oklch(0.145 0 0); }
```

### Typography
**System Font Stack**
- Base size: 16px
- Responsive scaling
- Semantic heading sizes (h1-h4)
- Weight variations (normal: 400, medium: 500)

**Typography Hierarchy:**
```css
h1 { font-size: var(--text-2xl); }  /* ~2rem */
h2 { font-size: var(--text-xl); }   /* ~1.5rem */
h3 { font-size: var(--text-lg); }   /* ~1.25rem */
h4 { font-size: var(--text-base); } /* 1rem */
```

### Spacing System
**Tailwind Default Scale (4px base)**
- `gap-2` = 8px
- `gap-4` = 16px
- `gap-6` = 24px
- `py-8` = 32px vertical padding

### Border Radius
**Custom Radius Token**
```css
--radius: 0.625rem; /* 10px */
--radius-sm: calc(var(--radius) - 4px);
--radius-lg: var(--radius);
```

---

## 🔀 Routing & Navigation

### Tab-Based Navigation
**Shadcn Tabs Component**
- No router library needed
- Client-side tab switching
- State preserved per tab
- URL-independent (could add URL sync later)

**Tabs:**
1. Tenants - Supplier management
2. Transactions - ERP transactions
3. Builder - Workflow configuration

---

## 📦 Build & Development

### Build Tool
**Vite (Implied)**
- Fast HMR (Hot Module Replacement)
- ES modules native
- Optimized production builds
- Plugin ecosystem

### Package Manager
**npm/yarn/pnpm**
- Dependency management
- Script running
- Lock file for consistency

### Code Quality

**TypeScript Compiler:**
- Type checking
- Interface validation
- Compile-time errors

**ESLint (Recommended):**
- Code style enforcement
- Best practices
- Auto-fixable issues

---

## 🧪 Testing Strategy (Recommended)

### Unit Testing
**Vitest** (Vite-native test runner)
- Component testing
- API function testing
- Fast execution

### Integration Testing
**React Testing Library**
- User-centric tests
- Accessibility checks
- DOM queries

### E2E Testing
**Playwright**
- Full user flows
- Multi-browser support
- Screenshot comparison

---

## 🚀 Performance Optimizations

### Code Splitting
- React lazy loading (if needed)
- Route-based splitting
- Component lazy imports

### Asset Optimization
- SVG icons (vector, scalable)
- No image dependencies
- Minimal CSS footprint

### Bundle Size
- Tree-shaking enabled
- No unused UI components
- Modular imports

### Runtime Performance
- Virtual scrolling (if needed for large lists)
- Debounced search input
- Memoization for expensive computations

---

## 🔒 Security

### Client-Side
- XSS prevention (React escapes by default)
- Input validation
- No eval() usage
- CSP-friendly

### API Security
- X-BFS-Auth header authentication
- HTTPS only (production)
- CORS configuration
- ETag for concurrency

### Data Handling
- No sensitive data in localStorage
- Secure JSON parsing (try-catch)
- File upload validation

---

## 🌐 Browser Support

### Modern Browsers
- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

### Required Features
- ES6+ JavaScript
- Fetch API
- CSS Custom Properties
- FileReader API
- Clipboard API

### Polyfills
- Not required for modern browsers
- Consider for legacy support if needed

---

## 📊 Data Formats

### Supported Formats

**Input:**
- JSON (application/json)
- YAML (.yaml, .yml)
- Plain text (.txt)

**Output:**
- JSON (application/json)
- Formatted JSON display

### Serialization
- `JSON.stringify(data, null, 2)` - Pretty printing
- `JSON.parse(text)` - Parsing

---

## 🔄 Development Modes

### Demo Mode
**Mock Data + No API Calls**

```typescript
const DEMO_MODE = API_BASE_URL.includes('example.com');

if (DEMO_MODE) {
  // Return mock data
  return demoTenants;
} else {
  // Call real API
  return fetch(API_BASE_URL);
}
```

**Benefits:**
- Instant testing without backend
- Realistic data structures
- Full UI/UX validation
- Safe for demonstrations

### Production Mode
**Real API Integration**

```typescript
const API_BASE_URL = 'https://mahesh-api.com/1.0';
const AUTH_HEADER_VALUE = 'actual-api-key';
```

**Switch with 2 lines:**
- Update URL
- Update API key

---

## 🗂️ Project Structure

### Architecture Layers

```
┌─────────────────────────────────────┐
│         Presentation Layer          │
│  (React Components, UI, Styling)    │
├─────────────────────────────────────┤
│         Business Logic Layer        │
│    (State, Validation, Handlers)    │
├─────────────────────────────────────┤
│           Data Layer                │
│       (API calls, Data types)       │
├─────────────────────────────────────┤
│         External Services           │
│    (Cosmos DB, REST API, Auth)      │
└─────────────────────────────────────┘
```

### File Organization

**Component Structure:**
```
/components
  /ui           - Reusable UI primitives
  /[Feature]    - Feature-specific components
```

**Colocation:**
- Components near related code
- Styles via Tailwind (no separate CSS files)
- Types inline or in shared types file

---

## 🛠️ Development Tools

### IDE Recommendations
- **VS Code** with extensions:
  - Tailwind CSS IntelliSense
  - TypeScript and JavaScript Language Features
  - ES7+ React/Redux/React-Native snippets
  - Prettier

### Browser DevTools
- React Developer Tools
- Network tab for API debugging
- Console for logging
- Lighthouse for performance

---

## 📈 Scalability Considerations

### Current Scale
- ✅ 3-100 tenants
- ✅ 16-1000 transactions
- ✅ Single user per session

### Future Scale
- Pagination for large datasets
- Virtual scrolling for tables
- Search API for server-side filtering
- Caching strategies
- WebSocket for real-time updates

---

## 🔮 Technology Decisions & Trade-offs

### Why React?
- ✅ Industry standard
- ✅ Large ecosystem
- ✅ Excellent TypeScript support
- ✅ Component reusability
- ✅ Strong community

### Why Tailwind CSS v4?
- ✅ Utility-first approach
- ✅ No runtime cost
- ✅ Consistent design
- ✅ Easy customization
- ✅ Dark mode built-in

### Why shadcn/ui?
- ✅ Not a dependency (copy-paste)
- ✅ Full customization
- ✅ Accessibility out of box
- ✅ Radix UI foundation
- ✅ No lock-in

### Why No State Management Library?
- ✅ Application complexity doesn't warrant it
- ✅ Tab isolation reduces state sharing
- ✅ React hooks sufficient
- ✅ Simpler codebase
- ✅ Easier to understand

### Why Fetch over Axios?
- ✅ Native browser API
- ✅ No dependency
- ✅ Modern Promise-based
- ✅ Streaming support
- ✅ Sufficient for needs

### Why No Router?
- ✅ Tab-based navigation sufficient
- ✅ Simpler architecture
- ✅ No URL management needed
- ✅ Can add later if needed

---

## 📚 External Resources

### Documentation
- [React Docs](https://react.dev)
- [TypeScript Handbook](https://www.typescriptlang.org/docs/)
- [Tailwind CSS v4](https://tailwindcss.com)
- [shadcn/ui](https://ui.shadcn.com)
- [Radix UI](https://www.radix-ui.com)
- [Lucide Icons](https://lucide.dev)

### Learning Resources
- React patterns and best practices
- TypeScript with React
- Tailwind utility patterns
- API integration patterns

---

## 🎯 Summary

### Core Stack
```
React 18+ + TypeScript
    ↓
Tailwind CSS v4 (Styling)
    ↓
shadcn/ui (UI Components)
    ↓
Lucide React (Icons)
    ↓
Fetch API (HTTP)
    ↓
Cosmos DB (Backend)
```

### Key Features
- ✅ Modern, type-safe frontend
- ✅ Component-based architecture
- ✅ Utility-first styling
- ✅ Accessible UI components
- ✅ RESTful API integration
- ✅ ETag-based concurrency
- ✅ Demo mode for development

### Technology Goals
- **Performance:** Fast, efficient rendering
- **Maintainability:** Clear code structure
- **Accessibility:** WCAG 2.1 compliant
- **Developer Experience:** TypeScript, hot reload, good tooling
- **User Experience:** Responsive, intuitive, feedback-rich

---

**Technology stack optimized for enterprise BFS platform management!** 🚀
