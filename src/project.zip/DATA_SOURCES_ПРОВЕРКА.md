# Data Sources - Проверка Интерфейса ✅

## User Story Требования

### Data Sources должны:
1. ✅ Подключаться к Data Plane через ACE - *backend*
2. ✅ Поддерживать CDC (Change Data Capture) - *backend*
3. ⚠️ **Быть связаны с global или specific tenant** - *нужно в UI*
4. ⚠️ **Иметь Data Capture Specifications (по одной на таблицу)** - *нужно в UI*
5. ✅ CRUD через TxServices API - *есть*

### Примеры:
```
Global Tenant:
├── Bidtools (SQL Server)
│   ├── Quotes
│   ├── QuoteDetails  
│   └── QuotePacks
└── Databricks
    └── Design

BFS Tenant:
├── Online (Informix)
│   ├── Customer
│   └── Order
├── Trend
└── SAP
```

---

## 📊 Результат Проверки

### ✅ Что Работает Отлично (90%)

#### 1. Data Source Onboarding Tab
**CRUD Операции:** ✅ Полностью Реализованы
- Create: "Add New Data Source" ✅
- Read: Таблица со всеми источниками ✅
- Update: Edit кнопка ✅
- Delete: Delete с подтверждением ✅

**UI Функции:** ✅ Отличные
- DataTable с сортировкой/поиском
- Column selector (показать/скрыть колонки)
- Expandable rows (раскрывающиеся строки)
- Permission-based access
- Tenant selector интеграция
- Responsive design

**Поля Data Source:**
```typescript
interface DataSource {
  DataSourceId: string;
  DataSourceName: string;
  Type: string;              // ✅ "SQL Server", "Informix"
  ConnectionString: string;
  Description: string;
  Status: string;
  CreateTime: string;
  // ❌ Нет: TenantId
}
```

#### 2. Transaction Onboarding Tab (ModelSchemaView)
**Это и есть Data Capture Specifications!** ✅

```typescript
interface ModelSchema {
  id: string;
  model: string;          // ✅ Имя таблицы (Quotes, Customer)
  version: number;        // ✅ Версия
  state: string;          // ✅ active/draft/archived
  semver: string;         // ✅ "1.0.0"
  jsonSchema: any;        // ✅ JSON Schema (draft-2020-12)
  CreateTime: string;
  UpdateTime: string;
  // ❌ Нет: TenantId
  // ❌ Нет: dataSourceId - связь с DataSource
}
```

**CRUD для Schemas:** ✅ Полностью Работает
- Create: "Add Data Capture Spec" ✅
- Read: Таблица со всеми схемами ✅
- Update: Edit (с защитой типов) ✅
- Delete: Delete (с защитой Customer/Location) ✅
- View: Detail dialog с форматированным JSON ✅

---

### ⚠️ Что Не Работает (Критичные Проблемы)

#### 🔴 Проблема 1: Нет TenantId

**Текущее Состояние:**
```
Data Sources Tab:
┌──────────────────────────────────┐
│ Name      | Type       | Status  │
├──────────────────────────────────┤
│ Bidtools  | SQL Server | Active  │  ← Не видно что это Global
│ Online    | Informix   | Active  │  ← Не видно что это BFS
│ Databricks| Cloud      | Active  │  ← Не видно что это Global
└──────────────────────────────────┘
```

**Проблема:**
- Невозможно отличить global от tenant-specific
- Не работает фильтрация по тенанту
- User Story требует разделение

**Решение:**
```typescript
interface DataSource {
  // ... existing fields
  TenantId?: string;  // ✅ ДОБАВИТЬ
}

interface ModelSchema {
  // ... existing fields
  TenantId?: string;      // ✅ ДОБАВИТЬ
  dataSourceId?: string;  // ✅ ДОБАВИТЬ - связь с DataSource
}
```

---

#### 🟡 Проблема 2: Data Sources и Specifications Не Связаны

**Текущее Состояние:**

```
Data Source Onboarding Tab:
├── Bidtools
│   └── Shows MOCK specifications ❌
│       • Quotes (mock)
│       • QuoteDetails (mock)

Transaction Onboarding Tab:
├── Customer (real) ✅
├── Quotes (real) ✅
└── Location (real) ✅
    ❌ Но нет связи с Bidtools!
```

**User Story Ожидает:**
```
Data Source Onboarding Tab:
├── Bidtools (SQL Server)
│   ├── Quotes (v1.0.0) ✅ Real from API
│   ├── QuoteDetails (v1.0.0) ✅ Real from API  
│   └── QuotePacks (v1.0.0) ✅ Real from API
└── Online (Informix)
    ├── Customer (v1.0.0) ✅ Real from API
    └── Order (v1.0.0) ✅ Real from API
```

**Решение:**
```typescript
// Загрузить реальные schemas для DataSource
const loadSpecsForDataSource = async (dataSourceId: string) => {
  const specs = await getAllModelSchemas(activeTenantId, dataSourceId);
  // Display real specs instead of mock
};
```

---

#### 🟢 Проблема 3: Кнопка "Add Specification" Не Работает

**Текущий Код:**
```typescript
onClick={() => {
  toast.info('Add Data Capture Specification - Coming soon!');
}}
```

**Нужно:**
- Открывать create dialog
- Pre-fill dataSourceId
- Создавать реальную specification

---

## 🎯 Соответствие User Story

| Требование | Статус | Примечание |
|------------|--------|------------|
| Data Sources CRUD | ✅ Готово | Полностью работает |
| Cosmos Storage | ✅ Готово | _etag, _rid и т.д. |
| TxServices API | ✅ Готово | Интеграция работает |
| **Global/Tenant Association** | ❌ Нет | Нет TenantId поля |
| **Data Capture Specifications** | 🟡 Частично | Есть, но не связаны |
| One Spec Per Table | ✅ Готово | model field = table name |
| Spec CRUD | ✅ Готово | Полный CRUD работает |
| ACE Integration | N/A | Backend |
| CDC Support | N/A | Backend |

**Общий Статус:** 🟡 **70% Готово**

---

## 🚀 Что Нужно Сделать

### Фаза 1: Добавить Tenant (2 часа) 🔴 КРИТИЧНО

#### 1.1 Обновить Интерфейсы
```typescript
// /lib/api.ts
export interface DataSource {
  DataSourceId?: string;
  DataSourceName?: string;
  Type?: string;
  TenantId?: string;          // ✅ ДОБАВИТЬ
  // ... rest
}

export interface ModelSchema {
  id: string;
  model: string;
  TenantId?: string;          // ✅ ДОБАВИТЬ
  dataSourceId?: string;      // ✅ ДОБАВИТЬ
  // ... rest
}
```

#### 1.2 Обновить API Функции
```typescript
// Передавать tenantId в API
const data = await getAllDataSources(activeTenantId);
const specs = await getAllModelSchemas(activeTenantId);
```

#### 1.3 Добавить Tenant Колонку
```typescript
// DataSourcesView.tsx
{ key: 'TenantId', label: 'Tenant', enabled: true }

// Render
<Badge variant={!value ? 'secondary' : 'default'}>
  {value || 'Global'}
</Badge>
```

**Время:** 2 часа  
**Приоритет:** 🔴 Критично

---

### Фаза 2: Связать DataSources и Specifications (3 часа) 🟡 ВАЖНО

#### 2.1 Загрузить Реальные Specifications
```typescript
// Заменить mock на реальные данные из API
const [dataSourceSpecs, setDataSourceSpecs] = useState<Record<string, ModelSchema[]>>({});

const loadSpecsForDataSource = async (dataSourceId: string) => {
  const specs = await getAllModelSchemas(activeTenantId, dataSourceId);
  setDataSourceSpecs(prev => ({ ...prev, [dataSourceId]: specs }));
};

// При раскрытии строки
const handleRowExpand = (dataSource: DataSource) => {
  loadSpecsForDataSource(getDataSourceId(dataSource));
};
```

#### 2.2 Отобразить Реальные Specifications
```typescript
// В expandable row
const specifications = dataSourceSpecs[getDataSourceId(row)] || [];

{specifications.map((spec) => (
  <div>
    <span>{spec.model}</span>
    <Badge>v{spec.semver}</Badge>
    <Badge variant={spec.state === 'active' ? 'default' : 'secondary'}>
      {spec.state}
    </Badge>
    {/* View/Edit/Delete buttons */}
  </div>
))}
```

#### 2.3 Реализовать "Add Specification"
```typescript
// Вместо toast открыть dialog
const handleAddSpec = (dataSource: DataSource) => {
  setSelectedDataSource(dataSource);
  setIsAddSpecDialogOpen(true);
};

// В create handler
const newSpec = {
  model: modelName,
  version: 1,
  dataSourceId: getDataSourceId(selectedDataSource), // ✅ Link
  TenantId: activeTenantId !== 'global' ? activeTenantId : undefined,
  jsonSchema: JSON.parse(jsonSchemaText)
};
```

**Время:** 3 часа  
**Приоритет:** 🟡 Важно

---

### Фаза 3: Тестирование (2 часа)

#### Тест 1: Фильтрация по Tenant
- [ ] SuperUser выбирает "Global Tenant"
- [ ] Видит: Bidtools, Databricks
- [ ] Переключается на "BFS Tenant"
- [ ] Видит: Online, Trend, SAP
- [ ] НЕ видит: Bidtools, Databricks

#### Тест 2: Real Specifications
- [ ] Раскрыть "Bidtools"
- [ ] Видит РЕАЛЬНЫЕ specs: Quotes, QuoteDetails, QuotePacks
- [ ] НЕ mock данные
- [ ] Правильные версии и state

#### Тест 3: Add Specification
- [ ] Click "Add Specification" под Bidtools
- [ ] Create dialog открывается
- [ ] Создать "Orders" spec
- [ ] Spec появляется под Bidtools
- [ ] Spec также виден в Transaction Onboarding

#### Тест 4: Edit/Delete Specification
- [ ] Edit "Quotes" из Data Source view
- [ ] Update version → 1.1.0
- [ ] Changes видны в обеих вкладках
- [ ] Try delete "Customer" (protected) → disabled
- [ ] Delete "Orders" → confirmation → removed

#### Тест 5: Cross-Tab Consistency
- [ ] Create spec в Data Source Onboarding
- [ ] Switch to Transaction Onboarding
- [ ] Spec появился там
- [ ] Edit в Transaction Onboarding
- [ ] Switch back to Data Source Onboarding
- [ ] Changes reflected

**Время:** 2 часа

---

## 📋 Итоговая Оценка

### ✅ Сильные Стороны

1. **Отличная CRUD Реализация**
   - DataSource и ModelSchema полностью работают
   - API интеграция рабочая
   - Permission-based контроль

2. **Хороший UI/UX Фундамент**
   - DataTable с sorting/filtering
   - Expandable rows
   - Column selector
   - Responsive

3. **Реальная API Интеграция**
   - ModelSchemaView использует `/1.0/txns?TxnType=ModelSchema`
   - Cosmos DB metadata handling
   - ETag concurrency control

4. **Защищённые Типы**
   - Customer, Location нельзя изменить/удалить
   - Хорошая защита данных

### ⚠️ Что Нужно Доработать

| Компонент | Статус | Работа |
|-----------|--------|--------|
| Data Sources CRUD | ✅ Готово | 0 часов |
| Specifications CRUD | ✅ Готово | 0 часов |
| Tenant Association | ❌ Нет | 2 часа |
| DS ↔ Spec Link | ❌ Нет | 3 часа |
| UI Polish | ⚠️ Partial | 1 час |
| Testing | ⏳ Нужно | 2 часа |

**Итого:** ~8 часов работы

---

## 🎯 Финальный Вердикт

**Может ли интерфейс поддержать User Story?**  
🟡 **ДА, с 8 часами работы**

**Текущее Состояние:** 70% готово

**Что Готово:**
- ✅ UI/UX дизайн отличный
- ✅ CRUD операции работают
- ✅ API интеграция есть
- ✅ Структура правильная

**Что Нужно:**
- ❌ Добавить TenantId (2 часа)
- ❌ Связать DS с Specs (3 часа)
- ❌ UI polish (1 час)
- ❌ Тестирование (2 часа)

**Рекомендация:**
1. **Фаза 1 КРИТИЧНА** - без tenant support не работает изоляция
2. **Фаза 2 ВАЖНА** - без связи DS↔Spec не показываем правильные данные
3. **Фаза 3 ОБЯЗАТЕЛЬНА** - нужно протестировать

**После завершения:** Интерфейс полностью поддержит User Story! 🚀

---

## 📝 Следующие Шаги

1. ✅ Проверить API response на наличие TenantId, dataSourceId полей
2. 🔴 Реализовать Фазу 1 (tenant support) - 2 часа
3. 🟡 Реализовать Фазу 2 (link DS to specs) - 3 часа
4. ✅ Протестировать все сценарии - 2 часа
5. 🚀 Deploy!

**Статус:** Интерфейс готов на 70%, нужна доработка backend интеграции

**Документация:** См. `/DATA_SOURCES_USER_STORY_ANALYSIS.md` для детального анализа
