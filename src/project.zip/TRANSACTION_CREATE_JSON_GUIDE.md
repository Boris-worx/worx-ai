# Transaction Create Dialog - JSON Text Input Guide

## Overview

The Transaction Create Dialog has been updated to use **JSON text input** instead of file upload, matching the style of the ModelSchema create dialog. This provides a more streamlined workflow for creating transactions.

## What Changed

### Before (Old)
- ❌ Required uploading a JSON file
- ❌ Immediate submission on file selection
- ❌ No ability to edit before submission
- ❌ Had to prepare JSON files externally

### After (New)
- ✅ Direct JSON text input in a textarea
- ✅ Edit JSON before submission
- ✅ Pre-filled templates for each transaction type
- ✅ Real-time JSON validation
- ✅ Better error messages

## How to Use

### 1. Open the Create Dialog
- Click **"Create Transaction"** button in the Data Plane tab
- The dialog will open with a pre-filled JSON template

### 2. Transaction Type
- The transaction type is automatically set to the currently selected type
- You can see the type in the info banner at the top

### 3. Edit the JSON
The textarea contains a pre-filled template with example data:
```json
{
  "CustomerId": "CUST-1730123456",
  "Name": "John Doe",
  "Email": "john.doe@example.com",
  "Phone1": "+1-555-0123",
  "Address": "123 Main Street",
  "City": "New York",
  "State": "NY",
  "ZipCode": "10001",
  "Country": "USA",
  "CustomerType": "Individual",
  "Status": "Active",
  "CreditLimit": 10000
}
```

**Edit the values** to match your actual data:
- Replace example IDs with real IDs
- Update names, emails, addresses, etc.
- Modify amounts, dates, and other values
- Add or remove fields as needed

### 4. JSON Validation
- The JSON is validated automatically when you click away from the field
- If there's an error, you'll see a red error message below the textarea
- Common errors:
  - Missing quotes around strings
  - Missing commas between fields
  - Extra commas at the end
  - Mismatched brackets `{}` or `[]`

### 5. Submit
- Click **"Create Transaction"** to submit
- If JSON is valid, the transaction will be created
- If invalid, fix the errors and try again

## JSON Templates

### Customer Template
```json
{
  "CustomerId": "CUST-1730123456",
  "Name": "John Doe",
  "Email": "john.doe@example.com",
  "Phone1": "+1-555-0123",
  "Phone2": "",
  "Address": "123 Main Street",
  "City": "New York",
  "State": "NY",
  "ZipCode": "10001",
  "Country": "USA",
  "CustomerType": "Individual",
  "Status": "Active",
  "CreditLimit": 10000,
  "Notes": ""
}
```

### Invoice Template
```json
{
  "InvoiceId": "INV-1730123456",
  "CustomerId": "CUST-12345",
  "InvoiceDate": "2025-10-28",
  "DueDate": "2025-11-27",
  "TotalAmount": 1500.00,
  "Currency": "USD",
  "Status": "Draft",
  "PaymentTerms": "Net 30",
  "LineItems": [
    {
      "ItemId": "ITEM-001",
      "Description": "Product/Service Description",
      "Quantity": 1,
      "UnitPrice": 1500.00,
      "Amount": 1500.00
    }
  ],
  "Notes": ""
}
```

### Payment Template
```json
{
  "PaymentId": "PAY-1730123456",
  "InvoiceId": "INV-12345",
  "CustomerId": "CUST-12345",
  "PaymentDate": "2025-10-28",
  "Amount": 1500.00,
  "Currency": "USD",
  "PaymentMethod": "CreditCard",
  "TransactionReference": "TXN-1730123456",
  "Status": "Completed",
  "Notes": ""
}
```

### Order Template
```json
{
  "OrderId": "ORD-1730123456",
  "CustomerId": "CUST-12345",
  "OrderDate": "2025-10-28",
  "TotalAmount": 2500.00,
  "Currency": "USD",
  "Status": "Pending",
  "ShippingAddress": {
    "Street": "123 Main Street",
    "City": "New York",
    "State": "NY",
    "ZipCode": "10001",
    "Country": "USA"
  },
  "Items": [
    {
      "ProductId": "PROD-001",
      "ProductName": "Sample Product",
      "Quantity": 2,
      "UnitPrice": 1250.00,
      "Amount": 2500.00
    }
  ],
  "Notes": ""
}
```

### Product Template
```json
{
  "ProductId": "PROD-1730123456",
  "Name": "Sample Product",
  "Description": "Product description goes here",
  "Category": "General",
  "Price": 99.99,
  "Currency": "USD",
  "SKU": "SKU-1730123456",
  "StockQuantity": 100,
  "Status": "Active",
  "Tags": ["sample", "new"]
}
```

## Tips for Working with JSON

### 1. Use Valid JSON Syntax
- Always use **double quotes** for strings: `"Name"` not `'Name'`
- Numbers don't need quotes: `1500.00` not `"1500.00"`
- Booleans are lowercase: `true` not `True`
- Arrays use square brackets: `[1, 2, 3]`
- Objects use curly braces: `{ "key": "value" }`

### 2. Common Mistakes to Avoid
```json
// ❌ BAD - trailing comma
{
  "Name": "John",
  "Email": "john@example.com",  // <- Remove this comma
}

// ✅ GOOD - no trailing comma
{
  "Name": "John",
  "Email": "john@example.com"
}

// ❌ BAD - single quotes
{
  'Name': 'John'
}

// ✅ GOOD - double quotes
{
  "Name": "John"
}

// ❌ BAD - unquoted string
{
  "Name": John
}

// ✅ GOOD - quoted string
{
  "Name": "John"
}
```

### 3. Format for Readability
Use proper indentation (2 or 4 spaces):
```json
{
  "Name": "John Doe",
  "Address": {
    "Street": "123 Main St",
    "City": "New York"
  },
  "Tags": [
    "customer",
    "vip"
  ]
}
```

### 4. Use Online Validators
If you're having trouble, use online JSON validators:
- [JSONLint](https://jsonlint.com/)
- [JSON Formatter](https://jsonformatter.org/)

## Workflow Examples

### Example 1: Create a Simple Customer
1. Click "Create Transaction" in Data Plane (Customer type selected)
2. The template appears with example data
3. Edit the JSON:
```json
{
  "CustomerId": "CUST-2025-001",
  "Name": "Alice Johnson",
  "Email": "alice@techcorp.com",
  "Phone1": "+1-555-0199",
  "Address": "456 Oak Avenue",
  "City": "San Francisco",
  "State": "CA",
  "ZipCode": "94102",
  "Country": "USA",
  "CustomerType": "Business",
  "Status": "Active",
  "CreditLimit": 50000,
  "Notes": "Premium customer - expedited shipping"
}
```
4. Click "Create Transaction"
5. Customer is created and appears in the table

### Example 2: Create an Invoice with Line Items
1. Switch to "Invoice" transaction type
2. Click "Create Transaction"
3. Edit the template:
```json
{
  "InvoiceId": "INV-2025-042",
  "CustomerId": "CUST-2025-001",
  "InvoiceDate": "2025-10-28",
  "DueDate": "2025-11-28",
  "TotalAmount": 3250.00,
  "Currency": "USD",
  "Status": "Sent",
  "PaymentTerms": "Net 30",
  "LineItems": [
    {
      "ItemId": "ITEM-001",
      "Description": "Software License - Annual",
      "Quantity": 1,
      "UnitPrice": 2500.00,
      "Amount": 2500.00
    },
    {
      "ItemId": "ITEM-002",
      "Description": "Support Services",
      "Quantity": 1,
      "UnitPrice": 750.00,
      "Amount": 750.00
    }
  ],
  "Notes": "Invoice for annual software subscription"
}
```
4. Click "Create Transaction"
5. Invoice is created with all line items

### Example 3: Quick Entry with Minimal Data
You can also simplify the JSON and only include required fields:
```json
{
  "CustomerId": "CUST-QUICK-001",
  "Name": "Quick Entry Customer",
  "Email": "quick@example.com",
  "Status": "Active"
}
```

## Troubleshooting

### Error: "Invalid JSON: Unexpected token..."
- **Cause**: Syntax error in JSON
- **Solution**: Check for missing quotes, commas, or brackets
- **Tip**: Copy your JSON to [JSONLint](https://jsonlint.com/) to find the exact error

### Error: "JSON data is required"
- **Cause**: Empty textarea
- **Solution**: Add JSON data or use the default template

### Error: "Failed to create transaction: ..."
- **Cause**: Server-side validation error
- **Solution**: Check the error message for details
- **Common issues**:
  - Duplicate ID
  - Missing required fields
  - Invalid data types
  - Foreign key constraints (e.g., CustomerId doesn't exist)

### JSON Looks Correct But Still Errors
1. Copy the JSON
2. Paste into [JSONLint](https://jsonlint.com/)
3. Click "Validate JSON"
4. Fix any syntax errors shown
5. Copy the validated JSON back

## Benefits of JSON Text Input

### For Power Users
- ✅ Faster data entry
- ✅ No need to create external files
- ✅ Easy to copy/paste from other sources
- ✅ Can edit and fix errors immediately

### For Developers
- ✅ Can copy JSON from API responses
- ✅ Can use JSON from test data
- ✅ Can script JSON generation
- ✅ Better for automation workflows

### For Everyone
- ✅ See exactly what you're sending
- ✅ Learn JSON syntax through examples
- ✅ More transparent data submission
- ✅ Consistent with ModelSchema workflow

## Next Steps

After creating transactions:
1. **Verify**: Check that the transaction appears in the table
2. **View Details**: Click the "View" button to see all fields
3. **Edit**: Click "Edit" if you need to make changes
4. **Create Related**: Create related transactions (e.g., Payment for an Invoice)

## Need Help?

- 📖 See the templates above for each transaction type
- 🔍 Use [JSONLint](https://jsonlint.com/) to validate your JSON
- 💬 Contact your administrator if you encounter persistent errors
- 📝 Check the browser console (F12) for detailed error messages
