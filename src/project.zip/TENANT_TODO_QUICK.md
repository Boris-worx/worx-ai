# Tenant Isolation - Quick TODO List

## 🎯 Цель
Реализовать полную изоляцию данных между тенантами согласно User Story.

## ✅ Что Уже Работает
- UI tenant selector (Global + список тенантов)
- Tenant CRUD operations
- User locked to their tenant (non-SuperUser)
- Active tenant persistence
- Permission model

## 🔴 Критичные Задачи (Must Have)

### 1. Проверить API Response
**Цель:** Узнать как API возвращает tenant information

```bash
# Выполнить в консоли браузера или Postman
curl -H "X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855" \
  https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/txns | jq '.'
```

**Что искать в response:**
- [ ] Есть ли поле `TenantId`?
- [ ] Есть ли поле `tenantId`?
- [ ] Есть ли поле `PartitionKey`?
- [ ] Есть ли поле `partitionKey`?
- [ ] Какое значение для глобальных данных?

---

### 2. Добавить Tenant Field в Interfaces

**Файл:** `/lib/api.ts`

```typescript
// Transaction Interface
export interface Transaction {
  TxnId?: string;
  TxnType: string;
  Txn: any;
  TenantId?: string;          // ✅ ADD THIS
  PartitionKey?: string;      // ✅ ADD THIS (if API uses it)
  CreateTime?: string;
  UpdateTime?: string;
  _etag?: string;
  // ... rest
}

// ModelSchema Interface  
export interface ModelSchema {
  id: string;
  model: string;
  version: number;
  state: string;
  semver: string;
  TenantId?: string;          // ✅ ADD THIS
  PartitionKey?: string;      // ✅ ADD THIS
  dataSourceId?: string;
  jsonSchema: any;
  // ... rest
}

// DataSource Interface
export interface DataSource {
  DataSourceId?: string;
  DataSourceName?: string;
  TenantId?: string;          // ✅ ADD THIS
  PartitionKey?: string;      // ✅ ADD THIS
  Type?: string;
  // ... rest
}
```

**Checklist:**
- [ ] Обновить Transaction interface
- [ ] Обновить ModelSchema interface
- [ ] Обновить DataSource interface
- [ ] Использовать правильное имя поля из шага 1

---

### 3. Update API Functions с Tenant Parameter

**Файл:** `/lib/api.ts`

```typescript
// OLD
export async function getAllTransactions(): Promise<Transaction[]> {
  const response = await fetch(`${API_BASE_URL}/txns`, ...);
  // ...
}

// NEW
export async function getAllTransactions(tenantId?: string): Promise<Transaction[]> {
  // Build URL with tenant filter
  let url = `${API_BASE_URL}/txns`;
  
  // If specific tenant (not global), add filter
  if (tenantId && tenantId !== 'global') {
    // Option 1: Query parameter
    url += `?TenantId=${tenantId}`;
    // Option 2: If API uses different parameter
    // url += `?PartitionKey=${tenantId}`;
  }
  
  const response = await fetch(url, {
    method: "GET",
    headers: getHeaders(),
  });
  
  // ... rest of code
}
```

**Функции для обновления:**
- [ ] `getAllTransactions(tenantId?: string)`
- [ ] `getAllModelSchemas(tenantId?: string)`
- [ ] `getAllDataSources(tenantId?: string)`
- [ ] `createTransaction(transaction, tenantId?)` - добавить TenantId при создании
- [ ] `createModelSchema(schema, tenantId?)` - добавить TenantId при создании
- [ ] `createDataSource(dataSource, tenantId?)` - добавить TenantId при создании

---

### 4. Pass activeTenantId to API Calls

**Файл:** `/App.tsx`

```typescript
// OLD
const refreshTransactions = async () => {
  setIsLoadingTransactions(true);
  try {
    const data = await getAllTransactions(); // ❌ No tenant filter
    setTransactions(data);
  } catch (error: any) {
    toast.error(`Failed to load transactions: ${error.message}`);
  } finally {
    setIsLoadingTransactions(false);
  }
};

// NEW
const refreshTransactions = async () => {
  setIsLoadingTransactions(true);
  try {
    const data = await getAllTransactions(activeTenantId); // ✅ Pass tenant
    setTransactions(data);
  } catch (error: any) {
    toast.error(`Failed to load transactions: ${error.message}`);
  } finally {
    setIsLoadingTransactions(false);
  }
};
```

**Обновить функции:**
- [ ] `refreshTransactions()` - передать activeTenantId
- [ ] `refreshDataSources()` - передать activeTenantId
- [ ] Аналогично для ModelSchemas если есть

---

### 5. Auto-Refresh on Tenant Change

**Файл:** `/App.tsx`

```typescript
// Add useEffect to reload data when tenant changes
useEffect(() => {
  if (activeTenantId && isAuthenticated) {
    refreshTransactions();
    refreshDataSources();
    // Add other refresh functions if needed
  }
}, [activeTenantId, isAuthenticated]);
```

**Checklist:**
- [ ] Добавить useEffect с dependency на activeTenantId
- [ ] Вызывать все refresh функции
- [ ] Тестировать: при смене тенанта данные перезагружаются

---

## 🟡 Важные Задачи (Should Have)

### 6. Add Tenant Column to Tables

**Файлы:** `/components/TransactionsView.tsx`, `/components/DataSourcesView.tsx`, `/components/ModelSchemaView.tsx`

```typescript
// In columns configuration
const columns = [
  { key: 'TxnId', label: 'Transaction ID', enabled: true },
  { key: 'TxnType', label: 'Type', enabled: true },
  { key: 'TenantId', label: 'Tenant', enabled: true }, // ✅ ADD THIS
  // ... rest
];

// In cell rendering
if (key === 'TenantId') {
  const tenantName = value === 'General Tenant' || !value ? 'Global' : value;
  return (
    <Badge variant={!value ? 'secondary' : 'default'} className="text-xs">
      {tenantName}
    </Badge>
  );
}
```

**Checklist:**
- [ ] Добавить TenantId колонку в TransactionsView
- [ ] Добавить TenantId колонку в DataSourcesView
- [ ] Добавить TenantId колонку в ModelSchemaView
- [ ] Форматировать с Badge компонентом

---

### 7. Add Tenant to Create Dialogs

**Файлы:** `/components/TransactionCreateDialog.tsx`, etc.

```typescript
// In create function
const handleCreate = async () => {
  const newTransaction = {
    TxnType: selectedType,
    Txn: txnData,
    // ✅ Add tenant if not global
    ...(activeTenantId !== 'global' && { TenantId: activeTenantId })
  };
  
  await createTransaction(newTransaction);
};
```

**Checklist:**
- [ ] TransactionCreateDialog - добавить TenantId
- [ ] DataSource create - добавить TenantId
- [ ] ModelSchema create - добавить TenantId
- [ ] Показывать в UI какой тенант будет использован

---

### 8. Add Current Tenant Indicator

**Файлы:** Все view компоненты

```typescript
// At top of each view
<Alert className="mb-4">
  <Building2 className="h-4 w-4" />
  <AlertDescription>
    Viewing data for: <strong>{activeTenantName}</strong>
  </AlertDescription>
</Alert>
```

**Checklist:**
- [ ] Добавить в TransactionsView
- [ ] Добавить в DataSourcesView
- [ ] Добавить в ModelSchemaView
- [ ] Использовать Info variant для нейтрального вида

---

## 🟢 Nice to Have

### 9. Tenant Filter in Tables
Добавить dropdown фильтр для фильтрации по тенанту в таблице (в дополнение к глобальному selector)

### 10. Tenant Color Coding
Использовать разные цвета для разных тенантов (BFS - синий, Meritage - зеленый, etc.)

### 11. Tenant Statistics
Показывать количество записей д��я каждого тенанта в dashboard

---

## 🧪 Testing Checklist

После реализации проверить:

### Test 1: SuperUser - Global View
- [ ] Login as SuperUser
- [ ] Select "Global Tenant"
- [ ] Open Transactions tab
- [ ] Should see: All transactions from all tenants
- [ ] Each row shows tenant badge

### Test 2: SuperUser - Specific Tenant
- [ ] Select "BFS" tenant
- [ ] Open Transactions tab
- [ ] Should see: Only BFS transactions
- [ ] Should NOT see: Meritage or other tenant data

### Test 3: Non-SuperUser
- [ ] Login as BFS Admin
- [ ] Tenant selector locked to "BFS"
- [ ] Open Transactions tab
- [ ] Should see: Only BFS transactions
- [ ] Cannot switch to other tenants

### Test 4: Create with Tenant
- [ ] SuperUser selects "BFS"
- [ ] Create new transaction
- [ ] Transaction should have TenantId = "BFS"
- [ ] Verify in view/edit dialog

### Test 5: Switch Tenant Auto-Refresh
- [ ] SuperUser viewing BFS tenant
- [ ] Switch to "Meritage" tenant
- [ ] Data should reload automatically
- [ ] Different data should be visible

---

## 📋 Quick Implementation Order

```
1. Check API response (5 min)
   ↓
2. Add tenant fields to interfaces (10 min)
   ↓
3. Update API functions with tenantId parameter (30 min)
   ↓
4. Pass activeTenantId in App.tsx (15 min)
   ↓
5. Add auto-refresh on tenant change (10 min)
   ↓
6. Test basic isolation (10 min)
   ↓
7. Add tenant column to tables (20 min)
   ↓
8. Add tenant to create operations (20 min)
   ↓
9. Add current tenant indicator (15 min)
   ↓
10. Full testing (30 min)
```

**Total estimated time: ~2.5 hours**

---

## 🚨 Potential Issues

### Issue 1: API doesn't support tenant filtering
**Workaround:** Client-side filtering
```typescript
const filteredData = data.filter(item => 
  activeTenantId === 'global' || item.TenantId === activeTenantId
);
```

### Issue 2: TenantId field name different
**Solution:** Check API response and use correct field name (tenantId, PartitionKey, etc.)

### Issue 3: No TenantId in existing data
**Solution:** Default to 'General Tenant' or 'Global' for backward compatibility
```typescript
const tenantId = item.TenantId || item.tenantId || 'General Tenant';
```

---

## 📞 Questions for Backend

Before starting, clarify:
- [ ] What is the exact field name for tenant? (`TenantId`, `PartitionKey`?)
- [ ] Does API support `?TenantId=xxx` query parameter?
- [ ] How is global data represented? (`null`, `"Global"`, `"General Tenant"`?)
- [ ] Can SuperUser get all data in one request?
- [ ] Must TenantId be sent when creating data?

---

## ✅ Done Criteria

Implementation is complete when:
- [ ] SuperUser can switch tenants and see filtered data
- [ ] Non-SuperUser sees only their tenant data
- [ ] Tenant selector works in all tabs
- [ ] Data automatically refreshes on tenant change
- [ ] Tenant is visible in table rows (badge)
- [ ] Creating new items includes correct TenantId
- [ ] All tests pass

**Status:** Ready to implement 🚀
