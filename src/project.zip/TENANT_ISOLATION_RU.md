# Изоляция данных между тенантами в BFS Portal

## Обзор

BFS Portal реализует строгую изоляцию данных между тенантами:
- **Каждый тенант видит только свои данные** (tenants, data sources, transactions, model schemas)
- **GLOBAL TENANT видит данные ВСЕХ тенантов** - это специальный режим для администраторов
- **Полная изоляция на уровне API и UI**

## Архитектура изоляции

### 1. Уровни изоляции

#### A. Роли пользователей

```typescript
type UserRole = 'superuser' | 'admin' | 'developer' | 'viewer';
```

- **Portal.SuperUser** - полный доступ ко всем тенантам через GLOBAL TENANT
- **Admin, Developer, Viewer** - доступ только к своему тенанту

#### B. Тенанты

- **GLOBAL TENANT** (`activeTenantId: 'global'`) - виртуальный тенант для SuperUser
- **Конкретные тенанты** (BFS, Meritage, PIM, etc.) - реальные тенанты в системе

### 2. Реализация изоляции по компонентам

#### Tenants (`/components/TenantsView.tsx`)

```typescript
// Фильтрация тенантов
const filteredTenants = useMemo(() => {
  if (activeTenantId === 'global') {
    return tenants; // SuperUser видит все тенанты
  }
  // Обычные пользователи видят только свой тенант
  return tenants.filter(t => t.TenantId === activeTenantId);
}, [tenants, activeTenantId]);
```

**Логика:**
- GLOBAL TENANT → видит все тенанты
- Конкретный тенант → видит только себя

#### Data Sources (`/App.tsx` + `/components/DataSourcesView.tsx`)

```typescript
// Загрузка data sources в App.tsx
if (activeTenantId === 'global') {
  // Для глобального тенанта - загружаем из ВСЕХ тенантов
  const promises = tenants.map(tenant => 
    getAllDataSources(tenant.TenantId)
  );
  const results = await Promise.all(promises);
  allDataSources = results.flat();
} else {
  // Для конкретного тенанта - только его data sources
  allDataSources = await getAllDataSources(activeTenantId);
}
```

**Логика:**
- GLOBAL TENANT → делает запросы ко ВСЕМ тенантам и объединяет результаты
- Конкретный тенант → один запрос с фильтром `?Filters={"TenantId":"BFS"}`

#### Transactions (`/components/TransactionsView.tsx`)

```typescript
// Загрузка транзакций
const loadTransactions = async (txnType: string) => {
  const tenantFilter = activeTenantId !== 'global' ? activeTenantId : undefined;
  const txns = await getAllTransactions(txnType, tenantFilter);
  // ...
};
```

**Логика:**
- GLOBAL TENANT → загружает транзакции без фильтра по тенанту
- Конкретный тенант → загружает с фильтром

#### Model Schemas (`/components/ModelSchemaView.tsx`)

Аналогично Data Sources - фильтрация по activeTenantId.

### 3. API изоляция

#### Функции API (`/lib/api.ts`)

Все функции поддерживают опциональный параметр `tenantId`:

```typescript
// Примеры
export async function getAllDataSources(tenantId?: string): Promise<DataSource[]>
export async function getAllTransactions(txnType: string, tenantId?: string): Promise<Transaction[]>
export async function getDataCaptureSpecs(tenantId?: string, dataSourceId?: string): Promise<DataCaptureSpec[]>
```

**Формат запросов:**

```bash
# С фильтром
GET /datasources?Filters={"TenantId":"BFS"}

# Без фильтра (для GLOBAL)
GET /datasources
```

### 4. UI изоляция

#### TenantSelector (`/components/TenantSelector.tsx`)

```typescript
<TenantSelector
  tenants={tenants}
  activeTenantId={activeTenantId}
  onTenantChange={onTenantChange}
  isSuperUser={userRole === 'superuser'}
/>
```

- **SuperUser** видит список всех тенантов + опцию "Global Tenant"
- **Обычные пользователи** НЕ видят TenantSelector (locked к своему тенанту)

#### Auth Lock (`/App.tsx`)

```typescript
// Для не-SuperUser - блокировка на тенанте пользователя
if (user && user.role !== 'superuser' && user.tenantId) {
  setActiveTenantId(user.tenantId);
  // Selector disabled для таких пользователей
}
```

## Примеры использования

### Сценарий 1: SuperUser переключается между тенантами

```
1. Login as Portal.SuperUser
2. activeTenantId = 'global' (по умолчанию)
3. Видит все data sources из всех тенантов
4. Переключается на 'BFS'
5. Видит только data sources BFS
6. Переключается обратно на 'global'
7. Снова видит все data sources
```

### Сценарий 2: Admin работает со своим тенантом

```
1. Login as Admin (tenantId: 'BFS')
2. activeTenantId = 'BFS' (locked)
3. TenantSelector не отображается (нельзя переключить)
4. Видит только data sources BFS
5. Не может создать data sources для других тенантов
6. Не видит данные Meritage, PIM и т.д.
```

### Сценарий 3: Создание data source

```typescript
// SuperUser создает для конкретного тенанта
await createDataSource({
  DatasourceName: "Test",
  TenantId: "BFS"  // обязательно указывается
});

// Admin создает для своего тенанта
await createDataSource({
  DatasourceName: "Test",
  TenantId: activeTenantId  // автоматически BFS
});
```

## Правила изоляции

### ✅ МОЖНО

- SuperUser может видеть и изменять данные любого тенанта
- SuperUser может переключаться между тенантами и GLOBAL
- Admin/Developer/Viewer может видеть и изменять ТОЛЬКО свой тенант
- GLOBAL TENANT видит данные всех тенантов

### ❌ НЕЛЬЗЯ

- Обычный пользователь НЕ может видеть данные других тенантов
- Обычный пользователь НЕ может переключить тенант
- Обычный пользователь НЕ может создать данные для другого тенанта
- SuperUser в режиме конкретного тенанта НЕ видит данные других тенантов

## Безопасность

### 1. Проверка на фронтенде

```typescript
// Проверка роли
const canCreate = ['superuser', 'admin', 'developer'].includes(userRole);

// Проверка тенанта
const isOwnTenant = dataSource.TenantId === activeTenantId;
const canEdit = activeTenantId === 'global' || isOwnTenant;
```

### 2. Проверка на бэкенде

BFS API должен выполнять проверку:
- Пользователь может изменять только данные своего тенанта
- X-BFS-Auth токен содержит информацию о тенанте пользователя

### 3. Аудит

Все операции логируются:
```typescript
console.log(`User ${user.email} (${user.role}) accessed ${activeTenantId}`);
console.log(`Created data source for tenant ${tenantId}`);
```

## Тестирование изоляции

### Тест 1: SuperUser видит все

```bash
# Login as Portal.SuperUser
# Select GLOBAL TENANT
# Expected: See all data sources from all tenants
```

### Тест 2: SuperUser видит конкретный тенант

```bash
# Login as Portal.SuperUser
# Select BFS
# Expected: See only BFS data sources
```

### Тест 3: Admin не видит других тенантов

```bash
# Login as Admin (BFS)
# Expected: TenantSelector not visible
# Expected: See only BFS data sources
# Expected: Cannot create data sources for other tenants
```

### Тест 4: Viewer read-only

```bash
# Login as Viewer (BFS)
# Expected: Can view BFS data
# Expected: Cannot create/edit/delete
```

## Диагностика проблем

### Проблема: GLOBAL не видит все данные

**Решение:** Проверьте в `/App.tsx`:

```typescript
if (activeTenantId === 'global') {
  // Должно быть: загрузка из ВСЕХ тенантов
  const promises = tenants.map(tenant => getAllDataSources(tenant.TenantId));
  // НЕ ДОЛЖНО быть: getAllDataSources(undefined)
}
```

### Проблема: Обычный пользователь видит другие тенанты

**Решение:** Проверьте фильтрацию в компоненте:

```typescript
const filteredData = useMemo(() => {
  if (activeTenantId === 'global') return data;
  return data.filter(item => item.TenantId === activeTenantId);
}, [data, activeTenantId]);
```

### Проблема: TenantSelector виден для не-SuperUser

**Решение:** Проверьте условие рендеринга:

```typescript
{userRole === 'superuser' && (
  <TenantSelector ... />
)}
```

## Связанные документы

- `/GLOBAL_TENANT_DATASOURCES_FIX_RU.md` - исправление загрузки для GLOBAL
- `/DATASOURCE_DELETE_FIX_RU.md` - исправление удаления
- `/DATASOURCE_CURL_TEST_RU.md` - тестирование через API

## История изменений

- **2025-11-13:** Исправлена загрузка data sources для GLOBAL TENANT
- **2025-11-12:** Добавлена задержка после создания/удаления
- **2025-11-09:** Первоначальная реализация изоляции тенантов

## Контакты

BFS Portal Development Team
