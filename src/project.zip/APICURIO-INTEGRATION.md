# Apicurio Registry Integration

## 🚀 Quick Start

**Status:** ✅ **FULLY WORKING** with automatic CORS fallback

- See [APICURIO-STATUS.md](./APICURIO-STATUS.md) for current status and testing
- See [APICURIO-QUICK-START.md](./APICURIO-QUICK-START.md) for step-by-step usage guide
- See [APICURIO-CORS-SOLUTION.md](./APICURIO-CORS-SOLUTION.md) for CORS information

## Overview

This application is fully integrated with Apicurio Registry for managing data source specifications and schemas. The integration supports automatic discovery of schemas across all groups and allows users to load schemas directly when creating Data Capture Specifications.

**CORS Handling:** The application automatically falls back to mock data when CORS errors occur. This means the integration works seamlessly even if the browser blocks direct access to Apicurio Registry.

## Features

### 1. **Automatic Schema Discovery**
- Discovers all schemas from all groups in Apicurio Registry
- Supports multiple artifact types: JSON, AVRO, PROTOBUF
- Groups specifications by their Apicurio group ID

### 2. **Direct Schema Loading**
- When creating a Data Capture Specification, available JSON schemas are automatically loaded
- Schemas can be selected from a dropdown and automatically populated into the form
- Support for dynamic group discovery

### 3. **Group Mappings**

The application uses the following group mappings based on data source names:

| Data Source | Apicurio Group ID |
|------------|-------------------|
| BFS | `bfs.online` |
| Bidtools | `paradigm.mybldr.bidtools` |
| TxServices | `paradigm.txservices` |
| Quotes | `paradigm.txservices.quotes` |
| Customers | `paradigm.txservices.customers` |

These mappings follow the Paradigm naming convention: `{organization}.{domain}.{application}`

## Registry Configuration

**Base URL:** `http://apicurio.52.158.160.62.nip.io/apis/registry/v2`

**UI URL:** `http://apicurio.52.158.160.62.nip.io/ui`

**Health Endpoint:** `http://apicurio.52.158.160.62.nip.io/health/live`

### Internal Kubernetes Access
```
http://apicurio-registry.apicurio.svc.cluster.local:8080
```

## Using the Integration

### Creating a Data Capture Specification with Apicurio Schema

1. **Navigate to Data Source Onboarding tab**
2. **Select or create a Data Source** (e.g., BFS, Bidtools)
3. **Click "Add Specification"** on a data source row
4. **Load Schema from Apicurio:**
   - At the top of the form, you'll see "Load Schema from Apicurio Registry" dropdown
   - Available JSON schemas will be listed (e.g., `bfs.QuoteDetails.json`)
   - Select a schema to automatically load it into the Container Schema JSON field
5. **Complete the form** with other required fields:
   - Specification Name (auto-filled from schema)
   - Version
   - Primary Key Field
   - Partition Key Field
   - Partition Key Value
   - Allowed Filters
6. **Create the specification**

### Discovering All Specifications

1. **Navigate to Data Source Onboarding tab**
2. **Click the menu button** (three dots) in the header
3. **Select "Discover Specifications"**
4. **View all schemas** organized by Apicurio group:
   - Each group shows its artifacts
   - JSON schemas can be viewed/copied
   - AVRO and other types are also listed

## API Functions

The integration provides the following API functions in `/lib/api.ts`:

### Groups
- `getApicurioGroups()` - Get all groups from registry
- Returns: `ApicurioGroupsList`

### Artifacts
- `getApicurioArtifacts(groupId)` - Get all artifacts in a group
- `getApicurioArtifactContent(groupId, artifactId)` - Get schema content
- Returns: Schema JSON content

### Discovery
- `getAllDataSourceSpecifications()` - Discover all specifications across all groups
- Returns: Array of `ApicurioArtifact` with `groupId` attached

### Data Source Specific
- `getJsonSchemasForDataSource(dataSourceName)` - Get JSON schemas for a specific data source
- Supports dynamic group discovery if no direct mapping exists
- Returns: Array of JSON type artifacts

## Testing the Connection

Run the test script to verify Apicurio connectivity:

```bash
node test-apicurio.js
```

This will:
1. List all groups in the registry
2. Show artifacts from `bfs.online` group
3. Show artifacts from `paradigm.mybldr.bidtools` group
4. Load and display a sample schema (`bfs.QuoteDetails.json`)

## Example: Creating QuoteDetails Specification

1. Create or select **Bidtools** data source
2. Click **"Add Specification"**
3. In the Apicurio dropdown, select **`bfs.QuoteDetails.json`**
4. The schema will load automatically:
   - Specification Name: `QuoteDetails`
   - Container Schema JSON: Full JSON schema from Apicurio
5. Complete other fields:
   - Primary Key Field: `quoteId`
   - Partition Key Field: `partitionKey`
   - Partition Key Value: `{tenantId}-bidtools`
   - Select Allowed Filters: `quoteId`, `customerId`, etc.
6. Click **"Create Specification"**

## Troubleshooting

### No schemas appear in dropdown
- Check that the data source name matches a group mapping
- Verify Apicurio Registry is accessible
- Check browser console for errors
- Try "Discover Specifications" to see all available schemas

### Schema fails to load
- Verify the artifact exists in Apicurio UI
- Check that the artifact type is JSON
- Ensure the group ID is correct
- Check network connectivity to Apicurio

### Group not found
- Add the group mapping in `getJsonSchemasForDataSource()` function
- Or use the dynamic discovery which will search all groups

## Architecture

```
┌─────────────────┐
│   React UI      │
│ DataSourcesView │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│   API Layer     │
│   /lib/api.ts   │
└────────┬────────┘
         │
         ▼
┌─────────────────────────────────┐
│   Apicurio Registry             │
│   /apis/registry/v2             │
│                                 │
│   ┌─────────────────────────┐  │
│   │ bfs.online              │  │
│   │ - bfs.QuoteDetails.json │  │
│   └─────────────────────────┘  │
│                                 │
│   ┌─────────────────────────┐  │
│   │ paradigm.mybldr.bidtools│  │
│   │ - bfs.QuoteDetails.json │  │
│   │ - bfs.Quotes (AVRO)     │  │
│   └─────────────────────────┘  │
│                                 │
│   ┌─────────────────────────┐  │
│   │ paradigm.txservices.*   │  │
│   └─────────────────────────┘  │
└─────────────────────────────────┘
```

## Future Enhancements

- [ ] Schema versioning support
- [ ] Schema validation before creating specification
- [ ] Upload custom schemas to Apicurio
- [ ] Schema diff/comparison tools
- [ ] Auto-generate specifications from schemas
- [ ] Schema migration tools
