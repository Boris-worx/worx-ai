# Apicurio Registry - Только реальный API (Mock данные удалены)

## ✅ Статус: Очистка завершена

Все MOCK данные и fallback логика удалены из функции `getApicurioArtifactContent`. Приложение теперь работает **исключительно** с реальным Apicurio Registry v3 API.

---

## 🎯 Что было сделано

### 1. Очистка `getApicurioArtifactContent()`

**Файл:** `/lib/api.ts` (строки 2327-2361)

**До:**
- ❌ Содержала mock AVRO схемы для `bfs.online` группы (10+ артефактов)
- ❌ Содержала mock AVRO схемы для `paradigm.mybldr.bidtools` группы (15+ артефактов)
- ❌ Fallback логика в `catch` блоке
- ❌ Feature flag `USE_MOCK_APICURIO`

**После:**
- ✅ Только реальный API вызов к `${APICURIO_REGISTRY_URL}/artifacts/${artifactId}`
- ✅ Чистая обработка ошибок без fallback
- ✅ Логирование для debugging
- ✅ Прямое возвращение данных из API

```typescript
export async function getApicurioArtifactContent(
  groupId: string, 
  artifactId: string
): Promise<ApicurioSchemaContent> {
  try {
    console.log(`📡 Fetching Apicurio artifact content (v3 API): ${artifactId}`);
    
    const url = `${APICURIO_REGISTRY_URL}/artifacts/${encodeURIComponent(artifactId)}`;
    console.log(`  URL: ${url}`);
    
    const response = await fetch(url, {
      method: "GET",
      headers: {
        "Accept": "application/json",
        "Content-Type": "application/json",
      },
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error(`❌ Failed to fetch artifact content: ${response.status}`, errorText);
      throw new Error(`Failed to fetch artifact ${artifactId}: ${response.status} ${response.statusText}`);
    }

    const data: ApicurioSchemaContent = await response.json();
    console.log(`✅ Fetched schema for ${artifactId}`);
    console.log('  Schema preview:', JSON.stringify(data).substring(0, 200) + '...');
    
    return data;
  } catch (error) {
    console.error("❌ Error fetching Apicurio artifact content:", error);
    throw error;
  }
}
```

---

## 📋 Состояние других Apicurio функций

### ✅ Все функции работают с реальным API:

| Функция | Файл | Строки | Статус |
|---------|------|--------|--------|
| `getApicurioGroups()` | `/lib/api.ts` | 2252-2260 | ✅ v3 API (groups deprecated) |
| `getApicurioArtifacts()` | `/lib/api.ts` | 2263-2323 | ✅ Реальный API + фильтрация |
| `getApicurioArtifactContent()` | `/lib/api.ts` | 2327-2361 | ✅ **ОЧИЩЕНО** - только реальный API |
| `getAllDataSourceSpecifications()` | `/lib/api.ts` | 2365-2388 | ✅ Реальный API |
| `getJsonSchemasForDataSource()` | `/lib/api.ts` | 2392-2414 | ✅ Реальный API |
| `createApicurioArtifact()` | `/lib/api.ts` | 2417-2449 | ✅ Реальный API |

---

## 🔧 Конфигурация Apicurio Registry

### API Endpoint (v3)
```typescript
const APICURIO_REGISTRY_URL = 
  "https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3";
```

### v3 API Endpoints используемые в приложении:

1. **Search Artifacts:**
   ```
   GET /apis/registry/v3/search/artifacts?name={searchQuery}
   ```

2. **Get Artifact Content (Schema):**
   ```
   GET /apis/registry/v3/artifacts/{artifactId}
   ```

3. **Create Artifact:**
   ```
   POST /apis/registry/v3/groups/{groupId}/artifacts
   Headers: X-Registry-ArtifactId: {artifactId}
   ```

---

## 🎯 Интеграция с Data Source Onboarding

### Поток создания Data Capture Specification:

```
User clicks "Add Specification"
         ↓
getJsonSchemasForDataSource(dataSourceName)
         ↓
getApicurioArtifacts(dataSourceName) [REAL API]
         ↓
Filter: artifactType === 'JSON' || 'AVRO'
         ↓
Display schemas in dropdown
         ↓
User selects schema
         ↓
getApicurioArtifactContent(groupId, artifactId) [REAL API - NO MOCK]
         ↓
Parse schema → Pre-fill form fields
         ↓
User completes form → Create Data Capture Spec
```

---

## ⚠️ Важные замечания

### 1. CORS Configuration Required

Поскольку теперь используется **только реальный API**, необходимо убедиться, что:

✅ Apicurio Registry настроен для CORS с вашим доменом  
✅ Или используется backend proxy для API вызовов  
✅ Или приложение и Apicurio на одном домене  

**Если CORS не настроен:**
```
❌ Error: Failed to fetch
❌ CORS policy: No 'Access-Control-Allow-Origin' header
```

### 2. Обработка ошибок API

Все функции теперь:
- ✅ Возвращают пустые массивы `[]` при ошибках (для UI graceful degradation)
- ✅ Логируют ошибки в консоль для debugging
- ✅ Показывают toast уведомления пользователю

### 3. Нет Offline Mode

- ❌ Нет fallback данных
- ❌ Нет mock schemas
- ❌ Нет feature flags для mock mode

**Приложение требует живое соединение с Apicurio Registry.**

---

## 📊 Что работает сейчас

### ✅ Discovery & Search
```typescript
// Поиск всех артефактов с "Value" в названии
const artifacts = await getApicurioArtifacts('Value');

// Поиск схем для конкретного data source
const schemas = await getJsonSchemasForDataSource('BFS.online');
```

### ✅ Schema Loading
```typescript
// Загрузка полной схемы для артефакта
const schema = await getApicurioArtifactContent('', 'bfs.QuoteDetails.json');
// Теперь работает ТОЛЬКО с реальным API
```

### ✅ UI Integration
- DataCaptureSpecCreateDialog - загружает схемы из реального Apicurio
- DataSourcesView - показывает реальные артефакты
- Apicurio Discovery Dialog - отображает live данные

---

## 🧪 Как тестировать

### 1. Проверка соединения с Apicurio

Откройте браузер DevTools → Console:

```javascript
// Тест 1: Поиск артефактов
fetch('https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/search/artifacts?name=Value', {
  headers: { 'Accept': 'application/json' }
})
.then(r => r.json())
.then(d => console.log('✅ Artifacts found:', d.count))
.catch(e => console.error('❌ CORS or network error:', e));

// Тест 2: Загрузка схемы
fetch('https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/artifacts/bfs.QuoteDetails.json', {
  headers: { 'Accept': 'application/json' }
})
.then(r => r.json())
.then(d => console.log('✅ Schema loaded:', d))
.catch(e => console.error('❌ Error:', e));
```

### 2. Проверка через UI

1. Откройте **Data Source Onboarding** вкладку
2. Найдите data source (например, "BFS.online")
3. Нажмите **"Add Specification"**
4. Проверьте консоль:
   - ✅ `📡 Fetching schemas for data source: BFS.online (v3 API)...`
   - ✅ `✅ Found X schemas (JSON + AVRO) for BFS.online`
5. Выберите схему из dropdown
6. Проверьте консоль:
   - ✅ `📡 Fetching Apicurio artifact content (v3 API): {artifactId}`
   - ✅ `✅ Fetched schema for {artifactId}`
7. Форма должна auto-populate с данными из схемы

### 3. Обработка ошибок

Если Apicurio недоступен:
- ❌ Console: `❌ Failed to fetch artifact content: 404 Not Found`
- ❌ Toast: "Failed to load schema from Apicurio"
- ⚠️ Dropdown будет пустой
- ⚠️ Пользователь должен вводить данные вручную

---

## 🔄 Миграция с Mock данных

### Старая документация (устарела):
- ❌ `/APICURIO-MOCK-DATA-FIX.md` - Mock данные больше не используются
- ❌ `/APICURIO-STATUS.md` - Упоминает `USE_MOCK_APICURIO = true`
- ❌ `/README-APICURIO.md` - Упоминает "Zero CORS Errors" с mock данными

### Новая документация:
- ✅ `/APICURIO-REAL-API-ТОЛЬКО.md` - **Этот файл** (актуальный статус)
- ✅ `/APICURIO-INTEGRATION.md` - Технические детали интеграции
- ✅ `/APICURIO-CORS-SOLUTION.md` - Решения для CORS (критично!)

---

## 🚀 Следующие шаги

### 1. Тестирование с реальным Apicurio Registry

- [ ] Проверить CORS конфигурацию
- [ ] Протестировать все API endpoints
- [ ] Убедиться, что схемы загружаются корректно
- [ ] Проверить создание Data Capture Specs из Apicurio схем

### 2. Обновить остальную документацию

- [ ] Пометить старые MD файлы как deprecated
- [ ] Обновить README.md с актуальной информацией
- [ ] Создать troubleshooting guide для CORS ошибок

### 3. Интеграция Data Plane с Transaction Types

Следующий большой шаг:
> Data Capture Specifications должны создаваться в Data Source Onboarding модуле и затем попадать в Data Plane как Transaction Types

**Требуется:**
- [ ] Механизм синхронизации Data Capture Spec → Transaction Type
- [ ] UI для отображения Transaction Types из Data Capture Specs
- [ ] Валидация данных по схемам из Apicurio

### 4. Production Checklist

- [ ] CORS настроен на Apicurio Registry
- [ ] Error handling для network failures
- [ ] Retry логика для API calls
- [ ] Monitoring и logging
- [ ] Fallback UI для offline режима (опционально)

---

## 📞 Troubleshooting

### Проблема: "Failed to fetch" ошибки

**Причина:** CORS не настроен или network issue

**Решение:**
1. Проверить CORS headers на Apicurio Registry
2. Использовать backend proxy
3. Проверить network connectivity

### Проблема: "No schemas found"

**Причина:** Apicurio пустой или неправильный search query

**Решение:**
1. Проверить что артефакты существуют в Apicurio
2. Проверить search query (должен соответствовать artifactId)
3. Проверить фильтрацию по artifactType (JSON/AVRO)

### Проблема: Schema не загружается

**Причина:** Неправильный artifactId или формат

**Решение:**
1. Проверить console logs для точного artifactId
2. Убедиться что артефакт существует в Apicurio
3. Проверить формат ответа от API

---

## ✅ Итоги

| Аспект | Статус | Примечания |
|--------|--------|------------|
| Mock данные удалены | ✅ Завершено | `getApicurioArtifactContent` очищен |
| Реальный API интегрирован | ✅ Завершено | Все функции работают с v3 API |
| CORS требуется | ⚠️ Критично | Без CORS ничего не работает |
| Компиляция | ✅ Без ошибок | Код готов к использованию |
| Документация | ✅ Обновлена | Этот файл - актуальная версия |
| Тестирование | 🔄 В процессе | Требуется проверка с live Apicurio |

---

**Статус:** ✅ **Готово к тестированию с реальным Apicurio Registry v3 API**

**Дата обновления:** 27 ноября 2025

**Следующий шаг:** Проверить CORS конфигурацию и протестировать полный flow создания Data Capture Specification
