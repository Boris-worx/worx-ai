# ⚡ Быстрый старт: Проверка DataSource API

## 🎯 Цель
Узнать, какие данные реально возвращает BFS API для Data Sources.

---

## 📋 За 3 шага:

### Шаг 1: Откройте тестер
```
Откройте файл: test-datasources-api.html
```

### Шаг 2: Нажмите кнопку
```
Нажмите: 🚀 Fetch DataSources
```

### Шаг 3: Смотрите результаты
```
Прокрутите вниз и изучите все секции
```

---

## 📊 Что вы увидите:

### 1. Response Summary (Краткая сводка)
```
📦 Response Format: "data.datasources array"
📊 Total DataSources: 5
🔑 Unique Fields: 12 fields
✅ ID Field: "DatasourceId" (5/5 have values)
📝 Name Field: "DatasourceName" (5/5 have values)
🏷️ Type Field: "Type" (3/5 have values)
🔄 Status Field: "Status" (5/5 have values)
📄 Description Field: "Description" (4/5 have values)
```

### 2. Fields Analysis (Анализ полей)
```
Таблица со всеми полями:
┌─────────────────────┬────────┬────────────────────────┐
│ Field Name          │ Type   │ Sample Value           │
├─────────────────────┼────────┼────────────────────────┤
│ DatasourceId        │ string │ "ds-12345"            │
│ DatasourceName      │ string │ "Main Database"       │
│ Type                │ string │ "SQL"                 │
│ Status              │ string │ "Active"              │
│ Description         │ string │ "Production DB"       │
│ ConnectionString    │ string │ "Server=..."          │
│ CreateTime          │ string │ "2025-10-15T..."      │
│ UpdateTime          │ string │ "2025-10-20T..."      │
│ _etag               │ string │ "\"abc-123\""         │
│ _ts                 │ number │ 1730233445            │
└─────────────────────┴────────┴────────────────────────┘
```

### 3. Raw API Response (Полный JSON)
```json
{
  "status": {
    "code": 200,
    "message": "Success"
  },
  "data": {
    "datasources": [
      {
        "DatasourceId": "ds-12345",
        "DatasourceName": "Main Database",
        "Type": "SQL",
        "Status": "Active",
        "Description": "Production database",
        "ConnectionString": "Server=tcp:...",
        "CreateTime": "2025-10-15T10:30:00Z",
        "UpdateTime": "2025-10-20T14:45:00Z",
        "_etag": "...",
        "_ts": 1730233445
      }
    ]
  }
}
```

### 4. First DataSource Object (Первый объект)
```json
{
  "DatasourceId": "ds-12345",
  "DatasourceName": "Main Database",
  ... весь объект целиком
}
```

---

## 💡 Полезные функции тестера:

### ✅ Кнопки копирования
- **📋 Copy JSON** (в секции Raw API Response)
  - Копирует весь JSON ответ в буфер обмена
  
- **📋 Copy JSON** (в секции First DataSource Object)
  - Копирует первый DataSource объект

### ✅ Кнопка очистки
- **🗑️ Clear Results**
  - Очищает все результаты
  - Готов к новой проверке

---

## 🔍 Что искать:

### ✅ Обязательные поля (должны быть!)
- [x] **DatasourceId** или **DataSourceId**
- [x] **DatasourceName** или **DataSourceName**
- [x] **_etag** (критично для UPDATE/DELETE!)

### 📝 Информационные поля
- [ ] **Type** - есть и заполнен?
- [ ] **Status** - есть и заполнен?
- [ ] **Description** - есть и заполнен?
- [ ] **ConnectionString** - хранится?

### 📅 Временные метки
- [ ] **CreateTime** - есть?
- [ ] **UpdateTime** - есть?

### ❓ Неизвестные поля
- [ ] Есть ли поля, которых мы не ожидали?
- [ ] Нужно ли их отображать в UI?

---

## ❗ Важные вопросы:

### 1. Сколько полей реально заполнено?
```
Смотрите в Fields Analysis:
- Если все 5/5 - отлично
- Если 0/5 - поле не используется
- Если 3/5 - поле опциональное
```

### 2. Какой формат у полей?
```
Смотрите колонку "Type":
- string - текст
- number - число
- object - JSON объект
- null - пустое значение
```

### 3. Есть ли проблемы с данными?
```
Проверьте Sample Values:
- Пустые строки?
- Неожиданные форматы?
- Null вместо строк?
```

---

## 🚨 Если что-то не так:

### ❌ Ошибка CORS
```
Проблема: API блокирует запросы
Решение: Проверьте CORS настройки на сервере
```

### ❌ 401 Unauthorized
```
Проблема: Неверный API ключ
Решение: Проверьте X-BFS-Auth в коде HTML файла
```

### ❌ Пустой список
```
Проблема: В базе нет Data Sources
Решение: Создайте тестовый Data Source в приложении
```

### ❌ Незнакомый формат
```
Проблема: API вернул неожиданную структуру
Решение: 
1. Посмотрите Raw Response
2. Сообщите разработчику
3. Добавьте обработку в getAllDataSources()
```

---

## 🎓 Альтернативные методы:

### Метод 2: Консоль браузера
```
1. Откройте приложение
2. F12 → Console
3. Перейдите на "Data Source Onboarding"
4. Смотрите логи в консоли
```

### Метод 3: cURL в терминале
```bash
curl -X GET \
  'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/datasources' \
  -H 'X-BFS-Auth: bfs-secret-key-12345' \
  -H 'Content-Type: application/json' \
  | jq  # для красивого форматирования
```

---

## 📚 Дополнительная документация:

- **`/ПРОВЕРКА_API_DATASOURCES.md`** - Краткое руководство (RU)
- **`/DATASOURCE_API_INSPECTION.md`** - Полная документация (EN)
- **`/API_EXAMPLES.md`** - Примеры работы с API
- **`/DATASOURCE_TESTING_GUIDE.md`** - Руководство по тестированию

---

## ✅ Чеклист проверки:

```
Перед тем как закрыть:

□ Я открыл test-datasources-api.html
□ Я нажал "Fetch DataSources"
□ Я увидел количество Data Sources
□ Я проверил все поля в таблице
□ Я посмотрел примеры значений
□ Я скопировал JSON для документации
□ Я проверил обязательные поля
□ Я записал, что нужно добавить/изменить

Результат:
□ Всё ок, ничего менять не нужно
□ Нужно добавить новые поля в UI
□ Нужно обновить TypeScript интерфейс
□ Нужно улучшить форматирование
```

---

## 🎯 Итоговая цель:

После проверки вы должны точно знать:

1. ✅ **Что возвращает API** - все поля и их типы
2. ✅ **Какие поля используются** - заполненные vs пустые
3. ✅ **Что показывать в UI** - какие колонки включить по умолчанию
4. ✅ **Что нужно изменить** - обновления кода, если нужны

---

**Время проверки:** ~5 минут  
**Сложность:** ⭐ Легко  
**Статус:** ✅ Готово к использованию

---

**Дата создания:** 29 октября 2025  
**Последнее обновление:** 29 октября 2025
