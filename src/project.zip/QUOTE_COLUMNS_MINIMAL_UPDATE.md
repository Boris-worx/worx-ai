# 📊 Quote Columns Minimal Display - Update

## ✅ Изменение

Обновлены **дефолтные колонки для Quote** - теперь по умолчанию отображаются **только location-поля**, без ID и Created.

---

## 🎯 Что изменилось

### До:
```
По умолчанию отображались:
✓ ID
✓ Created
✓ location Address
✓ location Code
✓ location Name

(5 колонок)
```

### После:
```
По умолчанию отображаются:
✓ location Address
✓ location Code
✓ location Name

(3 колонки - только location-поля)
```

---

## 🎨 Визуальное представление

### Таблица Quote (новый вид):

```
┌──────────────────────────────────────────────────────────────────────┐
│ location Address       │ location Code │ location Name      │ Actions │
├──────────────────────────────────────────────────────────────────────┤
│ BUILDERS FIRSTSOURCE,1 │ SHELKYYD      │ 6032-LOUISVILLE KY │ View... │
│ BUILDERS FIRSTSOURCE,4 │ LONGCOYD      │ LONGMONT CO YARD   │ View... │
│ 123 Main St            │ LOC001        │ Downtown Project   │ View... │
│ 123 Main St            │ LOC001        │ Downtown Project   │ View... │
└──────────────────────────────────────────────────────────────────────┘

Showing 1 to 10 of 6898 items
```

**Фокус на location-данных! 🎯**

---

## ✨ Преимущества

### 1. **Чистый интерфейс**
```
✅ Меньше колонок → легче читать
✅ Фокус на важной информации (location)
✅ Нет дублирования (ID есть в строках)
```

### 2. **Лучшая читаемость**
```
✅ Больше места для location данных
✅ Меньше горизонтальной прокрутки
✅ Информация о location сразу видна
```

### 3. **Гибкость**
```
✅ ID и Created доступны в Column Selector
✅ Можно включить одним кликом
✅ Настройки сохраняются
```

---

## 📋 Доступные колонки

### Видимые по умолчанию (3):
```
1. location Address ✓
2. location Code ✓
3. location Name ✓
```

### Скрытые (можно включить):
```
4. ID                       ← Можно включить
5. Created                  ← Можно включить
6. Quote ID
7. Account Number
8. Requested By Date
9. Export Notes
10. ERP User ID
11. Updated
```

---

## 🔧 Как включить скрытые колонки

### Способ 1: Column Selector

```
1. Открыть Data Plane → Quote
2. Нажать "Columns 7" (в правом верхнем углу)
3. Включить "ID" и/или "Created"
4. Нажать "Apply"
5. ✅ Колонки появились
```

### Способ 2: Сбросить к дефолту

```
1. Columns → Reset to Default
2. ✅ Вернутся 3 location-колонки
```

---

## 📊 Сравнение

### Старый вид (5 колонок):
```
┌───────────┬──────────┬─────────────┬──────────┬─────────────┬────────┐
│ ID        │ Created  │ loc Address │ loc Code │ loc Name    │ Actions│
├───────────┴──────────┴─────────────┴──────────┴─────────────┴────────┤
│ Quote:123 │ 11/3/25  │ 123 Main St │ LOC001   │ Downtown    │ View   │
└───────────┴──────────┴─────────────┴──────────┴─────────────┴────────┘
        ↑         ↑
   Отвлекает   Отвлекает
   от location данных
```

### Новый вид (3 колонки):
```
┌────────────────────┬──────────┬──────────────┬─────────┐
│ location Address   │ loc Code │ location Name│ Actions │
├────────────────────┴──────────┴──────────────┴─────────┤
│ 123 Main St        │ LOC001   │ Downtown     │ View    │
└────────────────────┴──────────┴──────────────┴─────────┘
         ↑                ↑            ↑
    Больше места    Фокус на     Всё видно
                    location      сразу
```

---

## 🎬 User Flow

### Сценарий 1: "Быстрый просмотр Quote"

```
Пользователь открывает Data Plane → Quote
┌──────────────────────────────────────────────┐
│ location Address  │ loc Code │ location Name │
│ 123 Main St       │ LOC001   │ Downtown      │
│ 456 Oak Ave       │ LOC002   │ Warehouse     │
└──────────────────────────────────────────────┘

✅ Сразу видно: адрес, код, название
✅ Легко найти нужный Quote
✅ Не отвлекают ID и даты
```

### Сценарий 2: "Нужен ID для Quote"

```
Пользователь: "Хочу видеть ID"

1. Columns → включить "ID"
2. Apply

┌─────────┬───────────────┬─────────┬──────────┐
│ ID      │ loc Address   │ loc Code│ loc Name │
│ Quote:1 │ 123 Main St   │ LOC001  │ Downtown │
└─────────┴───────────────┴─────────┴──────────┘

✅ ID добавлен
✅ location поля остались
```

### Сценарий 3: "Хочу видеть даты создания"

```
Пользователь: "Когда создали Quote?"

1. Columns → включить "Created"
2. Apply

┌────────────┬──────────┬─────────┬──────────┐
│ loc Address│ Created  │ loc Code│ loc Name │
│ 123 Main St│ 11/3/25  │ LOC001  │ Downtown │
└────────────┴──────────┴─────────┴──────────┘

✅ Created добавлен
```

---

## 💡 Почему только location?

### Quote = Location-центричные данные

```
Quote содержит информацию о:
  ✓ Адресе location
  ✓ Коде location
  ✓ Названии location

Это главная информация для Quote!

ID и Created - вспомогательные данные:
  - ID есть в каждой строке слева (Badge)
  - Created нужна редко
  - Можно включить когда нужно
```

### Другие типы транзакций:

```
Customer:
  По умолчанию: ID, Name, Status, Created
  (не location-центричные)

Location:
  По умолчанию: ID, Name, Address, Created
  (другая структура)

Quote:
  По умолчанию: location Address, Code, Name
  (только location - это правильно!)
```

---

## 🔍 Где найти ID и Created?

### ID всегда виден:

```
Каждая строка начинается с Badge:
┌─────────────┬────────────────┬──────────┐
│ Quote:12918 │ loc Address    │ loc Code │
│ Quote:12917 │ 123 Main St    │ LOC001   │
│ Quote:12916 │ 456 Oak Ave    │ LOC002   │
└─────────────┴────────────────┴──────────┘
      ↑
  ID всегда
  видно здесь!
```

### Created в деталях:

```
1. Нажать "View" на любой строке
2. Откроется Transaction Detail
3. Там видно Created, Updated, и всё остальное

Или:
1. Columns → включить "Created"
2. ✅ Видно в таблице
```

---

## 🧪 Тестирование

### Чеклист:

```
□ Открыть Data Plane
□ Выбрать Quote
□ Видны 3 колонки:
  □ location Address
  □ location Code
  □ location Name
□ НЕ видны:
  □ ID (но есть в Badge слева)
  □ Created
□ Открыть Columns
□ Включить "ID"
□ ID появился в таблице
□ Включить "Created"
□ Created появился
□ Reset to Default
□ Вернулись 3 location-колонки
```

---

## 📁 Технические детали

### Файл: `/components/TransactionsView.tsx`

#### Изменения:

**Строка 65:** (ID)
```typescript
// Было:
{ key: 'TxnId', label: 'ID', enabled: true, locked: true },

// Стало:
{ key: 'TxnId', label: 'ID', enabled: false, locked: true },
```

**Строка 66:** (Created)
```typescript
// Было:
{ key: 'CreateTime', label: 'Created', enabled: true },

// Стало:
{ key: 'CreateTime', label: 'Created', enabled: false },
```

**location-поля остались enabled: true:**
```typescript
{ key: 'Txn.location.Address', label: 'location Address', enabled: true },
{ key: 'Txn.location.Code', label: 'location Code', enabled: true },
{ key: 'Txn.location.Name', label: 'location Name', enabled: true },
```

#### Версия хранилища:

**Обновлена с '5' на '6':**
```typescript
// 4 места где обновлена версия:

1. useState (строка 99):
   const STORAGE_VERSION = '6';

2. useEffect save (строка 130):
   const STORAGE_VERSION = '6';

3. handleResetColumns (строка 120):
   const STORAGE_VERSION = '6';

4. useEffect load (строка 310):
   const STORAGE_VERSION = '6';
```

**Зачем обновляли версию?**
```
Чтобы старые настройки (с ID и Created) не применялись.
Новая версия = новые дефолты.
```

---

## ✅ Обратная совместимость

### Что сохранилось:

```
✅ Все колонки доступны в Column Selector
✅ ID можно включить
✅ Created можно включить
✅ Сохранение настроек работает
✅ Переключение между типами работает
```

### Что изменилось:

```
✅ Только дефолтное отображение Quote
✅ Другие типы (Customer, Location) не затронуты
✅ Пользовательские настройки сбросятся (один раз)
```

---

## 📊 Статистика

### Было (Quote):
```
Дефолтных колонок: 5
Видимые: ID, Created, loc Address, loc Code, loc Name
Скрытые: Quote ID, Account Number, etc.
```

### Стало (Quote):
```
Дефолтных колонок: 3
Видимые: loc Address, loc Code, loc Name
Скрытые: ID, Created, Quote ID, Account Number, etc.
```

### Экономия места:
```
-40% колонок по умолчанию
+50% места для location данных
```

---

## 🎨 Дизайн-решения

### Почему убрали ID?

```
✅ ID виден в Badge каждой строки
✅ ID не помогает идентифицировать location
✅ ID занимает место
✅ ID можно включить когда нужно
```

### Почему убрали Created?

```
✅ Дата создания не главная информация
✅ Дата есть в Transaction Detail
✅ Дата занимает место
✅ Можно включить для анализа
```

### Почему оставили location-поля?

```
✅ Это главная информация Quote
✅ Address - где находится
✅ Code - уникальный идентификатор
✅ Name - человеко-читаемое название
```

---

## 💡 Рекомендации

### Для обычного просмотра:
```
Оставить дефолт (3 location-колонки)
✓ Чисто
✓ Понятно
✓ Фокус на location
```

### Для анализа:
```
Включить дополнительные:
✓ Created - для анализа по датам
✓ Quote ID - для сопоставления
✓ Account Number - для привязки
```

### Для отладки:
```
Включить всё:
✓ ID
✓ Created
✓ Updated
✓ ERP User ID
```

---

## 🚀 Примеры использования

### Пример 1: "Найти Quote для конкретной location"

```
1. Data Plane → Quote
2. Фильтр "location Code" → "LOC001"
3. Видны все Quote для LOC001:

┌────────────┬──────────┬─────────────┐
│ loc Address│ loc Code │ location Name│
│ 123 Main St│ LOC001   │ Downtown    │
│ 123 Main St│ LOC001   │ Downtown    │
└────────────┴──────────┴─────────────┘

✅ Легко найти
✅ Ничего лишнего
```

### Пример 2: "Найти Quote по адресу"

```
1. Data Plane → Quote
2. Фильтр "location Address" → "Main"
3. Видны Quote с "Main" в адресе:

┌─────────────────┬──────────┬──────────────┐
│ location Address│ loc Code │ location Name│
│ 123 Main St     │ LOC001   │ Downtown     │
│ 456 Main Ave    │ LOC005   │ Warehouse    │
└─────────────────┴──────────┴──────────────┘

✅ Быстро нашли
```

### Пример 3: "Анализ Quote по датам"

```
1. Data Plane → Quote
2. Columns → включить "Created"
3. Фильтр "Created" → "2025-10"

┌────────────┬──────────┬──────────┬──────────┐
│ Created    │ loc Addr │ loc Code │ loc Name │
│ 10/31/2025 │ 123 Main │ LOC001   │ Downtown │
│ 10/30/2025 │ 456 Oak  │ LOC002   │ Warehouse│
└────────────┴──────────┴──────────┴──────────┘

✅ Анализ по датам готов
```

---

## 📚 Связанные документы

### Предыдущие обновления:
- `/QUOTE_COLUMNS_UPDATE.md` - Добавление type-specific колонок
- `/QUOTE_COLUMNS_SUMMARY.md` - Полная система колонок

### Другие фичи:
- `/COLUMN_FILTERS_FEATURE.md` - Фильтрация по колонкам
- `/DATA_PLANE_PAGINATION_UPDATE.md` - Пагинация 10 строк

---

## ✅ Проверка изменений

### Быстрый тест:

```bash
1. Открыть приложение
2. Data Plane → Quote
3. Проверить колонки:
   ✓ location Address - видна
   ✓ location Code - видна
   ✓ location Name - видна
   ✗ ID - скрыта (но есть в Badge)
   ✗ Created - скрыта
4. Columns → включить "ID"
   ✓ ID появилась
5. Columns → Reset
   ✓ Вернулись 3 location-колонки
```

---

## 🎯 Итого

### Что сделано:
- ✅ Убрали ID из дефолтных (enabled: false)
- ✅ Убрали Created из дефолтных (enabled: false)
- ✅ Оставили location Address, Code, Name
- ✅ Обновили STORAGE_VERSION с '5' на '6'
- ✅ Все старые настройки сбросятся

### Что получили:
- ✅ Чистый интерфейс (3 колонки)
- ✅ Фокус на location-данных
- ✅ Больше места для информации
- ✅ ID и Created доступны в Column Selector

### Кому полезно:
- ✅ Всем, кто работает с Quote
- ✅ Тем, кому важны location-данные
- ✅ Тем, кто хочет чистый интерфейс

---

**Статус:** ✅ Готово  
**Дата:** 3 ноября 2025  
**Версия:** TransactionsView v6  
**Impact:** Medium (UX improvement)  

Теперь Quote показывает **только то, что важно** - location-данные! 🎯
