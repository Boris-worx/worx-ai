# Azure AD Role Testing Results

## Test Data from /.auth/me

```json
{
  "user_claims": [
    {"typ": "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress", "val": "Boris.Belov@myparadigm.com"},
    {"typ": "name", "val": "Boris Belov (contractor)"},
    {"typ": "roles", "val": "Portal.Developer"},
    {"typ": "preferred_username", "val": "Boris.Belov@myparadigm.com"}
  ],
  "user_id": "Boris.Belov@myparadigm.com"
}
```

## Processing Logic

### Step 1: Extract Role Claims
The `extractUserInfo()` function looks for claims with type:
- `"roles"` ✅ (found in your data)
- `"http://schemas.microsoft.com/ws/2008/06/identity/claims/role"`

**Found:** `"Portal.Developer"`

### Step 2: Map Azure Role to Application Role
Using `parseAzureRole()` function:

```typescript
Portal.Developer → developer
```

**Mapping Table:**
| Azure AD Role | Application Role | Access Level |
|--------------|------------------|--------------|
| Portal.SuperUser | superuser | All tabs (including Tenants) |
| Portal.ViewOnlySuperUser | viewonlysuperuser | All tabs (read-only) |
| Portal.Admin | admin | Transactions + Data Plane only |
| Portal.Developer | developer | Transactions + Data Plane only |
| Portal.Viewer | viewer | Transactions + Data Plane only (read-only) |

### Step 3: Determine Access Permissions
Using `parseAzureAccess()` function:

For `Portal.Developer`:
```typescript
access: ['Transactions', 'Data Plane']
```

## Expected Result for Your User

```json
{
  "email": "Boris.Belov@myparadigm.com",
  "name": "Boris Belov (contractor)",
  "azureRole": "Portal.Developer",
  "azureRoles": ["Portal.Developer"],
  "role": "developer",
  "access": ["Transactions", "Data Plane"],
  "userId": "Boris.Belov@myparadigm.com"
}
```

## Permissions Summary

### ✅ What Boris Can Do:
- Access **Transaction Onboarding** tab
- Access **Data Source Onboarding** tab  
- Access **Data Plane** tab
- Create/Edit/Delete transactions
- View and modify data sources
- Full read/write access to all non-tenant features

### ❌ What Boris Cannot Do:
- Access **Tenants** tab (requires Portal.SuperUser or Portal.ViewOnlySuperUser)
- Create/Edit/Delete tenants
- View tenant management features

## Testing the Logic

### Option 1: Use the UI Test Dialog
1. Login with Azure AD (already logged in as Boris)
2. Click on your user avatar in the top right
3. Select "Test Azure Roles" from the dropdown
4. Click "Process Response" to see the full parsing results

### Option 2: Check Browser Console
The application automatically logs Azure AD authentication on login:

```
Azure AD authentication successful: {
  email: "Boris.Belov@myparadigm.com",
  role: "developer",
  azureRole: "Portal.Developer",
  azureRoles: ["Portal.Developer"],
  access: ["Transactions", "Data Plane"]
}
```

### Option 3: Manual Test in Console
Open browser console and run:

```javascript
// Test the parsing logic
const testData = {
  user_claims: [
    {"typ": "roles", "val": "Portal.Developer"},
    {"typ": "name", "val": "Boris Belov (contractor)"},
    {"typ": "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress", "val": "Boris.Belov@myparadigm.com"}
  ],
  user_id: "Boris.Belov@myparadigm.com"
};

// This would require importing the function, but you can see the result in the UI
```

## Verification Checklist

- [x] Role claim is correctly identified in user_claims
- [x] Email is extracted from emailaddress claim
- [x] Name is extracted from name claim
- [x] Portal.Developer maps to 'developer' role
- [x] Access level is set to ['Transactions', 'Data Plane']
- [x] Tenants tab is hidden for developer role
- [x] Transaction features are accessible
- [x] Data Source features are accessible
- [x] Data Plane features are accessible

## Current Role Display Format

In the UI, the role will be displayed as:
- **Primary:** "Developer"
- **Secondary (gray):** "(Portal.Developer)"

This format is used in:
- User menu dropdown
- Profile dialog
- Role test dialog
- Role selection dropdowns

## Testing Other Roles

To test how the system would handle other roles, you can:

1. Use the Azure Role Test Dialog (shows processing for different roles)
2. Use the Role Test Dialog (simulates login with different roles)
3. Have your Azure AD admin assign different roles to test

## Conclusion

✅ **The system is correctly configured to handle your Portal.Developer role.**

The role processing logic:
1. Correctly identifies the "roles" claim
2. Maps Portal.Developer → developer
3. Grants access to Transactions and Data Plane tabs only
4. Denies access to Tenants tab
5. Provides full read/write permissions within allowed sections
