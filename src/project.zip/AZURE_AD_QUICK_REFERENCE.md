# Azure AD Integration - Quick Reference

## ✅ Да, роль берётся именно оттуда!

Из вашего примера:
```json
{
  "typ": "roles",
  "val": "Portal.Admin"  ← ✅ ОТСЮДА
}
```

Приложение автоматически находит этот claim в массиве `user_claims` и маппит:
- `Portal.Admin` → `admin` (полный доступ)
- `Portal.Editor` → `edit` (без создания)
- `Portal.Reader` → `view` (только просмотр)

## 📋 Что извлекается из `/.auth/me`

```json
[
  {
    "user_claims": [
      {
        "typ": "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress",
        "val": "Boris.Belov@myparadigm.com"  ← Email
      },
      {
        "typ": "name",
        "val": "Boris Belov (contractor)"  ← Имя пользователя
      },
      {
        "typ": "roles",
        "val": "Portal.Admin"  ← Роль
      }
    ],
    "user_id": "Boris.Belov@myparadigm.com"  ← User ID
  }
]
```

## 🚪 Logout - Простой и понятный

### Для пользователей:
1. Кликаете на иконку профиля (👤) в правом верхнем углу
2. В меню выбираете **"Log Out"** или **"Sign Out from Azure"**
3. **Всё!** Вас автоматически перенаправит на `/.auth/logout`
4. Azure завершит сессию
5. **НИКАКИХ ПОПАПОВ** - чистый logout!

### Что происходит технически:
```typescript
// В AuthContext при клике на Logout:
const logout = () => {
  setUser(null);
  localStorage.removeItem('bfs_user');
  
  // Прямой redirect - БЕЗ попапов!
  if (user?.isAzureAuth && isAzureAuthEnabled()) {
    window.location.href = '/.auth/logout';  ← Редирект сразу
  }
};
```

### Для бекендера - ничего делать не нужно!

Azure App Service автоматически предоставляет endpoint:
```
GET /.auth/logout
```

Что он делает:
- ✅ Завершает Azure AD сессию
- ✅ Очищает authentication cookies
- ✅ Перенаправляет на post-logout URL (если настроен)

## 🔄 Полный поток авторизации

```
┌─────────────────┐
│  User открывает │
│  приложение     │
└────────┬────────┘
         │
         ↓
┌─────────────────┐
│  GET /.auth/me  │  ← Автоматически при загрузке
└────────┬────────┘
         │
         ↓
┌─────────────────────────┐
│  Парсинг user_claims:   │
│  - Email                │
│  - Name                 │
│  - Role (Portal.Admin)  │
└────────┬────────────────┘
         │
         ↓
┌─────────────────────────┐
│  Маппинг роли:          │
│  Portal.Admin → admin   │
└────────┬────────────────┘
         │
         ↓
┌─────────────────────────┐
│  Показываем UI с        │
│  правами пользователя   │
└─────────────────────────┘
```

## 🚪 Полный поток logout (БЕЗ ПОПАПОВ!)

```
┌──────────────────┐
│  User кликает    │
│  "Log Out"       │
└────────┬─────────┘
         │
         ↓
┌──────────────────┐
│  Frontend        │
│  очищает state   │
└────────┬─────────┘
         │
         ↓
┌───────────────────────┐
│  ПРЯМОЙ REDIRECT:     │
│  window.location.href │
│  = /.auth/logout      │  ← БЕЗ попапов!
└────────┬──────────────┘
         │
         ↓
┌──────────────────────┐
│  Azure завершает     │
│  AAD сессию          │
└────────┬─────────────┘
         │
         ↓
┌──────────────────────┐
│  Очищает cookies     │
└────────┬─────────────┘
         │
         ↓
┌──────────────────────┐
│  Redirect на         │
│  post-logout URL     │  ← Если настроен
└──────────────────────┘
```

## 🎯 Что показывается в User Menu

### Dropdown содержит:
```
┌─────────────────────────┐
│ Azure AD User           │  ← Для Azure пользователей
│ boris                   │
├─────────────────────────┤
│ 📧 Boris.Belov@...      │  ← Email
├─────────────────────────┤
│ 🛡️ Portal.Admin         │  ← Azure роль
├─────────────────────────┤
│ 👤 Access Level: admin  │  ← Внутренняя роль
├─────────────────────────┤
│ 🔄 Change Role          │  ← Тестирование ролей
├─────────────────────────┤
│ 🚪 Sign Out from Azure  │  ← LOGOUT! (без попапа)
└─────────────────────────┘
```

## 🔧 Проверка что всё работает

### 1. Проверить авторизацию:
```bash
curl https://your-app.azurewebsites.net/.auth/me
```

Должен вернуть JSON с `user_claims` если залогинен.

### 2. Проверить logout:
```bash
curl -L https://your-app.azurewebsites.net/.auth/logout
```

Должен перенаправить и очистить сессию.

### 3. В браузере:
1. Открыть DevTools → Console
2. Посмотреть логи: "Azure AD authentication successful"
3. В Network → найти `/.auth/me` → Response должен содержать `roles` claim
4. Кликнуть "Log Out" → должен быть redirect на `/.auth/logout` без попапов

## 📝 Важные моменты

1. **Роль ДОЛЖНА быть в user_claims**
   - Если нет claim с `typ: "roles"`, пользователь получит роль `view` по умолчанию
   - Убедитесь что роли настроены в Enterprise Application

2. **Logout теперь БЕЗ попапов!**
   - Прямой редирект на `/.auth/logout`
   - LoginDialog НЕ показывается после logout для Azure пользователей
   - Чистый UX без лишних диалогов

3. **Безопасность**
   - Frontend только отображает UI на основе роли
   - Backend ДОЛЖЕН проверять права доступа на каждый API запрос
   - Не полагайтесь только на frontend проверки!

## ❓ FAQ

**Q: Нужно ли что-то делать на backend для logout?**
A: Нет, `/.auth/logout` работает автоматически. Опционально можно настроить post-logout redirect.

**Q: Показывается ли попап при logout?**
A: НЕТ! Теперь происходит прямой редирект на `/.auth/logout` без попапов.

**Q: Где настроить роли Portal.Admin, Portal.Editor, Portal.Reader?**
A: Azure Portal → Enterprise Applications → App Roles → Добавить роли → Назначить пользователям.

**Q: Что если роль не приходит в user_claims?**
A: Проверьте настройки Enterprise Application и убедитесь что роли включены в token configuration.

**Q: Как тестировать локально?**
A: Используйте тестовые credentials (admin/admin123, editor/edit123, viewer/view123).

**Q: Можно ли изменить маппинг ролей?**
A: Да, в файле `/lib/azure-auth.ts` в функции `parseAzureRole()`.