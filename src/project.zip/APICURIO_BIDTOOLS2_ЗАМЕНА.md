# ✅ Apicurio: paradigm.bidtools → paradigm.bidtools2

**Дата:** 27 ноября 2025  
**Статус:** ✅ ИСПРАВЛЕНО - Теперь загружается из paradigm.bidtools2 ВМЕСТО paradigm.bidtools

---

## 🎯 Что сделано

**ЗАМЕНИЛИ** источник для Bid Tools Templates:

### ❌ БЫЛО (старый URL):
```
https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/paradigm.bidtools/artifacts/
```

### ✅ СТАЛО (новый URL):
```
https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/paradigm.bidtools2/artifacts/
```

---

## 📝 Изменения в коде

### 1. `/lib/apicurio.ts` - строка 87

**БЫЛО:**
```typescript
const groups = ['paradigm.bidtools', 'bfs.online'];
```

**СТАЛО:**
```typescript
const groups = ['paradigm.bidtools2', 'bfs.online'];
```

**Результат:**
- ✅ Приложение теперь запрашивает артефакты из `paradigm.bidtools2` вместо `paradigm.bidtools`
- ✅ Группа `bfs.online` остается без изменений

---

### 2. `/lib/apicurio.ts` - строки 179-250 (mock данные)

**ИЗМЕНЕНО:** Все 7 артефактов теперь имеют `groupId: "paradigm.bidtools2"` вместо `"paradigm.bidtools"`

**Артефакты с обновленным groupId:**

#### CDC Format (3 артефакта):
```typescript
{
  artifactId: "CDC_SQLServer_LineTypes",
  groupId: "paradigm.bidtools2",  // ← ИЗМЕНЕНО
  artifactType: "AVRO",
  name: "LineTypes (CDC)",
  ...
},
{
  artifactId: "CDC_SQLServer_ServiceRequests",
  groupId: "paradigm.bidtools2",  // ← ИЗМЕНЕНО
  artifactType: "AVRO",
  name: "ServiceRequests (CDC)",
  ...
},
{
  artifactId: "CDC_SQLServer_WorkflowCustomers",
  groupId: "paradigm.bidtools2",  // ← ИЗМЕНЕНО
  artifactType: "AVRO",
  name: "WorkflowCustomers (CDC)",
  ...
}
```

#### TxServices Format (4 артефакта):
```typescript
{
  artifactId: "TxServices_SQLServer_QuoteDetails.response",
  groupId: "paradigm.bidtools2",  // ← ИЗМЕНЕНО
  artifactType: "JSON",
  name: "QuoteDetails",
  ...
},
{
  artifactId: "TxServices_SQLServer_QuotePacks.response",
  groupId: "paradigm.bidtools2",  // ← ИЗМЕНЕНО
  artifactType: "JSON",
  name: "QuotePacks",
  ...
},
{
  artifactId: "TxServices_SQLServer_Quotes.response",
  groupId: "paradigm.bidtools2",  // ← ИЗМЕНЕНО
  artifactType: "JSON",
  name: "Quotes",
  ...
},
{
  artifactId: "TxServices_SQLServer_ReasonCodes.response",
  groupId: "paradigm.bidtools2",  // ← ИЗМЕНЕНО
  artifactType: "JSON",
  name: "ReasonCodes",
  ...
}
```

**Результат:**
- ✅ Если Apicurio недоступен, mock данные будут использовать `paradigm.bidtools2`
- ✅ Названия артефактов остались прежними (без V2 суффикса)
- ✅ Количество артефактов: 18 (7 от bidtools2 + 11 от bfs.online)

---

### 3. `/components/DataCaptureSpecCreateDialog.tsx` - строки 947-960

**БЫЛО:**
```typescript
heading={
  groupId === "paradigm.bidtools"
    ? "Bid Tools Templates"
    : groupId === "paradigm.bidtools2"
      ? "Bid Tools Templates V2"
      : groupId === "bfs.online"
        ? "BFS Online Templates"
        : groupId
}
```

**СТАЛО:**
```typescript
heading={
  groupId === "paradigm.bidtools2"
    ? "Bid Tools Templates"
    : groupId === "bfs.online"
      ? "BFS Online Templates"
      : groupId
}
```

**Результат:**
- ✅ В UI группа `paradigm.bidtools2` отображается как "Bid Tools Templates"
- ✅ Для пользователя название группы не изменилось
- ✅ Убрана проверка для старой группы `paradigm.bidtools`

---

## 📊 Сравнение До/После

### API Requests:

| Было | Стало |
|------|-------|
| GET /groups/**paradigm.bidtools**/artifacts | GET /groups/**paradigm.bidtools2**/artifacts |
| GET /groups/bfs.online/artifacts | GET /groups/bfs.online/artifacts |
| **2 группы** | **2 группы** |

### Mock данные:

| Группа | Артефактов | Статус |
|--------|-----------|--------|
| paradigm.bidtools | 7 | ❌ Удалено |
| paradigm.bidtools2 | 7 | ✅ Теперь используется |
| bfs.online | 11 | ✅ Без изменений |
| **Total** | **18** | ✅ Количество то же |

### UI Display:

| Было | Стало |
|------|-------|
| 📋 Bid Tools Templates (из paradigm.bidtools) | 📋 Bid Tools Templates (из paradigm.bidtools2) |
| 📋 BFS Online Templates | 📋 BFS Online Templates |

**Для пользователя:** Название группы в UI не изменилось, но источник данных теперь другой!

---

## 🎨 Как выглядит в UI

### Template Selection Dialog

```
┌─────────────────────────────────────────────┐
│ Create Data Capture Specification          │
├─────────────────────────────────────────────┤
│                                             │
│ Select Template:  [▼ Choose template...]   │
│                                             │
│ ┌─────────────────────────────────────────┐ │
│ │ 📋 Bid Tools Templates                  │ │
│ │    (source: paradigm.bidtools2)         │ │
│ │   • LineTypes (CDC)                     │ │
│ │   • QuoteDetails                        │ │
│ │   • QuotePacks                          │ │
│ │   • Quotes                              │ │
│ │   • ReasonCodes                         │ │
│ │   • ServiceRequests (CDC)               │ │
│ │   • WorkflowCustomers (CDC)             │ │
│ │                                         │ │
│ │ 📋 BFS Online Templates                 │ │
│ │    (source: bfs.online)                 │ │
│ │   • inv, inv1, inv2, inv3               │ │
│ │   • invap, invdes, invloc               │ │
│ │   • keyi, loc, loc1, stcode             │ │
│ └─────────────────────────────────────────┘ │
│                                             │
│ [Cancel]                    [Create]        │
└─────────────────────────────────────────────┘
```

**Важно:** Название "Bid Tools Templates" осталось прежним, но источник изменился!

---

## 🧪 Как проверить

### В Browser Console:

```javascript
// Проверить что запросы идут к paradigm.bidtools2
// Открыть DevTools → Network → Filter by "apicurio"

// Вы должны увидеть:
GET /apis/registry/v3/groups/paradigm.bidtools2/artifacts
GET /apis/registry/v3/groups/bfs.online/artifacts

// НЕ должно быть:
// GET /apis/registry/v3/groups/paradigm.bidtools/artifacts
```

### В UI:

```
1. Открыть Data Source Onboarding
2. Выбрать data source
3. Нажать "Add Specification"
4. Открыть dropdown "Select Template"
5. Проверить что группа "Bid Tools Templates" отображается
6. Проверить console - должен быть запрос к paradigm.bidtools2
```

### В Console Logs:

**Ожидаемые логи:**
```
📦 Fetching from group: paradigm.bidtools2
📦 Response status (paradigm.bidtools2): 200
📦 Loaded X artifacts from paradigm.bidtools2 group

📦 Fetching from group: bfs.online
📦 Response status (bfs.online): 200
📦 Loaded X artifacts from bfs.online group

📦 Total artifacts loaded: 18+
```

**НЕ должно быть:**
```
📦 Fetching from group: paradigm.bidtools  ← Этого больше нет!
```

---

## 🔄 Технический Flow

### При открытии Create Dialog:

```javascript
// 1. Попытка загрузить из Apicurio
async function searchApicurioArtifacts() {
  const groups = ['paradigm.bidtools2', 'bfs.online'];  // ← paradigm.bidtools2!
  
  for (const group of groups) {
    const url = `${APICURIO_URL}/groups/${group}/artifacts`;
    const response = await fetch(url);
    
    // Для группы paradigm.bidtools2:
    // GET https://apicurio-poc.../groups/paradigm.bidtools2/artifacts
    
    if (response.ok) {
      allArtifacts.push(...response.json().artifacts);
    }
  }
  
  return allArtifacts;
}

// 2. Group by groupId
const grouped = {
  'paradigm.bidtools2': [7 artifacts],  // ← Теперь bidtools2
  'bfs.online': [11 artifacts]
}

// 3. Display with custom heading
'paradigm.bidtools2' → "Bid Tools Templates"  // ← Название то же!
'bfs.online' → "BFS Online Templates"
```

---

## 📋 Checklist изменений

### Код:

- [x] ✅ Заменено `'paradigm.bidtools'` → `'paradigm.bidtools2'` в groups array
- [x] ✅ Обновлен groupId во всех 7 mock артефактах
- [x] ✅ Убраны дубликаты V2 артефактов
- [x] ✅ Обновлен UI heading для группы `paradigm.bidtools2`
- [x] ✅ Убрана проверка для старой группы `paradigm.bidtools`

### Количество артефактов:

- [x] ✅ Mock count остался 18 (не изменился)
- [x] ✅ Bid Tools Templates: 7 артефактов (из paradigm.bidtools2)
- [x] ✅ BFS Online Templates: 11 артефактов (из bfs.online)

### UI:

- [x] ✅ Название "Bid Tools Templates" осталось прежним
- [x] ✅ Группа `paradigm.bidtools` больше не используется
- [x] ✅ Группа `paradigm.bidtools2` отображается как "Bid Tools Templates"

---

## 🎯 Что изменилось для пользователя

### Визуально (UI):

**НИЧЕГО!** 😊

Группа по-прежнему называется "Bid Tools Templates" и содержит те же 7 шаблонов.

### Технически (под капотом):

**ВСЁ!** 🔧

- API запросы теперь идут к `paradigm.bidtools2` вместо `paradigm.bidtools`
- Mock данные используют `paradigm.bidtools2` вместо `paradigm.bidtools`
- Источник данных полностью изменился

---

## ⚠️ Важные замечания

### 1. Apicurio Registry должен содержать группу `paradigm.bidtools2`

Если в реальном Apicurio Registry нет группы `paradigm.bidtools2`, то:
- ✅ Будут использоваться mock данные (fallback)
- ✅ Приложение продолжит работать
- ⚠️ Но реальные схемы не загрузятся из API

**Решение:** Убедиться что в Apicurio Registry существует группа `paradigm.bidtools2` с нужными артефактами.

### 2. Названия артефактов остались прежними

Mock артефакты НЕ переименованы в V2:
- ✅ `QuoteDetails` (не `QuoteDetailsV2`)
- ✅ `LineTypes (CDC)` (не `LineTypesV2 (CDC)`)

Это значит что в `paradigm.bidtools2` должны быть артефакты с теми же ID что и раньше в `paradigm.bidtools`.

### 3. Cache может содержать старые данные

Если приложение уже загружало данные из `paradigm.bidtools`, в cache могут быть старые данные.

**Решение:**
```javascript
// Browser Console
import { clearArtifactsCache } from './lib/apicurio';
clearArtifactsCache();
location.reload();
```

---

## 🚀 Проверка перед deployment

### Development:

- [x] ✅ Код компилируется
- [x] ✅ TypeScript без ошибок
- [x] ✅ Mock данные обновлены
- [ ] ⏳ UI тестирование

### Production:

**На стороне Apicurio Registry:**
- [ ] Группа `paradigm.bidtools2` создана
- [ ] Все 7 артефактов загружены в `paradigm.bidtools2`:
  - [ ] CDC_SQLServer_LineTypes
  - [ ] CDC_SQLServer_ServiceRequests
  - [ ] CDC_SQLServer_WorkflowCustomers
  - [ ] TxServices_SQLServer_QuoteDetails.response
  - [ ] TxServices_SQLServer_QuotePacks.response
  - [ ] TxServices_SQLServer_Quotes.response
  - [ ] TxServices_SQLServer_ReasonCodes.response
- [ ] CORS настроен для доступа

**На стороне приложения:**
- [x] ✅ Код готов
- [ ] Тестирование с реальным Apicurio
- [ ] Clear cache перед deployment

---

## 📊 Статистика

| Метрика | Значение |
|---------|----------|
| Файлов изменено | 2 |
| Групп заменено | 1 (paradigm.bidtools → paradigm.bidtools2) |
| Артефактов обновлено | 7 (groupId изменен) |
| Всего групп | 2 (paradigm.bidtools2 + bfs.online) |
| Всего артефактов | 18 (без изменений) |
| UI изменений | 0 (название группы то же) |

---

## 🔍 Troubleshooting

### Проблема: Группа не отображается

**Симптомы:**
```
UI не показывает "Bid Tools Templates"
```

**Причины:**
1. Apicurio не содержит группу `paradigm.bidtools2`
2. CORS блокирует запросы
3. Cache содержит старые данные

**Решение:**
1. Проверить console logs
2. Очистить cache: `clearArtifactsCache()`
3. Проверить что mock данные загружаются

### Проблема: 403 Forbidden

**Симптомы:**
```
📦 Access forbidden (403) for group: paradigm.bidtools2
```

**Решение:**
✅ Это нормально! Приложение автоматически использует mock данные.

### Проблема: Артефакты не загружаются

**Симптомы:**
```
❌ Error fetching Apicurio artifact
```

**Причины:**
Артефактов нет в группе `paradigm.bidtools2`

**Решение:**
1. Использовать mock данные (fallback работает)
2. Загрузить артефакты в `paradigm.bidtools2` группу

---

## ✅ Summary

**Что было сделано:**
- ✅ Заменена группа `paradigm.bidtools` → `paradigm.bidtools2` в API запросах
- ✅ Обновлены mock данные (7 артефактов)
- ✅ Обновлен UI heading
- ✅ Код компилируется без ошибок

**Результат:**
- ✅ Приложение теперь загружает шаблоны из `paradigm.bidtools2`
- ✅ Для пользователя название группы не изменилось
- ✅ Fallback на mock данные работает

**Готово к:**
- ✅ Тестированию в development
- ⏳ Production deployment (требуется настройка Apicurio)

---

**Следующий шаг:** Проверить в browser что запросы идут к `/groups/paradigm.bidtools2/artifacts`

**Дата:** 27 ноября 2025  
**Версия:** 2.0 (исправлено)
