# 🔧 Model Schema ID Format Fix

## ✅ Status: FIXED

## 🐛 Error

```
❌ Error: {"status": {"code": 400, "message": "ModelSchema id mismatch or missing"}, "data": {}}
```

## 🎯 Root Cause

1. API ожидает `id` в объекте `Txn` **БЕЗ** префикса "ModelSchema:"
2. API **валидирует**, что `id` должен точно совпадать с `"{model}:{version}"`
   - Пример: если `model="Location"` и `version=1`, то `id` **ДОЛЖЕН** быть `"Location:1"`

## 📊 Comparison

### **❌ БЫЛО (Неправильно)**

```json
PUT /txns/ModelSchema:Location:1
{
  "TxnType": "ModelSchema",
  "Txn": {
    "id": "ModelSchema:Location:1",  ← С префиксом - ОШИБКА!
    "model": "Location",
    "version": 1,
    "state": "active",
    "semver": "1.0.0",
    "jsonSchema": {...}
  }
}
```

**Результат**: `400 Bad Request - ModelSchema id mismatch or missing`

### **✅ СТАЛО (Правильно)**

```json
PUT /txns/ModelSchema:Location:1
{
  "TxnType": "ModelSchema",
  "Txn": {
    "id": "Location:1",  ← БЕЗ префикса - РАБОТАЕТ!
    "model": "Location",
    "version": 1,
    "state": "active",
    "semver": "1.0.0",
    "jsonSchema": {...}
  }
}
```

**Результат**: `200 OK - Success!`

## 🔧 Implementation

### **updateModelSchema()** в `/lib/api.ts`

```typescript
export async function updateModelSchema(
  schemaId: string,
  schemaData: Partial<ModelSchema>,
  etag: string
): Promise<ModelSchema> {
  // 1. Construct full TxnId with ModelSchema prefix (for URL)
  const txnId = schemaId.startsWith('ModelSchema:') 
    ? schemaId 
    : `ModelSchema:${schemaId}`;
  
  // 2. IMPORTANT: API validates that id MUST match "{model}:{version}"
  // We can't use the old id - we must construct it from current model and version
  // Example: model="Location", version=1 -> id="Location:1"
  const constructedId = `${schemaData.model}:${schemaData.version}`;
  
  // 3. API expects id inside Txn object WITHOUT the ModelSchema prefix
  const txnDataWithId = {
    ...schemaData,
    id: constructedId, // ← Construct from model:version!
  };
  
  // 4. PUT request
  const response = await fetch(
    `${API_BASE_URL}/txns/${encodeURIComponent(txnId)}`, // ← URL с префиксом
    {
      method: "PUT",
      headers: getHeaders(etag),
      body: JSON.stringify({
        TxnType: "ModelSchema",
        Txn: txnDataWithId, // ← id БЕЗ префикса
      }),
    }
  );
  
  // ...
}
```

### **deleteModelSchema()** (Soft Delete)

```typescript
// Внутри soft delete fallback:

const currentData = await getCurrentResponse.json();
const currentSchema = currentData.data.Txn;

// IMPORTANT: API validates that id MUST match "{model}:{version}"
// Construct id from current schema's model and version
const constructedId = `${currentSchema.model}:${currentSchema.version}`;

// Update with state: "deleted"
const updatedSchema = {
  ...currentSchema,
  id: constructedId, // ← Construct from model:version!
  state: "deleted",
};

// PUT request for soft delete
await fetch(`${API_BASE_URL}/txns/${encodeURIComponent(txnId)}`, {
  method: "PUT",
  headers: getHeaders(etag),
  body: JSON.stringify({
    TxnType: "ModelSchema",
    Txn: updatedSchema, // ← id БЕЗ префикса
  }),
});
```

## 🔑 Key Points

| Element | Format | Usage |
|---------|--------|-------|
| **URL Path** | `ModelSchema:Location:1` | **С** префиксом |
| **Txn.id** | `Location:1` | **БЕЗ** префикса, **ДОЛЖЕН** быть `{model}:{version}` |
| **TxnType** | `"ModelSchema"` | Строка в body |

### **⚠️ CRITICAL: ID Validation**

API **строго валидирует**, что `id` совпадает с `{model}:{version}`:

```typescript
// ✅ ПРАВИЛЬНО
model: "Location"
version: 1
id: "Location:1"  // ← Совпадает!

// ❌ ОШИБКА
model: "NewLocation"  // ← Изменили model
version: 1
id: "Location:1"  // ← Старое значение - НЕ совпадает!
// Результат: "Value error, id must be 'NewLocation:1'"
```

### **Visual Breakdown**

```
Input: 
  schemaId = "Location:1"
  schemaData = { model: "Location", version: 1, ... }
   ↓
Step 1: Construct txnId = "ModelSchema:Location:1"
   ↓
Step 2: Construct id from model:version = "Location:1"
   ↓
Step 3: Build request
   ├─ URL: /txns/ModelSchema:Location:1  ← С префиксом
   └─ Body: { 
        TxnType: "ModelSchema", 
        Txn: { 
          id: "Location:1",  ← БЕЗ префикса, from model:version
          model: "Location",
          version: 1,
          ...
        } 
      }
```

### **When User Edits Model Name**

```
Original Schema:
  id: "boris new:2"
  model: "boris new"
  version: 2

User Changes:
  model: "boris new" → "boris new2"  ← Changed!
  version: 2  ← Same

Our Code:
  constructedId = `${schemaData.model}:${schemaData.version}`
                = `boris new2:2`  ← ✅ NEW ID!

API Request:
  PUT /txns/ModelSchema:boris new:2  ← URL uses OLD TxnId
  Body: {
    TxnType: "ModelSchema",
    Txn: {
      id: "boris new2:2",  ← ✅ NEW ID matches new model!
      model: "boris new2",
      version: 2,
      ...
    }
  }
```

## 🧪 Testing

### **Test Update**

1. Open Model Schema tab
2. Edit any schema (e.g., Location:1)
3. Change a field
4. Save

**Expected Console Output**:
```
📝 PUT Model Schema Request:
  SchemaId: Location:1
  TxnId: ModelSchema:Location:1
  Constructed ID: Location:1 (from model="Location" and version=1)  ← Verify this!
  URL: https://api.../txns/ModelSchema:Location:1
  Body: {
    "TxnType": "ModelSchema",
    "Txn": {
      "id": "Location:1",  ← Constructed from model:version!
      "model": "Location",
      "version": 1,
      ...
    }
  }

📥 Response status: 200 OK
✅ Model schema updated successfully
```

### **Test Delete (Soft Delete)**

1. Open Model Schema tab
2. Delete any schema
3. Confirm deletion

**Expected Console Output**:
```
🗑️ DELETE Model Schema Request:
  SchemaId: Location:1
  TxnId: ModelSchema:Location:1
  URL: https://api.../txns/ModelSchema:Location:1

📥 Response status: 400 Bad Request
❌ Error response: {"status":{"code":400,"message":"Unsupported TxnType"},"data":{}}

ℹ️ Hard delete not supported, trying soft delete (state: "deleted")
📝 Soft delete: updating state to "deleted"
  Constructed ID: Location:1 (from model="Location" and version=1)  ← Verify this!

✅ Model schema soft deleted (state: "deleted")
```

## 💡 Why This Format?

### **API Design Reasoning**

1. **URL**: Uses full `TxnId` with prefix для уникальности across all transaction types
2. **Body**: Uses `id` без prefix потому что:
   - `TxnType` уже указывает тип ("ModelSchema")
   - Префикс избыточен внутри typed context
   - Упрощает валидацию внутри API

### **Example in Other Transaction Types**

**Quote API (для сравнения)**:
```json
PUT /txns/Quote:12345
{
  "TxnType": "Quote",
  "Txn": {
    "id": "12345",  ← Тоже БЕЗ префикса "Quote:"
    ...
  }
}
```

**Pattern**: `{TransactionType}:{ID}` в URL, но только `{ID}` в body.

## ⚠️ Common Mistakes

### **❌ Mistake 1: Using Full TxnId in Body**
```typescript
const txnDataWithId = {
  ...schemaData,
  id: txnId, // ← ОШИБКА! Включает "ModelSchema:"
};
```

### **❌ Mistake 2: Using Old ID (Wrong when model changes)**
```typescript
const idWithoutPrefix = txnId.replace(/^ModelSchema:/, '');
const txnDataWithId = {
  ...schemaData,
  id: idWithoutPrefix, // ← ОШИБКА! Старое значение, не соответствует новому model
};
```

### **✅ Correct: Construct ID from Model and Version**
```typescript
const constructedId = `${schemaData.model}:${schemaData.version}`;
const txnDataWithId = {
  ...schemaData,
  id: constructedId, // ← ПРАВИЛЬНО! Всегда совпадает с model:version
};
```

## 📝 Summary

| Before Fix | After Fix |
|------------|-----------|
| ❌ `id: "ModelSchema:Location:1"` | ✅ `id: "Location:1"` |
| ❌ 400 Error | ✅ 200 Success |
| ❌ Can't update schemas | ✅ Update works |
| ❌ Can't delete schemas | ✅ Soft delete works |

## ✅ Result

Теперь работают:
- ✅ **UPDATE** - изменение схем
- ✅ **SOFT DELETE** - удаление схем (state: "deleted")
- ✅ **Console Logging** - показывает правильный формат id
- ✅ **Error Handling** - понятные ошибки если что-то не так

---

**Status**: Production Ready ✅  
**Last Updated**: Oct 29, 2025
