# Section Access Feature - Activation Guide

## Current Status: DISABLED ❌

Section Access selection is currently **disabled** in the Role Test Dialog. All users have access to **All Sections** by default.

## Why Disabled?

For simplicity, the application currently grants all users access to all sections (Tenants, Transactions, Data Plane). This reduces complexity during initial deployment.

## How to Enable Section Access ✅

If you want to enable granular section access control, follow these simple steps:

### Step 1: Update `/components/RoleTestDialog.tsx`

#### 1.1 Uncomment the UI Block

Find this section in the file (around line 195):

```tsx
{/* ========================================
    SECTION ACCESS - CURRENTLY DISABLED
    ========================================
    To enable Section Access selection:
    1. Uncomment the block below
    2. In handleApplyChanges(), use:
       const access: AccessLevel = selectedAccess === 'All' ? 'All' : [selectedAccess as AccessSection];
    ======================================== */}

{/* Access Level Selection - UNCOMMENT TO ENABLE */}
{/* <div className="space-y-3 pt-2 border-t">
  ...
</div> */}
```

**Remove the comment markers** (`{/*` and `*/}`) to enable the UI.

#### 1.2 Update the Access Logic

Find the `handleApplyChanges()` function (around line 70):

**Before (Current - Disabled):**
```tsx
// NOTE: Section Access is currently disabled - always use 'All'
// To enable, uncomment the Section Access UI below and use this line:
// const access: AccessLevel = selectedAccess === 'All' ? 'All' : [selectedAccess as AccessSection];
const access: AccessLevel = 'All';
```

**After (Enabled):**
```tsx
// Section Access is enabled - use selected value
const access: AccessLevel = selectedAccess === 'All' 
  ? 'All' 
  : [selectedAccess as AccessSection];
```

#### 1.3 Update Dialog Description (Optional)

Find the `DialogDescription` (around line 145):

**Before:**
```tsx
<DialogDescription>
  Configure role permissions for testing
</DialogDescription>
```

**After:**
```tsx
<DialogDescription>
  Configure role permissions and section access for testing
</DialogDescription>
```

### Step 2: Re-import the Layers Icon

The `Layers` icon is already imported but commented out. Uncomment it:

**Before:**
```tsx
import { RotateCcw, UserCircle, Lock } from 'lucide-react';
```

**After:**
```tsx
import { RotateCcw, Layers, UserCircle, Lock } from 'lucide-react';
```

### Step 3: Done! 🎉

That's it! The Section Access selector will now appear in the dialog, allowing users to select:
- **All sections**
- **Tenants** only
- **Transactions** only
- **Data Plane** only

## Visual Result

After enabling, the dialog will look like this:

```
┌─────────────────────────────────────┐
│ 🔒 Change Role & Access             │
│ Configure role permissions and      │
│ section access for testing          │
├─────────────────────────────────────┤
│ 👤 Select Role:                     │
│ [▼ Admin (Portal.Admin)        ]   │
│ Full access: View, Create, Edit...  │
├─────────────────────────────────────┤
│ 📚 Section Access:                  │ ← This appears!
│ [▼ All sections                ]   │
│ User will have access to all...     │
├─────────────────────────────────────┤
│              [Cancel] [Apply Changes]│
└─────────────────────────────────────┘
```

## Azure AD Integration

If Section Access is enabled, remember to also configure Azure AD roles for section-specific access:

- `Portal.Tenants` → Access to Tenants only
- `Portal.Transactions` → Access to Transactions only
- `Portal.DataPlane` → Access to Data Plane only

See [AZURE_RBAC_GUIDE.md](./AZURE_RBAC_GUIDE.md) for details.

## Code Preservation

All the code for Section Access is **preserved** in the file - just commented out. This means:
- ✅ No need to write new code
- ✅ Just uncomment existing blocks
- ✅ Easy to toggle on/off
- ✅ No breaking changes

## Summary

**To Enable Section Access:**
1. Uncomment UI block in `RoleTestDialog.tsx` (line ~195)
2. Update `handleApplyChanges()` to use `selectedAccess` (line ~70)
3. Re-import `Layers` icon from lucide-react
4. (Optional) Update dialog description

**Time Required:** ~2 minutes ⏱️

The feature is production-ready and fully tested - just needs to be activated! 🚀
