# How to Test Azure AD Role Processing

## Quick Test Methods

### Method 1: Visual UI Test (Recommended)

1. **Login with Azure AD** (you're already logged in as Boris)
   
2. **Open the Test Dialog:**
   - Click your avatar (top right corner)
   - Select **"Test Azure Roles"** from dropdown menu
   
3. **View Results:**
   - See the sample /.auth/me JSON
   - Click **"Process Response"** button
   - View detailed parsing results:
     - Extracted user info
     - Role mapping (Portal.Developer → developer)
     - Access permissions
     - Tab visibility rules

### Method 2: Browser Console

1. **Open Developer Console** (F12)

2. **Check Login Logs:**
   ```
   Azure AD authentication successful: {
     email: "Boris.Belov@myparadigm.com",
     role: "developer",
     azureRole: "Portal.Developer",
     azureRoles: ["Portal.Developer"],
     access: ["Transactions", "Data Plane"]
   }
   ```

3. **Manual Fetch:**
   ```javascript
   fetch('/.auth/me')
     .then(r => r.json())
     .then(data => console.log('Auth data:', data));
   ```

### Method 3: Profile Dialog

1. Click your avatar → **"View Profile"**
2. Check the displayed information:
   - **Name:** Boris Belov (contractor)
   - **Email:** Boris.Belov@myparadigm.com
   - **Role:** Developer (Portal.Developer)
   - **Authentication:** Azure AD

### Method 4: Tab Visibility Check

**Expected visible tabs:**
- ✅ Transaction Onboarding
- ✅ Data Source Onboarding
- ✅ Data Plane

**Expected hidden tabs:**
- ❌ Tenants (should NOT be visible)

## Testing Different Roles

### To Test Other Roles (Azure AD Admin Required)

Ask your Azure AD administrator to temporarily assign different roles:

```
Portal.SuperUser           → Full access to all tabs
Portal.ViewOnlySuperUser   → Read-only access to all tabs
Portal.Admin               → Same as Developer
Portal.Viewer              → Read-only Transactions + Data Plane
```

### Simulated Role Testing (No Azure Admin Needed)

1. Click avatar → **"Change Role"**
2. Select a different role
3. Click **"Apply Changes"**
4. App will simulate that role's permissions
5. **Reset:** Click "Reset to Original" to go back

## Verification Checklist

### For Portal.Developer Role:

- [ ] User menu shows: **Developer (Portal.Developer)**
- [ ] Profile shows correct name and email
- [ ] Transaction tab is visible and accessible
- [ ] Data Source tab is visible and accessible
- [ ] Data Plane tab is visible and accessible
- [ ] Tenants tab is NOT visible
- [ ] Can create/edit/delete transactions
- [ ] Can view/edit data sources
- [ ] Cannot access tenant management

## Expected Console Logs

When you login, you should see:

```
Azure AD endpoint checking...
Azure AD authentication successful: {
  email: "Boris.Belov@myparadigm.com",
  role: "developer",
  azureRole: "Portal.Developer",
  azureRoles: ["Portal.Developer"],
  access: ["Transactions", "Data Plane"]
}
User authenticated: {
  username: "Boris.Belov@myparadigm.com",
  name: "Boris Belov (contractor)",
  email: "Boris.Belov@myparadigm.com",
  role: "developer",
  isAzureAuth: true,
  azureRole: "Portal.Developer",
  access: ["Transactions", "Data Plane"]
}
```

## Debug Mode

### Enable Debug Logging

Add to browser console:
```javascript
localStorage.setItem('debug_azure_auth', 'true');
```

This will show additional logs during authentication.

### Disable Debug Logging
```javascript
localStorage.removeItem('debug_azure_auth');
```

## Common Issues & Solutions

### Issue: Role not recognized

**Check:**
1. Refresh the page (Ctrl+R or Cmd+R)
2. Clear browser cache
3. Check console for errors
4. Verify /.auth/me returns data

**Solution:**
```javascript
// Clear auth cache and reload
localStorage.clear();
sessionStorage.clear();
window.location.reload();
```

### Issue: Wrong permissions

**Check:**
1. Verify your Azure AD role assignment
2. Check console logs for parsed role
3. Use "Test Azure Roles" dialog to verify parsing

**Solution:**
Contact your Azure AD admin to verify role assignment.

### Issue: Tenants tab visible (should be hidden)

**Check:**
1. Verify role is "developer" not "superuser"
2. Check access array in console
3. Clear test mode: localStorage.removeItem('bfs_test_role')

## Testing Scenarios

### Scenario 1: First Login
1. Navigate to app
2. Click "Sign in with Microsoft"
3. Complete Azure AD login
4. Verify role is correctly assigned
5. Check tab visibility

### Scenario 2: Role Change (by Admin)
1. Admin changes your role in Azure AD
2. Logout from app
3. Login again
4. Verify new role is applied
5. Check new permissions

### Scenario 3: Session Persistence
1. Login with Azure AD
2. Refresh page (Ctrl+R)
3. Verify role persists
4. Close browser
5. Open app again
6. Verify still logged in with correct role

### Scenario 4: Test Mode
1. Login normally
2. Click avatar → "Change Role"
3. Select "SuperUser"
4. Verify Tenants tab appears
5. Click "Reset to Original"
6. Verify back to Developer permissions

## Files to Check

### `/lib/azure-auth.ts`
- `extractUserInfo()` - Processes /.auth/me response
- `parseAzureRole()` - Maps Azure role to internal role
- `parseAzureAccess()` - Determines tab access

### `/components/AuthContext.tsx`
- `hasAccess()` - Checks if user can access a section
- User state management

### `/components/App.tsx`
- Tab visibility logic
- Role-based rendering

## Support Resources

- **ROLE_HIERARCHY.md** - Complete role hierarchy
- **AZURE_ROLES_VERIFICATION_RU.md** - Russian verification guide
- **AZURE_ROLE_FLOW_DIAGRAM.md** - Visual flow diagram
- **QUICK_ROLE_GUIDE.md** - Quick reference

## Contact

If you encounter issues:
1. Check browser console for errors
2. Review the verification guides
3. Use the "Test Azure Roles" dialog
4. Contact your Azure AD administrator
