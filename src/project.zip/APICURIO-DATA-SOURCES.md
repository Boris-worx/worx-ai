# Apicurio Registry - Data Source Specifications Discovery

## Overview

This document explains how to discover and use Data Source Specifications from the Apicurio Registry in the BFS Tenant Management application.

## Apicurio Registry Configuration

- **Registry UI**: http://apicurio.52.158.160.62.nip.io/ui
- **Registry API**: http://apicurio.52.158.160.62.nip.io/apis/registry/v2
- **Health Check**: http://apicurio.52.158.160.62.nip.io/health/live

## Naming Convention (Paradigm Standard)

Apicurio uses a hierarchical naming structure:

```
/apis/registry/v2/groups/{groupId}/artifacts/{artifactId}
```

### Group ID Format
Groups follow the dot-notation hierarchy:
```
{organization}.{domain}.{application}
```

**Examples:**
- `paradigm.mybldr.bidtools` - Bidtools application schemas
- `paradigm.txservices.quotes` - Transaction Services quotes schemas
- `paradigm.txservices.customers` - Transaction Services customer schemas
- `bfs.online` - BFS online schemas

### Artifact ID Format
Artifacts represent specific data entities or schemas:
- `bfs.QuoteDetails` - Quote details schema
- `bfs.Customer` - Customer schema
- `bfs.Location` - Location schema

## Finding Data Source Specifications

### Method 1: Using the Test Script

Run the included test script to discover all available schemas:

```bash
node test-apicurio.js
```

This will:
1. ✅ Discover all groups in the registry
2. ✅ List all JSON schemas from each group
3. ✅ Display a sample schema with details

**Expected Output:**
```
📦 STEP 1: Discovering all groups in Apicurio Registry

✅ Found X group(s) in Apicurio Registry:
   1. paradigm.mybldr.bidtools
   2. paradigm.txservices.quotes
   3. bfs.online
   ...

📄 STEP 2: Discovering all JSON schemas from all groups

📁 Group: paradigm.mybldr.bidtools
   JSON Schemas:
      ✓ bfs.QuoteDetails.json
      ✓ bfs.Customer.json
      ...

✅ TOTAL JSON SCHEMAS DISCOVERED: XX
```

### Method 2: Using the Application UI

1. **Navigate to Data Sources Tab**
2. **Select a Data Source** (e.g., BFS or Bidtools)
3. **Click "Create Data Capture Specification"**
4. **Look for "Load Schema from Apicurio Registry" dropdown**
   - The application will automatically discover all available JSON schemas
   - Schemas are displayed in the format: `{groupId} / {artifactId}`

Example dropdown options:
- `paradigm.mybldr.bidtools / bfs.QuoteDetails.json`
- `paradigm.txservices.quotes / bfs.Quotes.json`
- `bfs.online / bfs.Customer.json`

### Method 3: Using curl/API Directly

**List all groups:**
```bash
curl -X GET http://apicurio.52.158.160.62.nip.io/apis/registry/v2/groups
```

**List artifacts in a specific group:**
```bash
curl -X GET http://apicurio.52.158.160.62.nip.io/apis/registry/v2/groups/paradigm.mybldr.bidtools/artifacts
```

**Get specific schema content:**
```bash
curl -X GET http://apicurio.52.158.160.62.nip.io/apis/registry/v2/groups/paradigm.mybldr.bidtools/artifacts/bfs.QuoteDetails.json
```

## Data Source to Group Mapping

The application uses the following default mappings:

| Data Source Name | Apicurio Group(s) |
|-----------------|-------------------|
| BFS | `bfs.online` |
| Bidtools | `paradigm.mybldr.bidtools` |
| TxServices | `paradigm.txservices.quotes`, `paradigm.txservices.customers` |

**Note:** If no specific mapping exists, the application will discover and display all JSON schemas from all groups.

## Schema Types

Apicurio Registry supports multiple schema types:
- **JSON** (JSON Schema draft-2020-12) - ✅ Fully supported in the application
- **AVRO** - Used for CDC (Change Data Capture) schemas
- **PROTOBUF** - Used for gRPC services
- Other types...

The BFS application specifically uses **JSON schemas** for Data Capture Specifications.

## Application Integration

### How it Works

1. When creating a Data Capture Specification, the application:
   - Queries Apicurio Registry for all groups
   - For each group, fetches all artifacts
   - Filters to show only JSON type schemas
   - Displays them in the dropdown

2. When a schema is selected:
   - The application fetches the schema content from Apicurio
   - The JSON schema is automatically loaded into the "Container Schema JSON" field
   - The user can then customize it or use it as-is

3. The schema is saved as part of the Data Capture Specification in Cosmos DB

### Code Implementation

See `/lib/api.ts` for the Apicurio integration functions:
- `getApicurioGroups()` - Get all groups
- `getApicurioArtifacts(groupId)` - Get artifacts from a group
- `getApicurioArtifactContent(groupId, artifactId)` - Get schema content
- `getAllJsonSchemasFromApicurio()` - Get all JSON schemas from all groups
- `getJsonSchemasForDataSource(dataSourceName)` - Get schemas for specific data source

## Troubleshooting

### No schemas appearing in the dropdown

1. Check Apicurio Registry is accessible:
   ```bash
   curl http://apicurio.52.158.160.62.nip.io/health/live
   ```

2. Run the test script to verify connectivity:
   ```bash
   node test-apicurio.js
   ```

3. Check browser console for errors (F12 → Console tab)

### CORS errors

If you see CORS errors in the browser console, the Apicurio Registry may need CORS configuration. Contact the infrastructure team.

### Schema not loading

- Verify the schema exists in Apicurio UI
- Check the artifact type is "JSON" (not AVRO or other types)
- Ensure the group ID and artifact ID are correct

## Example Workflow

1. **Discover schemas** using test script:
   ```bash
   node test-apicurio.js
   ```

2. **Open application** and navigate to Data Sources tab

3. **Select data source** (e.g., Bidtools)

4. **Click "Create Data Capture Specification"**

5. **Select schema** from "Load Schema from Apicurio Registry" dropdown:
   - Example: `paradigm.mybldr.bidtools / bfs.QuoteDetails.json`

6. **Verify schema loaded** in the Container Schema JSON field

7. **Customize if needed** (add/remove fields, adjust required fields, etc.)

8. **Fill in remaining fields**:
   - Specification Name
   - Version
   - Source Primary Key Field
   - Partition Key Field/Value
   - Allowed Filters

9. **Save the specification**

## Additional Resources

- Apicurio Registry Documentation: https://www.apicur.io/registry/
- JSON Schema Documentation: https://json-schema.org/
- BFS API Documentation: (internal)

---

**Last Updated:** November 2025  
**Maintained by:** BFS Development Team
