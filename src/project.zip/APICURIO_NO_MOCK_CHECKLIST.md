# Apicurio Registry - NO MOCK DATA - Checklist ✅

## Pre-deployment Verification

### Code Review ✅
- [x] Removed `getMockApicurioArtifacts()` function
- [x] Removed `getMockArtifactSchema()` function
- [x] Removed all references to mock data
- [x] Updated error handling to throw real errors
- [x] Updated comments to reflect changes
- [x] File size reduced from ~1,900 to ~795 lines

### Known Groups Configuration ✅
- [x] Only two groups hardcoded: `paradigm.bidtools2` and `bfs.online`
- [x] Groups used as fallback only when API returns 403
- [x] API response filtered to only these two groups

### Cache Strategy ✅
- [x] Cache duration: 30 minutes
- [x] Storage: localStorage + in-memory
- [x] Fallback to expired cache on API errors
- [x] Clear cache function available: `clearArtifactsCache()`

## Testing Checklist

### 1. Basic Template Loading
```
Data Source Onboarding → Create Data Capture Spec → Create from Template
```

- [ ] Dialog opens
- [ ] "Select Template" dropdown shows loading state
- [ ] Templates load from Apicurio Registry
- [ ] Only templates from two groups appear:
  - [ ] paradigm.bidtools2 templates visible
  - [ ] bfs.online templates visible
  - [ ] NO mock templates (verify by checking artifactId format)

### 2. Template Selection - paradigm.bidtools2
- [ ] Select a CDC template (e.g., CDC_SQLServer_LineTypes)
- [ ] Schema loads successfully
- [ ] Form fields populated:
  - [ ] Transaction Type Name
  - [ ] Transaction Type Description
  - [ ] Data Source ID
- [ ] Model Schema shows CDC fields (not mock data)

### 3. Template Selection - bfs.online
- [ ] Select an Informix template (e.g., TxServices_Informix_loc)
- [ ] Schema loads successfully
- [ ] Model Schema shows correct structure (TxnType + Txn)
- [ ] sourcePrimaryKeyField has correct const value

### 4. Cache Testing
- [ ] Open template dialog (loads from API - check console for "Fetching")
- [ ] Close dialog
- [ ] Reopen dialog (should use cache - check console for "Using cached")
- [ ] Verify age shows in seconds
- [ ] Wait 30+ minutes
- [ ] Reopen dialog (should reload from API)

### 5. Error Handling - With Cache
- [ ] Load templates successfully (creates cache)
- [ ] Disconnect from internet or block Apicurio URL
- [ ] Reopen dialog
- [ ] Should show cached templates
- [ ] Console shows: "Using expired cache data due to API error"

### 6. Error Handling - No Cache
- [ ] Clear localStorage: `localStorage.clear()`
- [ ] Clear in-memory cache: Run in console: 
  ```javascript
  import('./lib/apicurio').then(m => m.clearArtifactsCache())
  ```
- [ ] Disconnect from internet
- [ ] Open template dialog
- [ ] Should show empty dropdown or error message
- [ ] Console shows error: "No artifacts available and no cache"

### 7. Template Loading Errors
- [ ] Select a template
- [ ] If loading fails:
  - [ ] Toast error appears
  - [ ] Error message is clear
  - [ ] No silent fallback to mock data

### 8. Verify No Mock Data
Check console messages - should NOT see:
- [ ] ❌ "using local Apicurio templates"
- [ ] ❌ "using local template"
- [ ] ❌ "using mock data"
- [ ] ❌ "18 available"

Should see instead:
- [ ] ✅ "Fetching all groups from:"
- [ ] ✅ "Found 2 groups: paradigm.bidtools2, bfs.online"
- [ ] ✅ "Loaded X artifacts from paradigm.bidtools2"
- [ ] ✅ "Loaded X artifacts from bfs.online"
- [ ] ✅ "Total artifacts loaded: X from 2 groups"

### 9. Inspect Template Artifacts
Open browser DevTools → Network tab:
- [ ] Filter: `apicurio`
- [ ] Open template dialog
- [ ] Verify API calls to:
  - [ ] `/groups`
  - [ ] `/groups/paradigm.bidtools2/artifacts`
  - [ ] `/groups/bfs.online/artifacts`
- [ ] Select template
- [ ] Verify API call to:
  - [ ] `/groups/{groupId}/artifacts/{artifactId}/versions/{version}/content`

### 10. Verify Template Count
- [ ] Count templates in dropdown
- [ ] Compare with Apicurio Registry API directly:
  ```bash
  # paradigm.bidtools2
  curl https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/paradigm.bidtools2/artifacts
  
  # bfs.online
  curl https://apicurio-poc.proudpond-b12a57e6.eastus.azurecontainerapps.io/apis/registry/v3/groups/bfs.online/artifacts
  ```
- [ ] Counts should match exactly

## Console Verification

### Expected Success Pattern
```
📦 Fetching all groups from: https://apicurio-poc...
📦 Found 2 groups: paradigm.bidtools2, bfs.online
📦 Fetching artifacts from group paradigm.bidtools2: ...
📦 ✅ Loaded 7 artifacts from paradigm.bidtools2
📦 Fetching artifacts from group bfs.online: ...
📦 ✅ Loaded 11 artifacts from bfs.online
📦 ✅ Total artifacts loaded: 18 from 2 groups
```

### Expected Cache Pattern
```
📦 Using cached Apicurio artifacts (age: 45 seconds)
```

### Expected Error Pattern (no cache)
```
❌ Apicurio Registry error: Failed to fetch
❌ No artifacts available and no cache. Apicurio Registry is unavailable.
```

### Expected Error Pattern (with cache)
```
❌ Apicurio Registry error: Failed to fetch
📦 Using expired cache data due to API error
```

## Regression Testing

### Data Source Creation Flow
- [ ] Create from Template works
- [ ] Create from Blank works
- [ ] Edit existing Data Capture Spec works
- [ ] Delete Data Capture Spec works

### Data Plane Integration
- [ ] Data Capture Specs appear in Data Plane as Transaction Types
- [ ] Transaction Types work correctly
- [ ] No mock data artifacts in Data Plane

## Performance Checks

- [ ] Initial template load: < 2 seconds
- [ ] Cached template load: < 100ms
- [ ] Schema load on template select: < 1 second
- [ ] No memory leaks (check after multiple open/close cycles)

## Documentation Review

Files created:
- [x] `/APICURIO_NO_MOCK_DATA_RU.md` - Detailed explanation (Russian)
- [x] `/APICURIO_REAL_DATA_ONLY.md` - Quick reference (English)
- [x] `/APICURIO_MOCK_REMOVED_SUMMARY.txt` - Summary (Russian)
- [x] `/APICURIO_NO_MOCK_CHECKLIST.md` - This checklist

## Sign-off

### Developer
- [ ] All code changes reviewed
- [ ] No mock data references found
- [ ] Error handling tested
- [ ] Cache mechanism tested
- [ ] Console messages verified

### QA
- [ ] All test scenarios passed
- [ ] Error scenarios handled gracefully
- [ ] Performance acceptable
- [ ] No regression issues

### Product Owner
- [ ] Only real templates visible
- [ ] User experience acceptable
- [ ] Error messages clear
- [ ] Ready for production

---

## Quick Test Script

Run in browser console after opening the app:

```javascript
// 1. Check if mock functions are removed
console.log('Testing for mock functions...');
import('./lib/apicurio').then(module => {
  console.log('getMockApicurioArtifacts:', typeof module.getMockApicurioArtifacts); // should be 'undefined'
  console.log('getMockArtifactSchema:', typeof module.getMockArtifactSchema); // should be 'undefined'
  console.log('✅ Mock functions removed!');
});

// 2. Check cache
console.log('Cache data:', localStorage.getItem('apicurio_artifacts_cache'));
console.log('Cache timestamp:', localStorage.getItem('apicurio_artifacts_timestamp'));

// 3. Clear cache
import('./lib/apicurio').then(m => {
  m.clearArtifactsCache();
  console.log('✅ Cache cleared!');
});

// 4. Load artifacts
import('./lib/apicurio').then(async m => {
  console.log('Loading artifacts...');
  const result = await m.searchApicurioArtifacts();
  console.log(`Loaded ${result.count} artifacts`);
  console.log('Groups:', [...new Set(result.artifacts.map(a => a.groupId))]);
  console.log('✅ Done!');
});
```

---

**Date**: November 28, 2024  
**Status**: Ready for Testing ✅
