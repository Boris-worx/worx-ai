# Quote Extended Types - Verification Checklist ✅

## 🎯 Цель
Проверить что все три новых Quote типа работают корректно в приложении.

---

## ✅ Pre-Implementation Checklist

### Code Changes
- [x] Добавлены типы в `TRANSACTION_TYPES` в `/lib/api.ts`
  - [x] QuoteDetails
  - [x] QuotePack
  - [x] QuotePackOrder
- [x] Добавлены JSON шаблоны в `/components/TransactionCreateDialog.tsx`
  - [x] QuoteDetails template
  - [x] QuotePack template
  - [x] QuotePackOrder template

### Documentation
- [x] Создана полная документация: `QUOTE_TYPES_ENABLED.md`
- [x] Создан быстрый старт: `QUOTE_TYPES_QUICK_RU.md`
- [x] Создана сводка: `QUOTE_EXTENDED_TYPES_SUMMARY.md`
- [x] Обновлен индекс: `QUOTE_DOCUMENTATION_INDEX.md`
- [x] Создан чеклист: `QUOTE_TYPES_VERIFICATION.md` (этот файл)

---

## 🧪 UI Testing Checklist

### QuoteDetails

#### Видимость в UI
- [ ] Открыт Data Plane tab
- [ ] Dropdown "Select Transaction Type" содержит "QuoteDetails"
- [ ] QuoteDetails находится после "Quote" и перед "QuotePack"

#### Create
- [ ] Выбран тип "QuoteDetails"
- [ ] Нажата кнопка "+ Create New Transaction"
- [ ] Dialog открылся
- [ ] JSON template загружен
- [ ] Template содержит `quoteDetailId`
- [ ] Изменен `quoteDetailId` на уникальный
- [ ] Нажата кнопка "Create Transaction"
- [ ] Success toast появился
- [ ] Dialog закрылся
- [ ] Таблица автоматически обновилась
- [ ] Новая запись видна в таблице

#### Read
- [ ] Запись видна в таблице
- [ ] Нажата кнопка "View"
- [ ] Detail dialog открылся
- [ ] JSON корректно отформатирован
- [ ] Все поля присутствуют
- [ ] `CreateTime` присутствует
- [ ] `UpdateTime` присутствует
- [ ] `_etag` присутствует

#### Update
- [ ] Нажата кнопка "Edit"
- [ ] Edit dialog открылся
- [ ] JSON pre-filled с текущими данными
- [ ] Изменено поле (например `quantity`)
- [ ] Нажата кнопка "Save Changes"
- [ ] Success toast появился
- [ ] Dialog закрылся
- [ ] Таблица обновилась
- [ ] Изменения видны

#### Delete
- [ ] Нажата кнопка "Delete"
- [ ] Confirmation dialog появился
- [ ] Нажата кнопка "Delete"
- [ ] Success toast появился
- [ ] Dialog закрылся
- [ ] Таблица обновилась
- [ ] Запись исчезла

---

### QuotePack

#### Видимость в UI
- [ ] Dropdown содержит "QuotePack"
- [ ] QuotePack находится после "QuoteDetails" и перед "QuotePackOrder"

#### Create
- [ ] Выбран тип "QuotePack"
- [ ] Нажата кнопка "+ Create New Transaction"
- [ ] Dialog открылся
- [ ] JSON template загружен
- [ ] Template содержит `quotePackId`
- [ ] Изменен `quotePackId` на уникальный
- [ ] Нажата кнопка "Create Transaction"
- [ ] Success toast появился
- [ ] Новая запись видна в таблице

#### Read
- [ ] Запись видна в таблице
- [ ] Нажата кнопка "View"
- [ ] Detail dialog показывает все поля
- [ ] `quoteDetails` массив корректен

#### Update
- [ ] Edit работает
- [ ] Можно изменить `packName`
- [ ] Изменения сохраняются

#### Delete
- [ ] Delete работает
- [ ] Запись удаляется

---

### QuotePackOrder

#### Видимость в UI
- [ ] Dropdown содержит "QuotePackOrder"
- [ ] QuotePackOrder находится после "QuotePack"

#### Create
- [ ] Выбран тип "QuotePackOrder"
- [ ] Нажата кнопка "+ Create New Transaction"
- [ ] Dialog открылся
- [ ] JSON template загружен
- [ ] Template содержит `quotePackOrderId`
- [ ] Template содержит `orderDate` в ISO формате
- [ ] Template содержит `status: "pending"`
- [ ] Изменен `quotePackOrderId` на уникальный
- [ ] Нажата кнопка "Create Transaction"
- [ ] Success toast появился
- [ ] Новая запись видна в таблице

#### Read
- [ ] Запись видна в таблице
- [ ] View dialog показывает все поля
- [ ] `orderDate` корректно отображается

#### Update
- [ ] Edit работает
- [ ] Можно изменить `status`
- [ ] Изменения сохраняются

#### Delete
- [ ] Delete работает
- [ ] Запись удаляется

---

## 🔧 API Testing Checklist

### QuoteDetails API

#### Create (POST)
```bash
curl -X POST 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/txns' \
-H 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
-H 'Content-Type: application/json' \
-d '{
  "TxnType": "QuoteDetails",
  "Txn": {
    "quoteDetailId": "QD-VERIFY-001",
    "itemDescription": "Verification Test",
    "quantity": 1,
    "unitPrice": 100
  }
}'
```

- [ ] Выполнена команда
- [ ] Status: 201 Created
- [ ] Response содержит `data.Txn`
- [ ] Response содержит `_etag`
- [ ] Response содержит `CreateTime`

#### Get All (GET)
```bash
curl 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/txns?TxnType=QuoteDetails' \
-H 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
```

- [ ] Выполнена команда
- [ ] Status: 200 OK
- [ ] Response содержит `data.TxnType: "QuoteDetails"`
- [ ] Response содержит `data.Txns` (массив)
- [ ] Созданная запись присутствует

#### Get One (GET by ID)
```bash
curl 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/txns/QuoteDetails:QD-VERIFY-001' \
-H 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
```

- [ ] Выполнена команда
- [ ] Status: 200 OK
- [ ] Response содержит нужную запись
- [ ] `quoteDetailId` совпадает

#### Update (PUT)
```bash
# Сначала получите _etag из GET запроса выше
curl -X PUT 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/txns/QuoteDetails:QD-VERIFY-001' \
-H 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
-H 'Content-Type: application/json' \
-H 'If-Match: "YOUR_ETAG_HERE"' \
-d '{
  "TxnType": "QuoteDetails",
  "Txn": {
    "quoteDetailId": "QD-VERIFY-001",
    "itemDescription": "UPDATED",
    "quantity": 5,
    "unitPrice": 150
  }
}'
```

- [ ] Выполнена команда
- [ ] Status: 200 OK
- [ ] Response содержит обновленные данные
- [ ] `itemDescription` = "UPDATED"
- [ ] `quantity` = 5

#### Delete (DELETE)
```bash
# Используйте последний _etag
curl -X DELETE 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/txns/QuoteDetails:QD-VERIFY-001' \
-H 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
-H 'If-Match: "YOUR_ETAG_HERE"'
```

- [ ] Выполнена команда
- [ ] Status: 200 OK или 204 No Content
- [ ] GET запрос больше не находит запись (404)

---

### QuotePack API

#### Create
```bash
curl -X POST 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/txns' \
-H 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
-H 'Content-Type: application/json' \
-d '{
  "TxnType": "QuotePack",
  "Txn": {
    "quotePackId": "QP-VERIFY-001",
    "packName": "Verification Pack",
    "isActive": true
  }
}'
```

- [ ] Status: 201 Created
- [ ] Response корректен

#### Get All
```bash
curl 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/txns?TxnType=QuotePack' \
-H 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
```

- [ ] Status: 200 OK
- [ ] Запись присутствует

#### Get One
```bash
curl 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/txns/QuotePack:QP-VERIFY-001' \
-H 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
```

- [ ] Status: 200 OK
- [ ] Данные корректны

---

### QuotePackOrder API

#### Create
```bash
curl -X POST 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/txns' \
-H 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
-H 'Content-Type: application/json' \
-d '{
  "TxnType": "QuotePackOrder",
  "Txn": {
    "quotePackOrderId": "QPO-VERIFY-001",
    "status": "pending"
  }
}'
```

- [ ] Status: 201 Created
- [ ] Response корректен

#### Get All
```bash
curl 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/txns?TxnType=QuotePackOrder' \
-H 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
```

- [ ] Status: 200 OK
- [ ] Запись присутствует

---

## 📱 Mobile Testing Checklist

### Responsive Design
- [ ] Открыто приложение на мобильном (или DevTools mobile view)
- [ ] Data Plane tab доступен
- [ ] Dropdown работает
- [ ] Можно выбрать QuoteDetails
- [ ] Create dialog адаптивный
- [ ] JSON editor читаем
- [ ] Кнопки доступны
- [ ] View/Edit/Delete работают

---

## 🔐 Permissions Testing

### SuperUser Role
- [ ] Может создавать QuoteDetails
- [ ] Может редактировать QuoteDetails
- [ ] Может удалять QuoteDetails
- [ ] То же для QuotePack
- [ ] То же для QuotePackOrder

### Admin Role
- [ ] Может создавать все типы
- [ ] Может редактировать все типы
- [ ] Может удалять все типы

### Developer Role
- [ ] Может создавать все типы
- [ ] Может редактировать все типы
- [ ] Может удалять все типы

### Viewer Role
- [ ] НЕ видит кнопку "Create"
- [ ] Видит кнопку "View"
- [ ] НЕ видит кнопку "Edit"
- [ ] НЕ видит кнопку "Delete"

---

## 📊 Integration Testing

### Complete Workflow Test

#### Step 1: Create Quote
```bash
curl -X POST 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/txns' \
-H 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
-H 'Content-Type: application/json' \
-d '{
  "TxnType": "Quote",
  "Txn": {
    "quoteId": "QUOTE-WORKFLOW-001",
    "accountNumber": "579237",
    "erpUserId": "ONLINE"
  }
}'
```
- [ ] Quote создан

#### Step 2: Create QuoteDetails
```bash
curl -X POST 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/txns' \
-H 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
-H 'Content-Type: application/json' \
-d '{
  "TxnType": "QuoteDetails",
  "Txn": {
    "quoteDetailId": "QD-WORKFLOW-001",
    "quoteId": "QUOTE-WORKFLOW-001",
    "lineNumber": 1,
    "itemDescription": "Item A",
    "quantity": 5,
    "unitPrice": 100,
    "totalPrice": 500
  }
}'
```
- [ ] QuoteDetails создан
- [ ] Связь с Quote установлена

#### Step 3: Create QuotePack
```bash
curl -X POST 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/txns' \
-H 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
-H 'Content-Type: application/json' \
-d '{
  "TxnType": "QuotePack",
  "Txn": {
    "quotePackId": "QP-WORKFLOW-001",
    "quoteId": "QUOTE-WORKFLOW-001",
    "packName": "Complete Package",
    "quoteDetails": ["QD-WORKFLOW-001"],
    "totalAmount": 500,
    "isActive": true
  }
}'
```
- [ ] QuotePack создан
- [ ] Содержит ссылку на QuoteDetails

#### Step 4: Create QuotePackOrder
```bash
curl -X POST 'https://dp-eastus-poc-txservices-apis.azurewebsites.net/1.0/txns' \
-H 'X-BFS-Auth: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' \
-H 'Content-Type: application/json' \
-d '{
  "TxnType": "QuotePackOrder",
  "Txn": {
    "quotePackOrderId": "QPO-WORKFLOW-001",
    "quotePackId": "QP-WORKFLOW-001",
    "orderDate": "2025-10-29T12:00:00.000Z",
    "customerId": "CUST-12345",
    "totalAmount": 500,
    "status": "approved"
  }
}'
```
- [ ] QuotePackOrder создан
- [ ] Ссылается на QuotePack

#### Step 5: Verify Workflow
- [ ] Все 4 записи существуют
- [ ] Связи корректны
- [ ] Можно получить весь workflow через API
- [ ] UI показывает все записи

---

## 📚 Documentation Testing

### Check Documentation Exists
- [ ] QUOTE_TYPES_ENABLED.md существует
- [ ] QUOTE_TYPES_QUICK_RU.md существует
- [ ] QUOTE_EXTENDED_TYPES_SUMMARY.md существует
- [ ] QUOTE_DOCUMENTATION_INDEX.md обновлен

### Check Documentation Content
- [ ] Все примеры curl работают
- [ ] JSON templates корректны
- [ ] API endpoints правильные
- [ ] Screenshots/примеры актуальны

---

## ✅ Final Verification

### Overall Status
- [ ] Все UI тесты пройдены
- [ ] Все API тесты пройдены
- [ ] Mobile тесты пройдены
- [ ] Permissions тесты пройдены
- [ ] Integration тесты пройдены
- [ ] Documentation полная и корректная

### Ready for Production?
- [ ] Код протестирован
- [ ] Документация завершена
- [ ] Примеры работают
- [ ] Нет известных багов
- [ ] Team review пройден

---

## 🐛 Issues Found

### Issues Log
| # | Issue | Severity | Status | Notes |
|---|-------|----------|--------|-------|
| 1 |       |          |        |       |
| 2 |       |          |        |       |

---

## 📝 Testing Notes

### Environment
- **Date**: _______
- **Tester**: _______
- **Browser**: _______
- **Environment**: Production / Staging / Local
- **API Endpoint**: https://dp-eastus-poc-txservices-apis.azurewebsites.net

### Results Summary
- **Total Tests**: ___
- **Passed**: ___
- **Failed**: ___
- **Skipped**: ___

### Sign-off
- [ ] QA Lead: _______
- [ ] Developer: _______
- [ ] Product Owner: _______

---

**Verification Date**: ___________  
**Status**: ⬜ In Progress | ⬜ Completed | ⬜ Failed  
**Next Review**: ___________
